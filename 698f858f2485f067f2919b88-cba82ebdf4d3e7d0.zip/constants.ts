
// ... keep imports ...
import { Fabric, Gender, Measurements, GarmentStyle, FabricColor, PatternDesign, StyleItem, PricingRule, Order, CollarType, SleeveType, PricingPlan, User, UserRole } from './types';

export const TRANSLATIONS = {
  // ... keep existing translations ...
  ar: {
    nextStep: 'الخطوة التالية',
    backToHome: 'العودة للرئيسية',
    switchLang: 'English',
    journeyTitle: 'رحلة التفصيل الذكية',
    journeyDesc: 'ابدأ تصميم قطعتك خطوة بخطوة من الصفر',
    measurementsTitle: 'إدخال المقاسات',
    measurementsDesc: 'أدخل مقاساتك مع معاينة رسومية وتصدير PDF',
    devDashboard: 'لوحة تحكم المطور',
    devDesc: 'إدارة الهوية، السجل، الأسعار، والمزيد',
    genderSelect: 'اختر فئة التصميم',
    male: 'رجالي',
    female: 'نسائي',
    children: 'أطفال',
    maleDesc: 'بترونات كلاسيكية ورسمية',
    femaleDesc: 'أناقة وتفاصيل فنية ناعمة',
    childrenDesc: 'تصاميم مريحة وعملية',
    fabricLib: 'مكتبة الأقمشة الفاخرة',
    fabricDesc: 'اختر النسيج الذي يتناسب مع رؤيتك وتصميمك',
    thickness: 'مستوى السماكة',
    stretch: 'المرونة',
    breathability: 'المسامية',
    durability: 'المتانة',
    colorCategory: 'التصنيف',
    patternTexture: 'النقشة والخامة',
    styleSelect: 'اختر الموديل',
    exportTitle: 'تصدير الملفات التقنية',
    exportDesc: 'تم تجهيز بيانات التصميم والمقاسات. اختر التنسيق المناسب للتحميل.',
    pdfExport: 'ملف PDF فني',
    excelExport: 'ملف Excel / CSV',
    svgExport: 'بترون Vector SVG',
    finishSave: 'إنهاء وحفظ في السجل',
    downloadNow: 'تحميل الآن',
    standardSizes: 'مقاسات جاهزة',
    advancedMethod: 'المنهج الفني',
    archives: 'الأرشيف',
    saveMeasurements: 'حفظ القياسات',
    uploadPhoto: 'اضغط لرفع صورة',
    clientPhoto: 'صورة العميل / الموديل',
    blueprint: 'تخطيط هندسي',
    profileName: 'اسم الملف الشخصي...',
    noProfiles: 'لا توجد ملفات مقاسات محفوظة',
    use: 'استخدام',
    logout: 'خروج',
    // Payment & Customer Info Translations
    paymentTitle: 'معلومات العميل والدفع',
    paymentDesc: 'الرجاء إدخال بيانات التوصيل واختيار وسيلة الدفع المناسبة.',
    customerInfo: 'بيانات العميل',
    fullName: 'الاسم الكامل',
    phoneNumber: 'رقم الهاتف',
    address: 'العنوان بالتفصيل',
    paymentMethod: 'وسيلة الدفع',
    creditCard: 'بطاقة ائتمان / مدى',
    cashOnDelivery: 'الدفع عند الاستلام',
    orderSummary: 'ملخص الطلب',
    totalPrice: 'السعر الإجمالي',
    confirmOrder: 'تأكيد الطلب وإرساله',
    proceedToPayment: 'متابعة للدفع وإنهاء الطلب',
    currency: 'ر.س'
  },
  en: {
    nextStep: 'Next Step',
    backToHome: 'Back to Home',
    switchLang: 'العربية',
    journeyTitle: 'Smart Tailoring Journey',
    journeyDesc: 'Start designing your piece step by step from scratch',
    measurementsTitle: 'Measurements Input',
    measurementsDesc: 'Input measurements with graphical preview and PDF export',
    devDashboard: 'Developer Dashboard',
    devDesc: 'Manage branding, logs, pricing, and more',
    genderSelect: 'Select Design Category',
    male: 'Men',
    female: 'Women',
    children: 'Children',
    maleDesc: 'Classic and formal patterns',
    femaleDesc: 'Elegance and soft artistic details',
    childrenDesc: 'Comfortable and practical designs',
    fabricLib: 'Luxury Fabric Library',
    fabricDesc: 'Choose the fabric that matches your vision and design',
    thickness: 'Thickness Level',
    stretch: 'Stretch',
    breathability: 'Breathability',
    durability: 'Durability',
    colorCategory: 'Category',
    patternTexture: 'Pattern & Texture',
    styleSelect: 'Select Style',
    exportTitle: 'Export Technical Files',
    exportDesc: 'Design data and measurements are ready. Choose the format to download.',
    pdfExport: 'Technical PDF',
    excelExport: 'Excel / CSV File',
    svgExport: 'Vector SVG Pattern',
    finishSave: 'Finish & Save to Log',
    downloadNow: 'Download Now',
    standardSizes: 'Standard Sizes',
    advancedMethod: 'Technical Method',
    archives: 'Archives',
    saveMeasurements: 'Save Measurements',
    uploadPhoto: 'Click to upload photo',
    clientPhoto: 'Client / Model Photo',
    blueprint: 'Engineering Blueprint',
    profileName: 'Profile name...',
    noProfiles: 'No saved measurement profiles',
    use: 'Use',
    logout: 'Logout',
    // Payment & Customer Info Translations
    paymentTitle: 'Payment & Customer Info',
    paymentDesc: 'Please enter delivery details and choose a payment method.',
    customerInfo: 'Customer Information',
    fullName: 'Full Name',
    phoneNumber: 'Phone Number',
    address: 'Detailed Address',
    paymentMethod: 'Payment Method',
    creditCard: 'Credit Card / Mada',
    cashOnDelivery: 'Cash on Delivery',
    orderSummary: 'Order Summary',
    totalPrice: 'Total Price',
    confirmOrder: 'Confirm & Place Order',
    proceedToPayment: 'Proceed to Payment',
    currency: 'SAR'
  }
};

export const INITIAL_STYLES: StyleItem[] = [
  { 
    id: GarmentStyle.SHIRT, 
    label: 'قميص رجالي فاخر', 
    icon: '👔', 
    description: 'قميص كلاسيكي بقصة عصرية (Slim Fit) وأقمشة فاخرة، مثالي لاجتماعات العمل والمناسبات الرسمية.', 
    occasion: 'FORMAL', 
    season: 'ALL', 
    gender: Gender.MALE 
  },
  { 
    id: GarmentStyle.SUIT, 
    label: 'بدلة رسمية إيطالية', 
    icon: '🤵', 
    description: 'بدلة قطعتين بتصميم إيطالي وخياطة دقيقة تمنحك مظهراً احترافياً وجذاباً في كل الأوقات.', 
    occasion: 'FORMAL', 
    season: 'WINTER', 
    gender: Gender.MALE 
  },
  { 
    id: GarmentStyle.BISHT, 
    label: 'بشت ملكي أصيل', 
    icon: '🕌', 
    description: 'رمز الفخامة والتراث العربي، منسوج بعناية فائقة للمناسبات الكبرى وحفلات الزفاف.', 
    occasion: 'CEREMONY', 
    season: 'ALL', 
    gender: Gender.MALE 
  },
  { 
    id: GarmentStyle.PRINCESS_CUT_DRESS, 
    label: 'فستان البرنسيس', 
    icon: '👗', 
    description: 'تصميم ملكي بقصة البرنسيس التي تبرز جمال القوام وتنسدل بأناقة لا تضاهى.', 
    occasion: 'EVENING', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.MERMAID_DRESS, 
    label: 'فستان المرميد', 
    icon: '🧜‍♀️', 
    description: 'قصة حورية البحر الجذابة التي تعانق القوام وتتسع من الأسفل لإطلالة أنثوية ساحرة.', 
    occasion: 'EVENING', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.COWL_NECK_DRESS, 
    label: 'فستان بياقة منسدلة', 
    icon: '💃', 
    description: 'تصميم انسيابي ناعم مع ياقة منسدلة (Cowl Neck) تضفي لمسة رومانسية وعصرية.', 
    occasion: 'EVENING', 
    season: 'SUMMER', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.CORSET_TOP, 
    label: 'كورسيه عصري', 
    icon: '👚', 
    description: 'قطعة علوية بتصميم الكورسيه لتحديد الخصر وإبراز الأنوثة بأسلوب فني مبتكر.', 
    occasion: 'EVENING', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.ABAYA, 
    label: 'عباءة كريب عصرية', 
    icon: '👘', 
    description: 'عباءة يومية من قماش الكريب الفاخر، تجمع بين الحشمة والأناقة العصرية المريحة.', 
    occasion: 'DAILY', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.KIDS_SUIT, 
    label: 'طقم أطفال رسمي', 
    icon: '🤴', 
    description: 'طقم رسمي مريح وأنيق للأمراء الصغار، مثالي للأعياد وحفلات الزفاف.', 
    occasion: 'CEREMONY', 
    season: 'ALL', 
    gender: Gender.CHILDREN 
  },
  { 
    id: GarmentStyle.STRUCTURED_BLAZER, 
    label: 'بليزر رسمي محدد', 
    icon: '🧥', 
    description: 'جاكيت بليزر بقصة محددة (Structured) تبرز الأكتاف وتحدد الخصر لإطلالة قوية وأنيقة.', 
    occasion: 'FORMAL', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.WAISTCOAT, 
    label: 'صديري كلاسيك', 
    icon: '🤵', 
    description: 'قطعة مكملة للأناقة الرسمية، يمكن ارتداؤها مع البدلة أو بشكل منفصل لمظهر كلاسيكي.', 
    occasion: 'FORMAL', 
    season: 'ALL', 
    gender: Gender.MALE 
  },
  { 
    id: GarmentStyle.TRENCH_COAT, 
    label: 'معطف ترنش', 
    icon: '🧥', 
    description: 'معطف واقٍ من المطر بتصميم بريطاني كلاسيكي، يجمع بين الدفء والأناقة العملية.', 
    occasion: 'DAILY', 
    season: 'WINTER', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.SKIRT, 
    label: 'تنورة كلاسيكية', 
    icon: '👗', 
    description: 'تنورة بتصميم أساسي متعدد الاستخدامات، تناسب الإطلالات الرسمية واليومية.', 
    occasion: 'DAILY', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.PLEATED_SKIRT, 
    label: 'تنورة بليسيه', 
    icon: '🩰', 
    description: 'تنورة بطيات (كسرات) دقيقة تمنحك حيوية وحرية في الحركة مع لمسة أنثوية.', 
    occasion: 'DAILY', 
    season: 'SUMMER', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.DOUBLE_BREASTED_SUIT, 
    label: 'بدلة مزدوجة الأزرار', 
    icon: '👔', 
    description: 'بدلة كلاسيكية بصفين من الأزرار، تعكس الفخامة والهيبة للرجل العصري.', 
    occasion: 'FORMAL', 
    season: 'WINTER', 
    gender: Gender.MALE 
  },
  { 
    id: GarmentStyle.JUMPSUIT, 
    label: 'جمبسوت عصري', 
    icon: '👖', 
    description: 'قطعة واحدة انسيابية تجمع بين البنطال والجزء العلوي في تصميم عصري وجذاب.', 
    occasion: 'EVENING', 
    season: 'ALL', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.WRAP_DRESS, 
    label: 'فستان لف (Wrap)', 
    icon: '👘', 
    description: 'فستان بتصميم ملتف حول الجسم يناسب جميع الأجسام ويمنح إطلالة مريحة وأنيقة.', 
    occasion: 'DAILY', 
    season: 'SUMMER', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.HOODIE, 
    label: 'هودي كاجوال', 
    icon: '🧢', 
    description: 'سترة قطنية مريحة مع غطاء رأس، مثالية للإطلالات الرياضية واليومية المريحة.', 
    occasion: 'SPORTS', 
    season: 'WINTER', 
    gender: Gender.MALE 
  },
  { 
    id: GarmentStyle.PALAZZO_PANTS, 
    label: 'بنطال بالازو واسع', 
    icon: '👖', 
    description: 'بنطال بأرجل واسعة جداً يمنحك راحة التنورة وأناقة البنطال في آن واحد.', 
    occasion: 'DAILY', 
    season: 'SUMMER', 
    gender: Gender.FEMALE 
  },
  { 
    id: GarmentStyle.KIMONO_JACKET, 
    label: 'جاكيت كيمونو', 
    icon: '👘', 
    description: 'جاكيت بقصة يابانية واسعة ومريحة، يضيف لمسة بوهيمية فنية لإطلالتك.', 
    occasion: 'DAILY', 
    season: 'SUMMER', 
    gender: Gender.FEMALE 
  }
];

export const INITIAL_FABRICS: Fabric[] = [
  {
    id: 'cotton-1',
    name: 'قطن مصري 100%',
    description: 'نعومة فائقة ومسامية مثالية للصيف.',
    color: '#FFFFFF',
    thickness: 'medium',
    material: 'قطن',
    image: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'منخفضة', breathability: 'عالية جداً', durability: 'ممتازة' },
    physics: { mass: 1.0, stiffness: 0.8, damping: 0.3 }
  },
  {
    id: 'silk-1',
    name: 'حرير طبيعي ملكي',
    description: 'انسيابية مطلقة وملمس بارد للمناسبات.',
    color: '#FFF0F5',
    thickness: 'thin',
    material: 'حرير',
    image: 'https://images.unsplash.com/photo-1606132226758-005164f9979c?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'لا يوجد', breathability: 'متوسطة', durability: 'حساسة' },
    physics: { mass: 0.6, stiffness: 0.4, damping: 0.1 }
  },
  {
    id: 'wool-1',
    name: 'صوف ميرينو شتوي',
    description: 'دفء مثالي ووزن فخم للبدل والسترات.',
    color: '#2a2a2a',
    thickness: 'thick',
    material: 'صوف',
    image: 'https://images.unsplash.com/photo-1598418037385-059a46452f36?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'متوسطة', breathability: 'عالية', durability: 'جيدة جداً' },
    physics: { mass: 2.0, stiffness: 0.7, damping: 0.6 }
  },
  {
    id: 'denim-1',
    name: 'جينز ياباني فاخر',
    description: 'متانة عالية ومظهر كاجوال عصري.',
    color: '#1a2a4a',
    thickness: 'thick',
    material: 'جينز',
    image: 'https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'قليلة', breathability: 'منخفضة', durability: 'قصوى' },
    physics: { mass: 2.2, stiffness: 0.9, damping: 0.5 }
  }
];

export const INITIAL_COLORS: FabricColor[] = [
  { id: 'c1', name: 'أسود فاحم', hex: '#000000', category: 'BASIC' },
  { id: 'c2', name: 'أبيض ناصع', hex: '#FFFFFF', category: 'BASIC' },
  { id: 'c3', name: 'كحلي دبلوماسي', hex: '#001a33', category: 'BASIC' },
  { id: 'c4', name: 'بيج رملي', hex: '#d2b48c', category: 'NEUTRAL' },
  { id: 'c5', name: 'ذهبي ملكي', hex: '#C5A021', category: 'METALLIC' }
];

export const STANDARD_SIZES: Record<string, Measurements> = {
  'S': { height: 165, chest: 88, waist: 72, hips: 96, shoulderWidth: 40, armLength: 58, neckCircumference: 36, waistToFloor: 100 },
  'M': { height: 175, chest: 96, waist: 80, hips: 104, shoulderWidth: 44, armLength: 61, neckCircumference: 38, waistToFloor: 105 },
  'L': { height: 182, chest: 104, waist: 88, hips: 112, shoulderWidth: 48, armLength: 64, neckCircumference: 40, waistToFloor: 110 },
  'XL': { height: 188, chest: 112, waist: 96, hips: 120, shoulderWidth: 52, armLength: 66, neckCircumference: 42, waistToFloor: 115 }
};

export const CHILDREN_SIZES: Record<string, Measurements> = {
  '1Y': { height: 80, chest: 50, waist: 50, hips: 52, shoulderWidth: 22, armLength: 28, neckCircumference: 24, waistToFloor: 45 },
  '2Y': { height: 92, chest: 52, waist: 51, hips: 54, shoulderWidth: 23, armLength: 32, neckCircumference: 25, waistToFloor: 53 },
  '3Y': { height: 98, chest: 54, waist: 52, hips: 56, shoulderWidth: 24, armLength: 35, neckCircumference: 26, waistToFloor: 57 },
  '4Y': { height: 104, chest: 56, waist: 53, hips: 58, shoulderWidth: 25, armLength: 37, neckCircumference: 27, waistToFloor: 62 },
  '5Y': { height: 110, chest: 58, waist: 54, hips: 60, shoulderWidth: 26, armLength: 40, neckCircumference: 28, waistToFloor: 66 },
  '6Y': { height: 116, chest: 60, waist: 55, hips: 62, shoulderWidth: 27, armLength: 42, neckCircumference: 28, waistToFloor: 70 },
  '7Y': { height: 122, chest: 62, waist: 57, hips: 65, shoulderWidth: 28, armLength: 45, neckCircumference: 29, waistToFloor: 75 },
  '8Y': { height: 128, chest: 64, waist: 59, hips: 68, shoulderWidth: 29, armLength: 47, neckCircumference: 30, waistToFloor: 79 },
  '9Y': { height: 134, chest: 67, waist: 61, hips: 71, shoulderWidth: 31, armLength: 50, neckCircumference: 31, waistToFloor: 84 },
  '10Y': { height: 140, chest: 70, waist: 63, hips: 74, shoulderWidth: 32, armLength: 53, neckCircumference: 32, waistToFloor: 88 },
  '11Y': { height: 146, chest: 74, waist: 65, hips: 78, shoulderWidth: 33, armLength: 55, neckCircumference: 33, waistToFloor: 92 },
  '12Y': { height: 152, chest: 78, waist: 67, hips: 82, shoulderWidth: 35, armLength: 57, neckCircumference: 34, waistToFloor: 96 }
};

export const PATTERNS: PatternDesign[] = [
  { id: 'p1', name: 'سادة (كلاسيك)', type: 'PLAIN', preview: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=' },
  { id: 'p2', name: 'مقلم (إيطالي)', type: 'STRIPED', preview: 'https://www.transparenttextures.com/patterns/pinstriped-suit.png' },
  { id: 'p3', name: 'تطريز ذهبي', type: 'FLORAL', preview: 'https://www.transparenttextures.com/patterns/gray-floral.png' }
];

export const INITIAL_PRICING: PricingRule[] = [
  { styleId: GarmentStyle.SHIRT, basePrice: 280, fabricMultipliers: { 'cotton-1': 1.0, 'silk-1': 1.6 } },
  { styleId: GarmentStyle.SUIT, basePrice: 1800, fabricMultipliers: { 'wool-1': 1.2, 'silk-1': 1.8 } },
  { styleId: GarmentStyle.BISHT, basePrice: 2500, fabricMultipliers: { 'silk-1': 1.5 } }
];

export const DEFAULT_PLANS: PricingPlan[] = [
  { id: 'basic', name: 'النسخة الفضية', price: 99, features: ['بترون 19 حقل', 'تصدير PDF محدود', 'إدارة 10 عملاء'] },
  { id: 'pro', name: 'النسخة الذهبية', price: 299, features: ['بترونات غير محدودة', 'تصدير PDF احترافي', 'إدارة عملاء شاملة'] },
  { id: 'enterprise', name: 'النسخة الماسية', price: 799, features: ['نطاق مخصص', 'دعم فني 24/7', 'تقارير ذكاء أعمال'] }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-001',
    customerName: 'سارة الأحمد',
    phone: '0501234567',
    address: 'الرياض، حي النرجس، شارع الأمير محمد بن سلمان',
    paymentMethod: 'CARD',
    status: 'COMPLETED',
    createdAt: Date.now() - (1000 * 60 * 60 * 24 * 7), // 7 days ago
    details: {
      gender: Gender.FEMALE,
      style: GarmentStyle.ABAYA,
      measurements: {
        height: 160, chest: 90, waist: 70, hips: 100, shoulderWidth: 42,
        armLength: 58, neckCircumference: 36, waistToFloor: 100
      },
      fabric: INITIAL_FABRICS[0], // Cotton
      color: INITIAL_COLORS[0], // Black
      pattern: PATTERNS[0],
      sleeveType: SleeveType.BASIC,
      collarType: CollarType.NONE,
      totalPrice: 350
    }
  },
  {
    id: 'ord-002',
    customerName: 'خالد الفيصل',
    phone: '0559876543',
    address: 'جدة، حي الحمراء، شارع الأندلس',
    paymentMethod: 'CASH',
    status: 'PROCESSING',
    createdAt: Date.now() - (1000 * 60 * 60 * 24 * 3), // 3 days ago
    details: {
      gender: Gender.MALE,
      style: GarmentStyle.SHIRT,
      measurements: {
        height: 178, chest: 100, waist: 85, hips: 105, shoulderWidth: 48,
        armLength: 62, neckCircumference: 40, waistToFloor: 105
      },
      fabric: INITIAL_FABRICS[1], // Silk
      color: INITIAL_COLORS[2], // Navy
      pattern: PATTERNS[1],
      sleeveType: SleeveType.BASIC,
      collarType: CollarType.MANDARIN,
      totalPrice: 420
    }
  },
  {
    id: 'ord-003',
    customerName: 'ليلى العبدالله',
    phone: '0531122334',
    address: 'الدمام، حي الزهور، طريق الملك فهد',
    paymentMethod: 'CARD',
    status: 'PENDING',
    createdAt: Date.now() - (1000 * 60 * 60 * 24 * 1), // 1 day ago
    details: {
      gender: Gender.FEMALE,
      style: GarmentStyle.PRINCESS_CUT_DRESS,
      measurements: {
        height: 165, chest: 92, waist: 68, hips: 98, shoulderWidth: 38,
        armLength: 55, neckCircumference: 34, waistToFloor: 110
      },
      fabric: INITIAL_FABRICS[1], // Silk
      color: INITIAL_COLORS[4], // Gold
      pattern: PATTERNS[0],
      sleeveType: SleeveType.PUFF,
      collarType: CollarType.SCOOP,
      totalPrice: 850
    }
  }
];

export const INITIAL_USERS: User[] = [
  { id: "admin-001", username: "loay94an1@gmail.com", password: "12345677", role: UserRole.ADMIN },
  { id: "assistant-001", username: "assistant1", password: "pass123", role: UserRole.ASSISTANT },
  { id: "viewer-001", username: "viewer1", password: "viewpass", role: UserRole.VIEWER }
];
