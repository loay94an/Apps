
import { Measurements, Gender, SleeveType, GarmentStyle, CollarType } from './types';

export class PathBuilder {
  private d: string[] = [];
  
  moveTo(x: number, y: number): this {
    this.d.push(`M ${x} ${y}`);
    return this;
  }
  
  lineTo(x: number, y: number): this {
    this.d.push(`L ${x} ${y}`);
    return this;
  }
  
  cubicCurveTo(x1: number, y1: number, x2: number, y2: number, x: number, y: number): this {
    this.d.push(`C ${x1} ${y1}, ${x2} ${y2}, ${x} ${y}`);
    return this;
  }
  
  closePath(): this {
    this.d.push('Z');
    return this;
  }
  
  build(): string {
    return this.d.join(' ');
  }
}

export class FullPatternService {
  /**
   * توليد بترون الياقات الاحترافي بناءً على محيط الرقبة ونوع الياقة المختار
   * تم تطويره ليشمل جميع الموديلات العالمية
   */
  static generateCollar(type: CollarType, measurements: Measurements, scale: number = 2.0): string {
    const neckHalf = (measurements.neckCircumference / 2) * scale;
    const builder = new PathBuilder();
    
    if (type === CollarType.STAND || type === CollarType.MANDARIN) {
      const h = (type === CollarType.MANDARIN ? 3.5 : 4.5) * scale;
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 0)
             .cubicCurveTo(neckHalf + 5, 0, neckHalf + 5, -h, neckHalf, -h)
             .lineTo(0, -h)
             .closePath();
    } else if (type === CollarType.PETER_PAN) {
      const h = 6 * scale;
      builder.moveTo(0, 0)
             .cubicCurveTo(neckHalf * 0.5, h, neckHalf * 1.2, h, neckHalf, 0)
             .cubicCurveTo(neckHalf * 0.8, -h, neckHalf * 0.3, -h, 0, 0)
             .closePath();
    } else if (type === CollarType.SHAWL || type === CollarType.PEAKED_LAPEL || type === CollarType.NOTCHED) {
      const lapelWidth = type === CollarType.PEAKED_LAPEL ? 14 * scale : 11 * scale;
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 35)
             .lineTo(neckHalf + lapelWidth, -65)
             .lineTo(15, -95)
             .cubicCurveTo(8, -95, 0, -55, 0, 0)
             .closePath();
    } else if (type === CollarType.SAILOR) {
      const flapBack = 22 * scale;
      const flapWidth = 18 * scale;
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 0)
             .lineTo(neckHalf, flapBack)
             .lineTo(neckHalf - flapWidth, flapBack)
             .lineTo(0, 0)
             .closePath();
    } else if (type === CollarType.HOOD) {
      // Basic Hood Pattern
      const hoodH = 35 * scale;
      const hoodW = 25 * scale;
      builder.moveTo(0, 0)
             .cubicCurveTo(neckHalf*0.5, -5, neckHalf, 0, neckHalf, 0)
             .lineTo(neckHalf + hoodW, 0)
             .cubicCurveTo(neckHalf + hoodW + 10, -hoodH/2, neckHalf + hoodW, -hoodH, neckHalf, -hoodH)
             .lineTo(0, -hoodH)
             .closePath();
    } else if (type === CollarType.ROUND || type === CollarType.V_NECK || type === CollarType.SCOOP) {
      const vDepth = type === CollarType.V_NECK ? 22 * scale : type === CollarType.SCOOP ? 18 * scale : 10 * scale;
      builder.moveTo(0, 0)
             .cubicCurveTo(neckHalf * 0.3, vDepth, neckHalf * 0.7, vDepth, neckHalf, 0)
             .lineTo(neckHalf, -4 * scale)
             .cubicCurveTo(neckHalf * 0.7, vDepth - 5 * scale, neckHalf * 0.3, vDepth - 5 * scale, 0, -4 * scale)
             .closePath();
    } else {
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 0)
             .lineTo(neckHalf + 10, -32)
             .lineTo(10, -38)
             .lineTo(0, -18)
             .closePath();
    }
    return builder.build();
  }

  /**
   * توليد بترون الجسم المطور مع حسابات البنس والقصات التخصصية بناءً على قياسات الكتب الفنية الـ 19
   */
  static generateBodice(gender: Gender, isFront: boolean, measurements: Measurements, ease: number, scale: number = 2.0, style?: GarmentStyle): string {
    const { 
      chest, waist, hips, shoulderWidth, height, 
      backWidth, backLength, shoulderToBust, bustPointToPoint,
      waistToHip, bodiceLength, waistToArmhole
    } = measurements;
    
    const chestQ = (chest / 4) + (ease / 4);
    const waistQ = (waist / 4) + (ease / 4);
    const hipsQ = (hips / 4) + (ease / 4);
    
    const neckW = (chest / 12) + 2.5;
    const neckD = isFront ? neckW + 6 : 3;
    
    let armholeD = waistToArmhole ? waistToArmhole * scale : ((chest / 6) + 11) * scale;
    const effectiveBackWidth = (backWidth || (shoulderWidth * 0.9)) / 2;
    
    // Adjustments for specific styles
    const shoulderExt = (style === GarmentStyle.STRUCTURED_BLAZER || style === GarmentStyle.DOUBLE_BREASTED_SUIT || style === GarmentStyle.TRENCH_COAT) ? 1.5 : 0;
    
    if (style === GarmentStyle.KIMONO_JACKET || style === GarmentStyle.HOODIE) {
      armholeD *= 1.2; // Deeper armhole for comfort
    }

    let pieceLength = height * 0.45; 
    
    if ([GarmentStyle.ABAYA, GarmentStyle.BISHT, GarmentStyle.KAFTAN, GarmentStyle.TRENCH_COAT, GarmentStyle.TAILORED_COAT, GarmentStyle.JUMPSUIT].includes(style!)) pieceLength = height * 0.96;
    if (style === GarmentStyle.EVENING_GOWN || style === GarmentStyle.MERMAID_DRESS || style === GarmentStyle.PRINCESS_CUT_DRESS || style === GarmentStyle.COWL_NECK_DRESS || style === GarmentStyle.WRAP_DRESS) pieceLength = height * 0.94;
    
    const waistY = (backLength || (bodiceLength ? bodiceLength * 0.9 : 44)) * scale;
    if (style === GarmentStyle.WAISTCOAT) pieceLength = waistY / scale + (waistToHip || 20); // Waistcoat is short
    if (style === GarmentStyle.KIMONO_JACKET || style === GarmentStyle.HOODIE) pieceLength = waistY / scale + 25; // Mid-hip length

    const builder = new PathBuilder();
    
    // Center Front/Back start
    builder.moveTo(0, pieceLength * scale).lineTo(0, neckD * scale);
    
    // Neckline & Shoulder
    if (style === GarmentStyle.COWL_NECK_DRESS && isFront) {
      builder.lineTo(neckW * 2.5 * scale, -10 * scale)
             .lineTo((shoulderWidth / 2) * scale, 15 * scale);
    } else if (style === GarmentStyle.WRAP_DRESS && isFront) {
      // Wrap dress diagonal neckline
      builder.lineTo(neckW * scale, 0)
             .lineTo((shoulderWidth / 2) * scale, 6 * scale); // Shoulder slope
    } else {
      builder.cubicCurveTo((neckW * 0.45) * scale, neckD * scale, neckW * scale, (neckD * 0.45) * scale, neckW * scale, 0);
      const slope = gender === Gender.MALE ? 5.2 : 4.4;
      builder.lineTo((shoulderWidth / 2 + shoulderExt) * scale, slope * scale);
    }

    // Armhole
    if (style === GarmentStyle.KIMONO_JACKET) {
       // Kimono dropped shoulder/armhole
       builder.lineTo((chestQ * 1.2) * scale, armholeD);
    } else {
       builder.cubicCurveTo(effectiveBackWidth * scale, armholeD * 0.4, (chestQ * 0.9) * scale, armholeD * 0.8, chestQ * scale, armholeD);
    }

    const hipsY = (waistY + (waistToHip || 20) * scale);

    // Side Seams
    if (style === GarmentStyle.WAISTCOAT && isFront) {
        builder.lineTo(waistQ * 0.95 * scale, waistY);
        builder.lineTo(waistQ * scale, waistY + 15 * scale); 
        builder.lineTo(0, waistY + 8 * scale);
        builder.closePath();
        return builder.build();
    }

    if (style === GarmentStyle.PRINCESS_CUT_DRESS || style === GarmentStyle.MERMAID_DRESS) {
      builder.lineTo(chestQ * scale, waistY);
      if (style === GarmentStyle.MERMAID_DRESS) {
        const kneeY = (measurements.waistToKnee || 62) * scale + waistY;
        builder.lineTo(waistQ * 0.85 * scale, waistY)
               .lineTo(hipsQ * scale, hipsY)
               .lineTo(hipsQ * 0.75 * scale, kneeY) 
               .cubicCurveTo(hipsQ * 3 * scale, kneeY + 40, hipsQ * 6 * scale, pieceLength * scale, hipsQ * 8 * scale, pieceLength * scale); 
      } else {
        builder.lineTo(waistQ * scale, waistY)
               .cubicCurveTo(hipsQ * 1.5 * scale, hipsY, hipsQ * 4 * scale, hipsY + 30, hipsQ * 6 * scale, pieceLength * scale);
      }
    } else if (style === GarmentStyle.BISHT || style === GarmentStyle.KAFTAN || style === GarmentStyle.ABAYA || style === GarmentStyle.KIMONO_JACKET) {
      const sweep = style === GarmentStyle.BISHT ? 8 : 4;
      builder.lineTo(chestQ * (style === GarmentStyle.KIMONO_JACKET ? 1.1 : sweep) * scale, armholeD)
             .lineTo(chestQ * (style === GarmentStyle.KIMONO_JACKET ? 1.1 : sweep - 0.5) * scale, pieceLength * scale);
    } else if (style === GarmentStyle.TAILORED_COAT || style === GarmentStyle.STRUCTURED_BLAZER || style === GarmentStyle.DOUBLE_BREASTED_SUIT) {
      builder.lineTo(waistQ * 1.15 * scale, waistY) // Fitted waist
             .lineTo(hipsQ * 1.25 * scale, hipsY)
             .lineTo(hipsQ * 1.35 * scale, pieceLength * scale);
    } else if (style === GarmentStyle.WRAP_DRESS && isFront) {
      // Wrap dress overlap
      builder.lineTo(waistQ * 1.3 * scale, waistY)
             .lineTo(hipsQ * 1.3 * scale, hipsY)
             .lineTo(hipsQ * 1.4 * scale, pieceLength * scale)
             .lineTo(0, pieceLength * scale) // Bottom hem
             .lineTo(0, waistY) // Center front waist
             .lineTo(0, neckD * scale); // Back to neck
      builder.closePath();
      return builder.build();
    } else if (style === GarmentStyle.JUMPSUIT) {
      // Jumpsuit connects bodice to legs roughly
      builder.lineTo(waistQ * 1.05 * scale, waistY)
             .lineTo(hipsQ * 1.1 * scale, hipsY)
             // Simulating leg width
             .lineTo(hipsQ * 0.9 * scale, pieceLength * scale)
             .lineTo(hipsQ * 0.4 * scale, pieceLength * scale) // Inner leg hem
             .lineTo(0, hipsY + 15 * scale); // Crotch point
    } else {
      // Standard shirt/blouse/hoodie
      const hemW = (style === GarmentStyle.HOODIE) ? hipsQ * 0.9 : hipsQ; // Hoodie band tighter
      builder.lineTo(waistQ * (style === GarmentStyle.HOODIE ? 1.1 : 1.0) * scale, waistY)
             .lineTo(hipsQ * scale, hipsY)
             .lineTo(hemW * scale, pieceLength * scale);
    }

    if (style !== GarmentStyle.JUMPSUIT) {
        builder.lineTo(0, pieceLength * scale);
    }
    
    builder.closePath();
    return builder.build();
  }

  /**
   * توليد بترون التنورة الجديد
   */
  static generateSkirt(isFront: boolean, measurements: Measurements, ease: number, scale: number = 2.0, style: GarmentStyle): string {
    const { waist, hips, waistToFloor, skirtLength, waistToHip } = measurements;
    const builder = new PathBuilder();
    
    const waistQ = (waist / 4) + (ease / 4) + (isFront ? 1 : -1); 
    const hipsQ = (hips / 4) + (ease / 4);
    const len = (skirtLength || waistToFloor || 100) * scale;
    const wToH = (waistToHip || 20) * scale;
    
    const waistY = 50; 

    builder.moveTo(0, waistY);
    // Waist curve
    builder.cubicCurveTo(waistQ * 0.5 * scale, waistY + (isFront ? 5 : 0), waistQ * scale, waistY, waistQ * scale, waistY);
    
    // Hip curve
    builder.cubicCurveTo(waistQ * scale + 10, waistY + wToH * 0.5, hipsQ * scale, waistY + wToH, hipsQ * scale, waistY + wToH);
    
    // To Hem
    if (style === GarmentStyle.PLEATED_SKIRT) {
        // Flare out
        builder.lineTo(hipsQ * 1.5 * scale, waistY + len);
    } else {
        // Pencil/Straight
        builder.lineTo(hipsQ * scale, waistY + len);
    }
    
    // Hem
    builder.lineTo(0, waistY + len);
    builder.closePath();
    
    return builder.build();
  }

  /**
   * توليد بترون الأكمام المتطور (موسع لدعم أنواع الأكمام: Puff, Bishop, Bell, Leg Mutton)
   */
  static generateSleeve(type: SleeveType, measurements: Measurements, scale: number = 2.0): string {
    const { armLength, chest, armCircumference, cuffCircumference } = measurements;
    const builder = new PathBuilder();
    
    // Base Dimensions
    let bicepW = (armCircumference || (chest / 4 + 6));
    let crownH = (chest / 10 + 9);
    let wristW = (cuffCircumference || (chest / 6 + 7));
    let len = armLength;

    // Apply Style Logic
    if (type === SleeveType.PUFF) {
        crownH *= 2.5; // High cap for gathering
        bicepW *= 1.6; // Wide bicep
    } else if (type === SleeveType.BISHOP) {
        bicepW *= 1.3;
        wristW = bicepW; // Wide wrist for gathering
        len *= 1.05; // Blouson effect
    } else if (type === SleeveType.BELL) {
        wristW = bicepW * 1.8; // Flare
    } else if (type === SleeveType.LEG_MUTTON) {
        crownH *= 2.2;
        bicepW *= 2.2;
        wristW *= 0.7; // Tapered
    } else if (type === SleeveType.KIMONO) {
        bicepW *= 2.0;
        wristW = bicepW * 0.9;
        crownH *= 0.2; // Flatter cap
    }

    // Apply Scale
    const s_bW = bicepW * scale;
    const s_cH = crownH * scale;
    const s_len = len * scale;
    const s_wW = wristW * scale;

    const wristOffset = (s_bW - s_wW) / 2;

    // Drawing sequence: Bottom Left -> Top Left -> Cap -> Top Right -> Bottom Right -> Hem -> Close

    // 1. Move to Bottom Left
    builder.moveTo(wristOffset, s_len);

    // 2. Left Side Seam
    if (type === SleeveType.BISHOP) {
        // Curve out
        builder.cubicCurveTo(wristOffset - 20, s_len * 0.6, -20, s_cH * 1.5, 0, s_cH);
    } else if (type === SleeveType.BELL) {
        // Curve in
        builder.cubicCurveTo(wristOffset + 10, s_len * 0.6, 10, s_cH * 1.2, 0, s_cH);
    } else {
        // Straight
        builder.lineTo(0, s_cH);
    }

    // 3. Cap (Sleeve Head)
    // Standard Cap Logic (modified for Puff height)
    const capControlY = type === SleeveType.PUFF ? -s_cH * 0.5 : -10 * scale; 
    
    builder.cubicCurveTo(
        s_bW * 0.25, capControlY, 
        s_bW * 0.75, capControlY, 
        s_bW, s_cH
    );

    // 4. Right Side Seam
    const rightWristX = wristOffset + s_wW;
    if (type === SleeveType.BISHOP) {
        builder.cubicCurveTo(s_bW + 20, s_cH * 1.5, rightWristX + 20, s_len * 0.6, rightWristX, s_len);
    } else if (type === SleeveType.BELL) {
        builder.cubicCurveTo(s_bW - 10, s_cH * 1.2, rightWristX - 10, s_len * 0.6, rightWristX, s_len);
    } else {
        builder.lineTo(rightWristX, s_len);
    }

    // 5. Hem
    if (type === SleeveType.BISHOP) {
        // Curve down
        builder.cubicCurveTo(rightWristX - (s_wW * 0.3), s_len + 25, wristOffset + (s_wW * 0.3), s_len + 25, wristOffset, s_len);
    } else if (type === SleeveType.BELL) {
         // Slight curve
         builder.cubicCurveTo(rightWristX - (s_wW * 0.3), s_len + 10, wristOffset + (s_wW * 0.3), s_len + 10, wristOffset, s_len);
    } else {
        builder.lineTo(wristOffset, s_len);
    }

    builder.closePath();
    return builder.build();
  }

  static generatePants(gender: Gender, isFront: boolean, measurements: Measurements, ease: number, scale: number = 2.0, style?: GarmentStyle): string {
    const { waist, hips, height, waistToFloor, waistToHip } = measurements;
    const builder = new PathBuilder();
    
    const waistQ = (waist / 4) + (isFront ? -1.5 : 7.5);
    const hipsQ = (hips / 4) + (ease / 4.5);
    const rise = (hips / 4) + (gender === Gender.MALE ? 14 : 12); 
    const legLen = (waistToFloor || (height * 0.68)) * scale;
    const crotchExt = (hips / 20) * (isFront ? 2.8 : 6.2);

    builder.moveTo(0, 0)
           .lineTo(waistQ * scale, 0)
           .lineTo(hipsQ * scale, rise * scale);
           
    // Palazzo pants leg widening
    if (style === GarmentStyle.PALAZZO_PANTS) {
        builder.lineTo(hipsQ * 1.8 * scale, legLen)
               .lineTo(0, legLen) // Center front/back hem
               .lineTo(-crotchExt * 1.5 * scale, rise * scale); // Deep crotch for comfort
    } else {
        builder.lineTo(hipsQ * 0.9 * scale, legLen)
               .lineTo(0, legLen)
               .lineTo(-crotchExt * scale, rise * scale);
    }

    builder.cubicCurveTo(-crotchExt * 0.55 * scale, rise * 0.9 * scale, 0, rise * 0.35 * scale, 0, 0);

    builder.closePath();
    return builder.build();
  }
}
