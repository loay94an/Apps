
import React, { useState, useRef } from 'react';
import { Measurements, MeasurementProfile, BrandingSettings, Gender } from '../types';
import { STANDARD_SIZES, CHILDREN_SIZES, TRANSLATIONS } from '../constants';
import jsPDF from 'jspdf';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase'; 

interface Props {
  userId: string;
  value: Measurements;
  onChange: (m: Measurements) => void;
  savedProfiles: MeasurementProfile[];
  onSaveProfile: (name: string, m: Measurements) => void;
  onDeleteProfile: (id: string) => void;
  onSelectProfile: (m: Measurements) => void;
  branding?: BrandingSettings;
  onBackToHub: () => void; 
  language: 'ar' | 'en';
  gender: Gender | null;
  onImageChange: (url: string | null) => void; // Added prop
}

const modelLibrary = [
  { name: "Male Model", url: "https://placehold.co/400x600/1e293b/FFF?text=Male+Model" },
  { name: "Female Model", url: "https://placehold.co/400x600/1e293b/FFF?text=Female+Model" },
  { name: "Child Model", url: "https://placehold.co/400x600/1e293b/FFF?text=Child+Model" }
];

// Helper: Convert ArrayBuffer to Base64 for Font
const arrayBufferToBase64 = (buffer: ArrayBuffer) => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
};

export const SizeInput: React.FC<Props> = ({ userId, value, onChange, savedProfiles, onSaveProfile, onDeleteProfile, onSelectProfile, branding, onBackToHub, language, gender, onImageChange }) => {
  const [activeTab, setActiveTab] = useState<'standard' | 'advanced' | 'profiles'>('standard');
  const [profileName, setProfileName] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [activeAdvancedGroup, setActiveAdvancedGroup] = useState(0);
  const blueprintRef = useRef<HTMLDivElement>(null);
  const txt = TRANSLATIONS[language];

  // Translations for measurement labels
  const MEASUREMENT_GROUPS = [
  {
    title: language === 'ar' ? "الجذع والكتف" : "Torso & Shoulder",
    fields: {
      chest: language === 'ar' ? "محيط الصدر" : "Chest",
      waist: language === 'ar' ? "محيط الخصر" : "Waist",
      hips: language === 'ar' ? "محيط الورك" : "Hips",
      shoulderWidth: language === 'ar' ? "عرض الكتف الكلي" : "Shoulder Width",
      backWidth: language === 'ar' ? "عرض الظهر" : "Back Width",
      bodiceLength: language === 'ar' ? "طول الصدر الكلي" : "Bodice Length",
      backLength: language === 'ar' ? "طول الظهر" : "Back Length",
      bustPointToPoint: language === 'ar' ? "بين الثديين" : "Bust Point to Point",
      shoulderToBust: language === 'ar' ? "من الكتف للثدي" : "Shoulder to Bust"
    }
  },
  {
    title: language === 'ar' ? "الأطراف والرقبة" : "Limbs & Neck",
    fields: {
      neckCircumference: language === 'ar' ? "محيط الرقبة" : "Neck Circumference",
      armLength: language === 'ar' ? "طول الكم" : "Arm Length",
      armCircumference: language === 'ar' ? "محيط الذراع" : "Arm Circumference",
      cuffCircumference: language === 'ar' ? "محيط الإسوارة" : "Cuff Circumference",
      armholeCircumference: language === 'ar' ? "محيط حفرة الإبط" : "Armhole Circumference"
    }
  },
  {
    title: language === 'ar' ? "الارتفاعات السفلية" : "Lower Heights",
    fields: {
      height: language === 'ar' ? "الطول الكلي" : "Height",
      waistToHip: language === 'ar' ? "من الخصر للورك" : "Waist to Hip",
      waistToKnee: language === 'ar' ? "من الخصر للركبة" : "Waist to Knee",
      waistToFloor: language === 'ar' ? "طول الساق للأرض" : "Waist to Floor",
      skirtLength: language === 'ar' ? "طول التنورة المطلوب" : "Skirt Length"
    }
  }
];

  const handleFieldChange = (field: string, val: number) => {
    onChange({ ...value, [field]: val });
  };

  const updateImage = (url: string | null) => {
      setImageUrl(url);
      onImageChange(url);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    
    const file = e.target.files[0];

    // Check if storage is initialized for cloud upload
    if (storage) {
        const storageRef = ref(storage, `clients/${userId}/profile.jpg`);
        try {
          await uploadBytes(storageRef, file);
          const url = await getDownloadURL(storageRef);
          updateImage(url);
          alert("✅ تم تحميل الصورة بنجاح!");
          return;
        } catch (error) {
          console.warn("Firebase upload failed, falling back to local:", error);
        }
    }

    // Fallback: Local Base64 Preview
    const reader = new FileReader();
    reader.onloadend = () => {
        updateImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const exportPDF = async () => {
    const doc = new jsPDF();

    // --- Font Injection ---
    try {
        const fontUrl = "https://fonts.gstatic.com/s/tajawal/v9/Iura6YBj_oCad4k1nzSBCw.ttf";
        const response = await fetch(fontUrl);
        const buffer = await response.arrayBuffer();
        const fontBase64 = arrayBufferToBase64(buffer);
        doc.addFileToVFS("Tajawal-Regular.ttf", fontBase64);
        doc.addFont("Tajawal-Regular.ttf", "Tajawal", "normal");
        doc.setFont("Tajawal", "normal");
    } catch (error) {
        console.error("Font loading error", error);
    }
    // ----------------------
    
    // Add Branding Header
    doc.setFontSize(22);
    doc.setTextColor(branding?.primaryColor || '#000000');
    doc.text(branding?.companyName || "تقرير القياسات الفنية", 105, 25, { align: 'center' });
    
    doc.setFontSize(16);
    doc.setTextColor(50, 50, 50);
    doc.text("Technical Measurement Report", 105, 45, { align: 'center' });
    
    let y = 60; // Cursor for text measurements on the Left side
    let visualY = 60; // Cursor for images on the Right side

    // --- 1. Measurements List ---
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);

    Object.entries(value).forEach(([k, v]) => {
      // Find Arabic Label
      let arabicLabel = k;
      for (const group of MEASUREMENT_GROUPS) {
        if ((group.fields as any)[k]) {
          arabicLabel = (group.fields as any)[k];
          break;
        }
      }

      if (v) {
        // If we hit bottom of page
        if (y > 270) {
           doc.addPage();
           y = 20;
           visualY = 20;
        }
        // Align based on language
        const xPos = language === 'ar' ? 190 : 20;
        doc.text(`${arabicLabel}: ${v} cm`, xPos, y, { align: language === 'ar' ? 'right' : 'left' });
        y += 8;
      }
    });

    // --- 2. Visuals (Images & Blueprint) ---
    // Add Client Image if available
    if (imageUrl) {
      try {
        const xImg = language === 'ar' ? 20 : 120;
        doc.addImage(imageUrl, "JPEG", xImg, visualY, 70, 90); 
        visualY += 100; 
      } catch (e) {
        console.warn("Could not add image to PDF", e);
      }
    }

    // Add Blueprint SVG
    if (blueprintRef.current) {
        const svgElement = blueprintRef.current.querySelector("svg");
        if (svgElement) {
            try {
                // Serialize SVG to XML string
                const svgData = new XMLSerializer().serializeToString(svgElement);
                
                // Replace "currentColor" with the primary color (or black) ensuring visibility on white PDF
                const coloredSvgData = svgData.replace(/currentColor/g, branding?.primaryColor || '#000000');

                // Create a temporary canvas to rasterize the SVG
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                const img = new Image();
                const svgBlob = new Blob([coloredSvgData], { type: "image/svg+xml;charset=utf-8" });
                const url = URL.createObjectURL(svgBlob);

                await new Promise<void>((resolve) => {
                    img.onload = () => {
                        canvas.width = 1000;
                        canvas.height = 1500;
                        if (ctx) {
                            ctx.fillStyle = "#ffffff"; // White background
                            ctx.fillRect(0, 0, canvas.width, canvas.height);
                            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                            const imgData = canvas.toDataURL("image/png");
                            
                            // Check for page break
                            if (visualY + 110 > 280) {
                                doc.addPage();
                                visualY = 20;
                            }
                            
                            doc.setFontSize(10);
                            const xBp = language === 'ar' ? 55 : 155;
                            doc.text("Blueprint:", xBp, visualY - 5, { align: 'center' });
                            const xImg = language === 'ar' ? 20 : 120;
                            doc.addImage(imgData, 'PNG', xImg, visualY, 70, 105);
                        }
                        URL.revokeObjectURL(url);
                        resolve();
                    };
                    img.src = url;
                });
            } catch (e) {
                console.error("Error adding blueprint to PDF", e);
            }
        }
    }

    doc.save("measurements.pdf");
  };

  const exportPNG = () => {
    if (!blueprintRef.current) return;
    const svgElement = blueprintRef.current.querySelector("svg");
    if (!svgElement) return;

    const svgData = new XMLSerializer().serializeToString(svgElement);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d")!;
    const img = new Image();
    const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      canvas.width = 1200;
      canvas.height = 1800;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 100, 100, 1000, 1600);
      URL.revokeObjectURL(url);
      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = "measurements_blueprint.png";
      link.click();
    };
    img.src = url;
  };

  const renderBlueprint = () => (
    <div ref={blueprintRef} className="relative w-full aspect-[2/3] bg-slate-800/20 rounded-3xl border border-white/5 flex items-center justify-center p-4 overflow-hidden">
      <svg viewBox="0 0 100 150" className="w-full h-full text-primary opacity-40">
        <path d="M50 10 L60 20 L65 40 L85 40 L80 140 L20 140 L15 40 L35 40 L40 20 Z" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2,2" />
        <circle cx="50" cy="8" r="5" fill="none" stroke="currentColor" strokeWidth="0.5" />
        <line x1="30" y1="50" x2="70" y2="50" stroke="currentColor" strokeWidth="1" />
        <text x="50" y="48" fontSize="3" textAnchor="middle" fill="currentColor">CHEST: {value.chest}cm</text>
        <line x1="35" y1="80" x2="65" y2="80" stroke="currentColor" strokeWidth="1" />
        <text x="50" y="78" fontSize="3" textAnchor="middle" fill="currentColor">WAIST: {value.waist}cm</text>
      </svg>
    </div>
  );

  const activeSizes = gender === Gender.CHILDREN ? CHILDREN_SIZES : STANDARD_SIZES;

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 sm:space-y-10 animate-in fade-in duration-1000 pb-20 relative pt-12">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 z-50 w-12 h-12 bg-slate-800/50 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-700 transition-all shadow-lg group"
        title={txt.backToHome}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-6 h-6 transform group-hover:-translate-x-1 transition-transform">
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
        </svg>
      </button>

      {/* Adjusted tab buttons for better mobile responsiveness */}
      <div className="flex bg-slate-900/80 backdrop-blur-2xl p-1.5 sm:p-2 rounded-3xl border border-white/5 w-full md:w-fit mx-auto shadow-2xl overflow-x-auto no-scrollbar">
        <button onClick={() => setActiveTab('standard')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'standard' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{txt.standardSizes}</button>
        <button onClick={() => setActiveTab('advanced')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'advanced' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{txt.advancedMethod}</button>
        <button onClick={() => setActiveTab('profiles')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'profiles' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{txt.archives}</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        <div className="lg:col-span-8 bg-slate-900 rounded-[2.5rem] sm:rounded-[4rem] p-6 sm:p-10 border border-white/5 shadow-2xl min-h-[500px] sm:min-h-[600px]">
          {activeTab === 'standard' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 py-6 sm:py-10">
              {Object.keys(activeSizes).map((size) => (
                <button key={size} onClick={() => onSelectProfile(activeSizes[size])} className={`group py-8 sm:py-10 rounded-[2rem] sm:rounded-[3rem] border-2 transition-all ${JSON.stringify(value) === JSON.stringify(activeSizes[size]) ? 'border-primary bg-primary/5 text-primary scale-105 shadow-2xl' : 'border-white/5 bg-slate-800/40 text-slate-500'}`}>
                  <span className={`${gender === Gender.CHILDREN ? 'text-2xl sm:text-3xl' : 'text-4xl sm:text-6xl'} font-black mb-2 block`}>{size}</span>
                  <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-widest">{gender === Gender.CHILDREN ? 'Age Based' : 'Standard Fit'}</span>
                </button>
              ))}
            </div>
          )}

          {activeTab === 'advanced' && (
             <div className="space-y-8 sm:space-y-12 max-h-[700px] overflow-y-auto no-scrollbar pr-0 sm:pr-2">
                <div className="flex bg-slate-800 p-1.5 sm:p-2 rounded-2xl border border-white/5 w-full mx-auto shadow-lg mb-8 overflow-x-auto no-scrollbar">
                {MEASUREMENT_GROUPS.map((group, idx) => (
                  <button 
                    key={idx} 
                    onClick={() => setActiveAdvancedGroup(idx)}
                    className={`flex-1 px-4 sm:px-6 py-2 rounded-xl text-[10px] font-black whitespace-nowrap transition-all ${activeAdvancedGroup === idx ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    {group.title}
                  </button>
                ))}
              </div>

              {MEASUREMENT_GROUPS.map((group, idx) => (
                <div key={idx} className={`${activeAdvancedGroup === idx ? 'block' : 'hidden'} space-y-6`}>
                  <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-3">
                    <span className="w-1.5 sm:w-2 h-6 bg-primary rounded-full"></span>
                    {group.title}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
                    {Object.entries(group.fields).map(([field, label]) => (
                      <div key={field} className="space-y-3 group">
                        <div className="flex justify-between items-center text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-primary transition-colors">
                          <label>{label}</label>
                          <span className="text-primary">{(value as any)[field] || 0} cm</span>
                        </div>
                        <input 
                          type="range" 
                          min={0} 
                          max={250} 
                          value={(value as any)[field] || 0} 
                          onChange={(e) => handleFieldChange(field, parseInt(e.target.value))} 
                          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-primary" 
                        />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'profiles' && (
            <div className="grid grid-cols-1 gap-4">
              {savedProfiles.length === 0 ? (
                <div className="py-20 sm:py-40 text-center opacity-30">
                  <span className="text-6xl sm:text-8xl block mb-4">📭</span>
                  <p className="font-black text-lg sm:text-xl">{txt.noProfiles}</p>
                </div>
              ) : savedProfiles.map(p => (
                <div key={p.id} className="p-6 sm:p-8 bg-slate-800/40 rounded-[2rem] sm:rounded-[3rem] border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 group hover:border-primary/30 transition-all">
                  <div className={`text-center sm:text-${language === 'ar' ? 'right' : 'left'} w-full sm:w-auto`}>
                    <h5 className="text-white font-black text-lg sm:text-xl mb-1">{p.name}</h5>
                    <span className="text-[10px] font-black text-slate-500 uppercase">{new Date(p.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}</span>
                  </div>
                  <div className="flex gap-3 w-full sm:w-auto">
                    <button onClick={() => onSelectProfile(p.measurements)} className="flex-1 sm:flex-none bg-primary px-6 sm:px-10 py-3 sm:py-4 rounded-2xl text-white font-black text-xs shadow-xl active:scale-95 transition-all">{txt.use}</button>
                    <button onClick={() => onDeleteProfile(p.id)} className="bg-red-500/10 text-red-500 px-4 sm:px-6 py-3 sm:py-4 rounded-2xl hover:bg-red-500 hover:text-white transition-all">🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-4 space-y-6 sm:space-y-8">
           <div className="bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl space-y-6">
            <h3 className="text-xl sm:text-2xl font-black text-white mb-6">{txt.clientPhoto}</h3>
            
            <div className="grid grid-cols-3 gap-2 mb-4">
                {modelLibrary.map((model, i) => (
                    <button key={i} onClick={() => updateImage(model.url)} className="p-2 rounded-xl bg-slate-800 hover:bg-primary/20 transition-all border border-white/5">
                        <span className="text-[10px] sm:text-xs text-white">{model.name}</span>
                    </button>
                ))}
            </div>

            <div className="space-y-4">
              <label className="w-full flex flex-col items-center justify-center p-6 sm:p-8 border-2 border-dashed border-white/10 rounded-3xl cursor-pointer hover:bg-white/5 transition-all">
                <span className="text-4xl sm:text-5xl mb-4">📸</span>
                <span className="text-xs sm:text-sm font-bold text-white mb-2">{txt.uploadPhoto}</span>
                <span className="text-[9px] sm:text-[10px] text-slate-500 uppercase">JPEG, PNG, GIF</span>
                <input type="file" hidden accept="image/*" onChange={handleImageUpload} />
              </label>
              {imageUrl && (
                <div className="relative w-full aspect-square bg-slate-800 rounded-3xl overflow-hidden border border-white/5">
                  <img src={imageUrl} alt="Client/Model" className="w-full h-full object-cover" />
                  <button onClick={() => updateImage(null)} className="absolute top-4 left-4 w-9 h-9 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center text-xs font-black hover:bg-red-500 hover:text-white transition-all">✕</button>
                </div>
              )}
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl flex flex-col gap-6 sm:gap-8">
            <h3 className="text-xl sm:text-2xl font-black text-white">{txt.blueprint}</h3>
            {renderBlueprint()}
            <div className="flex gap-2">
               <button onClick={exportPDF} className="flex-1 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 py-3 sm:py-4 rounded-2xl font-black text-[10px] sm:text-xs hover:bg-emerald-500 hover:text-white transition-all">PDF</button>
               <button onClick={exportPNG} className="flex-1 bg-primary/10 text-primary border border-primary/20 py-3 sm:py-4 rounded-2xl font-black text-[10px] sm:text-xs hover:bg-primary hover:text-white transition-all">PNG</button>
            </div>
          </div>
          
          <div className="bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl space-y-6">
            <input 
              type="text" 
              placeholder={txt.profileName} 
              value={profileName} 
              onChange={(e) => setProfileName(e.target.value)} 
              className="w-full bg-slate-800 border border-white/5 p-4 sm:p-6 rounded-3xl outline-none text-white font-black text-base sm:text-lg" 
            />
            <button onClick={() => { if(profileName) { onSaveProfile(profileName, value); setProfileName(""); } }} className="w-full bg-primary text-white py-4 sm:py-6 rounded-3xl font-black text-lg sm:text-xl shadow-2xl shadow-primary/20 active:scale-95 transition-all">{txt.saveMeasurements} ✓</button>
          </div>
        </div>
      </div>
    </div>
  );
};
