
import React, { useMemo, useState } from 'react';
import { Order, GarmentStyle, Fabric, FabricColor, Measurements, BrandingSettings } from '../types';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface Props {
  orders: Order[];
  branding: BrandingSettings; // Added branding prop
}

// Helper: Convert ArrayBuffer to Base64 for Font
const arrayBufferToBase64 = (buffer: ArrayBuffer) => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
};

// Helper: Add font to PDF doc
const addArabicFont = async (doc: jsPDF) => {
    try {
        const fontUrl = "https://fonts.gstatic.com/s/tajawal/v9/Iura6YBj_oCad4k1nzSBCw.ttf";
        const response = await fetch(fontUrl);
        const buffer = await response.arrayBuffer();
        const fontBase64 = arrayBufferToBase64(buffer);
        
        doc.addFileToVFS("Tajawal-Regular.ttf", fontBase64);
        doc.addFont("Tajawal-Regular.ttf", "Tajawal", "normal");
        doc.setFont("Tajawal", "normal");
    } catch (error) {
        console.error("Could not load Arabic font, text might be garbled.", error);
    }
};

// Helper function to export individual order details to PDF
const exportOrderToPDF = async (order: Order) => {
  const doc = new jsPDF();
  
  await addArabicFont(doc);

  doc.setFontSize(20);
  doc.text("تفاصيل الطلب", 105, 20, { align: 'center' });

  doc.setFontSize(12);
  let yPos = 40;

  const styleName = order.details.style ? (order.details.style as string).replace(/_/g, ' ') : 'غير محدد';
  const sleeveName = order.details.sleeveType ? (order.details.sleeveType as string).replace(/_/g, ' ') : 'غير محدد';
  const collarName = order.details.collarType ? (order.details.collarType as string).replace(/_/g, ' ') : 'غير محدد';

  doc.text(`ID الطلب: ${order.id}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`حالة الطلب: ${order.status === 'PENDING' ? 'قيد الانتظار' : order.status === 'PROCESSING' ? 'قيد التجهيز' : order.status === 'SHIPPED' ? 'تم الشحن' : 'مكتمل'}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`تاريخ الطلب: ${new Date(order.createdAt).toLocaleString('ar-SA')}`, 196, yPos, { align: 'right' }); yPos += 12;

  doc.text(`اسم العميل: ${order.customerName}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`الهاتف: ${order.phone}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`العنوان: ${order.address}`, 196, yPos, { align: 'right' }); yPos += 12;

  doc.text(`الموديل: ${styleName}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`القماش: ${order.details.fabric?.name || 'غير محدد'}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`اللون: ${order.details.color?.name || 'غير محدد'} (${order.details.color?.hex || ''})`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`النقشة: ${order.details.pattern?.name || 'غير محدد'}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`نوع الكم: ${sleeveName}`, 196, yPos, { align: 'right' }); yPos += 8;
  doc.text(`نوع الياقة: ${collarName}`, 196, yPos, { align: 'right' }); yPos += 12;

  doc.text(`المقاسات المعتمدة:`, 196, yPos, { align: 'right' }); yPos += 8;

  const measurements = order.details.measurements as Measurements;
  const measurementData = Object.entries(measurements || {}).map(([key, value]) => {
    // Basic Arabic labels for common measurements
    const arabicLabels: Record<string, string> = {
      height: "الطول الكلي", chest: "محيط الصدر", waist: "محيط الخصر", hips: "محيط الورك",
      shoulderWidth: "عرض الكتف", armLength: "طول الكم", neckCircumference: "محيط الرقبة",
      backWidth: "عرض الظهر", shoulderLength: "طول الكتف", backLength: "طول الظهر",
      armCircumference: "محيط الذراع", cuffCircumference: "محيط الإسوارة", waistToHip: "من الخصر للورك",
      waistToKnee: "من الخصر للركبة", waistToFloor: "طول الساق للأرض", skirtLength: "طول التنورة",
      bodiceLength: "طول الصدر", armholeCircumference: "محيط حفرة الإبط", waistToArmhole: "من الخصر للإبط",
      shoulderToBust: "من الكتف للثدي", bustPointToPoint: "بين الثديين"
    };
    return [arabicLabels[key] || key, `${value} سم`];
  });

  (doc as any).autoTable({
    startY: yPos,
    head: [['القياس', 'القيمة']],
    body: measurementData,
    theme: 'grid',
    styles: { font: 'Tajawal', halign: 'right', fontStyle: 'normal' },
    headStyles: { fillColor: [37, 99, 235], textColor: [255, 255, 255], font: 'Tajawal' },
  });

  yPos = (doc as any).autoTable.previous.finalY + 12;
  doc.setFontSize(16);
  doc.text(`السعر الإجمالي: ${order.details.totalPrice} ر.س`, 196, yPos, { align: 'right' });
  doc.text(`طريقة الدفع: ${order.paymentMethod === 'CARD' ? 'بطاقة ائتمان' : 'نقداً'}`, 196, yPos + 10, { align: 'right' });


  doc.save(`order_${order.customerName}_${order.id}.pdf`);
};


export const StatsDashboard: React.FC<Props> = ({ orders, branding }) => {
  const [period, setPeriod] = useState<string>("يومي");

  const stats = useMemo(() => {
    const totalRevenue = orders.reduce((sum, o) => sum + (o.details?.totalPrice || 0), 0);
    const avgPrice = orders.length > 0 ? totalRevenue / orders.length : 0;
    
    const styleCounts: Record<string, number> = {};
    const fabricCounts: Record<string, number> = {};
    const colorCounts: Record<string, { count: number; hex: string }> = {};
    const regions: Record<string, number> = {};

    orders.forEach(o => {
      // Ensure style is a string, providing a fallback if null/undefined
      const style = o.details.style ? (o.details.style as string) : 'UNKNOWN_STYLE';
      styleCounts[style] = (styleCounts[style] || 0) + 1;
      
      const fabricName = o.details.fabric?.name || 'غير محدد';
      fabricCounts[fabricName] = (fabricCounts[fabricName] || 0) + 1;
      
      const colorName = o.details.color?.name || 'غير محدد';
      const colorHex = o.details.color?.hex || '#cccccc';
      if (!colorCounts[colorName]) {
        colorCounts[colorName] = { count: 0, hex: colorHex };
      }
      colorCounts[colorName].count++;
      
      const city = o.address ? o.address.split('،')[0] : 'غير محدد';
      regions[city] = (regions[city] || 0) + 1;
    });

    return { totalRevenue, avgPrice, styleCounts, fabricCounts, colorCounts, regions };
  }, [orders]);

  const exportSummaryPDF = async () => {
    const doc = new jsPDF();
    
    await addArabicFont(doc);

    let yOffset = 20;

    // Add company logo if available
    if (branding.logoUrl) {
      try {
        const response = await fetch(branding.logoUrl);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        await new Promise<void>((resolve) => {
          reader.onloadend = () => {
            doc.addImage(reader.result as string, "PNG", 150, 10, 40, 40); // Adjust position and size as needed
            resolve();
          };
        });
      } catch (error) {
        console.error("Error loading logo image:", error);
      }
    }

    // Add company name
    doc.setFontSize(22);
    doc.setTextColor(branding.primaryColor);
    doc.text(branding.companyName, 105, yOffset, { align: 'center' });
    yOffset += 10;

    doc.setFontSize(16);
    doc.setTextColor(50, 50, 50);
    doc.text(`تقرير الإحصائيات - فترة: ${period}`, 105, yOffset, { align: 'center' });
    yOffset += 20;
    
    doc.setFontSize(12);
    doc.text(`إجمالي المبيعات: ${stats.totalRevenue.toLocaleString()} ر.س`, 196, yOffset, { align: 'right' }); yOffset += 8;
    doc.text(`عدد الطلبات المنفذة: ${orders.length}`, 196, yOffset, { align: 'right' }); yOffset += 8;
    doc.text(`متوسط قيمة الطلب: ${stats.avgPrice.toFixed(2)} ر.س`, 196, yOffset, { align: 'right' }); yOffset += 15;

    const tableData = orders.map(o => [
      o.customerName,
      o.details.style ? (o.details.style as string).replace(/_/g, ' ') : 'غير محدد',
      o.details.fabric?.name || 'غير محدد',
      (o.details.totalPrice || 0) + ' ر.س',
      o.status === 'PENDING' ? 'قيد الانتظار' : o.status === 'PROCESSING' ? 'قيد التجهيز' : o.status === 'SHIPPED' ? 'تم الشحن' : 'مكتمل',
      new Date(o.createdAt).toLocaleDateString('ar-SA')
    ]);

    (doc as any).autoTable({
      head: [['اسم العميل', 'الموديل', 'القماش', 'السعر', 'الحالة', 'التاريخ']],
      body: tableData,
      startY: yOffset,
      styles: { font: 'Tajawal', halign: 'right', fontStyle: 'normal' },
      headStyles: { fillColor: [37, 99, 235], textColor: [255, 255, 255], font: 'Tajawal' },
    });

    doc.save(`smart_tailor_report_${period}.pdf`);
  };

  const maxStyleVal = Math.max(...(Object.values(stats.styleCounts) as number[]), 1);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500" dir="rtl">
      <div className="flex justify-between items-center mb-6">
         <div className="flex gap-2">
            {['يومي', 'أسبوعي', 'شهري'].map(p => (
              <button 
                key={p} 
                onClick={() => setPeriod(p)}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${period === p ? 'bg-primary text-white shadow-lg' : 'bg-slate-900 text-slate-500'}`}
              >
                {p}
              </button>
            ))}
         </div>
         <button 
           onClick={exportSummaryPDF} // Changed to exportSummaryPDF
           className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-6 py-2 rounded-xl text-[10px] font-black hover:bg-emerald-500 hover:text-white transition-all"
         >
           تصدير تقرير ملخص PDF 📄
         </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard label="إجمالي الدخل" val={`${stats.totalRevenue.toLocaleString()} ر.س`} icon="💰" color="emerald" />
        <StatCard label="عدد الطلبات" val={orders.length} icon="📦" color="primary" />
        <StatCard label="متوسط سعر الطلب" val={`${Math.round(stats.avgPrice)} ر.س`} icon="📈" color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="bg-slate-900/50 p-8 rounded-[3rem] border border-white/5 space-y-6">
          <h3 className="text-lg font-black text-white">الموديلات الأكثر طلباً</h3>
          <div className="space-y-4 pt-4">
            {Object.entries(stats.styleCounts).map(([style, count]) => (
              <div key={style} className="space-y-2">
                <div className="flex justify-between text-[10px] font-black text-slate-400">
                  <span>{style.replace(/_/g, ' ')}</span>
                  <span className="text-white">{(count as number)} طلب</span>
                </div>
                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary shadow-[0_0_10px_rgba(37,99,235,0.4)] transition-all duration-1000" 
                    style={{ width: `${((count as number) / maxStyleVal) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-slate-900/50 p-8 rounded-[3rem] border border-white/5 space-y-6">
          <h3 className="text-lg font-black text-white">توزيع المناطق</h3>
          <div className="space-y-4 pt-4">
            {Object.entries(stats.regions).map(([city, count]) => (
              <div key={city} className="flex items-center justify-between p-4 bg-slate-800/20 rounded-2xl border border-white/5">
                <div className="flex items-center gap-3">
                  <span className="text-sm">📍</span>
                  <span className="text-[11px] font-black text-white">{city}</span>
                </div>
                <span className="text-sm font-black text-primary">{(count as number)} عميل</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="bg-slate-900/50 p-8 rounded-[3rem] border border-white/5 space-y-6">
        <h3 className="text-lg font-black text-white">جميع الطلبات</h3>
        {orders.length === 0 ? (
          <div className="py-20 text-center opacity-30">
            <span className="text-7xl block mb-4">📦</span>
            <p className="font-black text-xl">لا توجد طلبات لعرضها.</p>
          </div>
        ) : (
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-right whitespace-nowrap">
              <thead>
                <tr className="text-[10px] font-black uppercase text-slate-400 border-b border-white/5">
                  <th className="p-3">ID</th>
                  <th className="p-3">العميل</th>
                  <th className="p-3">الموديل</th>
                  <th className="p-3">القماش</th>
                  <th className="p-3">السعر</th>
                  <th className="p-3">الحالة</th>
                  <th className="p-3">التاريخ</th>
                  <th className="p-3">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order, index) => (
                  <tr key={order.id} className={`group text-sm font-medium ${index % 2 === 0 ? 'bg-slate-800/20' : ''} hover:bg-slate-800/40 transition-all border-b border-white/5 last:border-b-0`}>
                    <td className="p-3 font-mono text-xs text-slate-500">{order.id}</td>
                    <td className="p-3 text-white">{order.customerName}</td>
                    <td className="p-3 text-white">
                      {order.details.style ? (order.details.style as string).replace(/_/g, ' ') : 'غير محدد'}
                    </td>
                    <td className="p-3 text-slate-300">{order.details.fabric?.name || 'غير محدد'}</td>
                    <td className="p-3 text-primary font-black">{order.details.totalPrice} ر.س</td>
                    <td className="p-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-black ${
                        order.status === 'COMPLETED' ? 'bg-emerald-500/20 text-emerald-500' :
                        order.status === 'PROCESSING' ? 'bg-indigo-500/20 text-indigo-500' :
                        order.status === 'SHIPPED' ? 'bg-cyan-500/20 text-cyan-500' :
                        'bg-amber-500/20 text-amber-500'
                      }`}>
                        {order.status === 'PENDING' ? 'قيد الانتظار' :
                         order.status === 'PROCESSING' ? 'قيد التجهيز' :
                         order.status === 'SHIPPED' ? 'تم الشحن' :
                         'مكتمل'}
                      </span>
                    </td>
                    <td className="p-3 text-slate-500 text-xs">{new Date(order.createdAt).toLocaleDateString('ar-SA')}</td>
                    <td className="p-3">
                      <button 
                        onClick={() => exportOrderToPDF(order)}
                        className="bg-emerald-500/10 text-emerald-500 px-4 py-2 rounded-xl text-xs font-black hover:bg-emerald-500 hover:text-white transition-all"
                      >
                        تصدير PDF
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};

const StatCard = ({ label, val, icon, color }: any) => {
  const colorMap: any = {
    emerald: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    primary: 'bg-primary/10 text-primary border-primary/20',
    amber: 'bg-amber-500/10 text-amber-500 border-amber-500/20'
  };

  return (
    <div className={`p-8 rounded-[2.5rem] border ${colorMap[color]} shadow-xl flex items-center justify-between group hover:scale-[1.02] transition-transform`}>
      <div className="text-right">
        <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block mb-2">{label}</span>
        <span className="text-3xl font-black text-white">{val}</span>
      </div>
      <div className="w-16 h-16 rounded-3xl bg-slate-900 border border-white/5 flex items-center justify-center text-4xl shadow-inner group-hover:rotate-6 transition-transform">
        {icon}
      </div>
    </div>
  );
};
