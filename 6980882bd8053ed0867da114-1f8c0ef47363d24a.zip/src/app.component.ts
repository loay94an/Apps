import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Measurements, PatternModel } from './models/pattern.model';

import { MeasurementsComponent } from './components/measurements/measurements.component';
import { PatternViewerComponent } from './components/pattern-viewer/pattern-viewer.component';
import { PatternDraftingComponent } from './components/pattern-drafting/pattern-drafting.component';
import { AiDesignComponent } from './components/ai-design/ai-design.component';
import { CustomDesignComponent } from './components/custom-design/custom-design.component';


type WizardStep = 'intro' | 'drafting' | 'ai-design' | 'custom-design' | 'measurements' | 'pattern';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MeasurementsComponent,
    PatternViewerComponent,
    PatternDraftingComponent,
    AiDesignComponent,
    CustomDesignComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  currentStep = signal<WizardStep>('intro');
  
  // State for AI-driven flows
  selectedModel = signal<PatternModel | null>(null);
  finalMeasurements = signal<Measurements | null>(null);
  
  startDrafting(): void {
    this.currentStep.set('drafting');
  }

  startAiDesign(): void {
    this.currentStep.set('ai-design');
  }

  startCustomDesign(): void {
    this.currentStep.set('custom-design');
  }

  onAnalysisComplete(model: PatternModel): void {
    this.selectedModel.set(model);
    this.currentStep.set('measurements');
  }
  
  onMeasurementsReady(measurements: Measurements): void {
    this.finalMeasurements.set(measurements);
    this.currentStep.set('pattern');
  }

  goBack(): void {
    const current = this.currentStep();
    switch (current) {
      case 'pattern':
        this.currentStep.set('measurements');
        break;
      case 'measurements':
        const model = this.selectedModel();
        // For AI flows, going back from measurements means restarting that specific AI flow
        if (model?.id.startsWith('ai-')) {
          this.currentStep.set('ai-design');
        } else if (model?.id.startsWith('custom-')) {
          this.currentStep.set('custom-design');
        } else {
           this.reset(); // Should not happen, but as a fallback
        }
        break;
      // For top-level tools, back always goes to intro
      case 'drafting':
      case 'ai-design':
      case 'custom-design':
        this.reset();
        break;
    }
  }

  reset(): void {
    this.currentStep.set('intro');
    this.selectedModel.set(null);
    this.finalMeasurements.set(null);
  }
}