import React from 'react';
import { Measurements } from '../types';

interface MeasurementTableProps {
  measurements: Measurements;
  onChange: (key: string, value: number) => void;
}

const MeasurementTable: React.FC<MeasurementTableProps> = ({ measurements, onChange }) => {
  if (!measurements || Object.keys(measurements).length === 0) {
    return (
      <div className="p-4 text-center text-slate-400 text-xs italic bg-slate-50 rounded-xl border border-dashed border-slate-200">
        جاري تحميل بيانات القياسات...
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-100 bg-white overflow-hidden shadow-sm">
      <table className="w-full text-right text-xs">
        <thead className="bg-slate-50 text-slate-400 border-b border-slate-100">
          <tr>
            <th className="px-3 py-2.5 font-bold uppercase tracking-tighter">القياس الأساسي</th>
            <th className="px-3 py-2.5 text-center font-bold uppercase tracking-tighter">سم</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50">
          {Object.entries(measurements).map(([key, val]) => (
            <tr key={key} className="hover:bg-slate-50/50 transition-colors group">
              <td className="px-3 py-2.5 text-slate-700 font-medium whitespace-nowrap">
                {key.replace(/_/g, ' ')}
              </td>
              <td className="px-3 py-2.5 text-center">
                <input
                  type="number"
                  step="0.1"
                  value={val}
                  onChange={(e) => onChange(key, parseFloat(e.target.value) || 0)}
                  className="w-16 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1.5 text-center text-secondary font-bold focus:outline-none focus:ring-2 focus:ring-secondary/20 focus:border-secondary focus:bg-white transition-all group-hover:border-secondary/30"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MeasurementTable;