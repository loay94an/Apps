import { Component, ChangeDetectionStrategy, output, signal, computed, inject, ElementRef, afterNextRender, effect, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Category, Measurements, PatternModel, PatternData, StandardSize } from '../../models/pattern.model';
import { PatternService } from '../../services/pattern.service';

@Component({
  selector: 'app-pattern-drafting',
  imports: [CommonModule],
  templateUrl: './pattern-drafting.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PatternDraftingComponent {
  back = output<void>();

  private patternService = inject(PatternService);
  private elementRef = inject(ElementRef<HTMLElement>);
  private injector = inject(Injector);

  // --- UI STATE SIGNALS ---
  draftingStep = signal<'model' | 'preview'>('model');
  showMeasurements = signal<boolean>(true);

  // --- STATE SIGNALS ---
  selectedCategory = signal<Category>('woman');
  selectedChildGender = signal<'boy' | 'girl'>('girl');
  selectedModelId = signal<string | null>(null);
  selectedSleeveType = signal<'basic' | 'puff' | 'twopiece' | 'darted' | 'bell' | 'bishop' | null>(null);
  availableSleeveOptions = signal<('basic' | 'puff' | 'twopiece' | 'darted' | 'bell' | 'bishop')[]>([]);
  selectedCollarType = signal<'stand' | 'mandarin' | 'shawl' | 'notch' | null>(null);
  availableCollarOptions = signal<('stand' | 'mandarin' | 'shawl' | 'notch')[]>([]);
  measurements = signal<Measurements>({
    bust: 92, waist: 74, hips: 98, shoulderWidth: 40, pieceLength: 60, 
    sleeveLength: 58, armCircumference: 30, inlegLength: 78, 
    waistToFloor: 105, shoulderToCrotch: 76, sleevePuffRatio: 1.5, neckCircumference: 38
  });
  selectedStandardSizeName = signal<string | null>(null);
  sewingNotes = signal<string>('');
  
  // --- View State Signals ---
  zoomLevel = signal(1);
  panX = signal(0);
  panY = signal(0);
  isPanning = signal(false);

  // --- Private state for interactions ---
  private panStart = { x: 0, y: 0 };
  private lastPan = { x: 0, y: 0 };
  private pinchStartDistance = 0;
  private pinchStartCenter = { x: 0, y: 0 };
  private lastZoom = 1;

  sleeveTypeLabels: { [key: string]: string } = {
    basic: 'كم أساسي',
    puff: 'كم منفوخ',
    twopiece: 'كم قطعتين',
    darted: 'كم ببنسة (تايلور)',
    bell: 'كم جرس',
    bishop: 'كم أسقف'
  };
  
  collarTypeLabels: { [key: string]: string } = {
    stand: 'ياقة قميص (ستاند)',
    mandarin: 'ياقة ماندرين',
    shawl: 'ياقة شال',
    notch: 'ياقة بيك (نوتش)'
  };

  measurementLabels: { [key in keyof Measurements]: string } = {
    bust: 'محيط الصدر', waist: 'محيط الخصر', hips: 'محيط الأرداف',
    shoulderWidth: 'عرض الكتف', pieceLength: 'طول القطعة', sleeveLength: 'طول الكم',
    armCircumference: 'محيط الذراع', inlegLength: 'طول الساق الداخلي', waistToFloor: 'الطول من الخصر للأرض',
    shoulderToCrotch: 'طول الجذع (من الكتف للحجر)', sleevePuffRatio: 'نسبة كشكشة الكم',
    neckCircumference: 'محيط الرقبة'
  };

  allMeasurementKeys = Object.keys(this.measurementLabels) as (keyof Measurements)[];

  private womanStandardSizes: StandardSize[] = [
    { name: '38', numericSize: '38', measurements: { neckCircumference: 30, bust: 82, waist: 64, hips: 92, waistToFloor: 102, inlegLength: 80, shoulderWidth: 39, pieceLength: 61, sleeveLength: 59.5, armCircumference: 29.5, shoulderToCrotch: 76, sleevePuffRatio: 1 }},
    { name: '40', numericSize: '40', measurements: { neckCircumference: 31.2, bust: 86, waist: 68, hips: 96, waistToFloor: 103, inlegLength: 80, shoulderWidth: 40, pieceLength: 62, sleeveLength: 60, armCircumference: 31, shoulderToCrotch: 77, sleevePuffRatio: 1 }},
    { name: '42', numericSize: '42', measurements: { neckCircumference: 32.5, bust: 92, waist: 72, hips: 100, waistToFloor: 104, inlegLength: 81, shoulderWidth: 41, pieceLength: 63, sleeveLength: 60.5, armCircumference: 32.5, shoulderToCrotch: 78, sleevePuffRatio: 1 }},
    { name: '44', numericSize: '44', measurements: { neckCircumference: 33.7, bust: 96, waist: 76, hips: 104, waistToFloor: 105, inlegLength: 81, shoulderWidth: 42, pieceLength: 64, sleeveLength: 61, armCircumference: 34, shoulderToCrotch: 79, sleevePuffRatio: 1 }},
    { name: '46', numericSize: '46', measurements: { neckCircumference: 35, bust: 100, waist: 80, hips: 108, waistToFloor: 106, inlegLength: 81, shoulderWidth: 43, pieceLength: 65, sleeveLength: 61.5, armCircumference: 35.5, shoulderToCrotch: 80, sleevePuffRatio: 1 }},
    { name: '48', numericSize: '48', measurements: { neckCircumference: 36.2, bust: 104, waist: 84, hips: 112, waistToFloor: 107, inlegLength: 81.5, shoulderWidth: 44, pieceLength: 66, sleeveLength: 62, armCircumference: 37, shoulderToCrotch: 81, sleevePuffRatio: 1 }},
    { name: '50', numericSize: '50', measurements: { neckCircumference: 37.5, bust: 108, waist: 88, hips: 116, waistToFloor: 108, inlegLength: 82, shoulderWidth: 45, pieceLength: 67, sleeveLength: 62.5, armCircumference: 38.5, shoulderToCrotch: 82, sleevePuffRatio: 1 }},
    { name: '52', numericSize: '52', measurements: { neckCircumference: 38.7, bust: 112, waist: 92, hips: 120, waistToFloor: 109, inlegLength: 82, shoulderWidth: 46, pieceLength: 68, sleeveLength: 63, armCircumference: 40, shoulderToCrotch: 83, sleevePuffRatio: 1 }},
    { name: '54', numericSize: '54', measurements: { neckCircumference: 40, bust: 116, waist: 96, hips: 124, waistToFloor: 110, inlegLength: 83, shoulderWidth: 47, pieceLength: 69, sleeveLength: 63, armCircumference: 41.5, shoulderToCrotch: 84, sleevePuffRatio: 1 }},
    { name: '56', numericSize: '56', measurements: { neckCircumference: 41.2, bust: 120, waist: 100, hips: 128, waistToFloor: 111, inlegLength: 83, shoulderWidth: 48, pieceLength: 70, sleeveLength: 63.5, armCircumference: 43, shoulderToCrotch: 85, sleevePuffRatio: 1 }},
    { name: '58', numericSize: '58', measurements: { neckCircumference: 42.5, bust: 124, waist: 104, hips: 132, waistToFloor: 112, inlegLength: 84, shoulderWidth: 49, pieceLength: 71, sleeveLength: 63.5, armCircumference: 44.5, shoulderToCrotch: 86, sleevePuffRatio: 1 }},
  ];

  private manStandardSizes: StandardSize[] = [
    { name: '38', numericSize: '38', measurements: { neckCircumference: 31.5, bust: 84, waist: 66, hips: 88, shoulderWidth: 36, pieceLength: 75, sleeveLength: 58, armCircumference: 34, waistToFloor: 102, inlegLength: 80, shoulderToCrotch: 78, sleevePuffRatio: 1 }},
    { name: '40', numericSize: '40', measurements: { neckCircumference: 32.5, bust: 88, waist: 70, hips: 92, shoulderWidth: 36, pieceLength: 75, sleeveLength: 59.5, armCircumference: 35, waistToFloor: 103, inlegLength: 80, shoulderToCrotch: 79, sleevePuffRatio: 1 }},
    { name: '42', numericSize: '42', measurements: { neckCircumference: 34, bust: 92, waist: 74, hips: 96, shoulderWidth: 38, pieceLength: 75, sleeveLength: 59.5, armCircumference: 36, waistToFloor: 104, inlegLength: 81, shoulderToCrotch: 80, sleevePuffRatio: 1 }},
    { name: '44', numericSize: '44', measurements: { neckCircumference: 35, bust: 96, waist: 78, hips: 98, shoulderWidth: 39, pieceLength: 76, sleeveLength: 60.5, armCircumference: 37, waistToFloor: 105, inlegLength: 81.5, shoulderToCrotch: 81.5, sleevePuffRatio: 1 }},
    { name: '46', numericSize: '46', measurements: { neckCircumference: 36, bust: 100, waist: 82, hips: 102, shoulderWidth: 40, pieceLength: 77, sleeveLength: 61.5, armCircumference: 38, waistToFloor: 106, inlegLength: 82, shoulderToCrotch: 83, sleevePuffRatio: 1 }},
    { name: '48', numericSize: '48', measurements: { neckCircumference: 37.5, bust: 104, waist: 86, hips: 106, shoulderWidth: 42, pieceLength: 77, sleeveLength: 61.5, armCircumference: 40, waistToFloor: 107, inlegLength: 82.5, shoulderToCrotch: 84.5, sleevePuffRatio: 1 }},
    { name: '50', numericSize: '50', measurements: { neckCircumference: 39, bust: 108, waist: 90, hips: 110, shoulderWidth: 44, pieceLength: 78, sleeveLength: 62.5, armCircumference: 41, waistToFloor: 108, inlegLength: 83, shoulderToCrotch: 86, sleevePuffRatio: 1 }},
    { name: '52', numericSize: '52', measurements: { neckCircumference: 40, bust: 112, waist: 94, hips: 114, shoulderWidth: 44, pieceLength: 78, sleeveLength: 62.5, armCircumference: 42, waistToFloor: 109, inlegLength: 83, shoulderToCrotch: 87.5, sleevePuffRatio: 1 }},
    { name: '54', numericSize: '54', measurements: { neckCircumference: 41, bust: 116, waist: 98, hips: 116, shoulderWidth: 44, pieceLength: 79, sleeveLength: 62.5, armCircumference: 42.5, waistToFloor: 110, inlegLength: 83, shoulderToCrotch: 89, sleevePuffRatio: 1 }},
    { name: '56', numericSize: '56', measurements: { neckCircumference: 42.5, bust: 120, waist: 102, hips: 120, shoulderWidth: 46, pieceLength: 79, sleeveLength: 63.5, armCircumference: 43, waistToFloor: 111, inlegLength: 84, shoulderToCrotch: 90.5, sleevePuffRatio: 1 }},
    { name: '58', numericSize: '58', measurements: { neckCircumference: 44, bust: 124, waist: 106, hips: 124, shoulderWidth: 46, pieceLength: 80, sleeveLength: 63.5, armCircumference: 44, waistToFloor: 112, inlegLength: 84, shoulderToCrotch: 92, sleevePuffRatio: 1 }},
  ];

  private childStandardSizes: StandardSize[] = [
    { name: 'سنتان', numericSize: '2', measurements: { neckCircumference: 22, bust: 58, waist: 52, hips: 64, pieceLength: 26, sleeveLength: 24, waistToFloor: 60, inlegLength: 49, shoulderWidth: 23, armCircumference: 17, shoulderToCrotch: 42, sleevePuffRatio: 1 }},
    { name: '3 سنوات', numericSize: '3', measurements: { neckCircumference: 23, bust: 57, waist: 53, hips: 66, pieceLength: 27, sleeveLength: 26, waistToFloor: 64, inlegLength: 52, shoulderWidth: 24, armCircumference: 17.5, shoulderToCrotch: 44, sleevePuffRatio: 1 }},
    { name: '4 سنوات', numericSize: '4', measurements: { neckCircumference: 24.5, bust: 58, waist: 54, hips: 68, pieceLength: 28, sleeveLength: 28, waistToFloor: 68, inlegLength: 55, shoulderWidth: 25, armCircumference: 18, shoulderToCrotch: 46, sleevePuffRatio: 1 }},
    { name: '5 سنوات', numericSize: '5', measurements: { neckCircumference: 25, bust: 60, waist: 55, hips: 70, pieceLength: 29, sleeveLength: 30, waistToFloor: 72, inlegLength: 58, shoulderWidth: 26, armCircumference: 19, shoulderToCrotch: 48, sleevePuffRatio: 1 }},
    { name: '6 سنوات', numericSize: '6', measurements: { neckCircumference: 25.5, bust: 62, waist: 56, hips: 72, pieceLength: 30, sleeveLength: 32, waistToFloor: 76, inlegLength: 62, shoulderWidth: 27, armCircumference: 20, shoulderToCrotch: 50, sleevePuffRatio: 1 }},
    { name: '7 سنوات', numericSize: '7', measurements: { neckCircumference: 26, bust: 64, waist: 57, hips: 74, pieceLength: 31, sleeveLength: 34, waistToFloor: 80, inlegLength: 64, shoulderWidth: 28, armCircumference: 21, shoulderToCrotch: 52, sleevePuffRatio: 1 }},
    { name: '8 سنوات', numericSize: '8', measurements: { neckCircumference: 27, bust: 66, waist: 58, hips: 76, pieceLength: 32, sleeveLength: 36, waistToFloor: 84, inlegLength: 67, shoulderWidth: 29, armCircumference: 22, shoulderToCrotch: 54, sleevePuffRatio: 1 }},
    { name: '10 سنوات', numericSize: '10', measurements: { neckCircumference: 27, bust: 70, waist: 62, hips: 78, pieceLength: 34, sleeveLength: 37, waistToFloor: 88, inlegLength: 72, shoulderWidth: 31, armCircumference: 24, shoulderToCrotch: 58, sleevePuffRatio: 1 }},
    { name: '12 سنة', numericSize: '12', measurements: { neckCircumference: 28, bust: 72, waist: 64, hips: 82, pieceLength: 36, sleeveLength: 38, waistToFloor: 92, inlegLength: 74, shoulderWidth: 33, armCircumference: 26, shoulderToCrotch: 62, sleevePuffRatio: 1 }},
    { name: '14 سنة', numericSize: '14', measurements: { neckCircumference: 29, bust: 80, waist: 65, hips: 86, pieceLength: 38, sleeveLength: 40, waistToFloor: 96, inlegLength: 76, shoulderWidth: 35, armCircumference: 28, shoulderToCrotch: 66, sleevePuffRatio: 1 }},
    { name: '16 سنة', numericSize: '16', measurements: { neckCircumference: 30, bust: 84, waist: 66, hips: 90, pieceLength: 40, sleeveLength: 42, waistToFloor: 100, inlegLength: 79, shoulderWidth: 36, armCircumference: 29, shoulderToCrotch: 68, sleevePuffRatio: 1 }},
  ];

  private allModels: PatternModel[] = [
    // Woman
    { id: 'w-blouse', name: 'بلوزة أساسية', category: 'woman', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'bell', 'bishop'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-blouse-darted', name: 'بلوزة ببنسات', category: 'woman', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'صعب', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'darted', 'bell', 'bishop'], collarType: 'stand', availableCollarTypes: ['stand', 'shawl'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-dress-darted', name: 'فستان ببنسات', category: 'woman', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'صعب', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'darted', 'bell', 'bishop'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-skirt', name: 'تنورة نصف كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'w-skirt-darted', name: 'تنورة مستقيمة (بنسل)', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'w-blouse-raglan', name: 'بلوزة بكم رجلان', category: 'woman', imageUrl: 'https://api.iconify.design/icon-park-outline:raglan-sleeve.svg', difficulty: 'صعب', sleeveType: 'raglan', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-kimono', name: 'كيمونو', category: 'woman', imageUrl: 'https://api.iconify.design/iconoir:kaftan.svg', difficulty: 'متوسط', sleeveType: 'kimono', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength'] },
    { id: 'w-dress', name: 'فستان أساسي', category: 'woman', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'bell', 'bishop'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-skirt-pleated', name: 'تنورة بكسرات', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-skirt-circle', name: 'تنورة كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:circle-slice-8.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-skirt-double-circle', name: 'تنورة دوبل كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:circle-double.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-pants', name: 'بنطال', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'w-jumpsuit', name: 'جمبسوت', category: 'woman', imageUrl: 'https://api.iconify.design/gis:jumpsuit.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderToCrotch', 'inlegLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-abaya', name: 'عباءة', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:robe.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength'] },
    { id: 'w-cardigan', name: 'كارديغان', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:cardigan.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'shawl', availableSleeveTypes: ['basic', 'puff', 'bell'], requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'w-tshirt', name: 'تيشيرت', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew-outline.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth', 'sleeveLength', 'armCircumference'] },
    { id: 'w-coat', name: 'معطف', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:coat-rack.svg', difficulty: 'صعب', sleeveType: 'twopiece', availableSleeveTypes: ['basic', 'twopiece'], collarType: 'notch', availableCollarTypes: ['notch', 'shawl'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },

    // Man
    { id: 'm-shirt', name: 'قميص', category: 'man', imageUrl: 'https://api.iconify.design/ion:shirt-outline.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'stand', availableCollarTypes: ['stand', 'mandarin'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-pants', name: 'بنطال', category: 'man', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'صعب', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'm-tshirt', name: 'تيشيرت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth', 'sleeveLength', 'armCircumference'] },
    { id: 'm-jacket', name: 'جاكيت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:jacket.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'm-jacket-formal', name: 'جاكيت رسمي', category: 'man', imageUrl: 'https://api.iconify.design/mdi:jacket-outline.svg', difficulty: 'احترافي', sleeveType: 'twopiece', availableSleeveTypes: ['basic', 'twopiece'], collarType: 'notch', availableCollarTypes: ['notch', 'shawl'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-thobe', name: 'ثوب', category: 'man', imageUrl: 'https://api.iconify.design/iconoir:kaftan.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'mandarin', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'neckCircumference'] },
    { id: 'm-polo', name: 'قميص بولو', category: 'man', imageUrl: 'https://api.iconify.design/mdi:polo.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'stand', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-shorts', name: 'شورت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:shorts.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'inlegLength', 'waistToFloor'] },
    { id: 'm-hoodie', name: 'هودي', category: 'man', imageUrl: 'https://api.iconify.design/mdi:hoodie.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'pieceLength', 'sleeveLength', 'armCircumference', 'shoulderWidth'] },
    { id: 'm-pajamas', name: 'طقم بيجاما', category: 'man', imageUrl: 'https://api.iconify.design/mdi:pajamas.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'inlegLength', 'waistToFloor'] },
    { id: 'm-coat', name: 'معطف', category: 'man', imageUrl: 'https://api.iconify.design/mdi:coat-rack.svg', difficulty: 'صعب', sleeveType: 'twopiece', availableSleeveTypes: ['basic', 'twopiece'], collarType: 'notch', availableCollarTypes: ['notch', 'shawl'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },

    // Child - Girl
    { id: 'c-dress', name: 'فستان', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'bell', 'bishop'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-skirt-girl', name: 'تنورة', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'c-blouse-girl', name: 'بلوزة', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'bell', 'bishop'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-leggings', name: 'بنطال ضيق (ليقنز)', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'inlegLength', 'waistToFloor'] },
    { id: 'c-jumpsuit-girl', name: 'أفرول طويل (جمبسوت)', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/gis:jumpsuit.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderToCrotch', 'inlegLength', 'sleeveLength', 'armCircumference', 'shoulderWidth'] },
    { id: 'c-romper-girl', name: 'أفرول (رومبير)', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/material-symbols:romper.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'hips', 'shoulderWidth', 'shoulderToCrotch', 'sleeveLength', 'armCircumference'] },
    { id: 'c-pajamas-girl', name: 'طقم بيجاما', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:pajamas.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference', 'shoulderWidth', 'waist', 'hips', 'inlegLength', 'waistToFloor'] },
    { id: 'c-coat-girl', name: 'معطف', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:coat-rack.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },

    // Child - Boy
    { id: 'c-shirt', name: 'قميص', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/ion:shirt-outline.svg', difficulty: 'سهل', sleeveType: 'basic', collarType: 'stand', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'c-pants', name: 'بنطال', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength'] },
    { id: 'c-tshirt-boy', name: 'تيشيرت', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth', 'sleeveLength', 'armCircumference'] },
    { id: 'c-shorts-boy', name: 'شورت', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:shorts.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'inlegLength', 'waistToFloor'] },
    { id: 'c-hoodie-boy', name: 'هودي', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:hoodie.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference', 'shoulderWidth'] },
    { id: 'c-pajamas-boy', name: 'طقم بيجاما', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pajamas.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference', 'shoulderWidth', 'waist', 'hips', 'inlegLength', 'waistToFloor'] },
    { id: 'c-vest-boy', name: 'فيست', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:vest.svg', difficulty: 'متوسط', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth'] },
    { id: 'c-overalls-boy', name: 'دنغري', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/gis:overalls.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'inlegLength', 'waistToFloor', 'shoulderToCrotch'] },
    { id: 'c-sweatpants-boy', name: 'بنطال رياضي', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'c-robe-boy', name: 'روب', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:robe.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'shoulderWidth'] },
  ];

  constructor() {
    effect(() => {
        if (this.draftingStep() === 'preview') {
            afterNextRender(() => {
                this.calculateInitialZoom();
            });
        }
    }, { injector: this.injector });

    effect(() => {
      const key = this.patternStorageKey();
      const notes = this.sewingNotes();
      // Only save if we are in preview mode and have a valid key
      if (this.draftingStep() === 'preview' && key) {
        localStorage.setItem(key, notes);
      }
    }, { injector: this.injector });
  }

  private simpleHash(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0; // Convert to 32bit integer
    }
    return hash.toString(16);
  }

  // --- COMPUTED SIGNALS ---
  patternStorageKey = computed<string>(() => {
      const model = this.currentModel();
      if (!model) return '';
      const measurementsString = JSON.stringify(this.measurements());
      const measurementsHash = this.simpleHash(measurementsString);
      return `pattern-notes:${model.id}:${measurementsHash}`;
  });

  standardSizes = computed<StandardSize[]>(() => {
    switch(this.selectedCategory()) {
      case 'child': return this.childStandardSizes;
      case 'man': return this.manStandardSizes;
      case 'woman': return this.womanStandardSizes;
      default: return this.womanStandardSizes;
    }
  });

  availableModels = computed(() => this.allModels.filter(m => {
    if (m.category !== this.selectedCategory()) return false;
    if (this.selectedCategory() === 'child' && m.gender !== this.selectedChildGender()) return false;
    return true;
  }));

  currentModel = computed(() => {
    const modelId = this.selectedModelId();
    if (!modelId) return null;
    return this.allModels.find(m => m.id === modelId) ?? null;
  });
  
  requiredMeasurements = computed(() => {
    const model = this.currentModel();
    if (!model) return [];
    
    const reqs = new Set(model.requiredMeasurements);
    const sleeveType = model.availableSleeveTypes ? this.selectedSleeveType() : model.sleeveType;
    const collarType = model.availableCollarTypes ? this.selectedCollarType() : model.collarType;

    if (sleeveType === 'puff') {
      reqs.add('sleevePuffRatio');
    }

    if (collarType) {
      reqs.add('neckCircumference');
    }

    return Array.from(reqs);
  });

  patternData = computed<PatternData>(() => {
    const model = this.currentModel();
    if (!model) return { paths: [], width: 100, height: 100 };

    const finalSleeveType = model.availableSleeveTypes ? this.selectedSleeveType() : model.sleeveType;
    const finalCollarType = model.availableCollarTypes ? this.selectedCollarType() : model.collarType;
    
    const modelForGeneration: PatternModel = { ...model, sleeveType: finalSleeveType as any, collarType: finalCollarType as any };

    return this.patternService.generatePattern(modelForGeneration, this.measurements(), { showMeasurements: this.showMeasurements() });
  });

  // --- EVENT HANDLERS ---
  onCategoryChange(event: Event) {
    const newCategory = (event.target as HTMLSelectElement).value as Category;
    this.selectedCategory.set(newCategory);
    this.selectedModelId.set(null);
    this.selectedStandardSizeName.set(null);
  }

  onChildGenderChange(event: Event) {
    this.selectedChildGender.set((event.target as HTMLInputElement).value as 'boy' | 'girl');
    this.selectedModelId.set(null);
    this.selectedStandardSizeName.set(null);
  }

  selectStandardSize(size: StandardSize): void {
    this.measurements.update(m => ({...m, ...size.measurements}));
    this.selectedStandardSizeName.set(size.name);
  }

  selectModel(model: PatternModel): void {
    this.selectedModelId.set(model.id);
    if (model.availableSleeveTypes && model.sleeveType) {
        this.selectedSleeveType.set(model.sleeveType as 'basic' | 'puff' | 'twopiece' | 'darted' | 'bell' | 'bishop');
        this.availableSleeveOptions.set(model.availableSleeveTypes);
    } else {
        this.selectedSleeveType.set(null);
        this.availableSleeveOptions.set([]);
    }
    
    if (model.availableCollarTypes) {
      this.selectedCollarType.set(model.collarType ? model.collarType : model.availableCollarTypes[0] || null);
      this.availableCollarOptions.set(model.availableCollarTypes);
    } else {
      this.selectedCollarType.set(null);
      this.availableCollarOptions.set([]);
    }
  }

  goToPreview(): void {
    const key = this.patternStorageKey();
    if (key) {
      const savedNotes = localStorage.getItem(key) || '';
      this.sewingNotes.set(savedNotes);
    }
    this.draftingStep.set('preview');
  }

  goBackTo(step: 'model'): void {
    this.draftingStep.set(step);
  }

  updateMeasurement(field: keyof Measurements, value: string): void {
    this.measurements.update(m => ({ ...m, [field]: parseFloat(value) || 0 }));
    this.selectedStandardSizeName.set(null);
  }
  
  updateSleeveType(event: Event): void {
    const newSleeveType = (event.target as HTMLSelectElement).value as 'basic' | 'puff' | 'twopiece' | 'darted' | 'bell' | 'bishop';
    this.selectedSleeveType.set(newSleeveType);
  }

  updateCollarType(event: Event): void {
    const newCollarType = (event.target as HTMLSelectElement).value as 'stand' | 'mandarin' | 'shawl' | 'notch';
    this.selectedCollarType.set(newCollarType);
  }

  updateNotes(event: Event): void {
    const notes = (event.target as HTMLTextAreaElement).value;
    this.sewingNotes.set(notes);
  }

  printPattern = () => window.print();

  exportAsSvg(): void {
    const data = this.patternData();
    const styles = `<style>path{fill:none;}.stroke-red-600{stroke:#dc2626;}.fill-red-500\\/10{fill:rgba(239,68,68,0.1);}.stroke-blue-600{stroke:#2563eb;}.fill-blue-500\\/10{fill:rgba(59,130,246,0.1);}.stroke-green-600{stroke:#16a34a;}.fill-green-500\\/10{fill:rgba(34,197,94,0.1);}.stroke-purple-600{stroke:#9333ea;}.fill-purple-500\\/10{fill:rgba(168,85,247,0.1);}.stroke-pink-600{stroke:#db2777;}.fill-pink-500\\/10{fill:rgba(236,72,153,0.1);}.stroke-indigo-600{stroke:#4f46e5;}.fill-indigo-500\\/10{fill:rgba(99,102,241,0.1);}.stroke-teal-600{stroke:#0d9488;}.fill-teal-500\\/10{fill:rgba(20,184,166,0.1);}.stroke-cyan-600{stroke:#0891b2;}.fill-cyan-500\\/10{fill:rgba(6,182,212,0.1);}.stroke-orange-600{stroke:#f97316;}.fill-orange-500\\/10{fill:rgba(251,146,60,0.1);}.stroke-2{stroke-width:2px;}.stroke-black{stroke:#000;}.stroke-1{stroke-width:1px;}.stroke-dasharray{stroke-dasharray:5,5;}.fill-gray-700{fill:#374151;}.text-lg{font-size:18px;}.font-bold{font-weight:700;}.text-xs{font-size:12px;}.text-sm{font-size:14px;}.fill-slate-600{fill:#475569;}.stroke-slate-500{stroke:#64748b;}.stroke-slate-400{stroke:#94a3b8;}.fill-none{fill:none;}</style>`;
    const pathsHtml = data.paths.map(p => p.label ? `<text x="${p.x}" y="${p.y}" class="${p.class}" font-family="sans-serif" dominant-baseline="middle" text-anchor="middle">${p.label}</text>` : `<path d="${p.d}" class="${p.class}" fill-rule="evenodd" />`).join('');
    const fullSvg = `<svg width="${data.width}" height="${data.height}" viewBox="0 0 ${data.width} ${data.height}" xmlns="http://www.w3.org/2000/svg">${styles}${pathsHtml}</svg>`;
    const blob = new Blob([fullSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pattern-draft.svg`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // --- Zoom Controls & Logic ---
  private zoomAtPoint(scaleAmount: number, pointX: number, pointY: number): void {
    const oldZoom = this.zoomLevel();
    const newZoom = Math.max(0.1, Math.min(oldZoom * scaleAmount, 10));
    
    const worldX = (pointX - this.panX()) / oldZoom;
    const worldY = (pointY - this.panY()) / oldZoom;
    
    const newPanX = pointX - worldX * newZoom;
    const newPanY = pointY - worldY * newZoom;

    this.zoomLevel.set(newZoom);
    this.panX.set(newPanX);
    this.panY.set(newPanY);
  }
  
  private calculateInitialZoom(): void {
    const container = this.elementRef.nativeElement.querySelector('.printable-area');
    if (!container) return;

    const data = this.patternData();
    const containerWidth = container.clientWidth;
    const containerHeight = container.clientHeight;
    
    const padding = 120; // Increased padding for better margins
    const effectiveWidth = containerWidth - padding;
    const effectiveHeight = containerHeight - padding;

    if (data.width <= 0 || data.height <= 0 || effectiveWidth <= 0 || effectiveHeight <= 0) {
        this.zoomLevel.set(1);
        this.panX.set(0);
        this.panY.set(0);
        return;
    }

    const scaleX = effectiveWidth / data.width;
    const scaleY = effectiveHeight / data.height;

    const initialZoom = Math.min(scaleX, scaleY, 1); // Cap at 1 to prevent zooming in on small patterns
    this.zoomLevel.set(initialZoom);
    
    // Center the pattern
    const scaledWidth = data.width * initialZoom;
    const scaledHeight = data.height * initialZoom;
    this.panX.set((containerWidth - scaledWidth) / 2);
    this.panY.set((containerHeight - scaledHeight) / 2);
  }

  // --- Wheel Event for Zooming ---
  onWheel(event: WheelEvent): void {
    event.preventDefault();
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const scaleAmount = event.deltaY > 0 ? 0.9 : 1.1;
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    this.zoomAtPoint(scaleAmount, mouseX, mouseY);
  }

  // --- Mouse Events for Panning ---
  onMouseDown(event: MouseEvent): void {
    if (event.button !== 0) return;
    event.preventDefault();
    this.isPanning.set(true);
    this.panStart.x = event.clientX;
    this.panStart.y = event.clientY;
    this.lastPan.x = this.panX();
    this.lastPan.y = this.panY();
  }

  onMouseMove(event: MouseEvent): void {
    if (!this.isPanning()) return;
    event.preventDefault();
    const dx = event.clientX - this.panStart.x;
    const dy = event.clientY - this.panStart.y;
    this.panX.set(this.lastPan.x + dx);
    this.panY.set(this.lastPan.y + dy);
  }

  onMouseUp(): void { this.isPanning.set(false); }
  onMouseLeave(): void { this.isPanning.set(false); }

  private getTouchDistance(touches: TouchList): number {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  private getTouchCenter(touches: TouchList): { x: number; y: number } {
    return {
      x: (touches[0].clientX + touches[1].clientX) / 2,
      y: (touches[0].clientY + touches[1].clientY) / 2,
    };
  }

  // --- Touch Events for Panning & Zooming ---
  onTouchStart(event: TouchEvent): void {
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    if (event.touches.length === 1) {
      this.isPanning.set(true);
      this.panStart.x = event.touches[0].clientX;
      this.panStart.y = event.touches[0].clientY;
      this.lastPan.x = this.panX();
      this.lastPan.y = this.panY();
    } else if (event.touches.length === 2) {
      this.isPanning.set(false); // Stop one-finger panning
      this.pinchStartDistance = this.getTouchDistance(event.touches);
      this.lastZoom = this.zoomLevel();
      const center = this.getTouchCenter(event.touches);
      this.pinchStartCenter = { x: center.x - rect.left, y: center.y - rect.top };
      this.lastPan = { x: this.panX(), y: this.panY() }; // Save pan state at start of pinch
    }
  }

  onTouchMove(event: TouchEvent): void {
    event.preventDefault();
    if (event.touches.length === 1 && this.isPanning()) {
      const dx = event.touches[0].clientX - this.panStart.x;
      const dy = event.touches[0].clientY - this.panStart.y;
      this.panX.set(this.lastPan.x + dx);
      this.panY.set(this.lastPan.y + dy);
    } else if (event.touches.length === 2 && this.pinchStartDistance > 0) {
      const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();

      // --- ZOOM ---
      const newDistance = this.getTouchDistance(event.touches);
      const scale = newDistance / this.pinchStartDistance;
      const newZoom = Math.max(0.1, Math.min(this.lastZoom * scale, 10));

      // --- PAN (to zoom towards pinch center) ---
      const newCenter = this.getTouchCenter(event.touches);
      const newCenterRelative = { x: newCenter.x - rect.left, y: newCenter.y - rect.top };

      const worldX = (this.pinchStartCenter.x - this.lastPan.x) / this.lastZoom;
      const worldY = (this.pinchStartCenter.y - this.lastPan.y) / this.lastZoom;

      const newPanX = newCenterRelative.x - worldX * newZoom;
      const newPanY = newCenterRelative.y - worldY * newZoom;

      this.zoomLevel.set(newZoom);
      this.panX.set(newPanX);
      this.panY.set(newPanY);
    }
  }

  onTouchEnd(event: TouchEvent): void {
    // Reset pinch state if we're no longer pinching
    if (this.pinchStartDistance > 0 && event.touches.length < 2) {
      this.pinchStartDistance = 0;
      this.lastZoom = this.zoomLevel();
      this.lastPan = { x: this.panX(), y: this.panY() };
    }

    // If one finger remains, (re)start panning
    if (event.touches.length === 1) {
      this.isPanning.set(true);
      this.panStart.x = event.touches[0].clientX;
      this.panStart.y = event.touches[0].clientY;
      this.lastPan = { x: this.panX(), y: this.panY() };
    } else {
      // 0 or 2+ touches means we stop panning
      this.isPanning.set(false);
    }
  }
}