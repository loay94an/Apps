import { Injectable } from '@angular/core';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // IMPORTANT: The API_KEY is injected via environment variables.
    // Do not hardcode or expose keys in the frontend code.
    if (!process.env.API_KEY) {
      throw new Error("API_KEY environment variable not set.");
    }
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  /**
   * Generates professional instructions for drawing and using a clothing pattern.
   */
  async getPatternDrawingInstructions(): Promise<string> {
    const prompt = `
      اشرح بالتفصيل كخبير خياطة محترف، الخطوات الكاملة لاستخدام باترون ملابس تم إنشاؤه بواسطة الكمبيوتر.
      يجب أن تكون التعليمات واضحة وموجهة لشخص لديه معرفة أساسية بالخياطة.
      
      قسم الشرح إلى المراحل التالية مع استخدام العناوين والقوائم النقطية:
      
      1.  **التحضير والطباعة:**
          *   كيفية طباعة الباترون متعدد الصفحات (PDF) بمقياس 1:1.
          *   التأكد من صحة المقياس باستخدام مربع الاختبار.
          *   كيفية تجميع وقص ولصق صفحات الباترون معًا.
      
      2.  **تجهيز القماش:**
          *   أهمية غسل وكي القماش قبل القص.
          *   كيفية تحديد اتجاه النسيج ووضع الباترون عليه بشكل صحيح.
          *   تثبيت قطع الباترون على القماش بالدبابيس.
      
      3.  **القص وإضافة علامات:**
          *   أهمية ترك هوامش الخياطة (seam allowance) إذا لم تكن مضافة.
          *   نصائح لقص القماش بدقة.
          *   كيفية نقل العلامات المهمة (مثل أماكن البنسات، نقاط الالتقاء) من الباترون إلى القماش.
      
      4.  **نصائح عامة للخياطة:**
          *   نصيحة حول أهمية خياطة قطعة تجريبية (muslin/toile).
          *   تذكير بمراجعة ترتيب خطوات الخياطة.
    `;

    try {
      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });
      return response.text;
    } catch (error) {
      console.error('Gemini API Error:', error);
      throw new Error('Failed to fetch instructions from Gemini API.');
    }
  }
}
