import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatternDraftingComponent } from './components/pattern-drafting/pattern-drafting.component';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    PatternDraftingComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
}
