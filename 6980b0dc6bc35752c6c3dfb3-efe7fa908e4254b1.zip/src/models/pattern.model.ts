export type Category = 'woman' | 'man' | 'child';

export interface PatternModel {
  id: string;
  name: string;
  category: Category;
  gender?: 'boy' | 'girl';
  imageUrl: string;
  difficulty: 'سهل' | 'متوسط' | 'صعب' | 'احترافي';
  requiredMeasurements: (keyof Measurements)[];
  sleeveType?: 'basic' | 'puff' | 'twopiece' | 'raglan' | 'kimono' | 'darted' | 'bell' | 'bishop' | null;
  collarType?: 'stand' | 'mandarin' | 'shawl' | 'notch' | null;
  availableSleeveTypes?: ('basic' | 'puff' | 'twopiece' | 'darted' | 'bell' | 'bishop')[];
  availableCollarTypes?: ('stand' | 'mandarin' | 'shawl' | 'notch')[];
}

export interface Measurements {
  bust: number;
  waist: number;
  hips: number;
  shoulderWidth: number;
  pieceLength: number;
  sleeveLength: number;
  armCircumference: number;
  inlegLength: number;
  waistToFloor: number;
  shoulderToCrotch: number;
  sleevePuffRatio?: number;
  neckCircumference?: number;
}

export interface StandardSize {
  name: string;
  numericSize: string;
  measurements: Measurements;
}

export interface SvgPath {
  d: string;
  class: string;
  label?: string;
  x?: number;
  y?: number;
}

export interface PatternData {
  paths: SvgPath[];
  width: number;
  height: number;
}