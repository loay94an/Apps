import { Component, ChangeDetectionStrategy, output } from '@angular/core';
import { CommonModule } from '@angular/common';

interface GenderOption {
  key: 'boy' | 'girl';
  name: string;
}

@Component({
  selector: 'app-child-gender-selector',
  imports: [CommonModule],
  templateUrl: './child-gender-selector.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChildGenderSelectorComponent {
  genderSelected = output<'boy' | 'girl'>();

  genders: GenderOption[] = [
    { key: 'girl', name: 'بنت' },
    { key: 'boy', name: 'ولد' },
  ];

  selectGender(gender: 'boy' | 'girl'): void {
    this.genderSelected.emit(gender);
  }
}
