import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Category, Measurements, PatternModel } from './models/pattern.model';

import { CategorySelectorComponent } from './components/category-selector/category-selector.component';
import { ModelSelectorComponent } from './components/model-selector/model-selector.component';
import { MeasurementsComponent } from './components/measurements/measurements.component';
import { PatternViewerComponent } from './components/pattern-viewer/pattern-viewer.component';
import { ChildGenderSelectorComponent } from './components/child-gender-selector/child-gender-selector.component';
import { OnlineSearchComponent } from './components/online-search/online-search.component';
import { PatternDraftingComponent } from './components/pattern-drafting/pattern-drafting.component';

type WizardStep = 'intro' | 'category' | 'child-gender' | 'model' | 'onlineSiteChoice' | 'measurements' | 'pattern' | 'drafting';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    CategorySelectorComponent,
    ModelSelectorComponent,
    MeasurementsComponent,
    PatternViewerComponent,
    ChildGenderSelectorComponent,
    OnlineSearchComponent,
    PatternDraftingComponent,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  currentStep = signal<WizardStep>('intro');
  
  selectedCategory = signal<Category | null>(null);
  selectedChildGender = signal<'boy' | 'girl' | null>(null);
  selectedModel = signal<PatternModel | null>(null);
  finalMeasurements = signal<Measurements | null>(null);
  
  startWizard(): void {
    this.currentStep.set('category');
  }

  startOnlineSearch(): void {
    this.currentStep.set('onlineSiteChoice');
  }

  startDrafting(): void {
    this.currentStep.set('drafting');
  }

  onCategorySelected(category: Category): void {
    this.selectedCategory.set(category);
    if (category === 'child') {
      this.currentStep.set('child-gender');
    } else {
      this.currentStep.set('model');
    }
  }

  onChildGenderSelected(gender: 'boy' | 'girl'): void {
    this.selectedChildGender.set(gender);
    this.currentStep.set('model');
  }

  onModelSelected(model: PatternModel): void {
    this.selectedModel.set(model);
    this.currentStep.set('measurements');
  }
  
  onMeasurementsReady(measurements: Measurements): void {
    this.finalMeasurements.set(measurements);
    this.currentStep.set('pattern');
  }

  goBack(): void {
    const current = this.currentStep();
    switch (current) {
      case 'pattern':
        this.currentStep.set('measurements');
        break;
      case 'measurements':
        const model = this.selectedModel();
        if (model?.id.startsWith('online-')) {
          this.reset(); // On online search flows, back from measurements is a reset.
        } else {
          this.currentStep.set('model');
        }
        break;
      case 'model':
        this.currentStep.set(this.selectedCategory() === 'child' ? 'child-gender' : 'category');
        break;
      case 'child-gender':
        this.currentStep.set('category');
        break;
      case 'category':
      case 'onlineSiteChoice':
      case 'drafting':
        this.reset();
        break;
    }
  }

  reset(): void {
    this.currentStep.set('intro');
    this.selectedCategory.set(null);
    this.selectedChildGender.set(null);
    this.selectedModel.set(null);
    this.finalMeasurements.set(null);
  }
}