import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { 
  Download, Eye, Info,
  Maximize2, Minimize2,
  ZoomIn, ZoomOut,
  LayoutTemplate, 
  X, Menu, Crosshair, Book,
  ChevronDown,
  Layers,
  Ruler,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  FileText,
  Star,
  Quote,
  Settings2,
  Scissors,
  CheckCircle2,
  Shirt,
  User,
  Activity
} from 'lucide-react';
import { Category, ChapterType, ModelType, Measurements, DrawResult, StyleConfig, PatternPath } from './types.ts';
import { DB, CATEGORY_STRUCTURE } from './constants.ts';
import { draftPattern } from './services/patternEngine.ts';
import MeasurementTable from './MeasurementTable.tsx';

// --- Exhaustive Book Summary Content reflecting the provided Table of Contents ---
const BOOK_SECTIONS = [
  {
    id: 'intro',
    title: 'المقدمة والأساس الهندي',
    icon: <Star className="text-amber-500" size={18} />,
    content: `تبدأ الموسوعة بوضع حجر الأساس في "هندسة الملابس". يوضح البروفيسور فتحي خليل أن الجسم البشري هو مجموعة من المنحنيات الهندسية التي يمكن قياسها بدقة.

يغطي هذا القسم (ص 1):
• كيفية أخذ القياسات بشكل احترافي.
• الأدوات الهندسية المطلوبة للرسم الفني.
• العلاقة بين القياسات الحيوية وخطوط الباترون المسطحة.`
  },
  {
    id: 'skirts_basic',
    title: 'موسوعة الجولنة (التنانير)',
    icon: <Layers className="text-purple-500" size={18} />,
    content: `يفصل الكتاب أنواع الجولنات من الصفحة 2 إلى 128:
• الجولنة العادية (الأساس): شرح توزيع بنس الوسط.
• الجولنة ذات الكرانيش والكسرات: قواعد حساب مساحات القماش.
• الجولنة البليسيه: الهندسة الدقيقة للثنيات المتساوية.
• الجولنة الكلوش وجونات الزفاف: استخدام المعادلات الدائرية (قطر الدائرة) لخلق اتساع انسيابي.`
  },
  {
    id: 'bodice_science',
    title: 'الكورساج والبلوزة',
    icon: <Settings2 className="text-blue-500" size={18} />,
    content: `القسم الهندسي الأكثر تعقيداً (ص 129 - 224):
• البلوزة والكورساج الأساسي: تشريح الجزء العلوي.
• الكورساج طبقاً لتكوين الأجسام: معالجة الانحناءات الخاصة وبروز الصدر.
• كورساج السيدة الممتلئة: قواعد خاصة لموازنة الأوزان الزائدة في القماش.
• الباترون الأساسي للبلوزة: تحويل الكورساج إلى قطعة ملابس مريحة.`
  },
  {
    id: 'sleeves_collars',
    title: 'الأكمام والكولات',
    icon: <Scissors className="text-orange-500" size={18} />,
    content: `فنون الربط التقني (ص 225 - 242):
• الأكمام: هندسة "رأس الكم" وعلاقتها بحردة الإبط لضمان حرية الحركة.
• الكولات: أنواع الياقات (المسطحة، المرتفعة، الشميزية) وقواعد رسم كل منها لضبط محيط الرقبة.`
  },
  {
    id: 'dresses_design',
    title: 'الفساتين والزي الإسلامي',
    icon: <Shirt className="text-emerald-500" size={18} />,
    content: `تصميم الموديلات المركبة (ص 243 - 384):
• فستان البرنسيس: قصة جمالية تقسم الباترون طولياً.
• الفستان السايب والبليزون: موديلات تعتمد على "التوسيع" والزم.
• الفستان الأمبير: رفع خط الوسط لأسفل الصدر.
• الزي الإسلامي: قواعد العباءات الفضفاضة مع الحفاظ على التوازن الهندسي.`
  },
  {
    id: 'trousers_engineering',
    title: 'البنطلونات والسالوبيت',
    icon: <Ruler className="text-red-500" size={18} />,
    content: `هندسة الحجر والسيقان (ص 385 - 480):
• البنطلون الحريمي والرجالي: الفرق الجوهري في "قعدة" البنطلون.
• الشورت والسالوبيت: دمج الكورساج مع البنطلون في قطعة واحدة.
• البنطلون الصغير: مراعاة نسب جسم الأطفال في الحركة.`
  },
  {
    id: 'jackets_coats',
    title: 'الجاكيت والبالطو (التفصيل الثقيل)',
    icon: <Activity className="text-indigo-500" size={18} />,
    content: `ذروة فن التفصيل (ص 481 - 660):
• الجاكيت الكلاسيك: هيكلة الأكتاف والبطانات الداخلية.
• كم الجاكيت: الكم المكون من قطعتين (الكم الرجالي) لراحة الكوع.
• البالطو والصديري: الطبقات الخارجية وقواعد الاتساع الإضافي.`
  },
  {
    id: 'traditional_home',
    title: 'العباءة والملابس المنزلية',
    icon: <User className="text-slate-500" size={18} />,
    content: `الراحة والأصالة (ص 661 - 1024):
• العباءة والكاب: هندسة المساحات الكبيرة من القماش.
• الكم الرجلان والجابونيز: قصات الأكمام المتصلة بالكتف.
• ملابس النوم (اللانجري): استخدام الأقمشة الرقيقة (الحرير والدانتيل) في الباترون.`
  },
  {
    id: 'men_children',
    title: 'الملابس الرجالية والأطفال',
    icon: <FileText className="text-blue-600" size={18} />,
    content: `تخصصات متنوعة (ص 1025 - 1180):
• الجلباب والروب الرجالي: الزي التقليدي بلمسة هندسية.
• القميص الرجالي: ضبط "الروبة" والياقة الصلبة.
• ملابس وبيجامة الأطفال: المتانة والراحة في الحركة الكثيرة.`
  },
  {
    id: 'technical_finishing',
    title: 'التطبيق العملي والتشطيب',
    icon: <CheckCircle2 className="text-teal-500" size={18} />,
    content: `نهاية الرحلة التقنية (ص 1181 - 1280):
• التشطيب والسرفلة: تنظيف حواف القماش.
• العراوي والجيوب والأساور: التفاصيل التي تصنع جودة القطعة.
• التكبير والتصغير (Grading): تحويل الموديل من مقاس إلى آخر آلياً.
• جداول المقاسات: المرجع الرقمي الذي يعتمد عليه هذا الاستوديو.`
  }
];

interface VisualConfig {
  outline: { width: number; color: string };
  dart: { width: number; color: string };
  technical: { width: number; color: string };
  dimension: { width: number; color: string };
  curve: { width: number; color: string };
}

const INITIAL_VISUAL_CONFIG: VisualConfig = {
  outline: { width: 3.2, color: '#0f172a' },
  dart: { width: 1.8, color: '#475569' },
  technical: { width: 1.2, color: '#94a3b8' },
  dimension: { width: 1.0, color: '#3b82f6' },
  curve: { width: 2.8, color: '#0f172a' }
};

const App: React.FC = () => {
  const [category, setCategory] = useState<Category>('women');
  const [size, setSize] = useState<string>('42');
  const [activeChapterIdx, setActiveChapterIdx] = useState(0);
  const [activeModelIdx, setActiveModelIdx] = useState(0);
  const [measurements, setMeasurements] = useState<Measurements>({});
  const [visualConfig] = useState<VisualConfig>(INITIAL_VISUAL_CONFIG);
  
  const [zoom, setZoom] = useState(0.9);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth > 1024);
  const [viewMode, setViewMode] = useState<'paper' | 'blueprint'>('paper');
  const [showSummary, setShowSummary] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [isPatternAnimating, setIsPatternAnimating] = useState(false);
  const [isBookReaderOpen, setIsBookReaderOpen] = useState(false);
  const [activeBookSection, setActiveBookSection] = useState(0);
  
  const [visibleLayers] = useState<Record<string, boolean>>({
    outline: true,
    dart: true,
    technical: true,
    dimension: true,
    labels: true,
    curve: true,
    pleat: true
  });

  const [hoveredPath, setHoveredPath] = useState<PatternPath | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  
  const svgRef = useRef<SVGSVGElement>(null);

  const currentChapters = useMemo(() => CATEGORY_STRUCTURE[category] || [], [category]);
  const currentChapter = currentChapters[activeChapterIdx] || currentChapters[0];
  const currentModel = currentChapter.models[activeModelIdx] || currentChapter.models[0];
  const availableSizes = useMemo(() => Object.keys(DB[category] || {}), [category]);

  const changeCategory = (newCat: Category) => {
    setCategory(newCat);
    const newSizes = Object.keys(DB[newCat]);
    setSize(newSizes.includes(size) ? size : newSizes[0]);
    setActiveChapterIdx(0);
    setActiveModelIdx(0);
  };

  useEffect(() => {
    setPan({ x: 0, y: 0 });
    setZoom(0.9);
    setIsPatternAnimating(true);
    const timer = setTimeout(() => setIsPatternAnimating(false), 400);
    return () => clearTimeout(timer);
  }, [activeModelIdx, activeChapterIdx, category, size]);

  useEffect(() => {
    if (size && DB[category][size]) {
      setMeasurements({ ...DB[category][size] });
    }
  }, [size, category]);

  const styleConfig: StyleConfig = useMemo(() => ({
    chapter: currentChapter.id as ChapterType,
    model: currentModel.id as ModelType,
    category: category,
    garmentLength: measurements["طول_الجولنة"] || 75,
    ease: 2.0
  }), [currentChapter, currentModel, category, measurements]);

  const patternData = useMemo<DrawResult>(() => draftPattern(styleConfig, measurements), [styleConfig, measurements]);

  // Touch & Mouse Handling
  const handleStart = (clientX: number, clientY: number) => {
    setIsDragging(true);
    dragStart.current = { x: clientX - pan.x, y: clientY - pan.y };
  };

  const handleMove = (clientX: number, clientY: number) => {
    setMousePos({ x: clientX, y: clientY });
    if (isDragging) {
      setPan({ x: clientX - dragStart.current.x, y: clientY - dragStart.current.y });
    }
  };

  const handleEnd = () => setIsDragging(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    handleStart(e.clientX, e.clientY);
  };

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    handleMove(e.clientX, e.clientY);
  }, [isDragging]);

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    handleStart(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    handleMove(touch.clientX, touch.clientY);
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.05 : 0.05;
      setZoom(z => Math.max(0.1, Math.min(5, z + delta)));
    } else {
      setPan(p => ({ x: p.x - e.deltaX, y: p.y - e.deltaY }));
    }
  };

  const handleExport = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgRef.current);
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `FathiKhalil_${currentModel.id}_Size${size}.svg`;
    link.click();
  };

  const getPathColor = (p: PatternPath) => {
    const isHovered = hoveredPath?.id === p.id;
    if (viewMode === 'blueprint') return isHovered ? '#fff' : (p.type === 'dimension' ? '#60a5fa' : '#3b82f6');
    const color = (visualConfig as any)[p.type]?.color || p.stroke || '#1e293b';
    return isHovered ? '#2563eb' : color;
  };

  const getPathWidth = (p: PatternPath) => {
    const width = (visualConfig as any)[p.type]?.width || p.strokeWidth || 1.5;
    return hoveredPath?.id === p.id ? width + 2.5 : width;
  };

  return (
    <div className="flex h-screen w-screen bg-slate-50 text-slate-900 overflow-hidden font-tajawal rtl select-none">
      
      {/* Mobile Backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 lg:hidden animate-fade-in" 
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        bg-white border-l border-slate-200 shadow-2xl z-50 fixed lg:relative h-full transition-all duration-300 flex flex-col
        ${sidebarOpen ? 'w-[320px] sm:w-[380px] translate-x-0' : 'w-0 translate-x-full lg:w-0 overflow-hidden'}
        ${focusMode ? 'lg:hidden translate-x-full' : ''}
      `}>
        <div className="p-4 sm:p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-30">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 sm:w-12 sm:h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white shadow-xl rotate-3">
                <LayoutTemplate size={20} />
             </div>
             <div>
                <h2 className="font-black text-sm sm:text-base tracking-tight text-slate-900 leading-tight">الاستوديو الرقمي</h2>
                <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 hidden sm:block">منهج البروفيسور فتحي خليل</p>
             </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-slate-900 transition-all">
            <X size={20} />
          </button>
        </div>

        <div className="px-4 sm:px-6 py-4 sm:py-5 space-y-4 sm:space-y-5 bg-slate-50 border-b border-slate-100 shadow-sm z-20">
           <div className="space-y-2">
              <div className="flex items-center gap-2">
                 <Layers size={14} className="text-blue-600" />
                 <h3 className="text-[10px] sm:text-[11px] font-black text-slate-500 uppercase tracking-wider">اختيار الفئة</h3>
              </div>
              <div className="flex gap-1.5 bg-white p-1 rounded-2xl shadow-sm border border-slate-100/50">
                {(['women', 'men', 'children'] as Category[]).map(c => (
                  <button
                    key={c}
                    onClick={() => changeCategory(c)}
                    className={`flex-1 py-1.5 sm:py-2 rounded-xl text-[10px] sm:text-[11px] font-black transition-all duration-300 ${category === c ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
                  >
                    {c === 'women' ? 'نسائي' : c === 'men' ? 'رجالي' : 'أطفال'}
                  </button>
                ))}
              </div>
           </div>

           <div className="space-y-2">
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <Ruler size={14} className="text-emerald-600" />
                    <h3 className="text-[10px] sm:text-[11px] font-black text-slate-500 uppercase tracking-wider">المقاس القياسي</h3>
                 </div>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none scroll-smooth touch-pan-x">
                 {availableSizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={`flex-shrink-0 min-w-[44px] h-9 sm:min-w-[50px] sm:h-10 flex items-center justify-center rounded-xl text-[11px] sm:text-[12px] font-black border transition-all duration-200 ${size === s ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg scale-105' : 'bg-white border-slate-200 text-slate-400 hover:border-slate-300'}`}
                    >
                      {s.replace('سنة ', '')}
                    </button>
                 ))}
              </div>
           </div>
        </div>

        <nav className="flex-1 overflow-y-auto custom-scroll p-4 sm:p-6 space-y-6 sm:space-y-8">
          <div className="space-y-3">
             <div className="flex items-center gap-2 mb-1 px-1">
                <BookOpen size={16} className="text-purple-600" />
                <h3 className="text-[11px] sm:text-[12px] font-black text-slate-800 uppercase tracking-tight">مكتبة التصميم</h3>
             </div>

             <div className="space-y-1.5">
                {currentChapters.map((ch, idx) => (
                  <div key={idx} className={`rounded-xl transition-all border ${activeChapterIdx === idx ? 'bg-slate-50 border-slate-200' : 'border-transparent hover:bg-slate-50/30'}`}>
                    <button
                      onClick={() => { setActiveChapterIdx(idx); setActiveModelIdx(0); }}
                      className={`w-full text-right px-3 py-3 rounded-xl text-[12px] sm:text-[13px] font-black flex items-center justify-between transition-all ${activeChapterIdx === idx ? 'text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                      <span className="flex items-center gap-3">
                        <span className={`w-1.5 h-1.5 rounded-full ${activeChapterIdx === idx ? 'bg-blue-600 scale-125' : 'bg-slate-200'}`} />
                        {ch.name}
                      </span>
                      <ChevronDown size={14} className={`transition-transform duration-300 ${activeChapterIdx === idx ? 'rotate-180 text-blue-500' : 'text-slate-300'}`} />
                    </button>
                    {activeChapterIdx === idx && (
                      <div className="px-2 pb-2 space-y-1 animate-fade-in">
                        {ch.models.map((m, mIdx) => (
                          <button
                            key={m.id}
                            onClick={() => { 
                              setActiveModelIdx(mIdx);
                              if (window.innerWidth < 1024) setSidebarOpen(false);
                            }}
                            className={`w-full text-right px-4 py-2.5 rounded-lg text-[11px] sm:text-[12px] transition-all border ${activeModelIdx === mIdx ? 'text-blue-700 font-bold bg-white border-blue-200 shadow-sm ring-2 ring-blue-50/50' : 'text-slate-400 border-transparent hover:bg-white'}`}
                          >
                            {m.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
             </div>
          </div>

          <div className="h-px bg-slate-100" />

          <div className="space-y-4 pb-12">
             <div className="flex items-center gap-2 mb-2 px-1">
                <Crosshair size={16} className="text-orange-600" />
                <h3 className="text-[11px] sm:text-[12px] font-black text-slate-800 uppercase tracking-tight">القياسات الفنية (سم)</h3>
             </div>
             <MeasurementTable 
               measurements={measurements} 
               onChange={(k, v) => setMeasurements(p => ({...p, [k]: v}))} 
             />
          </div>
        </nav>
      </aside>

      <main className="flex-1 flex flex-col relative min-w-0">
        {/* Main Header */}
        <header className="h-16 sm:h-20 bg-white border-b border-slate-100 flex items-center justify-between px-4 sm:px-8 z-40 shadow-sm">
          <div className="flex items-center gap-3 sm:gap-6 min-w-0">
            {!sidebarOpen && (
              <button onClick={() => setSidebarOpen(true)} className="p-2.5 sm:p-3 bg-slate-900 rounded-xl sm:rounded-2xl text-white shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all active:scale-90 flex-shrink-0">
                <Menu size={18} />
              </button>
            )}
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2 mb-0.5 sm:mb-1">
                 <span className="text-[8px] sm:text-[9px] text-white bg-blue-600 px-1.5 py-0.5 rounded-full font-black uppercase tracking-widest whitespace-nowrap">{currentChapter.name}</span>
                 <span className="text-[8px] sm:text-[9px] text-slate-400 font-black uppercase tracking-widest hidden xs:inline">مقاس: {size}</span>
              </div>
              <h1 className="text-sm sm:text-lg font-black text-slate-900 truncate leading-tight">{currentModel.name}</h1>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 flex-shrink-0">
            <button 
              onClick={() => setIsBookReaderOpen(true)} 
              className="p-2.5 sm:p-3 bg-white text-slate-400 border border-slate-100 rounded-xl sm:rounded-2xl shadow-md hover:text-blue-600 hover:border-blue-100 transition-all active:scale-95 flex items-center justify-center group"
            >
              <Book size={18} className="group-hover:rotate-12 transition-transform" />
            </button>
            <button onClick={handleExport} className="flex items-center gap-2 px-3 sm:px-6 py-2.5 sm:py-3 bg-slate-900 text-white rounded-xl sm:rounded-2xl text-[10px] sm:text-[12px] font-black shadow-lg shadow-slate-200 hover:bg-slate-800 transition-all active:scale-95 group">
              <Download size={16} className="group-hover:translate-y-0.5 transition-transform" />
              <span className="hidden md:inline">تصدير SVG</span>
              <span className="md:hidden">تصدير</span>
            </button>
          </div>
        </header>

        {/* Viewport */}
        <section 
          className="flex-1 relative overflow-hidden bg-slate-100 touch-none"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleEnd}
          onMouseLeave={handleEnd}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleEnd}
          onWheel={handleWheel}
        >
          <div className={`
            absolute inset-0 transition-all duration-700
            ${viewMode === 'blueprint' ? 'bg-[#050811]' : 'bg-[#fcfaf5] paper-texture'}
          `} style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: 'center' }}>
            <div className={`absolute inset-0 pointer-events-none transition-opacity duration-700 ${viewMode === 'blueprint' ? 'blueprint-grid opacity-30' : 'pattern-grid opacity-50'}`} />
            <div className="flex items-center justify-center w-full h-full">
              <svg 
                ref={svgRef} 
                viewBox="0 0 800 1000" 
                className={`w-full h-full max-w-[800px] pointer-events-auto transition-all ${viewMode === 'blueprint' ? 'drop-shadow-[0_0_40px_rgba(59,130,246,0.3)]' : 'drop-shadow-2xl'} ${isPatternAnimating ? 'scale-[1.02] opacity-0 blur-xl' : 'scale-100 opacity-100 blur-0'} duration-500 ease-out`}
              >
                {patternData.paths.map(p => (
                  (visibleLayers[p.type] || p.type === 'outline') && (
                    <path 
                      key={p.id} 
                      d={p.d} 
                      fill="none" 
                      stroke={getPathColor(p)} 
                      strokeWidth={getPathWidth(p)} 
                      strokeDasharray={p.dashArray} 
                      strokeLinecap="round" 
                      onMouseEnter={() => setHoveredPath(p)}
                      onMouseLeave={() => setHoveredPath(null)}
                      className="cursor-crosshair transition-all duration-300"
                    />
                  )
                ))}
                {visibleLayers.labels && patternData.labels.map((lbl, idx) => (
                  <text 
                    key={idx} x={lbl.x} y={lbl.y} 
                    fill={viewMode === 'blueprint' ? '#93c5fd' : (lbl.color || "#334155")} 
                    fontSize={lbl.fontSize || 12} 
                    fontWeight="900" 
                    textAnchor="middle" 
                    transform={lbl.angle ? `rotate(${lbl.angle}, ${lbl.x}, ${lbl.y})` : undefined}
                    className="select-none pointer-events-none opacity-100 drop-shadow-sm filter contrast-125"
                  >
                    {lbl.text}
                  </text>
                ))}
              </svg>
            </div>
          </div>

          <div className="absolute top-4 right-4 sm:top-8 sm:right-8 flex flex-col gap-2 sm:gap-3 z-40">
             <button onClick={() => setViewMode(v => v === 'paper' ? 'blueprint' : 'paper')} className={`p-3 sm:p-4 rounded-xl sm:rounded-[1.5rem] shadow-xl transition-all active:scale-90 ring-1 ring-white/20 ${viewMode === 'blueprint' ? 'bg-blue-600 text-white' : 'bg-white text-slate-400 hover:text-slate-900'}`}>
                <Eye size={18}/>
             </button>
             <button onClick={() => setShowSummary(!showSummary)} className={`p-3 sm:p-4 rounded-xl sm:rounded-[1.5rem] shadow-xl transition-all active:scale-90 ring-1 ring-white/20 ${showSummary ? 'bg-emerald-600 text-white' : 'bg-white text-slate-400 hover:text-slate-900'}`}>
                <Info size={18}/>
             </button>
          </div>

          {/* Floating Zoom Controls */}
          <div className="absolute bottom-6 sm:bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-1.5 sm:gap-2 bg-white/95 backdrop-blur-2xl border border-white p-1.5 sm:p-2 rounded-full shadow-2xl z-40 ring-1 ring-slate-200/50 max-w-[90vw]">
                <button onClick={() => setZoom(z => Math.max(0.1, z - 0.1))} className="p-2 sm:p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all active:scale-90"><ZoomOut size={16}/></button>
                <div className="w-px h-5 sm:h-6 bg-slate-100" />
                <button onClick={() => { setZoom(0.9); setPan({x:0, y:0}); }} className="px-3 sm:px-5 text-[10px] sm:text-[12px] font-black text-slate-900 tracking-tight whitespace-nowrap min-w-[60px] sm:min-w-[80px] text-center hover:bg-slate-50 py-1.5 sm:py-2 rounded-full transition-all">{Math.round(zoom * 100)}%</button>
                <div className="w-px h-5 sm:h-6 bg-slate-100" />
                <button onClick={() => setZoom(z => Math.min(4, z + 0.1))} className="p-2 sm:p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all active:scale-90"><ZoomIn size={16}/></button>
                <div className="w-px h-5 sm:h-6 bg-slate-100 hidden xs:block" />
                <button onClick={() => setFocusMode(!focusMode)} className="p-2 sm:p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all active:scale-90 hidden xs:block">
                    {focusMode ? <Minimize2 size={16}/> : <Maximize2 size={16}/>}
                </button>
          </div>

          {showSummary && (
             <div className="absolute top-24 right-4 left-4 sm:left-auto sm:top-28 sm:right-8 sm:w-72 bg-white/98 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] rounded-[1.5rem] sm:rounded-[2rem] border border-white overflow-hidden animate-scale-in z-30 ring-1 ring-slate-200/50">
                <div className="p-4 sm:p-5 bg-slate-50/80 border-b border-slate-100 flex justify-between items-center">
                   <h3 className="text-[10px] sm:text-[11px] font-black uppercase text-slate-600 tracking-widest flex items-center gap-3">
                     <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-emerald-500 rounded-full animate-pulse" />
                     الملخص الهندسي
                   </h3>
                   <button onClick={() => setShowSummary(false)} className="text-slate-300 hover:text-slate-900 p-1.5 hover:bg-slate-100 rounded-full transition-all"><X size={16} /></button>
                </div>
                <div className="p-4 sm:p-6 space-y-3 sm:space-y-4 max-h-[40vh] overflow-y-auto">
                   {patternData.summary.map(s => (
                      <div key={s.key} className="flex justify-between items-center group">
                         <span className="text-[11px] sm:text-[12px] text-slate-400 font-bold">{s.key}</span>
                         <span className="text-[11px] sm:text-[12px] font-black text-slate-900 bg-slate-50 px-2 sm:px-3 py-1 rounded-lg">{s.value}</span>
                      </div>
                   ))}
                </div>
                <div className="p-3 sm:p-4 bg-blue-600 text-[9px] sm:text-[10px] text-center text-white font-black tracking-widest uppercase">
                  المقاس المرجعي: {size}
                </div>
             </div>
          )}

          {/* Book Reader Modal */}
          {isBookReaderOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 xs:p-4 md:p-8 animate-fade-in">
               <div className="absolute inset-0 bg-slate-900/70 backdrop-blur-md" onClick={() => setIsBookReaderOpen(false)} />
               
               <div className="relative w-full max-w-5xl h-full xs:h-[90vh] md:h-[85vh] bg-[#fcfaf5] xs:rounded-[2rem] md:rounded-[2.5rem] shadow-[0_40px_100px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col md:flex-row paper-texture animate-scale-in border border-white/20">
                  
                  {/* Sidebar / Top Navigation for mobile */}
                  <div className="w-full md:w-[320px] bg-white/90 backdrop-blur-md border-l border-slate-200/50 flex flex-col order-2 md:order-1 overflow-hidden h-auto md:h-full">
                      
                      {/* Logo Area (Hidden on mobile stack) */}
                      <div className="hidden md:block p-8 pb-4">
                        <div className="flex items-center gap-3 mb-2">
                           <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white shadow-lg">
                              <BookOpen size={20} />
                           </div>
                           <h2 className="font-black text-xl text-slate-900">فهرست الموسوعة</h2>
                        </div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">الموسوعة الأصلية - الأستاذ فتحي خليل</p>
                      </div>

                      {/* Navigation Sections */}
                      <div className="flex-1 flex md:flex-col overflow-x-auto md:overflow-y-auto scrollbar-none p-4 md:p-6 gap-2 border-t md:border-t-0 border-slate-100 bg-slate-50/50">
                         {BOOK_SECTIONS.map((section, idx) => (
                           <button
                             key={section.id}
                             onClick={() => setActiveBookSection(idx)}
                             className={`flex items-center gap-2 md:gap-4 px-3 md:px-5 py-2.5 md:py-4 rounded-xl md:rounded-2xl transition-all text-right group relative shrink-0 md:shrink ${activeBookSection === idx ? 'bg-slate-900 text-white shadow-lg md:translate-x-1' : 'text-slate-500 hover:bg-white hover:text-slate-900 hover:shadow-sm'}`}
                           >
                             <div className={`p-1.5 md:p-2 rounded-lg transition-colors shrink-0 ${activeBookSection === idx ? 'bg-white/10 text-white' : 'bg-white text-slate-400 group-hover:text-slate-600'}`}>
                               {React.cloneElement(section.icon as React.ReactElement, { size: window.innerWidth < 768 ? 14 : 18 })}
                             </div>
                             <span className="text-[10px] md:text-[13px] font-black whitespace-nowrap md:whitespace-normal md:flex-1">{section.title}</span>
                             {activeBookSection === idx && <ArrowLeft size={14} className="hidden md:block text-blue-400 animate-pulse" />}
                             <div className={`md:hidden absolute bottom-0 left-0 right-0 h-1 bg-blue-500 rounded-full transition-opacity ${activeBookSection === idx ? 'opacity-100' : 'opacity-0'}`} />
                           </button>
                         ))}
                      </div>

                      <div className="hidden md:block p-8 pt-0 mt-auto border-t border-slate-100/60">
                         <div className="p-4 bg-white/50 rounded-2xl border border-slate-100 text-center">
                           <p className="text-[9px] text-slate-400 font-bold leading-relaxed italic">
                             "هندسة الملابس علم يبدأ بالنظر وينتهي بالدقة."
                           </p>
                         </div>
                      </div>
                  </div>

                  {/* Main Reading Content Area */}
                  <div className="flex-1 flex flex-col p-6 sm:p-10 md:p-16 order-1 md:order-2 overflow-y-auto custom-scroll relative bg-[#fcfaf5]">
                      <button 
                        onClick={() => setIsBookReaderOpen(false)}
                        className="absolute top-4 left-4 sm:top-8 sm:left-8 p-2.5 bg-white/80 backdrop-blur-sm rounded-xl text-slate-400 hover:text-slate-900 shadow-md z-50 border border-slate-200/20 active:scale-90"
                      >
                        <X size={20} />
                      </button>

                      <div className="max-w-2xl mx-auto w-full pt-6 sm:pt-10 pb-20">
                         <div className="flex items-center gap-3 mb-4 sm:mb-6 opacity-60">
                            <div className="w-6 sm:w-8 h-[2px] bg-blue-600 rounded-full" />
                            <span className="text-[9px] sm:text-[11px] font-black uppercase tracking-widest text-slate-500">
                              الباب الرقمي {activeBookSection + 1} من {BOOK_SECTIONS.length}
                            </span>
                         </div>

                         <h1 className="text-2xl sm:text-4xl md:text-5xl font-black text-slate-900 mb-6 sm:mb-10 leading-[1.2] tracking-tight">
                           {BOOK_SECTIONS[activeBookSection].title}
                         </h1>

                         <div className="relative">
                            <div className="absolute -right-4 -top-6 sm:-right-8 sm:-top-8 text-slate-200/40">
                               <Quote size={window.innerWidth < 768 ? 40 : 100} />
                            </div>
                            
                            <div className="relative z-10 prose prose-slate max-w-none">
                              <p className="text-slate-600 text-base sm:text-lg md:text-xl leading-[1.7] sm:leading-[1.9] whitespace-pre-wrap font-medium font-tajawal drop-shadow-sm">
                                {BOOK_SECTIONS[activeBookSection].content}
                              </p>
                            </div>
                         </div>

                         {/* Footer Navigation within Page */}
                         <div className="mt-12 sm:mt-24 flex items-center justify-between border-t border-slate-200/50 pt-6 sm:pt-10">
                            <button 
                              disabled={activeBookSection === 0}
                              onClick={() => setActiveBookSection(s => Math.max(0, s - 1))}
                              className="flex items-center gap-2 sm:gap-4 px-4 sm:px-8 py-3 sm:py-5 rounded-2xl sm:rounded-3xl font-black text-[10px] sm:text-sm bg-white border border-slate-200 text-slate-500 hover:text-slate-900 disabled:opacity-30 shadow-sm transition-all active:scale-95"
                            >
                              <ArrowRight size={18} />
                              <span className="hidden xs:inline">الباب السابق</span>
                            </button>
                            <button 
                              disabled={activeBookSection === BOOK_SECTIONS.length - 1}
                              onClick={() => setActiveBookSection(s => Math.min(BOOK_SECTIONS.length - 1, s + 1))}
                              className="flex items-center gap-2 sm:gap-4 px-4 sm:px-8 py-3 sm:py-5 rounded-2xl sm:rounded-3xl font-black text-[10px] sm:text-sm bg-slate-900 text-white shadow-xl disabled:opacity-30 shadow-slate-300 transition-all active:scale-95"
                            >
                              <span className="hidden xs:inline">الباب التالي</span>
                              <ArrowLeft size={18} />
                            </button>
                         </div>
                      </div>

                      {/* Aesthetic Paper Elements */}
                      <div className="absolute top-0 bottom-0 right-4 sm:right-[4.5rem] w-px bg-red-100/30 md:block" />
                      <div className="absolute top-0 bottom-0 right-5 sm:right-[4.8rem] w-px bg-red-100/30 md:block" />
                      
                      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[9px] font-black text-slate-300 uppercase tracking-widest opacity-50">
                        Fathi Khalil Encyclopedia Reader • {activeBookSection + 1} / {BOOK_SECTIONS.length}
                      </div>
                  </div>
               </div>
            </div>
          )}

          {hoveredPath && !isBookReaderOpen && (
             <div 
               className="fixed pointer-events-none z-50 bg-slate-900/98 backdrop-blur-xl text-white px-4 py-2 sm:px-5 sm:py-3 rounded-xl sm:rounded-2xl text-[10px] sm:text-[12px] font-black shadow-2xl flex items-center gap-2 sm:gap-3 ring-1 ring-white/20 animate-fade-in"
               style={{ left: Math.min(mousePos.x + 20, window.innerWidth - 180), top: mousePos.y + 20 }}
             >
               <div className="p-1.5 sm:p-2 bg-blue-500/30 rounded-lg sm:rounded-xl">
                 <Crosshair size={12} className="text-blue-400" />
               </div>
               {hoveredPath.description || 'جزء هندسي'}
             </div>
          )}
        </section>
      </main>
    </div>
  );
};

export default App;