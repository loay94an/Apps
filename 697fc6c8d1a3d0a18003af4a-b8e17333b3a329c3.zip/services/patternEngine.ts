
import { Measurements, Point, DrawResult, PatternPath, StyleConfig, PatternLabel } from '../types';

export const SCALE = 6.0; 

/**
 * Creates professional dimension lines with architectural ticks and labels.
 */
const createDimension = (
  id: string, x1: number, y1: number, x2: number, y2: number,
  label: string, offset: number = 20, vertical: boolean = false
): { paths: PatternPath[], labels: PatternLabel[] } => {
  const paths: PatternPath[] = [];
  const labels: PatternLabel[] = [];
  
  // Apply offset
  const ox1 = vertical ? x1 - offset : x1;
  const oy1 = vertical ? y1 : y1 - offset;
  const ox2 = vertical ? x2 - offset : x2;
  const oy2 = vertical ? y2 : y2 - offset;

  // Main dimension line
  paths.push({
    id: `${id}-line`,
    d: `M ${ox1} ${oy1} L ${ox2} ${oy2}`,
    type: 'dimension',
    strokeWidth: 0.8,
    stroke: '#3b82f6',
    dashArray: '2,2'
  });

  // Architectural ticks (diagonal slashes)
  const tick = 4;
  paths.push({ id: `${id}-t1`, d: `M ${ox1-tick} ${oy1+tick} L ${ox1+tick} ${oy1-tick}`, type: 'dimension', strokeWidth: 1.2, stroke: '#3b82f6' });
  paths.push({ id: `${id}-t2`, d: `M ${ox2-tick} ${oy2+tick} L ${ox2+tick} ${oy2-tick}`, type: 'dimension', strokeWidth: 1.2, stroke: '#3b82f6' });

  // Extension lines (thin lines connecting pattern to dimension)
  paths.push({ id: `${id}-ext1`, d: `M ${x1} ${y1} L ${ox1} ${oy1}`, type: 'technical', strokeWidth: 0.5, stroke: '#cbd5e1' });
  paths.push({ id: `${id}-ext2`, d: `M ${x2} ${y2} L ${ox2} ${oy2}`, type: 'technical', strokeWidth: 0.5, stroke: '#cbd5e1' });

  // Label position
  labels.push({ 
    x: (ox1+ox2)/2, 
    y: (oy1+oy2)/2 - (vertical ? 0 : 10), 
    text: label, 
    fontSize: 10, 
    color: '#3b82f6', 
    angle: vertical ? -90 : 0 
  });

  return { paths, labels };
};

/**
 * Adds a descriptive note at a specific point
 */
const addNote = (x: number, y: number, text: string, fontSize: number = 9): PatternLabel => ({
  x, y, text, fontSize, color: '#64748b'
});

export const draftPattern = (config: StyleConfig, m: Measurements): DrawResult => {
  const paths: PatternPath[] = [];
  const labels: PatternLabel[] = [];
  const summary: { key: string, value: string }[] = [];
  
  // Origin for drawing
  const originX = 180;
  const originY = 120;

  // Essential Measurement Extraction with safe defaults
  const bust = m["محيط_الصدر"] || 92;
  const waist = m["محيط_الوسط"] || 72;
  const hip = m["محيط_الهنش"] || 100;
  const backLen = m["طول_الظهر"] || 42;
  const neck = m["محيط_الرقبة"] || 34;
  const shoulder = m["عرض_الكتف"] || 13.5;
  const sleeveLen = m["طول_الكم"] || 60;
  const garmentLen = m["طول_الجولنة"] || config.garmentLength || 75;
  const sideLen = (m["طول_الجنب"] || 20) * SCALE;

  const modelId = config.model;

  // Helper to add dimensions to the arrays
  const addDim = (id: string, x1: number, y1: number, x2: number, y2: number, label: string, offset?: number, vert?: boolean) => {
    const dim = createDimension(id, x1, y1, x2, y2, label, offset, vert);
    paths.push(...dim.paths);
    labels.push(...dim.labels);
  };

  // --- MODEL ROUTING & DRAFTING ---

  // 1. SKIRTS CHAPTER
  if (config.chapter === 'skirts') {
    const qH = (hip / 4 + 1.5) * SCALE;
    const qW = (waist / 4 + 2.5) * SCALE;
    const gL = garmentLen * SCALE;

    if (modelId === 'skirt_circular') {
      const radius = (waist / 6.28) * SCALE;
      const totalR = radius + gL;
      
      // Construction Lines
      paths.push({ id: 'c-axis-h', d: `M ${originX} ${originY} H ${originX+totalR}`, type: 'technical', dashArray: '5,5' });
      paths.push({ id: 'c-axis-v', d: `M ${originX} ${originY} V ${originY+totalR}`, type: 'technical', dashArray: '5,5' });
      
      // Outline
      paths.push({ id: 'c-w', d: `M ${originX} ${originY+radius} A ${radius} ${radius} 0 0 1 ${originX+radius} ${originY}`, type: 'outline', strokeWidth: 2 });
      paths.push({ id: 'c-h', d: `M ${originX} ${originY+totalR} A ${totalR} ${totalR} 0 0 1 ${originX+totalR} ${originY}`, type: 'outline', strokeWidth: 3 });
      paths.push({ id: 'c-s1', d: `M ${originX} ${originY+radius} V ${originY+totalR}`, type: 'outline' });
      paths.push({ id: 'c-s2', d: `M ${originX+radius} ${originY} H ${originX+totalR}`, type: 'outline' });
      
      labels.push(addNote(originX + radius + 10, originY - 10, 'خط الوسط'));
      labels.push(addNote(originX + totalR - 20, originY + 20, 'خط الذيل'));
      
      addDim('sk-r', originX, originY, originX + radius, originY, `النقرة: ${(waist/6.28).toFixed(1)}`);
      addDim('sk-l', originX, originY + radius, originX, originY + totalR, `الطول: ${garmentLen}`, 40, true);
      
      summary.push({ key: 'النمط', value: 'كلوش كامل' });
    } else {
      // Basic / Pleated Skirt Block
      // Skeleton
      paths.push({ id: 'sk-base-h', d: `M ${originX} ${originY} H ${originX+qH}`, type: 'technical', dashArray: '8,4' });
      paths.push({ id: 'sk-hip-h', d: `M ${originX} ${originY+sideLen} H ${originX+qH}`, type: 'technical', dashArray: '4,4' });
      
      // Main Paths
      paths.push({ id: 's-c', d: `M ${originX} ${originY} V ${originY+gL}`, type: 'outline', description: 'خط نصف الظهر/الأمام' });
      paths.push({ id: 's-h', d: `M ${originX} ${originY+gL} H ${originX+qH}`, type: 'outline', strokeWidth: 3 });
      
      // Side Curve Construction
      const sideCurve = `M ${originX+qH} ${originY+gL} V ${originY+sideLen} Q ${originX+qH} ${originY+sideLen/2} ${originX+qW} ${originY}`;
      paths.push({ id: 's-side', d: sideCurve, type: 'outline', strokeWidth: 2.5 });
      paths.push({ id: 's-w', d: `M ${originX} ${originY} L ${originX+qW} ${originY}`, type: 'outline' });
      
      // Explanatory Labels
      labels.push(addNote(originX + 10, originY + 20, 'نصف الباترون'));
      labels.push(addNote(originX + qW, originY - 15, 'الوسط'));
      labels.push(addNote(originX + qH + 10, originY + sideLen, 'خط الأرداف'));
      
      // Internal Detail for Pleats
      if (modelId === 'skirt_pleats' || modelId === 'skirt_plisse') {
        for(let i=1; i<4; i++) {
          const px = originX + (qH/4)*i;
          paths.push({ id: `pl-${i}`, d: `M ${px} ${originY} V ${originY+gL}`, type: 'pleat', dashArray: '2,2', stroke: '#94a3b8' });
        }
        labels.push(addNote(originX + qH/2, originY + gL/2, 'منطقة الكسرات'));
      }

      // Dimensions
      addDim('sk-w', originX, originY - 40, originX + qW, originY - 40, `عرض الوسط: ${(waist/4 + 2.5).toFixed(1)}`);
      addDim('sk-hip', originX, originY + sideLen + 10, originX + qH, originY + sideLen + 10, `عرض الهنش: ${(hip/4 + 1.5).toFixed(1)}`);
      addDim('sk-len', originX - 40, originY, originX - 40, originY + gL, `طول الجولنة: ${garmentLen}`, 0, true);
      
      summary.push({ key: 'النمط', value: modelId === 'skirt_pleats' ? 'جولنة بكسرات' : 'جولنة أساسية' });
    }
  }

  // 2. BODICE & BLOUSE & DRESSES
  else if (['bodice', 'blouses', 'dresses', 'outerwear', 'islamic'].includes(config.chapter)) {
    const qB = (bust / 4 + (config.chapter === 'outerwear' ? 4 : 2)) * SCALE;
    const bl = backLen * SCALE;
    const nw = (neck / 5) * SCALE;
    const nh = (neck / 5 + 1) * SCALE;
    const sd = (bust / 4) * SCALE; // Scye Depth / Armhole Depth
    const sh = shoulder * SCALE;

    // Construction Skeleton
    paths.push({ id: 'b-frame', d: `M ${originX} ${originY} H ${originX+qB} V ${originY+bl} H ${originX} Z`, type: 'technical', dashArray: '10,5', stroke: '#cbd5e1' });
    paths.push({ id: 'b-bust-line', d: `M ${originX} ${originY+sd} H ${originX+qB}`, type: 'technical', dashArray: '4,2' });
    
    // Neckline
    paths.push({ id: 'b-n', d: `M ${originX} ${originY+nh} Q ${originX} ${originY} ${originX+nw} ${originY}`, type: 'outline', strokeWidth: 2.5 });
    
    // Shoulder
    const shX = originX + nw + sh;
    const shY = originY + 30;
    paths.push({ id: 'b-sh', d: `M ${originX+nw} ${originY} L ${shX} ${shY}`, type: 'outline', strokeWidth: 2.5 });
    
    // Armhole
    paths.push({ id: 'b-arm', d: `M ${shX} ${shY} C ${shX} ${originY+sd} ${originX+qB-5} ${originY+sd} ${originX+qB} ${originY+sd}`, type: 'outline', strokeWidth: 3 });
    
    // Body Extensions
    const totalH = (config.chapter === 'dresses' || config.chapter === 'outerwear') ? bl + 40 * SCALE : bl;
    paths.push({ id: 'b-side', d: `M ${originX+qB} ${originY+sd} V ${originY+totalH}`, type: 'outline' });
    paths.push({ id: 'b-hem', d: `M ${originX} ${originY+totalH} H ${originX+qB}`, type: 'outline', strokeWidth: 3 });
    paths.push({ id: 'b-cf', d: `M ${originX} ${originY+nh} V ${originY+totalH}`, type: 'outline', dashArray: '10,5', description: 'خط نصف الأمام' });

    // Internal Darts (Typical Fathi Khalil placement)
    const dartX = originX + (qB * 0.4);
    paths.push({ id: 'b-dart', d: `M ${dartX-5} ${originY+totalH} L ${dartX} ${originY+totalH-60} L ${dartX+5} ${originY+totalH}`, type: 'dart', stroke: '#94a3b8' });

    // Notes
    labels.push(addNote(originX + nw, originY - 10, 'حردة الرقبة'));
    labels.push(addNote(shX - 10, shY - 10, 'خط الكتف'));
    labels.push(addNote(originX + qB + 10, originY + sd, 'خط الإبط'));
    labels.push(addNote(originX + 10, originY + totalH - 10, 'خط الذيل'));

    // Dimensions
    addDim('b-w-dim', originX, originY - 60, originX + qB, originY - 60, `عرض الربع: ${(bust/4 + 2).toFixed(1)}`);
    addDim('b-sh-dim', originX + nw, originY - 20, shX, originY - 20, `الكتف: ${shoulder}`);
    addDim('b-len-dim', originX - 60, originY, originX - 60, originY + totalH, `الطول الكلي: ${(totalH/SCALE).toFixed(0)}`, 0, true);
    
    summary.push({ key: 'النمط', value: 'كورساج احترافي' });
  }

  // 3. SLEEVES
  else if (config.chapter === 'sleeves') {
    const sw = (bust / 4) * SCALE; // Sleeve Width
    const sl = sleeveLen * SCALE;
    const capH = (bust / 8 + 3) * SCALE; // Cap Height
    
    // Construction Skeleton
    paths.push({ id: 'sl-skeleton', d: `M ${originX} ${originY} H ${originX+sw} V ${originY+sl} H ${originX} Z`, type: 'technical', dashArray: '5,5' });
    paths.push({ id: 'sl-cap-line', d: `M ${originX} ${originY+capH} H ${originX+sw}`, type: 'technical', dashArray: '4,4' });
    
    // Sleeve Cap Curve
    paths.push({ id: 'sl-c', d: `M ${originX} ${originY+capH} C ${originX+sw/4} ${originY-20} ${originX+sw*0.75} ${originY-20} ${originX+sw} ${originY+capH}`, type: 'outline', strokeWidth: 3 });
    
    // Sides
    paths.push({ id: 'sl-s1', d: `M ${originX} ${originY+capH} L ${originX+20} ${originY+sl}`, type: 'outline' });
    paths.push({ id: 'sl-s2', d: `M ${originX+sw} ${originY+capH} L ${originX+sw-20} ${originY+sl}`, type: 'outline' });
    
    // Wrist
    paths.push({ id: 'sl-w', d: `M ${originX+20} ${originY+sl} H ${originX+sw-20}`, type: 'outline', strokeWidth: 2.5 });
    
    // Labels
    labels.push(addNote(originX + sw/2, originY - 30, 'رأس الكم'));
    labels.push(addNote(originX + 10, originY + capH + 20, 'خط العضلة'));
    labels.push(addNote(originX + sw/2, originY + sl - 10, 'الأسورة'));

    // Dimensions
    addDim('sl-cap-dim', originX + sw + 20, originY, originX + sw + 20, originY + capH, `سقوط الكم: ${(capH/SCALE).toFixed(1)}`, 0, true);
    addDim('sl-len-dim', originX - 60, originY, originX - 60, originY + sl, `طول الكم: ${sleeveLen}`, 0, true);
    addDim('sl-wrist-dim', originX + 20, originY + sl + 40, originX + sw - 20, originY + sl + 40, `عرض المعصم: ${((sw-40)/SCALE).toFixed(1)}`);
    
    summary.push({ key: 'النمط', value: 'كم قميص/بلوزة' });
  }

  // 4. TROUSERS
  else if (config.chapter === 'trousers' || modelId.includes('pants')) {
    const qH = (hip / 4 + 1.5) * SCALE;
    const totalL = (m["الطول_الكلي"] || 105) * SCALE;
    const innerL = (m["الطول_الداخلي"] || 80) * SCALE;
    const rise = totalL - innerL;
    const cExt = (hip / 16) * SCALE; // Crotch extension
    const kneeL = (m["طول_الركبة"] || 55) * SCALE;
    
    // Skeleton
    paths.push({ id: 't-skeleton', d: `M ${originX} ${originY} H ${originX+qH} V ${originY+totalL} H ${originX} Z`, type: 'technical', dashArray: '10,5' });
    paths.push({ id: 't-rise-line', d: `M ${originX} ${originY+rise} H ${originX+qH+cExt}`, type: 'technical', dashArray: '4,4' });
    paths.push({ id: 't-knee-line', d: `M ${originX} ${originY+kneeL} H ${originX+qH}`, type: 'technical', dashArray: '4,4' });
    
    // Main Lines
    paths.push({ id: 't-w', d: `M ${originX} ${originY} H ${originX+qH}`, type: 'outline' });
    // Crotch curve
    paths.push({ id: 't-c', d: `M ${originX+qH} ${originY} V ${originY+rise-40} Q ${originX+qH} ${originY+rise} ${originX+qH+cExt} ${originY+rise}`, type: 'outline', strokeWidth: 3 });
    // Inner leg
    paths.push({ id: 't-i', d: `M ${originX+qH+cExt} ${originY+rise} L ${originX+qH-15} ${originY+totalL}`, type: 'outline' });
    // Outer leg
    paths.push({ id: 't-o', d: `M ${originX} ${originY} V ${originY+totalL}`, type: 'outline', strokeWidth: 2 });
    // Hem
    paths.push({ id: 't-h', d: `M ${originX} ${originY+totalL} H ${originX+qH-15}`, type: 'outline', strokeWidth: 3 });
    
    // Notes
    labels.push(addNote(originX + qH - 10, originY - 10, 'خط الوسط'));
    labels.push(addNote(originX + qH + cExt - 5, originY + rise - 10, 'الحجر'));
    labels.push(addNote(originX + 10, originY + totalL - 10, 'رجل البنطلون'));

    // Dimensions
    addDim('t-rise-dim', originX + qH + cExt + 30, originY, originX + qH + cExt + 30, originY + rise, `طول الحجر: ${(rise/SCALE).toFixed(1)}`, 0, true);
    addDim('t-len-dim', originX - 60, originY, originX - 60, originY + totalL, `الطول الكلي: ${(totalL/SCALE).toFixed(0)}`, 0, true);
    addDim('t-hip-dim', originX, originY + rise + 20, originX + qH, originY + rise + 20, `عرض الورك: ${(hip/4).toFixed(1)}`);
    
    summary.push({ key: 'النمط', value: 'بنطلون هندسي' });
  }

  // CATCH-ALL BLOCK (Default Rect)
  else {
    const w = (bust / 4) * SCALE;
    const h = (m["طول_الظهر"] || 42) * SCALE;
    paths.push({ id: 'gen-box', d: `M ${originX} ${originY} H ${originX+w} V ${originY+h} H ${originX} Z`, type: 'outline', dashArray: '5,5' });
    labels.push({ x: originX+w/2, y: originY+h/2, text: 'قالب افتراضي قيد التطوير', fontSize: 10 });
    summary.push({ key: 'الحالة', value: 'باترون تجريبي' });
  }

  return { points: [], paths, labels, summary };
};
