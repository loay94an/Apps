
export type Category = 'women' | 'men' | 'children';
export type ChapterType = 
  | 'introduction' | 'skirts' | 'bodice' | 'blouses' | 'sleeves' | 'collars' 
  | 'dresses' | 'islamic' | 'trousers' | 'outerwear' | 'home' | 'underwear' 
  | 'men_traditional' | 'men_modern' | 'swimwear' | 'technical' | 'children';

export type ModelType = string;
export type ViewMode = 'blueprint' | 'paper';

export interface Measurements {
  [key: string]: number;
}

export type Database = Record<Category, Record<string, Measurements>>;

export interface Point {
  x: number;
  y: number;
  label?: string;
  id?: string | number;
  isCustom?: boolean;
}

export type InteractionMode = 'select' | 'move' | 'add' | 'delete';

export interface PatternPath {
  id: string;
  d: string;
  type: 'outline' | 'technical' | 'curve' | 'dart' | 'pleat' | 'dimension';
  description?: string;
  stroke?: string;
  strokeWidth?: number;
  dashArray?: string;
  fill?: string;
}

export interface PatternLabel {
  x: number;
  y: number;
  text: string;
  angle?: number;
  color?: string;
  fontSize?: number;
}

export interface DrawResult {
  points: Point[];
  paths: PatternPath[];
  labels: PatternLabel[];
  summary: { key: string, value: string }[];
  warnings?: string[];
}

export interface StyleConfig {
  chapter: ChapterType;
  model: ModelType;
  category: Category;
  garmentLength: number;
  ease: number;
}

export interface ModelInfo {
  id: ModelType;
  name: string;
  pageNumber?: number;
}

export interface ChapterInfo {
  id: ChapterType;
  name: string;
  models: ModelInfo[];
}
