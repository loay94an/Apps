
import React, { useRef, useEffect } from 'react';

interface SizeDialProps {
  sizes: string[];
  currentSize: string;
  onSizeChange: (size: string) => void;
  variant?: 'full' | 'compact';
}

const SizeDial: React.FC<SizeDialProps> = ({ sizes, currentSize, onSizeChange, variant = 'full' }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const isProgrammaticScroll = useRef(false);
  const scrollTimeout = useRef<number | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      const activeElement = scrollRef.current.querySelector(`[data-size="${currentSize}"]`);
      if (activeElement) {
        isProgrammaticScroll.current = true;
        activeElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        
        if (scrollTimeout.current) window.clearTimeout(scrollTimeout.current);
        scrollTimeout.current = window.setTimeout(() => {
          isProgrammaticScroll.current = false;
        }, 600); 
      }
    }
  }, [currentSize]);

  const handleScroll = () => {
    if (isProgrammaticScroll.current || !scrollRef.current) return;
    
    const container = scrollRef.current;
    const children = container.querySelectorAll('.dial-item');
    let closestSize = sizes[0];
    let minDistance = Infinity;

    const containerRect = container.getBoundingClientRect();
    const containerCenterX = containerRect.left + containerRect.width / 2;

    children.forEach((child) => {
      const rect = (child as HTMLElement).getBoundingClientRect();
      const childCenter = rect.left + rect.width / 2;
      const distance = Math.abs(childCenter - containerCenterX);
      
      if (distance < minDistance) {
        minDistance = distance;
        closestSize = (child as HTMLElement).dataset.size || sizes[0];
      }
    });

    if (closestSize !== currentSize) {
      onSizeChange(closestSize);
    }
  };

  return (
    <div className={`relative ${variant === 'compact' ? 'h-10 w-24' : 'h-12 w-full'} bg-slate-50 rounded-xl border border-slate-200 overflow-hidden shadow-inner group transition-all`}>
      {/* Selection Center Indicator */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-full bg-blue-500/30 z-20 pointer-events-none" />
      
      {/* Glossy Overlay for "Wheel" look */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-200/20 via-transparent to-slate-200/20 pointer-events-none z-10" />

      {/* Fade Edges */}
      <div className="absolute inset-y-0 left-0 w-6 bg-gradient-to-r from-slate-50 to-transparent z-10 pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-6 bg-gradient-to-l from-slate-50 to-transparent z-10 pointer-events-none" />

      {/* Dial Area */}
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex items-center h-full overflow-x-auto scrollbar-none snap-x snap-mandatory px-[40%] touch-pan-x"
        style={{ scrollBehavior: 'smooth' }}
      >
        {sizes.map((s) => {
          const isActive = s === currentSize;
          const label = s.replace('سنة ', '');
          
          return (
            <div 
              key={s}
              data-size={s}
              onClick={() => {
                isProgrammaticScroll.current = false;
                onSizeChange(s);
              }}
              className="dial-item flex-shrink-0 w-10 flex flex-col items-center justify-center snap-center cursor-pointer transition-all duration-300"
            >
              <span className={`text-[11px] font-black transition-all duration-300 ${isActive ? 'text-blue-600 scale-125' : 'text-slate-400 opacity-60'}`}>
                {label}
              </span>
              <div className={`mt-1 w-2 rounded-full transition-all duration-300 ${isActive ? 'h-1 bg-blue-600' : 'h-0.5 bg-slate-300'}`} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SizeDial;
