
import React from 'react';

interface ButtonProps {
  onClick?: () => void;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'accent' | 'outline';
  className?: string;
  icon?: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({ onClick, children, variant = 'primary', className = '', icon }) => {
  const baseStyles = "flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-bold transition-all duration-300 active:scale-95";
  
  const variants = {
    primary: "bg-primary text-white hover:bg-slate-700 shadow-md",
    secondary: "bg-secondary text-white hover:bg-blue-600 shadow-md",
    accent: "bg-accent text-white hover:bg-red-600 shadow-md",
    outline: "border-2 border-gray-300 text-gray-700 hover:bg-gray-100"
  };

  return (
    <button onClick={onClick} className={`${baseStyles} ${variants[variant]} ${className}`}>
      {icon && <span className="text-lg">{icon}</span>}
      {children}
    </button>
  );
};

export default Button;
