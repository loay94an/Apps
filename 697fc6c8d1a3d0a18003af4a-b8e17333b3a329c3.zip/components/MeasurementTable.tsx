
import React from 'react';
import { Measurements } from '../types.ts';

interface MeasurementTableProps {
  measurements: Measurements;
  onChange: (key: string, value: number) => void;
}

const MeasurementTable: React.FC<MeasurementTableProps> = ({ measurements, onChange }) => {
  if (!measurements || Object.keys(measurements).length === 0) {
    return (
      <div className="p-6 text-center text-slate-400 text-[10px] font-bold uppercase tracking-widest bg-slate-50 rounded-2xl border border-dashed border-slate-200">
        جاري تهيئة البيانات...
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-slate-100 bg-white overflow-hidden shadow-sm">
      <table className="w-full text-right text-[11px]">
        <thead className="bg-slate-50/80 text-slate-400 border-b border-slate-50">
          <tr>
            <th className="px-4 py-3 font-black uppercase tracking-tighter">البيان</th>
            <th className="px-4 py-3 text-center font-black uppercase tracking-tighter">سم</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50">
          {Object.entries(measurements).map(([key, val]) => (
            <tr key={key} className="hover:bg-blue-50/30 transition-colors group">
              <td className="px-4 py-2.5 text-slate-600 font-bold whitespace-nowrap">
                {key.replace(/_/g, ' ')}
              </td>
              <td className="px-4 py-2.5 text-center">
                <input
                  type="number"
                  step="0.1"
                  value={val}
                  onChange={(e) => onChange(key, parseFloat(e.target.value) || 0)}
                  className="w-16 rounded-xl border border-slate-200 bg-slate-50 px-2 py-1.5 text-center text-slate-900 font-black focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:bg-white transition-all group-hover:border-slate-300"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MeasurementTable;
