
export interface DomeStrut {
  id: string;
  type: string;
  length: number;
  color: string;
  count: number;
  angleFace: number;
  angleDihedral: number;
}

export interface DomeData {
  vertices: [number, number, number][];
  edges: { start: number; end: number; type: string; length: number }[];
  strutTypes: DomeStrut[];
  stats: {
    height: number;
    baseRadius: number;
    surfaceArea: number;
    volume: number;
    totalStrutLength: number;
  };
}

export type ConnectionType = 'pipe' | 'goodkarma' | 'semi-conical' | 'conical' | 'hub';

export interface CalculatorConfig {
  polyhedron: 'icosahedron' | 'octahedron' | 'tetrahedron';
  frequency: number;
  subdivisionMethod: 'kruschke' | 'chordal';
  domePart: number;
  connectionType: ConnectionType;
  beamWidth: number;
  beamHeight: number;
  radius: number;
  woodIntensity: number;
  woodColor: string;
}
