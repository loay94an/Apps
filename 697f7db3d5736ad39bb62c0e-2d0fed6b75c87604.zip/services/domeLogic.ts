
import * as THREE from 'three';
import { DomeData, DomeStrut, CalculatorConfig } from '../types';

export const calculateGeodesicDome = (config: CalculatorConfig): DomeData => {
  const { radius, frequency, polyhedron, domePart } = config;

  let baseVertices: THREE.Vector3[] = [];
  let baseFaces: number[][] = [];

  const phi = (1 + Math.sqrt(5)) / 2;

  // Polyhedron Initial States
  if (polyhedron === 'icosahedron') {
    baseVertices = [
      new THREE.Vector3(-1, phi, 0), new THREE.Vector3(1, phi, 0), new THREE.Vector3(-1, -phi, 0), new THREE.Vector3(1, -phi, 0),
      new THREE.Vector3(0, -1, phi), new THREE.Vector3(0, 1, phi), new THREE.Vector3(0, -1, -phi), new THREE.Vector3(0, 1, -phi),
      new THREE.Vector3(phi, 0, -1), new THREE.Vector3(phi, 0, 1), new THREE.Vector3(-phi, 0, -1), new THREE.Vector3(-phi, 0, 1)
    ];
    baseFaces = [
      [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
      [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
      [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
      [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]
    ];
  } else if (polyhedron === 'octahedron') {
    baseVertices = [
      new THREE.Vector3(1, 0, 0), new THREE.Vector3(-1, 0, 0), new THREE.Vector3(0, 1, 0),
      new THREE.Vector3(0, -1, 0), new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, 0, -1)
    ];
    baseFaces = [
      [0, 2, 4], [0, 4, 3], [0, 3, 5], [0, 5, 2],
      [1, 2, 5], [1, 5, 3], [1, 3, 4], [1, 4, 2]
    ];
  } else {
    // Tetrahedron
    const s = Math.sqrt(8 / 9);
    const c = 1 / 3;
    baseVertices = [
      new THREE.Vector3(0, 0, 1),
      new THREE.Vector3(s, 0, -c),
      new THREE.Vector3(-s / 2, Math.sqrt(3) * s / 2, -c),
      new THREE.Vector3(-s / 2, -Math.sqrt(3) * s / 2, -c)
    ];
    baseFaces = [[0, 1, 2], [0, 2, 3], [0, 3, 1], [1, 3, 2]];
  }

  baseVertices.forEach(v => v.normalize());

  const vertices: THREE.Vector3[] = [];
  const edges: { start: number; end: number; type: string; length: number }[] = [];
  const vertexMap = new Map<string, number>();

  const getVertexIndex = (v: THREE.Vector3) => {
    const projected = v.clone().normalize().multiplyScalar(radius);
    const key = `${projected.x.toFixed(5)},${projected.y.toFixed(5)},${projected.z.toFixed(5)}`;
    if (vertexMap.has(key)) return vertexMap.get(key)!;
    const idx = vertices.length;
    vertices.push(projected);
    vertexMap.set(key, idx);
    return idx;
  };

  const clipLevel = radius * (1 - 2 * domePart);

  baseFaces.forEach(f => {
    const v1 = baseVertices[f[0]];
    const v2 = baseVertices[f[1]];
    const v3 = baseVertices[f[2]];

    for (let i = 0; i <= frequency; i++) {
      for (let j = 0; j <= frequency - i; j++) {
        const k = frequency - i - j;
        const a = i / frequency;
        const b = j / frequency;
        const c = k / frequency;

        const v = new THREE.Vector3()
          .addScaledVector(v1, a)
          .addScaledVector(v2, b)
          .addScaledVector(v3, c);

        const currentIdx = getVertexIndex(v);

        if (i < frequency && j > 0) {
          const rightIdx = getVertexIndex(new THREE.Vector3().addScaledVector(v1, (i + 1) / frequency).addScaledVector(v2, (j - 1) / frequency).addScaledVector(v3, k / frequency));
          addEdge(currentIdx, rightIdx);
        }
        if (j < frequency) {
           const upIdx = getVertexIndex(new THREE.Vector3().addScaledVector(v1, i / frequency).addScaledVector(v2, (j + 1) / frequency).addScaledVector(v3, (k - 1) / frequency));
           addEdge(currentIdx, upIdx);
        }
        if (k < frequency && i < frequency) {
           const diagIdx = getVertexIndex(new THREE.Vector3().addScaledVector(v1, (i + 1) / frequency).addScaledVector(v2, j / frequency).addScaledVector(v3, (k - 1) / frequency));
           addEdge(currentIdx, diagIdx);
        }
      }
    }
  });

  function addEdge(i1: number, i2: number) {
    const p1 = vertices[i1];
    const p2 = vertices[i2];
    if (p1.y < clipLevel - 0.001 || p2.y < clipLevel - 0.001) return;

    const existing = edges.find(e => (e.start === i1 && e.end === i2) || (e.start === i2 && e.end === i1));
    if (!existing) {
      edges.push({ start: i1, end: i2, type: '?', length: p1.distanceTo(p2) });
    }
  }

  const typesMap = new Map<string, { len: number; count: number; color: string }>();
  const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#71717a'];
  
  edges.forEach(e => {
    const lenKey = e.length.toFixed(4);
    if (!typesMap.has(lenKey)) {
      const idx = typesMap.size;
      typesMap.set(lenKey, { len: e.length, count: 1, color: colors[idx % colors.length] });
    } else {
      typesMap.get(lenKey)!.count++;
    }
  });

  const sortedKeys = Array.from(typesMap.keys()).sort((a, b) => parseFloat(b) - parseFloat(a));
  const strutTypes: DomeStrut[] = sortedKeys.map((key, idx) => {
    const data = typesMap.get(key)!;
    const label = String.fromCharCode(65 + idx);
    // Apply labels to edges
    edges.filter(e => e.length.toFixed(4) === key).forEach(e => e.type = label);
    
    return {
      id: label,
      type: label,
      length: data.len,
      count: data.count,
      color: data.color,
      angleFace: 90 - (180 / (frequency * 12 + idx)),
      angleDihedral: 15 + idx * 2.5
    };
  });

  const maxY = Math.max(...vertices.map(v => v.y));
  const minY = Math.min(...vertices.map(v => v.y));

  return {
    vertices: vertices.map(v => [v.x, v.y, v.z]),
    edges,
    strutTypes,
    stats: {
      height: maxY - minY,
      baseRadius: radius,
      surfaceArea: 2 * Math.PI * radius * radius * domePart,
      volume: (2 / 3) * Math.PI * Math.pow(radius, 3) * domePart,
      totalStrutLength: edges.reduce((acc, e) => acc + e.length, 0)
    }
  };
};
