
import React from 'react';
import { DomeStrut } from '../types';
import { Table, Scissors, Package } from 'lucide-react';

interface ResultsTableProps {
  struts: DomeStrut[];
}

const ResultsTable: React.FC<ResultsTableProps> = ({ struts }) => {
  const totalStruts = struts.reduce((acc, curr) => acc + curr.count, 0);

  return (
    <div className="w-full bg-white rounded-xl shadow-md md:shadow-lg p-4 md:p-6 border border-gray-100">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
        <div className="flex items-center gap-2 text-slate-800">
          <Table className="w-5 h-5 md:w-6 md:h-6" />
          <h2 className="text-lg md:text-xl font-bold">جدول الكميات وزوايا القطع</h2>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Package className="w-4 h-4" />
          <span>إجمالي العوارض: {totalStruts}</span>
        </div>
      </div>

      <div className="overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0">
        <table className="w-full text-right border-collapse min-w-[500px]">
          <thead>
            <tr className="bg-slate-50 text-slate-600">
              <th className="p-2 md:p-3 border-b border-gray-200 text-xs md:text-sm">النوع</th>
              <th className="p-2 md:p-3 border-b border-gray-200 text-xs md:text-sm">العدد</th>
              <th className="p-2 md:p-3 border-b border-gray-200 text-xs md:text-sm">الطول (سم)</th>
              <th className="p-2 md:p-3 border-b border-gray-200 text-xs md:text-sm">زاوية الوجه</th>
              <th className="p-2 md:p-3 border-b border-gray-200 text-xs md:text-sm">زاوية الدييدرال</th>
              <th className="p-2 md:p-3 border-b border-gray-200 text-xs md:text-sm">دليل اللون</th>
            </tr>
          </thead>
          <tbody>
            {struts.map((s) => (
              <tr key={s.id} className="hover:bg-gray-50 transition-colors">
                <td className="p-2 md:p-3 border-b font-bold text-slate-700 text-xs md:text-sm">{s.type}</td>
                <td className="p-2 md:p-3 border-b text-xs md:text-sm">{s.count}</td>
                <td className="p-2 md:p-3 border-b text-xs md:text-sm">{(s.length * 100).toFixed(1)}</td>
                <td className="p-2 md:p-3 border-b text-orange-600 font-mono text-xs md:text-sm">
                  {s.angleFace.toFixed(1)}°
                </td>
                <td className="p-2 md:p-3 border-b text-blue-600 font-mono text-xs md:text-sm">
                  {s.angleDihedral.toFixed(1)}°
                </td>
                <td className="p-2 md:p-3 border-b">
                  <div 
                    className="w-full h-3 md:h-4 rounded-full" 
                    style={{ backgroundColor: s.color }}
                  ></div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-8 grid md:grid-cols-2 gap-4 md:gap-6">
        <div className="p-4 bg-orange-50 border border-orange-100 rounded-lg">
          <div className="flex items-center gap-2 mb-2 text-orange-800 font-bold">
            <Scissors className="w-4 h-4 md:w-5 md:h-5" />
            <h3 className="text-sm md:text-base">دليل قطع المنشار</h3>
          </div>
          <p className="text-[10px] md:text-xs text-orange-700 leading-relaxed">
            يجب ضبط منشار التلسين (Miter Saw) على "زاوية الوجه" لقص الطول الأساسي، بينما تُستخدم "زاوية الدييدرال" لضبط ميلان الشفرة (Bevel Angle) لضمان التقاء العوارض بشكل مثالي في المركز.
          </p>
        </div>
        <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg">
          <h3 className="text-sm md:text-base text-blue-800 font-bold mb-2">تعليمات التركيب</h3>
          <ul className="text-[10px] md:text-xs text-blue-700 list-disc list-inside space-y-1">
            <li>ابدأ دائماً من القاعدة وصعوداً للأعلى.</li>
            <li>تأكد من مطابقة ألوان العوارض مع المخطط ثلاثي الأبعاد.</li>
            <li>استخدم براغي مخصصة للأخشاب لضمان المتانة الهيكلية.</li>
            <li>راجع زوايا الميلان باستمرار أثناء تثبيت الوصلات.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ResultsTable;
