
import React from 'react';
import { DomeStrut } from '../types';
import { Ruler } from 'lucide-react';

interface StrutDiagramsProps {
  struts: DomeStrut[];
  beamHeight: number;
}

const StrutDiagrams: React.FC<StrutDiagramsProps> = ({ struts, beamHeight }) => {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3 border-r-4 border-orange-500 pr-4">
        <h2 className="text-xl font-bold text-slate-900">مخططات قص العوارض (Beams)</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {struts.map((strut) => (
          <div key={strut.id} className="bg-slate-50 border rounded-xl p-6 relative overflow-hidden group hover:shadow-lg transition-shadow">
            <div className="absolute top-4 left-4 flex items-center gap-2">
                <span className="bg-white px-2 py-1 rounded text-[10px] font-bold border text-slate-500 uppercase tracking-widest">Type {strut.type}</span>
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: strut.color }}></span>
            </div>
            
            <div className="mb-6">
                <h3 className="text-lg font-bold text-slate-800">النوع {strut.type} - {strut.count} قطعة</h3>
                <p className="text-xs text-slate-500">الطول الأساسي: {(strut.length * 100).toFixed(1)} سم</p>
            </div>

            {/* SVG Diagram Inspired by Acidome */}
            <div className="w-full bg-white border border-slate-200 rounded-lg p-4 py-8 shadow-inner overflow-x-auto">
                <svg width="400" height="120" viewBox="0 0 400 120" className="mx-auto min-w-[350px]">
                    {/* Beam Main Body */}
                    <path 
                        d="M 50,20 L 350,20 L 370,100 L 30,100 Z" 
                        fill="none" 
                        stroke="#1e293b" 
                        strokeWidth="2" 
                    />
                    {/* Measurement Lines */}
                    <line x1="50" y1="10" x2="350" y2="10" stroke="#94a3b8" strokeDasharray="4 2" />
                    <text x="200" y="8" fontSize="10" textAnchor="middle" fill="#64748b" className="font-mono">{(strut.length * 100).toFixed(1)} cm</text>
                    
                    {/* Angle Labels */}
                    <text x="35" y="65" fontSize="10" fill="#ef4444" className="font-bold">{strut.angleFace.toFixed(1)}°</text>
                    <text x="355" y="65" fontSize="10" fill="#ef4444" className="font-bold">{strut.angleFace.toFixed(1)}°</text>

                    {/* Height indicators */}
                    <line x1="10" y1="20" x2="10" y2="100" stroke="#94a3b8" strokeWidth="1" />
                    <text x="8" y="60" fontSize="10" textAnchor="end" fill="#64748b" transform="rotate(-90, 8, 60)" className="font-mono">{beamHeight} cm</text>
                </svg>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
                <div className="bg-orange-50 p-2 rounded border border-orange-100">
                    <span className="text-orange-800 font-bold block mb-1">زاوية الوجه:</span>
                    <span className="text-lg font-mono">{strut.angleFace.toFixed(2)}°</span>
                </div>
                <div className="bg-blue-50 p-2 rounded border border-blue-100">
                    <span className="text-blue-800 font-bold block mb-1">زاوية الميلان:</span>
                    <span className="text-lg font-mono">{strut.angleDihedral.toFixed(2)}°</span>
                </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StrutDiagrams;
