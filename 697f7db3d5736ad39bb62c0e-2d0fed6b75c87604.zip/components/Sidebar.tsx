
import React from 'react';
import { CalculatorConfig, ConnectionType } from '../types';
import { Settings, Info, Ruler, Layers, X, Palette, Box as BoxIcon, Share2, Link } from 'lucide-react';

interface SidebarProps {
  config: CalculatorConfig;
  onChange: (config: CalculatorConfig) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ config, onChange, isOpen, onClose }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    onChange({
      ...config,
      [name]: type === 'number' ? parseFloat(value) : value
    });
  };

  const sidebarClasses = `
    fixed inset-y-0 right-0 z-[60] w-72 bg-white shadow-2xl transition-transform duration-300 ease-in-out transform
    ${isOpen ? 'translate-x-0' : 'translate-x-full'}
    md:relative md:translate-x-0 md:w-80 md:shadow-inner md:border-l md:border-gray-200 md:z-auto
  `;

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 md:hidden backdrop-blur-sm" onClick={onClose} />
      )}

      <aside className={sidebarClasses}>
        <div className="flex flex-col h-full p-5 overflow-y-auto space-y-8">
          <div className="flex items-center justify-between md:hidden">
            <h2 className="font-bold text-lg">الإعدادات</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
              <X className="w-5 h-5" />
            </button>
          </div>

          <section>
            <div className="flex items-center gap-2 mb-4 text-slate-800">
              <Settings className="w-5 h-5" />
              <h2 className="font-bold">خيارات الحساب</h2>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600 flex items-center gap-1">
                  <BoxIcon className="w-3 h-3" /> المجسم الأساسي
                </label>
                <select name="polyhedron" value={config.polyhedron} onChange={handleInputChange} className="w-full px-3 py-2 border rounded-md bg-white">
                  <option value="icosahedron">إيكوسايدرون</option>
                  <option value="octahedron">أوكتايدرون</option>
                  <option value="tetrahedron">تيترايدرون</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600 flex items-center gap-1">
                  <Layers className="w-3 h-3" /> التردد (Frequency)
                </label>
                <input type="number" name="frequency" value={config.frequency} onChange={handleInputChange} min="1" max="8" className="w-full px-3 py-2 border rounded-md" />
              </div>

              <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600 flex items-center gap-1">
                  <Link className="w-3 h-3" /> نوع الاتصال (Joint)
                </label>
                <select name="connectionType" value={config.connectionType} onChange={handleInputChange} className="w-full px-3 py-2 border rounded-md bg-white">
                  <option value="hub">مشترك (Standard Hub)</option>
                  <option value="goodkarma">جود كارما (GoodKarma)</option>
                  <option value="pipe">أنابيب (Pipe)</option>
                  <option value="conical">مخروط (Conical)</option>
                  <option value="semi-conical">شبه مخروطي (Semi-Conical)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600">الجزء المقطوع من الكرة</label>
                <select name="domePart" value={config.domePart} onChange={handleInputChange} className="w-full px-3 py-2 border rounded-md bg-white">
                  <option value="0.5">1/2 (نصف كرة)</option>
                  <option value="0.625">5/8 (أكثر من نصف)</option>
                  <option value="0.416">5/12 (أقل من نصف)</option>
                  <option value="1">1/1 (كرة كاملة)</option>
                </select>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-4 text-slate-800">
              <Ruler className="w-5 h-5" />
              <h2 className="font-bold">الأبعاد الفيزيائية</h2>
            </div>
            <div className="space-y-4">
               <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600">نصف قطر القبة (متر)</label>
                <input type="number" name="radius" value={config.radius} onChange={handleInputChange} step="0.1" className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-gray-500">عرض الخشب (سم)</label>
                  <input type="number" name="beamWidth" value={config.beamWidth} onChange={handleInputChange} className="w-full px-2 py-2 border rounded appearance-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-gray-500">سمك الخشب (سم)</label>
                  <input type="number" name="beamHeight" value={config.beamHeight} onChange={handleInputChange} className="w-full px-2 py-2 border rounded appearance-none" />
                </div>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-4 text-slate-800">
              <Palette className="w-5 h-5" />
              <h2 className="font-bold">المظهر</h2>
            </div>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600">لون الخشب</label>
                <input type="color" name="woodColor" value={config.woodColor} onChange={handleInputChange} className="w-full h-10 border rounded cursor-pointer" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-gray-600">كثافة الألياف</label>
                <input type="range" name="woodIntensity" min="0" max="1" step="0.1" value={config.woodIntensity} onChange={handleInputChange} className="w-full" />
              </div>
            </div>
          </section>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
