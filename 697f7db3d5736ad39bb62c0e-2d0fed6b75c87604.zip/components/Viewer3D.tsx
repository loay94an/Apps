
import React, { Suspense, useMemo, useState, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Grid, Environment, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import { DomeData, DomeStrut, ConnectionType } from '../types';

interface Viewer3DProps {
  data: DomeData;
  beamWidth: number;
  woodIntensity: number;
  woodColor: string;
  connectionType: ConnectionType;
}

interface TooltipInfo {
  type: string;
  length: number;
  angleFace: number;
  angleDihedral: number;
  x: number;
  y: number;
}

const createWoodTexture = (baseColor: string, intensity: number) => {
  const canvas = document.createElement('canvas');
  const width = 256;
  const height = 512;
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  
  if (ctx) {
    ctx.fillStyle = baseColor;
    ctx.fillRect(0, 0, width, height);
    
    const lerpColor = (a: string, b: string, t: number) => {
      // Use explicit string manipulation to avoid regex literal confusion
      const cleanA = a.startsWith('#') ? a.substring(1) : a;
      const cleanB = b.startsWith('#') ? b.substring(1) : b;
      
      const ah = parseInt(cleanA, 16);
      const bh = parseInt(cleanB, 16);
      
      const ar = ah >> 16, ag = (ah >> 8) & 0xff, ab = ah & 0xff;
      const br = bh >> 16, bg = (bh >> 8) & 0xff, bb = bh & 0xff;
      
      const rr = ar + t * (br - ar);
      const rg = ag + t * (bg - ag);
      const rb = ab + t * (bb - ab);
      
      return `rgb(${Math.round(rr)},${Math.round(rg)},${Math.round(rb)})`;
    };

    const grainColor = lerpColor(baseColor, '#4a2c11', 0.4);
    const fiberCount = Math.floor(100 + intensity * 300);
    
    for (let i = 0; i < fiberCount; i++) {
      const xStart = Math.random() * width;
      const lineWidth = 0.5 + Math.random() * 1.5;
      const opacity = (0.05 + Math.random() * 0.2) * intensity;
      
      ctx.beginPath();
      ctx.strokeStyle = grainColor;
      ctx.globalAlpha = opacity;
      ctx.lineWidth = lineWidth;
      
      let currentX = xStart;
      ctx.moveTo(currentX, 0);
      
      const waveFreq = 0.005 + Math.random() * 0.01;
      const waveAmp = 5 + Math.random() * 15;
      const phase = Math.random() * Math.PI * 2;
      
      for (let y = 0; y <= height; y += 4) {
        const dx = Math.sin(y * waveFreq + phase) * waveAmp + (Math.random() - 0.5) * 2;
        let x = ((xStart + dx % width) + width) % width;
        
        // Added space around division
        if (Math.abs(x - currentX) > (width / 2)) {
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
        currentX = x;
      }
      ctx.stroke();
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(1, 2);
  return texture;
};

interface StrutProps {
  start: [number, number, number];
  end: [number, number, number];
  color: string;
  width: number;
  texture: THREE.Texture;
  info: DomeStrut;
  connectionType: ConnectionType;
  onHover: (info: TooltipInfo | null) => void;
}

export const Strut: React.FC<StrutProps> = ({ start, end, color, width, texture, info, connectionType, onHover }) => {
  const [hovered, setHovered] = useState(false);
  const vStart = useMemo(() => new THREE.Vector3(...start), [start]);
  const vEnd = useMemo(() => new THREE.Vector3(...end), [end]);
  const rawDirection = useMemo(() => new THREE.Vector3().subVectors(vEnd, vStart).normalize(), [vStart, vEnd]);
  
  const offset = useMemo(() => {
    if (connectionType !== 'goodkarma') return new THREE.Vector3(0, 0, 0);
    const up = new THREE.Vector3(0, 1, 0);
    const side = new THREE.Vector3().crossVectors(rawDirection, up).normalize();
    return side.multiplyScalar(width / 200); 
  }, [connectionType, rawDirection, width]);

  const finalStart = useMemo(() => vStart.clone().add(offset), [vStart, offset]);
  const finalEnd = useMemo(() => vEnd.clone().add(offset), [vEnd, offset]);
  const distance = useMemo(() => finalStart.distanceTo(finalEnd), [finalStart, finalEnd]);
  const midpoint = useMemo(() => new THREE.Vector3().addVectors(finalStart, finalEnd).multiplyScalar(0.5), [finalStart, finalEnd]);
  
  const rotation = useMemo(() => {
    const axis = new THREE.Vector3(0, 1, 0);
    return new THREE.Quaternion().setFromUnitVectors(axis, rawDirection);
  }, [rawDirection]);

  const radius = width / 200;
  const topRadius = (connectionType === 'conical' || connectionType === 'semi-conical') ? radius * 0.4 : radius;
  const bottomRadius = (connectionType === 'conical') ? radius * 0.4 : radius;

  return (
    <mesh 
      position={midpoint} 
      quaternion={rotation}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); onHover({ ...info, x: e.clientX, y: e.clientY }); }}
      onPointerOut={() => { setHovered(false); onHover(null); }}
      scale={hovered ? [1.1, 1, 1.1] : [1, 1, 1]}
    >
      <cylinderGeometry args={[topRadius, bottomRadius, distance * 0.98, 12]} />
      <meshStandardMaterial 
        color={hovered ? '#ffd700' : color} 
        map={texture}
        metalness={0.15} 
        roughness={0.7}
        emissive={hovered ? '#fbbf24' : '#000000'}
        emissiveIntensity={hovered ? 0.3 : 0}
      />
    </mesh>
  );
};

const VertexJoint: React.FC<{ position: [number, number, number]; size: number; connectionType: ConnectionType }> = ({ position, size, connectionType }) => {
  if (connectionType === 'goodkarma') return null;
  
  const jointSize = size / 60; // Added spaces around division
  
  return (
    <mesh position={position}>
      {connectionType === 'pipe' ? (
        <cylinderGeometry args={[size * 1.8, size * 1.8, (size / 1.5), 16]} />
      ) : (
        <sphereGeometry args={[size, 16, 16]} />
      )}
      <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.1} />
    </mesh>
  );
};

const Viewer3D: React.FC<Viewer3DProps> = ({ data, beamWidth, woodIntensity, woodColor, connectionType }) => {
  const [tooltip, setTooltip] = useState<TooltipInfo | null>(null);
  const woodTex = useMemo(() => createWoodTexture(woodColor, woodIntensity), [woodColor, woodIntensity]);

  const handleStrutHover = useCallback((info: TooltipInfo | null) => {
    setTooltip(info);
  }, []);

  return (
    <div className="w-full h-full relative bg-slate-100 cursor-crosshair">
      <Canvas camera={{ position: [8, 8, 12], fov: 45 }} shadows dpr={[1, 2]}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.6} />
          <spotLight position={[10, 15, 10]} angle={0.3} penumbra={1} intensity={2} castShadow />
          <directionalLight position={[-10, 10, -5]} intensity={0.5} />
          
          <group>
            {data.edges.map((edge, idx) => {
              const strutInfo = data.strutTypes.find(s => s.type === edge.type) || data.strutTypes[0];
              return (
                <Strut 
                  key={`strut-${idx}`} 
                  start={data.vertices[edge.start]} 
                  end={data.vertices[edge.end]} 
                  color={strutInfo.color}
                  width={beamWidth}
                  texture={woodTex}
                  info={strutInfo}
                  connectionType={connectionType}
                  onHover={handleStrutHover}
                />
              );
            })}
            {data.vertices.map((v, idx) => (
              <VertexJoint 
                key={`joint-${idx}`} 
                position={v} 
                size={beamWidth / 60} 
                connectionType={connectionType}
              />
            ))}
          </group>

          <Grid infiniteGrid sectionSize={1} cellSize={0.5} sectionColor="#94a3b8" cellColor="#cbd5e1" />
          <ContactShadows opacity={0.3} scale={20} blur={2.5} far={5} />
          <OrbitControls makeDefault minDistance={2} maxDistance={30} />
          <Environment preset="studio" />
        </Suspense>
      </Canvas>

      {tooltip && (
        <div 
          className="fixed z-[100] pointer-events-none bg-slate-900/95 backdrop-blur-md text-white px-4 py-3 rounded-xl shadow-2xl border border-white/20 text-xs text-right min-w-[160px] animate-in fade-in zoom-in duration-200"
          style={{ left: `${tooltip.x + 20}px`, top: `${tooltip.y + 20}px` }}
        >
          <div className="font-bold border-b border-white/10 pb-2 mb-2 text-orange-400 flex items-center justify-between gap-2">
            <span>العارضة النوع {tooltip.type}</span>
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: 'currentColor' }}></div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">الطول:</span>
              <span className="font-mono text-orange-200">{(tooltip.length * 100).toFixed(1)} سم</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">زاوية الوجه:</span>
              <span className="font-mono text-blue-200">{tooltip.angleFace.toFixed(1)}°</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Viewer3D;
