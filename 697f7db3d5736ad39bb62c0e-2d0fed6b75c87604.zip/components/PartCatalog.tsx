
import React, { Suspense, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stage } from '@react-three/drei';
import * as THREE from 'three';
import { DomeStrut, ConnectionType } from '../types';
import { Strut } from './Viewer3D';
import { Box, Layers } from 'lucide-react';

interface PartCatalogProps {
  struts: DomeStrut[];
  connectionType: ConnectionType;
  beamWidth: number;
  woodColor: string;
}

const SingleStrutPreview: React.FC<{ 
  strut: DomeStrut; 
  connectionType: ConnectionType; 
  beamWidth: number;
  woodColor: string;
}> = ({ strut, connectionType, beamWidth, woodColor }) => {
  const texture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 64; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = woodColor;
      ctx.fillRect(0, 0, 64, 128);
      ctx.strokeStyle = 'rgba(0,0,0,0.1)';
      for(let i=0; i<20; i++) {
        ctx.beginPath();
        ctx.moveTo(Math.random() * 64, 0);
        ctx.lineTo(Math.random() * 64, 128);
        ctx.stroke();
      }
    }
    return new THREE.CanvasTexture(canvas);
  }, [woodColor]);

  const halfLength = strut.length / 2;

  return (
    <div className="h-48 bg-slate-900/5 rounded-xl border border-slate-200 overflow-hidden relative group">
      <Canvas camera={{ position: [0, 0, 2], fov: 35 }}>
        <Suspense fallback={null}>
          <Stage environment="city" intensity={0.5} contactShadow={false} adjustCamera={false}>
            <Strut 
              start={[0, -halfLength, 0]} 
              end={[0, halfLength, 0]} 
              color={strut.color}
              width={beamWidth}
              texture={texture}
              info={strut}
              connectionType={connectionType}
              onHover={() => {}}
            />
          </Stage>
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={4} />
        </Suspense>
      </Canvas>
      <div className="absolute bottom-2 right-2 bg-white/80 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
        عرض ثلاثي الأبعاد
      </div>
    </div>
  );
};

const PartCatalog: React.FC<PartCatalogProps> = ({ struts, connectionType, beamWidth, woodColor }) => {
  return (
    <section className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center gap-3 border-r-4 border-blue-600 pr-4">
        <Box className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-slate-800">كتالوج الأجزاء المنفصلة</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {struts.map((strut) => (
          <div key={strut.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 flex items-center justify-center rounded-lg bg-slate-100 font-bold text-slate-700 text-lg">
                  {strut.type}
                </span>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">عـارضة أساسـية</span>
              </div>
              <div className="px-3 py-1 bg-orange-50 text-orange-600 rounded-full text-[10px] font-bold">
                {strut.count} قطعة
              </div>
            </div>

            <SingleStrutPreview 
              strut={strut} 
              connectionType={connectionType} 
              beamWidth={beamWidth} 
              woodColor={woodColor} 
            />

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="block text-slate-400 mb-1">الطول</span>
                <span className="font-mono font-bold text-slate-800">{(strut.length * 100).toFixed(1)} سم</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="block text-slate-400 mb-1">الزاوية</span>
                <span className="font-mono font-bold text-orange-600">{strut.angleFace.toFixed(1)}°</span>
              </div>
            </div>
            
            <button className="w-full py-2 text-[10px] font-bold text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors flex items-center justify-center gap-2">
              <Layers className="w-3 h-3" />
              تـصدير بيانات القص
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};

export default PartCatalog;
