
import React from 'react';
import { Box, Menu } from 'lucide-react';

interface HeaderProps {
  onToggleSidebar?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onToggleSidebar }) => {
  return (
    <header className="bg-slate-900 text-white p-4 shadow-lg flex items-center justify-between z-50 relative">
      <div className="flex items-center gap-3">
        <button 
          onClick={onToggleSidebar}
          className="md:hidden p-2 hover:bg-slate-800 rounded-md transition-colors"
          aria-label="Toggle menu"
        >
          <Menu className="w-6 h-6 text-orange-500" />
        </button>
        <Box className="w-8 h-8 text-orange-500 hidden sm:block" />
        <div>
          <h1 className="text-lg md:text-xl font-bold leading-none">مـهـنـدس الـقـبـاب</h1>
          <p className="text-[10px] md:text-xs text-slate-400">حاسبة هندسية ذكية للتصاميم الجيوديسية</p>
        </div>
      </div>
      <div className="hidden sm:block">
        <span className="text-xs md:text-sm bg-slate-800 px-3 py-1 rounded-full border border-slate-700 text-slate-300">
          محرك Acidome v2.0
        </span>
      </div>
    </header>
  );
};

export default Header;
