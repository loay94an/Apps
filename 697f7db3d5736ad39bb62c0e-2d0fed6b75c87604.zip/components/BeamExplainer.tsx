
import React from 'react';
import { ConnectionType } from '../types';
// Add missing Layers import
import { Info, HelpCircle, CheckCircle2, Layers } from 'lucide-react';

interface BeamExplainerProps {
  connectionType: ConnectionType;
}

const BeamExplainer: React.FC<BeamExplainerProps> = ({ connectionType }) => {
  const descriptions: Record<ConnectionType, { title: string; desc: string; advice: string; pros: string[] }> = {
    hub: {
      title: "نظام الموصل المركزي (Standard Hub)",
      desc: "تعتمد هذه الطريقة على التقاء رؤوس العوارض في مركز واحد يتم تثبيته بواسطة موصل معدني (Hub). العوارض تُقص بشكل مستوٍ أو بزاوية بسيطة لتناسب الموصل.",
      advice: "أفضل خيار للمبتدئين وللقباب التي يراد فكها ونقلها باستمرار.",
      pros: ["سهولة التركيب", "قابلية الفك", "توفر قطع جاهزة"]
    },
    goodkarma: {
      title: "نظام جود كارما (GoodKarma Hubless)",
      desc: "تقنية تعتمد على إزاحة العوارض لتتجاوز بعضها البعض (Bypass) بدلاً من الالتقاء في نقطة واحدة. يتم التثبيت بالبراغي بشكل جانبي ومباشر.",
      advice: "يتطلب دقة متناهية في قص الزوايا الجانبية للأخشاب (Dihedral Angles).",
      pros: ["استقرار هيكلي عالي", "توفير تكلفة الموصلات", "مظهر خشبي طبيعي"]
    },
    pipe: {
      title: "نظام الأنابيب المعدنية (Pipe Joints)",
      desc: "يتم استخدام قطع من الأنابيب في المفاصل، حيث توضع العوارض فوقها أو حولها وتثبت بأطواق معدنية.",
      advice: "ممتاز للقباب الكبيرة التي تتطلب تهوية مركزية عند المفاصل.",
      pros: ["قوة تحمل عالية", "إمكانية تمرير كابلات", "مقاومة للرياح"]
    },
    conical: {
      title: "القص المخروطي الكامل (Full Conical)",
      desc: "تُقص نهايات العوارض بزوايا مركبة حادة لتلتحم تماماً في الرأس مكونة شكلاً مخروطياً داخلياً.",
      advice: "أكثر الطرق جمالاً من الداخل، ولكنها الأصعب من حيث التنفيذ اليدوي.",
      pros: ["مظهر داخلي انسيابي", "إغلاق كامل للفراغات", "فخامة هندسية"]
    },
    'semi-conical': {
      title: "القص شبه المخروطي (Semi-Conical)",
      desc: "تطوير للنظام المخروطي يقلل من حدة الزاوية لزيادة مساحة التلامس بين العوارض وتسهيل التثبيت بالبراغي.",
      advice: "الخيار الأمثل للجمع بين المظهر الاحترافي وسهولة الإنشاء.",
      pros: ["توازن بين القوة والجمال", "مساحة تثبيت أفضل", "أقل عرضة للتصدع"]
    }
  };

  const info = descriptions[connectionType];

  return (
    <div className="bg-slate-900 text-white rounded-[2rem] p-8 md:p-12 shadow-2xl border border-white/5 relative overflow-hidden group">
      {/* Abstract Background Decoration */}
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl group-hover:bg-blue-600/20 transition-colors duration-1000"></div>
      
      <div className="relative z-10 grid lg:grid-cols-5 gap-10 items-center">
        <div className="lg:col-span-3 space-y-8">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-600/20 rotate-3 group-hover:rotate-0 transition-transform">
              <Info className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-2xl md:text-3xl font-bold tracking-tight">{info.title}</h3>
              <p className="text-blue-400 font-medium text-sm md:text-base mt-1">تـوضيح آلـية الاتـصال والتركـيب</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/5 p-6 rounded-2xl border border-white/5 hover:bg-white/[0.08] transition-colors">
              <h4 className="text-orange-400 text-sm font-bold mb-3 flex items-center gap-2">
                <HelpCircle className="w-4 h-4" /> المبدأ الهندسي
              </h4>
              <p className="text-slate-300 leading-relaxed md:text-lg">{info.desc}</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
               {info.pros.map((pro, i) => (
                 <div key={i} className="flex items-center gap-3 text-slate-400 text-sm">
                   <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                   {pro}
                 </div>
               ))}
            </div>
          </div>

          <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/20">
            <span className="text-orange-400 text-xs font-bold uppercase tracking-widest block mb-2">تـوصية خبير:</span>
            <p className="text-sm text-orange-100 italic leading-relaxed">{info.advice}</p>
          </div>
        </div>

        <div className="lg:col-span-2 aspect-square md:aspect-auto md:h-full bg-slate-800/50 rounded-3xl border border-white/10 flex flex-col items-center justify-center p-8 relative overflow-hidden">
           <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent"></div>
           
           {/* Visual Aid Area */}
           <div className="relative w-full h-full flex flex-col items-center justify-center">
              <div className="mb-6 opacity-40">
                <Layers className="w-24 h-24 text-slate-400" />
              </div>
              <p className="text-[10px] text-slate-500 font-mono text-center leading-relaxed">
                TECHNICAL DRAWING MODIFIED<br/>
                SYSTEM: {connectionType.toUpperCase()}<br/>
                TYPE: GEODESIC JOINT
              </p>
              
              {/* Dynamic connection representation mockup */}
              <div className="mt-8 flex gap-2">
                 <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                 <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                 <div className="w-2 h-2 rounded-full bg-slate-600"></div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default BeamExplainer;
