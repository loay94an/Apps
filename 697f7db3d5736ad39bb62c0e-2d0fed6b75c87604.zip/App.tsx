
import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Viewer3D from './components/Viewer3D';
import ResultsTable from './components/ResultsTable';
import StrutDiagrams from './components/StrutDiagrams';
import BeamExplainer from './components/BeamExplainer';
import PartCatalog from './components/PartCatalog';
import { calculateGeodesicDome } from './services/domeLogic';
import { CalculatorConfig } from './types';
import { ChevronDown, ChevronUp, Printer, Info, Maximize2 } from 'lucide-react';

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSummaryExpanded, setIsSummaryExpanded] = useState(true);
  const [config, setConfig] = useState<CalculatorConfig>({
    polyhedron: 'icosahedron',
    frequency: 3,
    subdivisionMethod: 'kruschke',
    domePart: 0.5,
    connectionType: 'hub',
    radius: 2.5,
    beamWidth: 10.0,
    beamHeight: 5.0,
    woodIntensity: 0.7,
    woodColor: '#d2b48c'
  });

  const domeData = useMemo(() => {
    return calculateGeodesicDome(config);
  }, [config]);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="flex flex-col h-screen bg-gray-50 overflow-hidden">
      <Header onToggleSidebar={toggleSidebar} />
      
      <main className="flex flex-1 overflow-hidden relative">
        <Sidebar config={config} onChange={setConfig} isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Top Visualizer Area */}
          <div className="flex-[3] md:flex-[5] relative border-b border-gray-200">
            <Viewer3D 
              data={domeData} 
              beamWidth={config.beamWidth} 
              woodIntensity={config.woodIntensity} 
              woodColor={config.woodColor} 
              connectionType={config.connectionType}
            />
            
            <div className="absolute top-4 left-4 z-40 w-72 bg-slate-900/90 backdrop-blur text-white rounded-2xl shadow-2xl border border-white/10 overflow-hidden text-xs md:text-sm">
              <div 
                className="p-4 bg-white/5 flex items-center justify-between cursor-pointer hover:bg-white/10 transition-colors"
                onClick={() => setIsSummaryExpanded(!isSummaryExpanded)}
              >
                <span className="font-bold flex items-center gap-2">
                  <Info className="w-4 h-4 text-orange-400" />
                  بيانات القبة الهندسية
                </span>
                {isSummaryExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </div>
              
              {isSummaryExpanded && (
                <div className="p-5 space-y-4 font-mono">
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">الارتفاع:</span>
                    <span className="text-orange-200">{(domeData.stats.height * 100).toFixed(1)} سم</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">قطر القاعدة:</span>
                    <span className="text-orange-200">{(domeData.stats.baseRadius * 2 * 100).toFixed(1)} سم</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">مساحة السطح:</span>
                    <span className="text-blue-200">{domeData.stats.surfaceArea.toFixed(2)} م²</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400">عدد العوارض:</span>
                    <span className="text-orange-400 font-bold">{domeData.edges.length} قطعة</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">إجمالي الخشب:</span>
                    <span className="text-slate-200">{(domeData.stats.totalStrutLength).toFixed(1)} م</span>
                  </div>
                </div>
              )}
            </div>

            <div className="absolute bottom-6 right-6 flex flex-col gap-3">
              <button 
                onClick={() => window.print()}
                className="p-4 bg-white hover:bg-slate-50 text-slate-700 rounded-2xl shadow-xl border border-slate-200 transition-all active:scale-95 group"
              >
                <Printer className="w-6 h-6 group-hover:text-blue-600 transition-colors" />
              </button>
              <button 
                className="p-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl shadow-xl border border-blue-500 transition-all active:scale-95"
                title="ملء الشاشة"
              >
                <Maximize2 className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Bottom Results Panel */}
          <div className="flex-[2] overflow-y-auto bg-white shadow-inner">
            <div className="max-w-7xl mx-auto p-6 md:p-12 space-y-20">
              <BeamExplainer connectionType={config.connectionType} />
              <PartCatalog 
                struts={domeData.strutTypes} 
                connectionType={config.connectionType} 
                beamWidth={config.beamWidth} 
                woodColor={config.woodColor}
              />
              <ResultsTable struts={domeData.strutTypes} />
              <StrutDiagrams struts={domeData.strutTypes} beamHeight={config.beamHeight} />
              
              <footer className="pt-16 pb-10 text-center text-slate-400 text-xs border-t border-slate-100">
                <div className="flex justify-center gap-8 mb-4">
                  <span>نظام: {config.subdivisionMethod === 'kruschke' ? 'كروسكي' : 'أوتار متعادلة'}</span>
                  <span>النوع: {config.polyhedron}</span>
                </div>
                <p className="font-bold text-slate-500">مـهـنـدس الـقـبـاب © 2025</p>
                <p className="mt-1 opacity-60 italic">صمم بكل فخر لهواة العمارة الهندسية</p>
              </footer>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
