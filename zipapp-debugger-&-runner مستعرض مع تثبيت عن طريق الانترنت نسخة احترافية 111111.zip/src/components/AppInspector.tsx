import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeft,
  Play,
  Download,
  Folder,
  FolderTree,
  Code,
  Save,
  Copy,
  Check,
  Search,
  FileText,
  FileCode,
  File,
  ChevronDown,
  FileJson,
  FileSpreadsheet
} from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { DownloadDropdown } from './DownloadDropdown';

interface AppInspectorProps {
  lang: Language;
  app: AppMetadata;
  onBack: () => void;
  onRunApp: (app: AppMetadata) => void;
  onUpdateApp: (updated: AppMetadata) => void;
}

export const AppInspector: React.FC<AppInspectorProps> = ({
  lang,
  app,
  onBack,
  onRunApp,
  onUpdateApp,
}) => {
  const isAr = lang === 'ar';
  const fileKeys = useMemo(() => Object.keys(app.files).sort(), [app.files]);
  
  const initialPath = useMemo(() => {
    return fileKeys.find((p) => p.endsWith('.html')) || fileKeys[0] || 'index.html';
  }, [fileKeys]);

  const [selectedFilePath, setSelectedFilePath] = useState<string>(initialPath);
  const [editedContent, setEditedContent] = useState<string>(app.files[initialPath]?.content || '');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [mobileShowFileTree, setMobileShowFileTree] = useState(false);
  const [saveNotice, setSaveNotice] = useState(false);
  const [copiedNotice, setCopiedNotice] = useState(false);

  // Sync state whenever the inspected app changes or file selection changes
  useEffect(() => {
    const keys = Object.keys(app.files).sort();
    const defaultPath = keys.find((p) => p.endsWith('.html')) || keys[0] || 'index.html';
    setSelectedFilePath(defaultPath);
    setEditedContent(app.files[defaultPath]?.content || '');
    setSaveNotice(false);
    setCopiedNotice(false);
  }, [app.id]);

  const selectedFile = app.files[selectedFilePath];

  const handleSelectFile = (path: string) => {
    setSelectedFilePath(path);
    setEditedContent(app.files[path]?.content || '');
    setSaveNotice(false);
    setCopiedNotice(false);
    setMobileShowFileTree(false);
  };

  const handleSaveFileChanges = () => {
    if (!selectedFile) return;
    const updatedFiles = {
      ...app.files,
      [selectedFilePath]: {
        ...selectedFile,
        content: editedContent,
      },
    };
    onUpdateApp({
      ...app,
      files: updatedFiles,
    });
    setSaveNotice(true);
    setTimeout(() => setSaveNotice(false), 2000);
  };

  const handleCopyCode = () => {
    if (!editedContent) return;
    navigator.clipboard.writeText(editedContent);
    setCopiedNotice(true);
    setTimeout(() => setCopiedNotice(false), 2000);
  };

  const handleDownloadSingleFile = () => {
    if (!selectedFile) return;
    const blob = new Blob([editedContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const fileName = selectedFilePath.split('/').pop() || 'file.txt';
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Filter file list by search query
  const filteredFileKeys = useMemo(() => {
    if (!searchTerm.trim()) return fileKeys;
    const term = searchTerm.toLowerCase();
    return fileKeys.filter((key) => key.toLowerCase().includes(term));
  }, [fileKeys, searchTerm]);

  // Helper function to return icon for file extension
  const getFileIcon = (path: string) => {
    const ext = path.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'html':
      case 'htm':
        return <FileCode className="w-4 h-4 text-amber-400 flex-shrink-0" />;
      case 'js':
      case 'jsx':
      case 'ts':
      case 'tsx':
        return <Code className="w-4 h-4 text-sky-400 flex-shrink-0" />;
      case 'json':
        return <FileJson className="w-4 h-4 text-emerald-400 flex-shrink-0" />;
      case 'css':
      case 'scss':
        return <FileSpreadsheet className="w-4 h-4 text-indigo-400 flex-shrink-0" />;
      case 'md':
      case 'txt':
        return <FileText className="w-4 h-4 text-slate-400 flex-shrink-0" />;
      default:
        return <File className="w-4 h-4 text-slate-400 flex-shrink-0" />;
    }
  };

  const lineCount = useMemo(() => {
    if (!editedContent) return 1;
    return editedContent.split('\n').length;
  }, [editedContent]);

  return (
    <div className="max-w-7xl mx-auto py-3 sm:py-6 px-2 sm:px-4 flex flex-col min-h-[calc(100vh-80px)]">
      {/* Top File Explorer Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center"
            title={isAr ? 'العودة لمعرض التطبيقات' : 'Back to Catalog'}
          >
            <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <FolderTree className="w-5 h-5 text-indigo-400 flex-shrink-0" />
              <h2 className="text-base sm:text-lg font-bold text-white truncate">{app.name}</h2>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full font-mono flex-shrink-0">
                {app.framework}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate mt-0.5">
              {isAr ? 'مستعرض ملفات التطبيق وهيكليته' : 'App File Browser & Directory Structure'} • <span className="text-indigo-300 font-mono">{fileKeys.length} {isAr ? 'ملفات' : 'files'}</span>
            </p>
          </div>
        </div>

        {/* Header Quick Actions */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => onRunApp(app)}
            className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold px-3.5 sm:px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition min-h-[40px]"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isAr ? 'تشغيل التطبيق' : 'Run App'}</span>
          </button>

          <DownloadDropdown lang={lang} app={app} variant="compact" onRunApp={() => onRunApp(app)} />
        </div>
      </div>

      {/* Main File Explorer Workspace */}
      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col md:flex-row shadow-2xl min-h-[550px]">
        
        {/* Mobile File Selector Dropdown Header */}
        <div className="md:hidden bg-slate-950 p-2.5 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={() => setMobileShowFileTree(!mobileShowFileTree)}
            className="w-full bg-slate-900 border border-slate-800 text-slate-200 px-3 py-2 rounded-xl text-xs font-mono flex items-center justify-between"
          >
            <span className="flex items-center gap-2 truncate">
              {getFileIcon(selectedFilePath)}
              <span className="truncate">{selectedFilePath}</span>
            </span>
            <ChevronDown className={`w-4 h-4 transition ${mobileShowFileTree ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* File Tree Panel (Sidebar) */}
        <div
          className={`w-full md:w-72 bg-slate-950 border-r border-slate-800 flex flex-col flex-shrink-0 ${
            mobileShowFileTree ? 'block' : 'hidden md:flex'
          }`}
        >
          {/* File Explorer Search Header */}
          <div className="p-3 border-b border-slate-800 bg-slate-900/50 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Folder className="w-3.5 h-3.5 text-indigo-400" />
                {isAr ? 'هيكلة الملفات' : 'File Explorer'}
              </span>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-mono">
                {fileKeys.length} {isAr ? 'ملف' : 'files'}
              </span>
            </div>

            {/* Filter Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute top-2.5 right-2.5 rtl:right-2.5 rtl:left-auto ltr:left-2.5 ltr:right-auto pointer-events-none" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={isAr ? 'بحث عن ملف...' : 'Search file...'}
                className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg py-1.5 ltr:pl-8 ltr:pr-3 rtl:pr-8 rtl:pl-3 focus:outline-none focus:border-indigo-500/50"
              />
            </div>
          </div>

          {/* File Tree Items List */}
          <div className="max-h-72 md:max-h-none flex-1 overflow-y-auto p-2 space-y-1">
            {filteredFileKeys.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs">
                {isAr ? 'لا توجد ملفات مطابقة' : 'No matching files'}
              </div>
            ) : (
              filteredFileKeys.map((path) => {
                const isSelected = path === selectedFilePath;
                const pathParts = path.split('/');
                const fileName = pathParts.pop() || path;
                const dirPath = pathParts.join('/');

                return (
                  <button
                    key={path}
                    onClick={() => handleSelectFile(path)}
                    className={`w-full text-left rtl:text-right px-3 py-2 rounded-xl text-xs font-mono transition flex items-center justify-between gap-2 active:scale-98 ${
                      isSelected
                        ? 'bg-indigo-600/20 text-indigo-200 border border-indigo-500/40 font-semibold shadow-sm'
                        : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate min-w-0">
                      {getFileIcon(path)}
                      <div className="truncate text-left rtl:text-right">
                        <span className="block truncate">{fileName}</span>
                        {dirPath && (
                          <span className="block text-[9px] text-slate-500 truncate">
                            {dirPath}/
                          </span>
                        )}
                      </div>
                    </div>
                    {path === app.entryPoint && (
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded flex-shrink-0">
                        entry
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Main Code View & Editor Pane */}
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-950 min-h-[450px]">
          {/* File Toolbar Header */}
          <div className="border-b border-slate-800 bg-slate-900 px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 truncate min-w-0">
              {getFileIcon(selectedFilePath)}
              <span className="text-xs sm:text-sm font-mono text-slate-200 font-medium truncate">
                {selectedFilePath}
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono hidden sm:inline-block">
                {lineCount} {isAr ? 'سطر' : 'lines'}
              </span>
            </div>

            {/* Code Actions (Copy, Save, Single File Download) */}
            <div className="flex items-center gap-1.5 flex-shrink-0">
              {copiedNotice && (
                <span className="text-xs text-emerald-400 flex items-center gap-1 font-medium">
                  <Check className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isAr ? 'تم النسخ!' : 'Copied!'}</span>
                </span>
              )}

              {saveNotice && (
                <span className="text-xs text-emerald-400 flex items-center gap-1 font-medium">
                  <Check className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isAr ? 'تم الحفظ!' : 'Saved!'}</span>
                </span>
              )}

              {!selectedFile?.isBinary && (
                <>
                  <button
                    onClick={handleCopyCode}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition text-xs flex items-center gap-1"
                    title={isAr ? 'نسخ الكود' : 'Copy Code'}
                  >
                    <Copy className="w-3.5 h-3.5 text-slate-300" />
                  </button>

                  <button
                    onClick={handleDownloadSingleFile}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition text-xs flex items-center gap-1"
                    title={isAr ? 'تنزيل هذا الملف' : 'Download File'}
                  >
                    <Download className="w-3.5 h-3.5 text-slate-300" />
                  </button>

                  <button
                    onClick={handleSaveFileChanges}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition active:scale-95"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isAr ? 'حفظ' : 'Save'}</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Code Text Editor Container */}
          <div className="flex-1 p-2 sm:p-4 flex flex-col bg-slate-950 font-mono text-xs overflow-hidden">
            {selectedFile?.isBinary ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-500 p-8 text-center space-y-2">
                <File className="w-12 h-12 text-slate-600" />
                <p>{isAr ? 'ملف ثنائي غير قابل للتعديل المباشر' : 'Binary file preview not editable directly'}</p>
              </div>
            ) : (
              <div className="flex-1 flex rounded-xl border border-slate-800 bg-slate-950 overflow-hidden">
                {/* Line Numbers Column */}
                <div className="bg-slate-900/60 py-3 px-2 text-right rtl:text-left select-none text-slate-600 border-r border-slate-800 text-[11px] font-mono leading-relaxed min-w-[40px] hidden sm:block overflow-hidden">
                  {Array.from({ length: lineCount }).map((_, idx) => (
                    <div key={idx}>{idx + 1}</div>
                  ))}
                </div>

                {/* Main Textarea Editor */}
                <textarea
                  value={editedContent}
                  onChange={(e) => setEditedContent(e.target.value)}
                  className="w-full flex-1 bg-slate-950 text-slate-200 p-3 sm:p-4 font-mono text-xs focus:outline-none resize-none leading-relaxed min-h-[400px] selection:bg-indigo-500/30"
                  placeholder={isAr ? 'اكتب أو عدل الأكواد هنا...' : 'Edit code here...'}
                  spellCheck={false}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
