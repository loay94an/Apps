import React, { useState, useEffect } from 'react';
import { AppMetadata, Language, ViewMode } from './types';
import { SAMPLE_APPS } from './data/sampleApps';
import { Header } from './components/Header';
import { AppCatalog } from './components/AppCatalog';
import { ZipUploader } from './components/ZipUploader';
import { AppInspector } from './components/AppInspector';
import { AppRunnerModal } from './components/AppRunnerModal';

const STORAGE_KEY = 'app_browser_saved_apps_v1';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [apps, setApps] = useState<AppMetadata[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load apps from localStorage', e);
    }
    return SAMPLE_APPS;
  });
  const [activeView, setActiveView] = useState<ViewMode>('catalog');
  const [selectedApp, setSelectedApp] = useState<AppMetadata | null>(null);
  const [runningApp, setRunningApp] = useState<AppMetadata | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));
    } catch (e) {
      console.error('Failed to save apps to localStorage', e);
    }
  }, [apps]);

  const handleAppUploaded = (newApp: AppMetadata) => {
    setApps((prev) => [newApp, ...prev.filter((a) => a.id !== newApp.id)]);
  };

  const handleUpdateApp = (updatedApp: AppMetadata) => {
    setApps((prev) => prev.map((a) => (a.id === updatedApp.id ? updatedApp : a)));
    if (selectedApp?.id === updatedApp.id) {
      setSelectedApp(updatedApp);
    }
  };

  const handleDeleteApp = (appId: string) => {
    setApps((prev) => prev.filter((a) => a.id !== appId));
    if (selectedApp?.id === appId) {
      setSelectedApp(null);
      setActiveView('catalog');
    }
    if (runningApp?.id === appId) {
      setRunningApp(null);
    }
  };

  const handleInspectApp = (app: AppMetadata) => {
    setSelectedApp(app);
    setActiveView('inspector');
  };

  const handleRunApp = (app: AppMetadata) => {
    setRunningApp(app);
  };

  const fixedCount = apps.filter((a) => a.diagnostics.length === 0).length;

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 font-sans ${lang === 'ar' ? 'rtl' : 'ltr'}`} dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <Header
        lang={lang}
        setLang={setLang}
        activeView={activeView}
        setActiveView={setActiveView}
        appsCount={apps.length}
        fixedCount={fixedCount}
      />

      <main className="pb-20 sm:pb-8">
        {activeView === 'catalog' && (
          <AppCatalog
            lang={lang}
            apps={apps}
            onSelectApp={handleInspectApp}
            onRunApp={handleRunApp}
            onUpdateApp={handleUpdateApp}
            onDeleteApp={handleDeleteApp}
            onGoToUpload={() => setActiveView('uploader')}
          />
        )}

        {activeView === 'uploader' && (
          <ZipUploader
            lang={lang}
            onAppUploaded={handleAppUploaded}
            onInspectApp={(app) => {
              setSelectedApp(app);
              setActiveView('inspector');
            }}
            onRunApp={handleRunApp}
          />
        )}

        {activeView === 'inspector' && selectedApp && (
          <AppInspector
            lang={lang}
            app={selectedApp}
            onBack={() => setActiveView('catalog')}
            onRunApp={handleRunApp}
            onUpdateApp={handleUpdateApp}
          />
        )}
      </main>

      {/* Live App Sandbox Runner Modal */}
      {runningApp && (
        <AppRunnerModal
          lang={lang}
          app={runningApp}
          onClose={() => setRunningApp(null)}
          onInspect={() => {
            setSelectedApp(runningApp);
            setRunningApp(null);
            setActiveView('inspector');
          }}
        />
      )}
    </div>
  );
}
