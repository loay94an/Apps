import React, { useState } from 'react';
import { ArrowLeft, Play, Wrench, Download, Folder, CheckCircle2, AlertTriangle, Code, Save, ChevronDown } from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { autoFixAndReorganizeApp, createZipBlobFromApp } from '../utils/zipParser';

interface AppInspectorProps {
  lang: Language;
  app: AppMetadata;
  onBack: () => void;
  onRunApp: (app: AppMetadata) => void;
  onUpdateApp: (updated: AppMetadata) => void;
}

export const AppInspector: React.FC<AppInspectorProps> = ({
  lang,
  app,
  onBack,
  onRunApp,
  onUpdateApp,
}) => {
  const isAr = lang === 'ar';
  const fileKeys = Object.keys(app.files).sort();
  const initialPath = fileKeys.find((p) => p.endsWith('.html')) || fileKeys[0] || 'index.html';
  
  const [selectedFilePath, setSelectedFilePath] = useState<string>(initialPath);
  const [editedContent, setEditedContent] = useState<string>(app.files[initialPath]?.content || '');
  const [activeTab, setActiveTab] = useState<'code' | 'diagnostics'>('code');
  const [mobileShowFileTree, setMobileShowFileTree] = useState(false);
  const [saveNotice, setSaveNotice] = useState(false);

  // Sync state whenever the inspected app changes
  React.useEffect(() => {
    const keys = Object.keys(app.files).sort();
    const defaultPath = keys.find((p) => p.endsWith('.html')) || keys[0] || 'index.html';
    setSelectedFilePath(defaultPath);
    setEditedContent(app.files[defaultPath]?.content || '');
    setSaveNotice(false);
  }, [app.id]);

  const selectedFile = app.files[selectedFilePath];

  const handleSelectFile = (path: string) => {
    setSelectedFilePath(path);
    setEditedContent(app.files[path]?.content || '');
    setSaveNotice(false);
    setMobileShowFileTree(false);
  };

  const handleSaveFileChanges = () => {
    if (!selectedFile) return;
    const updatedFiles = {
      ...app.files,
      [selectedFilePath]: {
        ...selectedFile,
        content: editedContent,
      },
    };
    onUpdateApp({
      ...app,
      files: updatedFiles,
    });
    setSaveNotice(true);
    setTimeout(() => setSaveNotice(false), 2000);
  };

  const handleAutoFix = () => {
    const fixed = autoFixAndReorganizeApp(app);
    onUpdateApp(fixed);
    if (fixed.files[selectedFilePath]) {
      setEditedContent(fixed.files[selectedFilePath].content);
    }
  };

  const handleDownloadZip = async () => {
    const blob = await createZipBlobFromApp(app);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${app.name.toLowerCase().replace(/\s+/g, '-')}-reorganized.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto py-3 sm:py-6 px-2 sm:px-4 flex flex-col min-h-[calc(100vh-80px)]">
      {/* Top Inspector Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 sm:mb-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBack}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-white truncate">{app.name}</h2>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full font-mono flex-shrink-0">
                {app.framework}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate">
              {Object.keys(app.files).length} {isAr ? 'ملف' : 'files'} • <code className="text-sky-300">{app.entryPoint}</code>
            </p>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => onRunApp(app)}
            className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-3 sm:px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition min-h-[40px]"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isAr ? 'تشغيل' : 'Run App'}</span>
          </button>

          <button
            onClick={handleAutoFix}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-3 sm:px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition min-h-[40px]"
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>{isAr ? 'تصحيح تلقائي' : 'Auto-Fix'}</span>
          </button>

          <button
            onClick={handleDownloadZip}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition min-h-[40px]"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isAr ? 'تنزيل ZIP' : 'ZIP'}</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Area */}
      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col md:flex-row shadow-2xl min-h-[500px]">
        
        {/* Mobile File Selector Dropdown Header */}
        <div className="md:hidden bg-slate-950 p-2.5 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={() => setMobileShowFileTree(!mobileShowFileTree)}
            className="w-full bg-slate-900 border border-slate-800 text-slate-200 px-3 py-2 rounded-xl text-xs font-mono flex items-center justify-between"
          >
            <span className="flex items-center gap-2 truncate">
              <Folder className="w-4 h-4 text-indigo-400 flex-shrink-0" />
              <span className="truncate">{selectedFilePath}</span>
            </span>
            <ChevronDown className={`w-4 h-4 transition ${mobileShowFileTree ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* File Tree Panel (Hidden on mobile unless toggled, desktop always visible) */}
        <div
          className={`w-full md:w-64 bg-slate-950 border-r border-slate-800 flex flex-col flex-shrink-0 ${
            mobileShowFileTree ? 'block' : 'hidden md:flex'
          }`}
        >
          <div className="p-3 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Folder className="w-3.5 h-3.5 text-indigo-400" />
              {isAr ? 'هيكلية الملفات' : 'File Explorer'}
            </span>
            <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">
              {fileKeys.length}
            </span>
          </div>

          <div className="max-h-60 md:max-h-none flex-1 overflow-y-auto p-2 space-y-1">
            {fileKeys.map((path) => {
              const isSelected = path === selectedFilePath;
              const ext = path.split('.').pop()?.toLowerCase();

              return (
                <button
                  key={path}
                  onClick={() => handleSelectFile(path)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono transition flex items-center justify-between active:scale-98 ${
                    isSelected
                      ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 font-semibold'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <span className="truncate">{path}</span>
                  <span className="text-[10px] text-slate-500 uppercase">{ext}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Editor & Diagnostics Area */}
        <div className="flex-1 flex flex-col overflow-hidden bg-slate-950 min-h-[400px]">
          {/* Subheader tabs */}
          <div className="border-b border-slate-800 bg-slate-900 px-3 sm:px-4 py-2 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setActiveTab('code')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                  activeTab === 'code'
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Code className="w-3.5 h-3.5 text-sky-400" />
                <span className="hidden sm:inline">{selectedFilePath}</span>
                <span className="sm:hidden">{isAr ? 'الكود' : 'Code'}</span>
              </button>

              <button
                onClick={() => setActiveTab('diagnostics')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ${
                  activeTab === 'diagnostics'
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>{isAr ? 'الأخطاء' : 'Diagnostics'}</span>
                {app.diagnostics.length > 0 && (
                  <span className="bg-amber-500/20 text-amber-300 text-[10px] px-1.5 rounded-full font-mono">
                    {app.diagnostics.length}
                  </span>
                )}
              </button>
            </div>

            {activeTab === 'code' && !selectedFile?.isBinary && (
              <div className="flex items-center gap-2">
                {saveNotice && (
                  <span className="text-xs text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{isAr ? 'تم الحفظ!' : 'Saved!'}</span>
                  </span>
                )}
                <button
                  onClick={handleSaveFileChanges}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition active:scale-95 min-h-[36px]"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isAr ? 'حفظ' : 'Save'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Tab 1: Code Editor View */}
          {activeTab === 'code' && (
            <div className="flex-1 p-2 sm:p-4 flex flex-col bg-slate-950 font-mono text-xs">
              {selectedFile?.isBinary ? (
                <div className="flex-1 flex items-center justify-center text-slate-500 p-8 text-center">
                  {isAr ? 'ملف ثنائي غير قابل للتعديل المباشر' : 'Binary file preview not editable directly'}
                </div>
              ) : (
                <textarea
                  value={editedContent}
                  onChange={(e) => setEditedContent(e.target.value)}
                  className="w-full flex-1 bg-slate-950 text-slate-200 p-3 sm:p-4 font-mono text-xs focus:outline-none resize-none rounded-xl border border-slate-800 leading-relaxed focus:border-indigo-500/50 min-h-[350px]"
                  placeholder={isAr ? 'اكتب أو عدل الأكواد هنا...' : 'Edit code here...'}
                />
              )}
            </div>
          )}

          {/* Tab 2: Diagnostics Panel */}
          {activeTab === 'diagnostics' && (
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto bg-slate-950">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
                <h3 className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  {isAr ? 'نتائج الفحص التشخيصي للمشروع' : 'Diagnostics Report'}
                </h3>
                <button
                  onClick={handleAutoFix}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إصلاح التلقائي' : 'Auto-Fix'}</span>
                </button>
              </div>

              {app.diagnostics.length === 0 ? (
                <div className="text-center py-12 bg-slate-900/40 border border-slate-800 rounded-2xl">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
                  <h4 className="text-base font-bold text-slate-200">
                    {isAr ? 'لا توجد أخطاء حرجة!' : 'No Critical Errors Detected'}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    {isAr ? 'الهيكلية والنقاط الرئيسية سليمة وجاهزة للتشغيل.' : 'Project structure and entry points are intact.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {app.diagnostics.map((diag) => (
                    <div
                      key={diag.id}
                      className="bg-slate-900 border border-amber-500/30 p-3 sm:p-4 rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-amber-400">
                            {isAr ? diag.titleAr : diag.title}
                          </span>
                          {diag.file && (
                            <span className="text-[10px] bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded">
                              {diag.file}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          {isAr ? diag.descriptionAr : diag.description}
                        </p>
                      </div>

                      {diag.autoFixable && (
                        <button
                          onClick={handleAutoFix}
                          className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1"
                        >
                          <Wrench className="w-3.5 h-3.5" />
                          <span>{isAr ? 'إصلاح' : 'Fix'}</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

