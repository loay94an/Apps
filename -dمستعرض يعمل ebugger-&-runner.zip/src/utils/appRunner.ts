import { AppMetadata } from '../types';

export function generateRunnableSrcDoc(app: AppMetadata): string {
  // 1. Locate primary HTML file or create wrapper HTML
  const indexHtmlFile =
    app.files['index.html'] ||
    app.files['public/index.html'] ||
    app.files['src/index.html'] ||
    Object.values(app.files).find(f => f.name.endsWith('.html'));

  let htmlContent = indexHtmlFile?.content || `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${app.name}</title>
</head>
<body class="bg-slate-900 text-white min-h-screen">
  <div id="root"></div>
</body>
</html>`;

  // Ensure root div exists for React/Vue apps
  if (!htmlContent.includes('id="root"') && !htmlContent.includes("id='root'") && !htmlContent.includes('id="app"') && !htmlContent.includes("id='app'")) {
    if (htmlContent.includes('</body>')) {
      htmlContent = htmlContent.replace('</body>', '  <div id="root"></div>\n</body>');
    } else {
      htmlContent += '\n<div id="root"></div>';
    }
  }

  // Ensure <head> and <body> exist
  if (!htmlContent.includes('<head>')) {
    htmlContent = `<head>\n  <meta charset="UTF-8">\n</head>\n` + htmlContent;
  }

  // 2. Disable local script and link tag network fetches that would result in 404s inside srcdoc
  htmlContent = htmlContent.replace(/<script\s+[^>]*src=["'](\.[^"']+|[^"':]+(?!\/\/))["'][^>]*>\s*<\/script>/gi, (match, src) => {
    if (src.startsWith('http://') || src.startsWith('https://') || src.startsWith('//')) {
      return match;
    }
    return `<!-- Local script ${src} handled by Virtual Sandbox Engine -->`;
  });

  htmlContent = htmlContent.replace(/<link\s+[^>]*href=["'](\.[^"']+|[^"':]+(?!\/\/))["'][^>]*\/?>/gi, (match, href) => {
    if (href.startsWith('http://') || href.startsWith('https://') || href.startsWith('//')) {
      return match;
    }
    return `<!-- Local stylesheet ${href} inlined by Virtual Sandbox Engine -->`;
  });

  // 3. Inject Required Libraries (Tailwind, React 18, Babel Standalone)
  const cdnHeadScripts = `
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/@babel/standalone@7/babel.min.js"></script>
  `;
  htmlContent = htmlContent.replace('<head>', `<head>${cdnHeadScripts}`);

  // 4. Inline CSS files into <head>
  let cssInjections = '';
  for (const [path, file] of Object.entries(app.files)) {
    if (path.endsWith('.css') && !file.isBinary) {
      cssInjections += `\n/* Inline ${path} */\n<style>\n${file.content}\n</style>\n`;
    }
  }
  if (cssInjections) {
    htmlContent = htmlContent.replace('</head>', `${cssInjections}\n</head>`);
  }

  // 5. Console & Error Interceptor Script
  const consoleInterceptor = `
  <script>
    (function() {
      const oldLog = console.log;
      const oldErr = console.error;
      const oldWarn = console.warn;
      
      function sendToParent(type, args) {
        try {
          const msg = Array.from(args).map(a => {
            if (a instanceof Error) return a.stack || a.message;
            if (typeof a === 'object') return JSON.stringify(a);
            return String(a);
          }).join(' ');
          window.parent.postMessage({
            type: 'APP_CONSOLE_LOG',
            logType: type,
            message: msg
          }, '*');
        } catch(e) {}
      }

      console.log = function(...args) {
        oldLog.apply(console, args);
        sendToParent('log', args);
      };
      console.error = function(...args) {
        oldErr.apply(console, args);
        sendToParent('error', args);
      };
      console.warn = function(...args) {
        oldWarn.apply(console, args);
        sendToParent('warn', args);
      };

      window.onerror = function(message, source, lineno, colno, error) {
        sendToParent('error', ['Uncaught Error: ' + message + (lineno ? ' at line ' + lineno : '')]);
      };
    })();
  </script>
  `;
  htmlContent = htmlContent.replace('<head>', `<head>\n${consoleInterceptor}`);

  // 6. Build Virtual Files Dictionary for JS/TS/JSX/TSX & JSON
  const virtualFiles: Record<string, string> = {};
  for (const [path, file] of Object.entries(app.files)) {
    if ((path.endsWith('.js') || path.endsWith('.jsx') || path.endsWith('.ts') || path.endsWith('.tsx') || path.endsWith('.json')) && !file.isBinary) {
      virtualFiles[path] = file.content;
    }
  }

  // 7. Virtual Module Bundler System
  const virtualBundlerScript = `
  <script>
    window.__VIRTUAL_FILES__ = ${JSON.stringify(virtualFiles)};
    window.__VIRTUAL_MODULES__ = {};
    window.__CACHE__ = {};

    function resolveModulePath(currentFile, importPath) {
      if (!importPath.startsWith('.')) return importPath;

      const currentParts = currentFile.split('/');
      currentParts.pop(); // remove current filename

      const targetParts = importPath.split('/');
      for (const part of targetParts) {
        if (part === '.') continue;
        if (part === '..') {
          if (currentParts.length > 0) currentParts.pop();
        } else {
          currentParts.push(part);
        }
      }

      const basePath = currentParts.join('/');
      const possibleExtensions = ['', '.tsx', '.ts', '.jsx', '.js', '.json', '/index.tsx', '/index.jsx', '/index.js', '/index.ts'];

      for (const ext of possibleExtensions) {
        const fullPath = basePath + ext;
        if (window.__VIRTUAL_FILES__[fullPath] !== undefined) {
          return fullPath;
        }
      }

      return basePath;
    }

    window.require = function(importPath, currentFile = 'root') {
      // Core built-in npm modules
      if (importPath === 'react') return window.React;
      if (importPath === 'react-dom' || importPath === 'react-dom/client') {
        return {
          ...window.ReactDOM,
          createRoot: function(container) {
            return {
              render: function(element) {
                if (window.ReactDOM.createRoot) {
                  const root = window.ReactDOM.createRoot(container);
                  root.render(element);
                } else {
                  window.ReactDOM.render(element, container);
                }
              }
            };
          }
        };
      }

      if (importPath === 'lucide-react') {
        return new Proxy({}, {
          get: function(target, prop) {
            if (prop === '__esModule') return true;
            return function LucideIconFallback(props) {
              const iconName = String(prop);
              return window.React.createElement(
                'span',
                { className: 'inline-flex items-center justify-center border border-indigo-500/30 bg-indigo-500/10 text-indigo-300 text-[10px] px-1 py-0.5 rounded font-mono' },
                iconName
              );
            };
          }
        });
      }

      // JSON files
      const resolved = resolveModulePath(currentFile, importPath);
      if (resolved.endsWith('.json') && window.__VIRTUAL_FILES__[resolved]) {
        try {
          return JSON.parse(window.__VIRTUAL_FILES__[resolved]);
        } catch(e) {
          return {};
        }
      }

      // Cached module exports
      if (window.__CACHE__[resolved]) {
        return window.__CACHE__[resolved].exports;
      }

      if (window.__VIRTUAL_MODULES__[resolved]) {
        const module = { exports: {} };
        window.__CACHE__[resolved] = module;
        try {
          window.__VIRTUAL_MODULES__[resolved](module, module.exports, function(nextPath) {
            return window.require(nextPath, resolved);
          });
        } catch (execErr) {
          console.error('Error executing module "' + resolved + '":', execErr);
        }
        return module.exports;
      }

      console.warn('Virtual Module Not Found:', importPath, '(Resolved path: ' + resolved + ')');
      return {};
    };

    window.addEventListener('DOMContentLoaded', function() {
      try {
        const files = window.__VIRTUAL_FILES__;

        // Step A: Transpile all JS/TS/JSX/TSX code using Babel Standalone
        for (const filePath in files) {
          if (filePath.endsWith('.json')) continue;

          let code = files[filePath];
          // Remove CSS import lines so they don't throw syntax errors
          code = code.replace(/import\s+['"][^'"]+\.css['"];?/g, '');
          code = code.replace(/import\s+[^'"]+\s+from\s+['"][^'"]+\.css['"];?/g, '');

          try {
            const result = Babel.transform(code, {
              presets: [
                ['react', { runtime: 'classic' }],
                'typescript',
                ['env', { modules: 'commonjs' }]
              ],
              filename: filePath
            });

            window.__VIRTUAL_MODULES__[filePath] = new Function('module', 'exports', 'require', result.code);
          } catch (compileErr) {
            console.error('Babel compilation error in file "' + filePath + '":', compileErr.message);
          }
        }

        // Step B: Identify main entry point file
        const entryCandidates = [
          '${app.entryPoint}',
          'src/main.tsx', 'src/main.jsx', 'src/main.js', 'src/main.ts',
          'src/index.tsx', 'src/index.jsx', 'src/index.js', 'src/index.ts',
          'src/App.tsx', 'src/App.jsx', 'src/App.js',
          'main.tsx', 'main.jsx', 'main.js', 'index.tsx', 'index.jsx', 'index.js', 'App.tsx', 'App.jsx', 'App.js'
        ];

        let targetEntry = null;
        for (const candidate of entryCandidates) {
          if (window.__VIRTUAL_MODULES__[candidate]) {
            targetEntry = candidate;
            break;
          }
        }

        if (!targetEntry) {
          const allModules = Object.keys(window.__VIRTUAL_MODULES__);
          if (allModules.length > 0) targetEntry = allModules[0];
        }

        if (targetEntry) {
          console.log('⚡ Launching Virtual Application Entry Point:', targetEntry);
          const exported = window.require(targetEntry);

          const Component = exported.default || (typeof exported === 'function' ? exported : null);
          const rootElement = document.getElementById('root') || document.getElementById('app') || document.body;

          if (Component && typeof Component === 'function' && rootElement && rootElement.children.length === 0) {
            if (window.ReactDOM.createRoot) {
              const root = window.ReactDOM.createRoot(rootElement);
              root.render(window.React.createElement(Component));
            } else {
              window.ReactDOM.render(window.React.createElement(Component), rootElement);
            }
          }
        }
      } catch (runtimeErr) {
        console.error('Runtime Sandbox Boot Error:', runtimeErr);
      }
    });
  </script>
  `;

  if (htmlContent.includes('</body>')) {
    htmlContent = htmlContent.replace('</body>', `${virtualBundlerScript}\n</body>`);
  } else {
    htmlContent += virtualBundlerScript;
  }

  return htmlContent;
}
