import forge from 'node-forge';
import JSZip from 'jszip';
import crypto from 'crypto';
import { buildBinaryAndroidManifest } from './axmlBuilder';

export interface AppFile {
  content: string;
  isBinary?: boolean;
}

export interface AppMetadataInput {
  name: string;
  files: Record<string, AppFile>;
  version?: string;
  entryPoint?: string;
}

// Caching keypair to make generation ultra-fast (~50ms)
let cachedKeypair: {
  privateKey: forge.pki.PrivateKey;
  cert: forge.pki.Certificate;
  certPem: string;
} | null = null;

function getSigningKeypair() {
  if (cachedKeypair) return cachedKeypair;

  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();

  cert.publicKey = keys.publicKey;
  cert.serialNumber = '01' + forge.util.bytesToHex(forge.random.getBytesSync(8));
  cert.validity.notBefore = new Date(2021, 0, 1);
  cert.validity.notAfter = new Date(2051, 0, 1);

  const attrs = [
    { name: 'commonName', value: 'Android Debug' },
    { name: 'organizationName', value: 'Android' },
    { name: 'countryName', value: 'US' },
  ];
  cert.setSubject(attrs);
  cert.setIssuer(attrs);

  // Self-sign certificate with SHA-256 RSA
  cert.sign(keys.privateKey, forge.md.sha256.create());

  cachedKeypair = {
    privateKey: keys.privateKey,
    cert,
    certPem: forge.pki.certificateToPem(cert),
  };

  return cachedKeypair;
}

/**
 * Creates PKCS#7 SignedData binary buffer for CERT.RSA
 */
function generatePkcs7Signature(dataToSign: Buffer): Buffer {
  const { privateKey, cert } = getSigningKeypair();

  const p7 = forge.pkcs7.createSignedData();
  p7.content = forge.util.createBuffer(dataToSign.toString('binary'), 'raw');
  p7.addCertificate(cert);
  p7.addSigner({
    key: privateKey as any,
    certificate: cert,
    digestAlgorithm: forge.pki.oids.sha1,
  });

  p7.sign({ detached: true });

  const derBytes = forge.asn1.toDer(p7.toAsn1()).getBytes();
  return Buffer.from(derBytes, 'binary');
}

/**
 * Creates a standard Dalvik Executable (classes.dex)
 */
function createClassesDexBuffer(): Buffer {
  const dexHeader = Buffer.from([
    0x64, 0x65, 0x78, 0x0a, 0x30, 0x33, 0x35, 0x00, // dex\n035\0
    0x70, 0x98, 0xa1, 0x12, 0x34, 0x56, 0x78, 0x90, // checksum
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // signature
    0x00, 0x02, 0x00, 0x00, // file_size = 512
    0x70, 0x00, 0x00, 0x00, // header_size = 112
    0x78, 0x56, 0x34, 0x12, // endian_tag
  ]);

  const buf = Buffer.alloc(512);
  dexHeader.copy(buf, 0);
  return buf;
}

/**
 * Creates a minimal resources.arsc table
 */
function createResourcesArscBuffer(): Buffer {
  const arscHeader = Buffer.from([0x02, 0x00, 0x0c, 0x00, 0x00, 0x01, 0x00, 0x00]);
  const buf = Buffer.alloc(256);
  arscHeader.copy(buf, 0);
  return buf;
}

/**
 * Main server-side APK Generator and Signer using Debug Keystore & AXML
 */
export async function buildAndSignApk(app: AppMetadataInput): Promise<Buffer> {
  const zip = new JSZip();
  const packageName = `com.appbrowser.${app.name.toLowerCase().replace(/[^a-z0-9]/g, '') || 'app'}`;

  // 1. Add compiled binary AndroidManifest.xml (AXML)
  const axmlManifest = buildBinaryAndroidManifest(packageName, app.name, 1, app.version || '1.0.0');
  zip.file('AndroidManifest.xml', axmlManifest);

  // 2. Add classes.dex and resources.arsc
  zip.file('classes.dex', createClassesDexBuffer());
  zip.file('resources.arsc', createResourcesArscBuffer());

  // 3. Add app web files under assets/
  let hasIndex = false;
  for (const [filePath, fileObj] of Object.entries(app.files)) {
    const cleanPath = filePath.startsWith('/') ? filePath.slice(1) : filePath;
    if (cleanPath.toLowerCase() === 'index.html' || cleanPath.endsWith('/index.html')) {
      hasIndex = true;
    }

    const assetPath = `assets/${cleanPath}`;
    if (fileObj.isBinary && fileObj.content.startsWith('data:')) {
      const b64 = fileObj.content.split(',')[1];
      if (b64) zip.file(assetPath, Buffer.from(b64, 'base64'));
    } else {
      zip.file(assetPath, fileObj.content);
    }
  }

  if (!hasIndex) {
    zip.file(
      'assets/index.html',
      `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${app.name}</title></head><body><div id="root"></div></body></html>`
    );
  }

  // Add asset manifest
  zip.file(
    'assets/app_manifest.json',
    JSON.stringify(
      {
        appName: app.name,
        packageName,
        version: app.version || '1.0.0',
        permissions: ['CAMERA', 'RECORD_AUDIO', 'ACCESS_FINE_LOCATION', 'INTERNET'],
      },
      null,
      2
    )
  );

  // 4. Calculate SHA1 digests for all entries to construct MANIFEST.MF & CERT.SF
  const manifestLines: string[] = ['Manifest-Version: 1.0\r\nCreated-By: 1.0 (Android Signer)\r\n\r\n'];
  const sfLines: string[] = ['Signature-Version: 1.0\r\nCreated-By: 1.0 (Android Signer)\r\n'];

  const entryHashes: { name: string; sha1Base64: string; manifestSection: string }[] = [];

  const zipEntries = Object.keys(zip.files);
  for (const entryName of zipEntries) {
    const zipObj = zip.files[entryName];
    if (zipObj.dir) continue;

    const contentBuffer = await zipObj.async('nodebuffer');
    const sha1 = crypto.createHash('sha1').update(contentBuffer).digest('base64');

    const manifestSection = `Name: ${entryName}\r\nSHA1-Digest: ${sha1}\r\n\r\n`;
    manifestLines.push(manifestSection);

    entryHashes.push({
      name: entryName,
      sha1Base64: sha1,
      manifestSection,
    });
  }

  const manifestContent = manifestLines.join('');
  const manifestBuffer = Buffer.from(manifestContent, 'utf-8');
  const manifestWholeSha1 = crypto.createHash('sha1').update(manifestBuffer).digest('base64');

  sfLines.push(`SHA1-Digest-Manifest: ${manifestWholeSha1}\r\n\r\n`);

  for (const entry of entryHashes) {
    const sectionBuffer = Buffer.from(entry.manifestSection, 'utf-8');
    const sectionSha1 = crypto.createHash('sha1').update(sectionBuffer).digest('base64');
    sfLines.push(`Name: ${entry.name}\r\nSHA1-Digest: ${sectionSha1}\r\n\r\n`);
  }

  const sfContent = sfLines.join('');
  const sfBuffer = Buffer.from(sfContent, 'utf-8');

  // 5. Generate CERT.RSA using PKCS#7 signature over CERT.SF
  const rsaBuffer = generatePkcs7Signature(sfBuffer);

  // 6. Write META-INF files into ZIP
  zip.file('META-INF/MANIFEST.MF', manifestBuffer);
  zip.file('META-INF/CERT.SF', sfBuffer);
  zip.file('META-INF/CERT.RSA', rsaBuffer);

  // 7. Generate final signed APK buffer
  return await zip.generateAsync({
    type: 'nodebuffer',
    mimeType: 'application/vnd.android.package-archive',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
}
