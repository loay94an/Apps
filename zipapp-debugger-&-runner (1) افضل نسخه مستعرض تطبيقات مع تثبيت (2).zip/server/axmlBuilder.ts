/**
 * Compiles a minimal AndroidManifest.xml into binary AXML format required by Android OS PackageParser.
 */
export function buildBinaryAndroidManifest(
  packageName: string,
  appName: string,
  versionCode: number = 1,
  versionName: string = '1.0.0'
): Buffer {
  const strings: string[] = [];

  function getStringIdx(s: string): number {
    let idx = strings.indexOf(s);
    if (idx === -1) {
      idx = strings.length;
      strings.push(s);
    }
    return idx;
  }

  // Pre-populate string pool
  const NS_ANDROID = 'http://schemas.android.com/apk/res/android';
  const STR_ANDROID = 'android';
  const STR_MANIFEST = 'manifest';
  const STR_PACKAGE = 'package';
  const STR_VERSION_CODE = 'versionCode';
  const STR_VERSION_NAME = 'versionName';
  const STR_USES_PERMISSION = 'uses-permission';
  const STR_NAME = 'name';
  const STR_APPLICATION = 'application';
  const STR_LABEL = 'label';
  const STR_HARDWARE_ACCEL = 'hardwareAccelerated';
  const STR_USES_CLEARTEXT = 'usesCleartextTraffic';
  const STR_ACTIVITY = 'activity';
  const STR_EXPORTED = 'exported';
  const STR_INTENT_FILTER = 'intent-filter';
  const STR_ACTION = 'action';
  const STR_CATEGORY = 'category';

  const PERM_INTERNET = 'android.permission.INTERNET';
  const PERM_CAMERA = 'android.permission.CAMERA';
  const PERM_RECORD_AUDIO = 'android.permission.RECORD_AUDIO';
  const PERM_LOCATION = 'android.permission.ACCESS_FINE_LOCATION';

  const ACTION_MAIN = 'android.intent.action.MAIN';
  const CATEGORY_LAUNCHER = 'android.intent.category.LAUNCHER';
  const MAIN_ACTIVITY = 'com.appbrowser.runner.MainActivity';

  const idxNsAndroid = getStringIdx(NS_ANDROID);
  const idxStrAndroid = getStringIdx(STR_ANDROID);
  const idxManifest = getStringIdx(STR_MANIFEST);
  const idxPackage = getStringIdx(STR_PACKAGE);
  const idxVersionCode = getStringIdx(STR_VERSION_CODE);
  const idxVersionName = getStringIdx(STR_VERSION_NAME);
  const idxUsesPerm = getStringIdx(STR_USES_PERMISSION);
  const idxName = getStringIdx(STR_NAME);
  const idxApplication = getStringIdx(STR_APPLICATION);
  const idxLabel = getStringIdx(STR_LABEL);
  const idxHardwareAccel = getStringIdx(STR_HARDWARE_ACCEL);
  const idxUsesCleartext = getStringIdx(STR_USES_CLEARTEXT);
  const idxActivity = getStringIdx(STR_ACTIVITY);
  const idxExported = getStringIdx(STR_EXPORTED);
  const idxIntentFilter = getStringIdx(STR_INTENT_FILTER);
  const idxAction = getStringIdx(STR_ACTION);
  const idxCategory = getStringIdx(STR_CATEGORY);

  const idxPermInternet = getStringIdx(PERM_INTERNET);
  const idxPermCamera = getStringIdx(PERM_CAMERA);
  const idxPermAudio = getStringIdx(PERM_RECORD_AUDIO);
  const idxPermLocation = getStringIdx(PERM_LOCATION);

  const idxActionMain = getStringIdx(ACTION_MAIN);
  const idxCatLauncher = getStringIdx(CATEGORY_LAUNCHER);
  const idxMainActivity = getStringIdx(MAIN_ACTIVITY);

  const idxPackageVal = getStringIdx(packageName);
  const idxAppNameVal = getStringIdx(appName);
  const idxVerNameVal = getStringIdx(versionName);

  // Helper to write string pool
  const strOffsets: number[] = [];
  let strDataLen = 0;
  const strDataBufs: Buffer[] = [];

  for (const s of strings) {
    strOffsets.push(strDataLen);
    const charCount = s.length;
    const buf = Buffer.alloc(2 + charCount * 2 + 2);
    buf.writeUInt16LE(charCount, 0);
    for (let i = 0; i < charCount; i++) {
      buf.writeUInt16LE(s.charCodeAt(i), 2 + i * 2);
    }
    buf.writeUInt16LE(0, 2 + charCount * 2); // null term
    strDataBufs.push(buf);
    strDataLen += buf.length;
  }

  // Align strDataLen to 4 bytes
  const strPadding = (4 - (strDataLen % 4)) % 4;
  if (strPadding > 0) {
    strDataBufs.push(Buffer.alloc(strPadding, 0));
    strDataLen += strPadding;
  }

  const stringPoolHeaderSize = 28;
  const stringPoolSize = stringPoolHeaderSize + strings.length * 4 + strDataLen;
  const stringsStart = stringPoolHeaderSize + strings.length * 4;

  const strPoolBuf = Buffer.alloc(stringPoolHeaderSize + strings.length * 4);
  strPoolBuf.writeUInt16LE(0x0001, 0); // RES_STRING_POOL_TYPE
  strPoolBuf.writeUInt16LE(28, 2); // headerSize
  strPoolBuf.writeUInt32LE(stringPoolSize, 4); // chunkSize
  strPoolBuf.writeUInt32LE(strings.length, 8); // stringCount
  strPoolBuf.writeUInt32LE(0, 12); // styleCount
  strPoolBuf.writeUInt32LE(0, 16); // flags (0 = UTF-16)
  strPoolBuf.writeUInt32LE(stringsStart, 20); // stringsStart
  strPoolBuf.writeUInt32LE(0, 24); // stylesStart

  for (let i = 0; i < strings.length; i++) {
    strPoolBuf.writeUInt32LE(strOffsets[i], 28 + i * 4);
  }

  const finalStrPool = Buffer.concat([strPoolBuf, ...strDataBufs]);

  // Resource ID map (RES_XML_RESOURCE_MAP_TYPE)
  const resIds: number[] = new Array(strings.length).fill(0);
  resIds[idxVersionCode] = 0x0101021b;
  resIds[idxVersionName] = 0x0101021c;
  resIds[idxName] = 0x01010003;
  resIds[idxLabel] = 0x01010001;
  resIds[idxHardwareAccel] = 0x010102d3;
  resIds[idxUsesCleartext] = 0x010104ec;
  resIds[idxExported] = 0x01010010;

  const resMapChunkSize = 8 + strings.length * 4;
  const resMapBuf = Buffer.alloc(resMapChunkSize);
  resMapBuf.writeUInt16LE(0x0180, 0);
  resMapBuf.writeUInt16LE(8, 2);
  resMapBuf.writeUInt32LE(resMapChunkSize, 4);
  for (let i = 0; i < strings.length; i++) {
    resMapBuf.writeUInt32LE(resIds[i], 8 + i * 4);
  }

  // XML Tree Chunks
  const xmlChunks: Buffer[] = [];

  // Start Namespace
  xmlChunks.push(createNamespaceChunk(0x0100, idxStrAndroid, idxNsAndroid));

  // <manifest package="..." versionCode="..." versionName="...">
  xmlChunks.push(
    createElementStartChunk(idxManifest, 0xffffffff, [
      createAttr(0xffffffff, idxPackage, idxPackageVal, 0x03, idxPackageVal),
      createAttr(idxNsAndroid, idxVersionCode, 0xffffffff, 0x10, versionCode),
      createAttr(idxNsAndroid, idxVersionName, idxVerNameVal, 0x03, idxVerNameVal),
    ])
  );

  // <uses-permission name="android.permission.INTERNET" />
  const perms = [idxPermInternet, idxPermCamera, idxPermAudio, idxPermLocation];
  for (const permIdx of perms) {
    xmlChunks.push(
      createElementStartChunk(idxUsesPerm, 0xffffffff, [
        createAttr(idxNsAndroid, idxName, permIdx, 0x03, permIdx),
      ])
    );
    xmlChunks.push(createElementEndChunk(idxUsesPerm, 0xffffffff));
  }

  // <application label="..." hardwareAccelerated="true" usesCleartextTraffic="true">
  xmlChunks.push(
    createElementStartChunk(idxApplication, 0xffffffff, [
      createAttr(idxNsAndroid, idxLabel, idxAppNameVal, 0x03, idxAppNameVal),
      createAttr(idxNsAndroid, idxHardwareAccel, 0xffffffff, 0x12, 0xffffffff),
      createAttr(idxNsAndroid, idxUsesCleartext, 0xffffffff, 0x12, 0xffffffff),
    ])
  );

  // <activity name="com.appbrowser.runner.MainActivity" exported="true">
  xmlChunks.push(
    createElementStartChunk(idxActivity, 0xffffffff, [
      createAttr(idxNsAndroid, idxName, idxMainActivity, 0x03, idxMainActivity),
      createAttr(idxNsAndroid, idxExported, 0xffffffff, 0x12, 0xffffffff),
    ])
  );

  // <intent-filter>
  xmlChunks.push(createElementStartChunk(idxIntentFilter, 0xffffffff, []));

  // <action name="android.intent.action.MAIN" />
  xmlChunks.push(
    createElementStartChunk(idxAction, 0xffffffff, [
      createAttr(idxNsAndroid, idxName, idxActionMain, 0x03, idxActionMain),
    ])
  );
  xmlChunks.push(createElementEndChunk(idxAction, 0xffffffff));

  // <category name="android.intent.category.LAUNCHER" />
  xmlChunks.push(
    createElementStartChunk(idxCategory, 0xffffffff, [
      createAttr(idxNsAndroid, idxName, idxCatLauncher, 0x03, idxCatLauncher),
    ])
  );
  xmlChunks.push(createElementEndChunk(idxCategory, 0xffffffff));

  // </intent-filter>
  xmlChunks.push(createElementEndChunk(idxIntentFilter, 0xffffffff));

  // </activity>
  xmlChunks.push(createElementEndChunk(idxActivity, 0xffffffff));

  // </application>
  xmlChunks.push(createElementEndChunk(idxApplication, 0xffffffff));

  // </manifest>
  xmlChunks.push(createElementEndChunk(idxManifest, 0xffffffff));

  // End Namespace
  xmlChunks.push(createNamespaceChunk(0x0101, idxStrAndroid, idxNsAndroid));

  // Combine body
  const bodyBuf = Buffer.concat([finalStrPool, resMapBuf, ...xmlChunks]);

  // Overall RES_XML_TYPE Header
  const totalFileSize = 8 + bodyBuf.length;
  const headerBuf = Buffer.alloc(8);
  headerBuf.writeUInt16LE(0x0008, 0); // RES_XML_TYPE
  headerBuf.writeUInt16LE(8, 2); // headerSize
  headerBuf.writeUInt32LE(totalFileSize, 4);

  return Buffer.concat([headerBuf, bodyBuf]);
}

interface AttributeDef {
  ns: number;
  name: number;
  rawValue: number;
  dataType: number;
  data: number;
}

function createAttr(ns: number, name: number, rawValue: number, dataType: number, data: number): AttributeDef {
  return { ns, name, rawValue, dataType, data };
}

function createNamespaceChunk(type: number, prefixIdx: number, uriIdx: number): Buffer {
  const buf = Buffer.alloc(24);
  buf.writeUInt16LE(type, 0);
  buf.writeUInt16LE(16, 2);
  buf.writeUInt32LE(24, 4);
  buf.writeUInt32LE(1, 8); // lineNumber
  buf.writeUInt32LE(0xffffffff, 12); // comment
  buf.writeUInt32LE(prefixIdx, 16);
  buf.writeUInt32LE(uriIdx, 20);
  return buf;
}

function createElementStartChunk(nameIdx: number, nsIdx: number, attrs: AttributeDef[]): Buffer {
  const attrSize = 20;
  const chunkSize = 36 + attrs.length * attrSize;
  const buf = Buffer.alloc(chunkSize);

  buf.writeUInt16LE(0x0102, 0); // RES_XML_START_ELEMENT_TYPE
  buf.writeUInt16LE(16, 2);
  buf.writeUInt32LE(chunkSize, 4);
  buf.writeUInt32LE(1, 8); // lineNumber
  buf.writeUInt32LE(0xffffffff, 12); // comment
  buf.writeUInt32LE(nsIdx, 16);
  buf.writeUInt32LE(nameIdx, 20);
  buf.writeUInt16LE(20, 24); // attributeStart
  buf.writeUInt16LE(attrSize, 26); // attributeSize
  buf.writeUInt16LE(attrs.length, 28); // attributeCount
  buf.writeUInt16LE(0, 30); // idIndex
  buf.writeUInt16LE(0, 32); // classIndex
  buf.writeUInt16LE(0, 34); // styleIndex

  let offset = 36;
  for (const attr of attrs) {
    buf.writeUInt32LE(attr.ns, offset);
    buf.writeUInt32LE(attr.name, offset + 4);
    buf.writeUInt32LE(attr.rawValue, offset + 8);
    buf.writeUInt16LE(8, offset + 12); // valueSize
    buf.writeUInt8(0, offset + 14); // res0
    buf.writeUInt8(attr.dataType, offset + 15);
    buf.writeUInt32LE(attr.data, offset + 16);
    offset += attrSize;
  }

  return buf;
}

function createElementEndChunk(nameIdx: number, nsIdx: number): Buffer {
  const buf = Buffer.alloc(24);
  buf.writeUInt16LE(0x0103, 0); // RES_XML_END_ELEMENT_TYPE
  buf.writeUInt16LE(16, 2);
  buf.writeUInt32LE(24, 4);
  buf.writeUInt32LE(1, 8); // lineNumber
  buf.writeUInt32LE(0xffffffff, 12); // comment
  buf.writeUInt32LE(nsIdx, 16);
  buf.writeUInt32LE(nameIdx, 20);
  return buf;
}
