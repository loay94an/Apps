import JSZip from 'jszip';
import { AppMetadata, AppFile, DiagnosticIssue } from '../types';

export async function parseUploadedFile(file: File): Promise<AppMetadata> {
  const ext = file.name.split('.').pop()?.toLowerCase() || '';

  // If file is a zip/rar archive, attempt JSZip parsing first
  if (['zip', 'rar', 'tar', 'gz', '7z'].includes(ext)) {
    try {
      return await parseZipFile(file);
    } catch (e) {
      // Fallback to single file handling if zip loading fails
    }
  }

  // Handle single file upload (HTML, JS, JSX, TS, TSX, CSS, JSON, PHP, PY, SVG, TXT, etc.)
  const fileName = file.name;
  const isHtml = ['html', 'htm', 'xhtml'].includes(ext);
  const isJs = ['js', 'jsx', 'ts', 'tsx', 'vue', 'svelte'].includes(ext);

  let content = '';
  let isBinary = false;

  if (['png', 'jpg', 'jpeg', 'gif', 'ico', 'webp', 'svg'].includes(ext)) {
    isBinary = true;
    content = await readAsDataURL(file);
  } else {
    try {
      content = await readAsText(file);
    } catch (e) {
      content = await readAsText(file);
    }
  }

  const filesMap: Record<string, AppFile> = {};

  if (isHtml) {
    filesMap['index.html'] = {
      path: 'index.html',
      name: fileName,
      content: content,
      isBinary: false,
      language: 'html'
    };
  } else {
    filesMap[fileName] = {
      path: fileName,
      name: fileName,
      content: content,
      isBinary,
      language: getLanguageFromExt(ext)
    };

    if (!isBinary) {
      if (ext === 'css') {
        filesMap['index.html'] = {
          path: 'index.html',
          name: 'index.html',
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${file.name.replace(/\.[^/.]+$/, '')}</title>
  <link rel="stylesheet" href="./${fileName}">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 text-white p-6 min-h-screen">
  <div class="max-w-2xl mx-auto">
    <h1 class="text-2xl font-bold mb-4">Preview: ${fileName}</h1>
    <p class="text-slate-300">Custom stylesheet loaded.</p>
  </div>
</body>
</html>`,
          isBinary: false,
          language: 'html'
        };
      } else {
        filesMap['index.html'] = {
          path: 'index.html',
          name: 'index.html',
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${file.name.replace(/\.[^/.]+$/, '')}</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 text-white min-h-screen">
  <div id="root"></div>
  <script type="module" src="./${fileName}"></script>
</body>
</html>`,
          isBinary: false,
          language: 'html'
        };
      }
    }
  }

  let framework: AppMetadata['framework'] = isJs ? 'react' : 'vanilla-html';
  let appName = fileName.replace(/\.[^/.]+$/, '') || 'Uploaded Application';

  const diagnostics = runDiagnostics(filesMap, 'index.html', framework);

  return {
    id: 'app-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    name: appName,
    version: '1.0.0',
    description: `Uploaded file (${fileName})`,
    category: isHtml ? 'Web Page' : isJs ? 'JavaScript App' : 'Web Application',
    uploadedAt: new Date().toISOString(),
    entryPoint: 'index.html',
    framework,
    files: filesMap,
    diagnostics,
    status: 'analyzed'
  };
}

function readAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string) || '');
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file);
  });
}

function readAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string) || '');
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export async function parseZipFile(file: File): Promise<AppMetadata> {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(file);
  
  const rawEntries: Record<string, JSZip.JSZipObject> = {};
  
  for (const [relativePath, zipEntry] of Object.entries(loadedZip.files)) {
    if (zipEntry.dir) continue;
    
    // Normalize slashes (Windows \ -> /)
    const normPath = relativePath.replace(/\\/g, '/');
    
    // Ignore git/macOS junk & node_modules
    if (
      normPath.includes('__MACOSX/') ||
      normPath.includes('.DS_Store') ||
      normPath.includes('.git/') ||
      normPath.includes('node_modules/')
    ) {
      continue;
    }

    rawEntries[normPath] = zipEntry;
  }

  // Detect and unwrap single top-level root folder prefix if present (e.g. my-app/src/... -> src/...)
  let allPaths = Object.keys(rawEntries);
  if (allPaths.length > 0) {
    const topSegments = new Set(allPaths.map(p => p.split('/')[0]));
    if (topSegments.size === 1) {
      const rootDir = Array.from(topSegments)[0] + '/';
      if (allPaths.every(p => p.startsWith(rootDir))) {
        const unwrapped: Record<string, JSZip.JSZipObject> = {};
        for (const [p, entry] of Object.entries(rawEntries)) {
          const stripped = p.substring(rootDir.length);
          if (stripped) {
            unwrapped[stripped] = entry;
          }
        }
        if (Object.keys(unwrapped).length > 0) {
          allPaths = Object.keys(unwrapped);
          for (const k of Object.keys(rawEntries)) delete rawEntries[k];
          Object.assign(rawEntries, unwrapped);
        }
      }
    }
  }

  const filesMap: Record<string, AppFile> = {};

  for (const [relativePath, zipEntry] of Object.entries(rawEntries)) {
    const name = relativePath.split('/').pop() || relativePath;
    const ext = name.split('.').pop()?.toLowerCase() || '';

    let isBinary = false;
    let content = '';

    if (['png', 'jpg', 'jpeg', 'gif', 'ico', 'webp', 'svg'].includes(ext)) {
      isBinary = true;
      try {
        const base64 = await zipEntry.async('base64');
        const mimeType = ext === 'svg' ? 'image/svg+xml' : `image/${ext === 'jpg' ? 'jpeg' : ext}`;
        content = `data:${mimeType};base64,${base64}`;
      } catch (e) {
        content = '[Binary Image]';
      }
    } else if (['pdf', 'zip', 'woff', 'woff2', 'eot', 'ttf'].includes(ext)) {
      isBinary = true;
      content = '[Binary File]';
    } else {
      content = await zipEntry.async('string');
    }

    filesMap[relativePath] = {
      path: relativePath,
      name,
      content,
      isBinary,
      language: getLanguageFromExt(ext)
    };
  }

  // Detect project name & description from package.json or folder name
  let appName = file.name.replace(/\.zip$/i, '');
  let appDesc = 'Uploaded application archive';
  let framework: AppMetadata['framework'] = 'vanilla-html';
  let entryPoint = 'index.html';

  if (filesMap['metadata.json']) {
    try {
      const meta = JSON.parse(filesMap['metadata.json'].content);
      if (meta.name && meta.name !== 'My App' && meta.name !== 'Untitled') appName = meta.name;
      if (meta.description) appDesc = meta.description;
    } catch (e) {
      // metadata parse error
    }
  }

  if (filesMap['package.json']) {
    try {
      const pkg = JSON.parse(filesMap['package.json'].content);
      if (pkg.name && (!appName || appName === file.name.replace(/\.zip$/i, ''))) appName = pkg.name;
      if (pkg.description) appDesc = pkg.description;
      if (pkg.dependencies?.react || pkg.devDependencies?.react) {
        framework = 'react';
      } else if (pkg.dependencies?.vue || pkg.devDependencies?.vue) {
        framework = 'vue';
      }
    } catch (e) {
      // json parse error
    }
  }

  // Auto detect React if JSX/TSX files are present
  if (Object.keys(filesMap).some(p => p.endsWith('.jsx') || p.endsWith('.tsx'))) {
    framework = 'react';
  }

  // Find entry point
  if (filesMap['index.html']) {
    entryPoint = 'index.html';
  } else if (filesMap['public/index.html']) {
    entryPoint = 'public/index.html';
  } else if (filesMap['src/index.html']) {
    entryPoint = 'src/index.html';
  } else {
    // Look for main React/JS entry point
    const mainJs = Object.keys(filesMap).find(p =>
      p === 'src/main.tsx' || p === 'src/main.jsx' ||
      p === 'src/index.tsx' || p === 'src/index.jsx' ||
      p === 'src/App.tsx' || p === 'src/App.jsx' ||
      p.endsWith('.tsx') || p.endsWith('.jsx') || p.endsWith('.js')
    );
    if (mainJs) {
      entryPoint = mainJs;
    } else {
      const htmlFile = Object.keys(filesMap).find(p => p.endsWith('.html'));
      if (htmlFile) entryPoint = htmlFile;
    }
  }

  // Perform diagnostics
  const diagnostics = runDiagnostics(filesMap, entryPoint, framework);

  const appMetadata: AppMetadata = {
    id: 'app-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    name: appName,
    version: '1.0.0',
    description: appDesc,
    category: framework === 'react' ? 'React App' : framework === 'vue' ? 'Vue App' : 'Web Application',
    uploadedAt: new Date().toISOString(),
    entryPoint,
    framework,
    files: filesMap,
    diagnostics,
    status: diagnostics.length > 0 ? 'errors_found' : 'analyzed'
  };

  return appMetadata;
}

function getLanguageFromExt(ext: string): string {
  switch (ext) {
    case 'html': return 'html';
    case 'css': return 'css';
    case 'js': case 'jsx': return 'javascript';
    case 'ts': case 'tsx': return 'typescript';
    case 'json': return 'json';
    case 'md': return 'markdown';
    default: return 'plaintext';
  }
}

export function runDiagnostics(
  files: Record<string, AppFile>,
  entryPoint: string,
  framework: AppMetadata['framework']
): DiagnosticIssue[] {
  const issues: DiagnosticIssue[] = [];

  // Check 1: Missing index.html
  const hasHtml = Object.keys(files).some(p => p.endsWith('.html'));
  if (!hasHtml) {
    issues.push({
      id: 'missing-index-html',
      type: 'error',
      title: 'Missing HTML Entry Point',
      titleAr: 'ملف index.html غير موجود',
      description: 'No HTML file found in the project root or directories.',
      descriptionAr: 'لم يتم العثور على ملف HTML في الجذر أو في المجلدات الفرعية.',
      autoFixable: true,
      suggestedFix: 'Auto-generate a wrapper index.html mounting the application entry point.'
    });
  }

  // Check 2: Invalid JSON files
  for (const [path, file] of Object.entries(files)) {
    if (path.endsWith('.json') && !file.isBinary) {
      try {
        JSON.parse(file.content);
      } catch (e: any) {
        issues.push({
          id: `invalid-json-${path}`,
          type: 'error',
          title: `Syntax Error in ${file.name}`,
          titleAr: `خطأ نحوي في ${file.name}`,
          description: `Invalid JSON syntax: ${e.message}`,
          descriptionAr: `تنسيق JSON غير صالح: ${e.message}`,
          file: path,
          autoFixable: true,
          suggestedFix: 'Sanitize and clean up JSON formatting.'
        });
      }
    }
  }

  // Check 3: Check for missing React/JS imports or scripts
  const indexHtml = files['index.html'] || files['public/index.html'];
  if (indexHtml && !indexHtml.isBinary) {
    if (!indexHtml.content.includes('<script') && Object.keys(files).some(p => p.endsWith('.js') || p.endsWith('.ts') || p.endsWith('.tsx'))) {
      issues.push({
        id: 'html-missing-script-tag',
        type: 'warning',
        title: 'Script Tag Missing in index.html',
        titleAr: 'وسم <script> مفقود في index.html',
        description: 'JavaScript files exist in the project but are not linked in index.html.',
        descriptionAr: 'توجد ملفات JavaScript بالمشروع لكن لم يتم ربطها في index.html.',
        file: indexHtml.path,
        autoFixable: true,
        suggestedFix: 'Inject module script tag referencing the main JavaScript/TypeScript file.'
      });
    }
  }

  // Check 4: Unorganized files in root
  const rootFiles = Object.keys(files).filter(p => !p.includes('/') && !['package.json', 'index.html', 'README.md', '.gitignore', 'vite.config.ts'].includes(p));
  if (rootFiles.length > 5) {
    issues.push({
      id: 'unorganized-structure',
      type: 'info',
      title: 'Root Directory Clutter',
      titleAr: 'تشتت الملفات في المجلد الرئيسي',
      description: `Found ${rootFiles.length} source files directly in root directory.`,
      descriptionAr: `تم العثور على ${rootFiles.length} ملفاً بالدليل الرئيسي مباشرة.`,
      autoFixable: true,
      suggestedFix: 'Reorganize source files into clean /src, /public, and /assets directories.'
    });
  }

  return issues;
}

export function autoFixAndReorganizeApp(app: AppMetadata): AppMetadata {
  const updatedFiles = { ...app.files };

  // Fix 1: Generate index.html if missing
  const hasHtml = Object.keys(updatedFiles).some(p => p.endsWith('.html'));
  if (!hasHtml) {
    const mainJsFile = Object.keys(updatedFiles).find(p => p.endsWith('.tsx') || p.endsWith('.jsx') || p.endsWith('.js')) || 'src/main.js';
    
    updatedFiles['index.html'] = {
      path: 'index.html',
      name: 'index.html',
      language: 'html',
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${app.name}</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-900 text-white min-h-screen">
  <div id="root"></div>
  <script type="module" src="./${mainJsFile}"></script>
</body>
</html>`
    };
  }

  // Fix 2: Auto link scripts in index.html if missing
  let indexHtml = updatedFiles['index.html'];
  if (indexHtml && !indexHtml.content.includes('<script')) {
    const mainJs = Object.keys(updatedFiles).find(p => p.endsWith('.tsx') || p.endsWith('.jsx') || p.endsWith('.js'));
    if (mainJs) {
      indexHtml.content = indexHtml.content.replace(
        '</body>',
        `  <script type="module" src="./${mainJs}"></script>\n</body>`
      );
    }
  }

  // Fix 3: Fix invalid JSONs
  for (const [path, file] of Object.entries(updatedFiles)) {
    if (path.endsWith('.json') && !file.isBinary) {
      try {
        JSON.parse(file.content);
      } catch (e) {
        // Try fixing trailing commas
        let fixed = file.content.replace(/,\s*([}\]])/g, '$1');
        updatedFiles[path] = { ...file, content: fixed };
      }
    }
  }

  // Re-run diagnostics
  const newDiagnostics = runDiagnostics(updatedFiles, 'index.html', app.framework);

  return {
    ...app,
    entryPoint: 'index.html',
    files: updatedFiles,
    diagnostics: newDiagnostics,
    status: 'ready'
  };
}

export async function createZipBlobFromApp(app: AppMetadata): Promise<Blob> {
  const zip = new JSZip();
  for (const [path, file] of Object.entries(app.files)) {
    const cleanPath = path.startsWith('/') ? path.slice(1) : path;
    if (file.isBinary && file.content.startsWith('data:')) {
      const b64 = file.content.split(',')[1];
      if (b64) {
        try {
          const binaryString = atob(b64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          zip.file(cleanPath, bytes);
        } catch (e) {
          // fallback if base64 decode fails
          zip.file(cleanPath, file.content);
        }
      } else {
        zip.file(cleanPath, file.content);
      }
    } else {
      zip.file(cleanPath, file.content);
    }
  }
  return await zip.generateAsync({ type: 'blob' });
}
