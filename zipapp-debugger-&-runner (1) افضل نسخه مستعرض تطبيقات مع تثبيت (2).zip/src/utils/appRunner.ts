import { AppMetadata } from '../types';

export function generateRunnableSrcDoc(app: AppMetadata): string {
  // 1. Locate primary HTML file or create wrapper HTML
  const indexHtmlFile =
    app.files['index.html'] ||
    app.files['public/index.html'] ||
    app.files['src/index.html'] ||
    Object.values(app.files).find((f) => f.name.endsWith('.html'));

  let htmlContent =
    indexHtmlFile?.content ||
    `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${app.name}</title>
</head>
<body class="bg-slate-900 text-white min-h-screen">
  <div id="root"></div>
</body>
</html>`;

  // Detect script entry point from index.html if present
  let detectedScriptEntry = '';
  const scriptMatch = htmlContent.match(/<script\s+[^>]*src=["']([^"']+)["']/i);
  if (scriptMatch && scriptMatch[1] && !scriptMatch[1].startsWith('http')) {
    detectedScriptEntry = scriptMatch[1].replace(/^\/|\.\//, '');
  }

  // Ensure root div exists for React/Vue apps
  if (
    !htmlContent.includes('id="root"') &&
    !htmlContent.includes("id='root'") &&
    !htmlContent.includes('id="app"') &&
    !htmlContent.includes("id='app'")
  ) {
    if (htmlContent.includes('</body>')) {
      htmlContent = htmlContent.replace('</body>', '  <div id="root"></div>\n</body>');
    } else {
      htmlContent += '\n<div id="root"></div>';
    }
  }

  // Ensure <head> and <body> exist
  if (!htmlContent.includes('<head>')) {
    htmlContent = `<head>\n  <meta charset="UTF-8">\n</head>\n` + htmlContent;
  }

  // 2. Disable local script and link tag network fetches that would result in 404s inside srcdoc
  htmlContent = htmlContent.replace(
    /<script\s+[^>]*src=["'](\.[^"']+|[^"':]+(?!\/\/))["'][^>]*>\s*<\/script>/gi,
    (match, src) => {
      if (src.startsWith('http://') || src.startsWith('https://') || src.startsWith('//')) {
        return match;
      }
      return `<!-- Local script ${src} handled by Virtual Sandbox Engine -->`;
    }
  );

  htmlContent = htmlContent.replace(
    /<link\s+[^>]*href=["'](\.[^"']+|[^"':]+(?!\/\/))["'][^>]*\/?>/gi,
    (match, href) => {
      if (href.startsWith('http://') || href.startsWith('https://') || href.startsWith('//')) {
        return match;
      }
      return `<!-- Local stylesheet ${href} inlined by Virtual Sandbox Engine -->`;
    }
  );

  // 3. Inject Required Libraries (Tailwind, React 18, Babel Standalone) & PWA Manifest/Service Worker
  const safeName = app.name.replace(/"/g, '&quot;');
  const pwaManifestObj = {
    name: app.name,
    short_name: app.name.slice(0, 12),
    description: app.description || `${app.name} Web Application`,
    start_url: './',
    display: 'standalone',
    background_color: '#0f172a',
    theme_color: '#0f172a',
    orientation: 'portrait',
    icons: [
      {
        src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="192" height="192" viewBox="0 0 24 24" fill="%230f172a"><rect width="24" height="24" rx="5" fill="%234f46e5"/><circle cx="12" cy="12" r="6" fill="%2338bdf8"/></svg>',
        sizes: '192x192',
        type: 'image/svg+xml',
        purpose: 'any maskable'
      },
      {
        src: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 24 24" fill="%230f172a"><rect width="24" height="24" rx="5" fill="%234f46e5"/><circle cx="12" cy="12" r="6" fill="%2338bdf8"/></svg>',
        sizes: '512x512',
        type: 'image/svg+xml',
        purpose: 'any maskable'
      }
    ]
  };
  const manifestDataUrl = `data:application/manifest+json;charset=utf-8,${encodeURIComponent(JSON.stringify(pwaManifestObj))}`;

  const cdnHeadScripts = `
  <!-- Progressive Web App (PWA) Manifest & Service Worker -->
  <link rel="manifest" href="${manifestDataUrl}">
  <meta name="theme-color" content="#0f172a">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="${safeName}">
  <link rel="apple-touch-icon" href="data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 24 24"><rect width="24" height="24" rx="5" fill="%234f46e5"/><circle cx="12" cy="12" r="6" fill="%2338bdf8"/></svg>">
  <script>
    (function() {
      // Register PWA Service Worker for Offline & WebAPK Installation
      if ('serviceWorker' in navigator) {
        try {
          const swCode = "self.addEventListener('install', function(e) { self.skipWaiting(); }); self.addEventListener('activate', function(e) { e.waitUntil(self.clients.claim()); }); self.addEventListener('fetch', function(e) {});";
          const blob = new Blob([swCode], { type: 'application/javascript' });
          const swUrl = URL.createObjectURL(blob);
          navigator.serviceWorker.register(swUrl, { scope: './' }).catch(function() {});
        } catch(e) {}
      }

      // Handle PWA Installation prompt event
      let deferredPrompt = null;
      window.addEventListener('beforeinstallprompt', function(e) {
        e.preventDefault();
        deferredPrompt = e;
        window.__PWA_DEFERRED_PROMPT__ = e;
        showInstallBanner();
      });

      function showInstallBanner() {
        if (document.getElementById('pwa-banner-el')) return;
        const banner = document.createElement('div');
        banner.id = 'pwa-banner-el';
        banner.style.cssText = 'position:fixed;bottom:14px;left:50%;transform:translateX(-50%);z-index:999999;background:#0f172a;color:#fff;border:1px solid #3b82f6;padding:10px 16px;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,0.6);display:flex;align-items:center;gap:12px;font-family:sans-serif;font-size:12px;max-width:90%;';
        banner.innerHTML = '<span style="display:flex;align-items:center;gap:6px;">📱 <b>تثبيت التطبيق (PWA):</b> جاهز للتثبيت على هاتفك</span>' +
          '<button id="pwa-install-act" style="background:#2563eb;color:#fff;border:none;padding:6px 12px;border-radius:8px;font-weight:bold;cursor:pointer;font-size:12px;">تثبيت الآن</button>' +
          '<button id="pwa-dismiss-act" style="background:transparent;color:#94a3b8;border:none;cursor:pointer;font-size:14px;">✕</button>';
        document.body.appendChild(banner);

        document.getElementById('pwa-install-act').onclick = function() {
          if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then(function() {
              deferredPrompt = null;
              banner.remove();
            });
          } else {
            alert('لتثبيت التطبيق على جهازك:\\n\\n1. اضغط على قائمة المتصفح (⋮ في أندرويد) أو زر المشاركة (Share في آيفون).\\n2. اختر "إضافة إلى الشاشة الرئيسية" أو "تثبيت التطبيق".');
          }
        };

        document.getElementById('pwa-dismiss-act').onclick = function() {
          banner.remove();
        };
      }

      window.triggerPwaInstallPrompt = function() {
        if (deferredPrompt) {
          deferredPrompt.prompt();
        } else {
          alert('تثبيت التطبيق (PWA):\\n\\n• أندرويد / كروم: اضغط على القائمة (⋮) ثم اختر "تثبيت التطبيق" أو "إضافة للشاشة الرئيسية".\\n• آيفون / سفاري: اضغط على زر المشاركة (Share) ثم "إضافة إلى الشاشة الرئيسية".');
        }
      };
    })();
  </script>

  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/@babel/standalone@7/babel.min.js"></script>
  `;
  htmlContent = htmlContent.replace('<head>', `<head>${cdnHeadScripts}`);

  // 4. Inline CSS files into <head>
  let cssInjections = '';
  for (const [path, file] of Object.entries(app.files)) {
    if (path.endsWith('.css') && !file.isBinary) {
      cssInjections += `\n/* Inline ${path} */\n<style>\n${file.content}\n</style>\n`;
    }
  }
  if (cssInjections) {
    htmlContent = htmlContent.replace('</head>', `${cssInjections}\n</head>`);
  }

  // 5. Console & Error Interceptor Script
  const consoleInterceptor = `
  <script>
    (function() {
      const oldLog = console.log;
      const oldErr = console.error;
      const oldWarn = console.warn;
      
      function sendToParent(type, args) {
        try {
          const msg = Array.from(args).map(a => {
            if (a instanceof Error) return a.stack || a.message;
            if (typeof a === 'object') return JSON.stringify(a);
            return String(a);
          }).join(' ');
          window.parent.postMessage({
            type: 'APP_CONSOLE_LOG',
            logType: type,
            message: msg
          }, '*');
        } catch(e) {}
      }

      console.log = function(...args) {
        oldLog.apply(console, args);
        sendToParent('log', args);
      };
      console.error = function(...args) {
        oldErr.apply(console, args);
        sendToParent('error', args);
      };
      console.warn = function(...args) {
        oldWarn.apply(console, args);
        sendToParent('warn', args);
      };

      window.onerror = function(message, source, lineno, colno, error) {
        sendToParent('error', ['Uncaught Error: ' + message + (lineno ? ' at line ' + lineno : '')]);
      };
    })();
  </script>
  `;
  htmlContent = htmlContent.replace('<head>', `<head>\n${consoleInterceptor}`);

  // 6. Build Virtual Files Dictionary for JS/TS/JSX/TSX & JSON & base64 assets
  const virtualFiles: Record<string, string> = {};
  for (const [path, file] of Object.entries(app.files)) {
    if (
      (path.endsWith('.js') ||
        path.endsWith('.jsx') ||
        path.endsWith('.ts') ||
        path.endsWith('.tsx') ||
        path.endsWith('.json')) &&
      !file.isBinary
    ) {
      virtualFiles[path] = file.content;
    } else if (file.isBinary && file.content.startsWith('data:')) {
      virtualFiles[path] = file.content;
    }
  }

  // 7. Virtual Module Bundler System with full Google AI Studio & Vite Compatibility
  const virtualBundlerScript = `
  <script>
    window.__VIRTUAL_FILES__ = ${JSON.stringify(virtualFiles)};
    window.__VIRTUAL_MODULES__ = {};
    window.__CACHE__ = {};

    function resolveModulePath(currentFile, importPath) {
      let normalizedPath = importPath;

      // Handle Vite & AI Studio path aliases (@/ or ~/ or /src/)
      if (normalizedPath.startsWith('@/')) {
        normalizedPath = 'src/' + normalizedPath.slice(2);
      } else if (normalizedPath.startsWith('~/')) {
        normalizedPath = 'src/' + normalizedPath.slice(2);
      } else if (normalizedPath.startsWith('/src/')) {
        normalizedPath = normalizedPath.slice(1);
      } else if (normalizedPath.startsWith('/') && !normalizedPath.startsWith('//')) {
        normalizedPath = normalizedPath.slice(1);
      }

      let basePath = '';
      if (normalizedPath.startsWith('.')) {
        const currentParts = currentFile.split('/');
        currentParts.pop(); // remove filename

        const targetParts = normalizedPath.split('/');
        for (const part of targetParts) {
          if (part === '.') continue;
          if (part === '..') {
            if (currentParts.length > 0) currentParts.pop();
          } else {
            currentParts.push(part);
          }
        }
        basePath = currentParts.join('/');
      } else {
        basePath = normalizedPath;
      }

      const possibleExtensions = [
        '',
        '.tsx', '.ts', '.jsx', '.js', '.json',
        '/index.tsx', '/index.jsx', '/index.js', '/index.ts'
      ];

      for (const ext of possibleExtensions) {
        const fullPath = basePath + ext;
        if (window.__VIRTUAL_FILES__[fullPath] !== undefined) {
          return fullPath;
        }
      }

      if (!basePath.startsWith('src/')) {
        const withSrc = 'src/' + basePath;
        for (const ext of possibleExtensions) {
          const fullPath = withSrc + ext;
          if (window.__VIRTUAL_FILES__[fullPath] !== undefined) {
            return fullPath;
          }
        }
      }

      return basePath;
    }

    window.require = function(importPath, currentFile = 'root') {
      // 1. React & ReactDOM
      if (importPath === 'react') return window.React;
      if (importPath === 'react-dom' || importPath === 'react-dom/client') {
        return {
          ...window.ReactDOM,
          createRoot: function(container) {
            return {
              render: function(element) {
                if (window.ReactDOM.createRoot) {
                  const root = window.ReactDOM.createRoot(container);
                  root.render(element);
                } else {
                  window.ReactDOM.render(element, container);
                }
              }
            };
          }
        };
      }

      // 2. Lucide React Icon Engine
      if (importPath === 'lucide-react' || importPath.startsWith('lucide-react/')) {
        return new Proxy({}, {
          get: function(target, prop) {
            if (prop === '__esModule') return true;
            if (prop === 'default') return target;
            return function LucideIconFallback(props) {
              const { className = '', size = 20, color = 'currentColor', strokeWidth = 2, ...rest } = props || {};
              return window.React.createElement(
                'svg',
                {
                  xmlns: 'http://www.w3.org/2000/svg',
                  width: size,
                  height: size,
                  viewBox: '0 0 24 24',
                  fill: 'none',
                  stroke: color,
                  strokeWidth: strokeWidth,
                  strokeLinecap: 'round',
                  strokeLinejoin: 'round',
                  className: className,
                  ...rest
                },
                window.React.createElement('circle', { cx: '12', cy: '12', r: '9' }),
                window.React.createElement('path', { d: 'm10 15 5-3-5-3v6z' })
              );
            };
          }
        });
      }

      // 3. Motion / Framer Motion Animation Engine Shim
      if (
        importPath === 'framer-motion' ||
        importPath === 'motion/react' ||
        importPath === 'motion' ||
        importPath.startsWith('framer-motion/') ||
        importPath.startsWith('motion/')
      ) {
        const motionHandler = {
          get: function(target, prop) {
            if (prop === '__esModule') return true;
            return function MotionComponent(props) {
              const {
                initial, animate, exit, transition, whileHover, whileTap, whileFocus, whileInView,
                variants, layout, layoutId, viewport, onAnimationComplete, ...restProps
              } = props || {};
              return window.React.createElement(String(prop), restProps);
            };
          }
        };
        const motionProxy = new Proxy(function(Component) {
          return function MotionWrapped(props) {
            const { initial, animate, exit, transition, whileHover, whileTap, ...restProps } = props || {};
            return window.React.createElement(Component, restProps);
          };
        }, motionHandler);

        return {
          motion: motionProxy,
          AnimatePresence: function AnimatePresence(props) { return props.children; },
          useAnimation: function() { return { start: function() { return Promise.resolve(); }, stop: function() {} }; },
          useMotionValue: function(init) { return { get: function() { return init; }, set: function() {} }; },
          useTransform: function(val) { return { get: function() { return 0; } }; },
          useSpring: function(val) { return val; },
          useInView: function() { return true; },
          useScroll: function() { return { scrollY: { get: function() { return 0; } }, scrollYProgress: { get: function() { return 0; } } }; },
          default: motionProxy,
          __esModule: true
        };
      }

      // 4. clsx & tailwind-merge Utilities
      if (importPath === 'clsx') {
        const clsx = function(...args) {
          return args.flat(Infinity).filter(Boolean).map(a => {
            if (typeof a === 'string' || typeof a === 'number') return a;
            if (typeof a === 'object') {
              return Object.entries(a).filter(([_, v]) => Boolean(v)).map(([k]) => k).join(' ');
            }
            return '';
          }).filter(Boolean).join(' ');
        };
        return { clsx, default: clsx, __esModule: true };
      }

      if (importPath === 'tailwind-merge') {
        const twMerge = function(...args) {
          return args.filter(Boolean).join(' ');
        };
        return { twMerge, default: twMerge, __esModule: true };
      }

      // 5. React Router Shim
      if (importPath === 'react-router-dom' || importPath === 'react-router') {
        const Dummy = (props) => props.children || null;
        return {
          BrowserRouter: Dummy,
          HashRouter: Dummy,
          MemoryRouter: Dummy,
          Routes: Dummy,
          Route: (props) => (props.element ? window.React.createElement(props.element) : null),
          Link: (props) => window.React.createElement('a', { href: props.to || '#', ...props }),
          NavLink: (props) => window.React.createElement('a', { href: props.to || '#', ...props }),
          useNavigate: () => (() => {}),
          useLocation: () => ({ pathname: '/', search: '', hash: '', state: null }),
          useParams: () => ({}),
          useSearchParams: () => [new URLSearchParams(), () => {}],
          Outlet: () => null,
          __esModule: true
        };
      }

      // 6. Gemini AI SDK Shim
      if (importPath === '@google/genai' || importPath === '@google/generative-ai') {
        return {
          GoogleGenAI: class GoogleGenAI {
            constructor() {}
            get models() {
              return {
                generateContent: async () => ({ text: 'AI Studio response placeholder in browser sandbox' })
              };
            }
          },
          GoogleGenerativeAI: class GoogleGenerativeAI {
            constructor() {}
            getGenerativeModel() {
              return {
                generateContent: async () => ({ response: { text: () => 'AI Studio response placeholder in browser sandbox' } })
              };
            }
          },
          __esModule: true
        };
      }

      // 7. canvas-confetti Shim
      if (importPath === 'canvas-confetti') {
        const confetti = () => {};
        confetti.reset = () => {};
        return { default: confetti, confetti, __esModule: true };
      }

      // 8. JSON files
      const resolved = resolveModulePath(currentFile, importPath);
      if (resolved.endsWith('.json') && window.__VIRTUAL_FILES__[resolved]) {
        try {
          return JSON.parse(window.__VIRTUAL_FILES__[resolved]);
        } catch(e) {
          return {};
        }
      }

      // 9. Cached module exports
      if (window.__CACHE__[resolved]) {
        return window.__CACHE__[resolved].exports;
      }

      if (window.__VIRTUAL_MODULES__[resolved]) {
        const module = { exports: {} };
        window.__CACHE__[resolved] = module;
        try {
          window.__VIRTUAL_MODULES__[resolved](module, module.exports, function(nextPath) {
            return window.require(nextPath, resolved);
          });
        } catch (execErr) {
          console.error('Error executing virtual module "' + resolved + '":', execErr);
        }
        return module.exports;
      }

      console.warn('Virtual Module Not Found:', importPath, '(Resolved path: ' + resolved + ')');
      return {};
    };

    window.addEventListener('DOMContentLoaded', function() {
      try {
        const files = window.__VIRTUAL_FILES__;

        // Step A: Transpile all JS/TS/JSX/TSX code using Babel Standalone
        for (const filePath in files) {
          if (filePath.endsWith('.json') || files[filePath].startsWith('data:')) continue;

          let code = files[filePath];
          // Strip CSS imports so they don't break JS syntax
          code = code.replace(/import\s+['"][^'"]+\.css['"];?/g, '');
          code = code.replace(/import\s+[^'"]+\s+from\s+['"][^'"]+\.css['"];?/g, '');

          try {
            const result = Babel.transform(code, {
              presets: [
                ['react', { runtime: 'classic' }],
                'typescript',
                ['env', { modules: 'commonjs' }]
              ],
              filename: filePath
            });

            window.__VIRTUAL_MODULES__[filePath] = new Function('module', 'exports', 'require', result.code);
          } catch (compileErr) {
            console.error('Babel compilation error in file "' + filePath + '":', compileErr.message);
          }
        }

        // Step B: Identify main entry point file
        const entryCandidates = [
          '${detectedScriptEntry}',
          '${app.entryPoint}',
          'src/main.tsx', 'src/main.jsx', 'src/main.js', 'src/main.ts',
          'src/index.tsx', 'src/index.jsx', 'src/index.js', 'src/index.ts',
          'src/App.tsx', 'src/App.jsx', 'src/App.js',
          'main.tsx', 'main.jsx', 'main.js', 'index.tsx', 'index.jsx', 'index.js', 'App.tsx', 'App.jsx', 'App.js'
        ];

        let targetEntry = null;
        for (const candidate of entryCandidates) {
          if (candidate && window.__VIRTUAL_MODULES__[candidate]) {
            targetEntry = candidate;
            break;
          }
        }

        if (!targetEntry) {
          const allModules = Object.keys(window.__VIRTUAL_MODULES__);
          if (allModules.length > 0) targetEntry = allModules[0];
        }

        if (targetEntry) {
          console.log('⚡ Launching Application Entry Point:', targetEntry);
          const exported = window.require(targetEntry);

          const Component = exported.default || (typeof exported === 'function' ? exported : null);
          const rootElement = document.getElementById('root') || document.getElementById('app') || document.body;

          if (Component && typeof Component === 'function' && rootElement && rootElement.children.length === 0) {
            if (window.ReactDOM.createRoot) {
              const root = window.ReactDOM.createRoot(rootElement);
              root.render(window.React.createElement(Component));
            } else {
              window.ReactDOM.render(window.React.createElement(Component), rootElement);
            }
          }
        }
      } catch (runtimeErr) {
        console.error('Runtime Sandbox Boot Error:', runtimeErr);
      }
    });
  </script>
  `;

  if (htmlContent.includes('</body>')) {
    htmlContent = htmlContent.replace('</body>', `${virtualBundlerScript}\n</body>`);
  } else {
    htmlContent += virtualBundlerScript;
  }

  return htmlContent;
}
