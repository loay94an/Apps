import React, { useState } from 'react';
import { Smartphone, AlertTriangle, Download, ExternalLink, X, Sparkles, Layers, Globe, ChevronDown, CheckCircle2 } from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { createZipBlobFromApp } from '../utils/zipParser';
import { generateRunnableSrcDoc } from '../utils/appRunner';

interface ApkGuideModalProps {
  lang: Language;
  app: AppMetadata;
  onClose: () => void;
  onRunApp?: () => void;
}

interface ConverterSite {
  id: string;
  name: string;
  url: string;
  type: 'apk' | 'web';
  descAr: string;
  descEn: string;
  badgeAr: string;
  badgeEn: string;
}

const CONVERTER_SERVICES: ConverterSite[] = [
  // ZIP -> APK Converters
  {
    id: 'pwabuilder',
    name: 'PWABuilder (Microsoft)',
    url: 'https://www.pwabuilder.com',
    type: 'apk',
    descAr: 'أداة مايكروسوفت الرسمية لتحويل تطبيقات الويب إلى APK موقع وجاهز لمتجر جوجل بلاي',
    descEn: 'Official Microsoft tool to convert Web Apps into signed Google Play APKs',
    badgeAr: 'موصى به مجاناً',
    badgeEn: 'Recommended Free',
  },
  {
    id: 'website2apk',
    name: 'Website2APK Builder',
    url: 'https://website2apk.com',
    type: 'apk',
    descAr: 'تحويل أكواد HTML/ZIP وسكريبتات الويب إلى تطبيق أندرويد APK قابل للتثبيت',
    descEn: 'Converts HTML/ZIP code bundles into installable Android APK apps',
    badgeAr: 'تطبيق أندرويد',
    badgeEn: 'Android App',
  },
  {
    id: 'appsgeyser',
    name: 'AppsGeyser Web2App',
    url: 'https://appsgeyser.com',
    type: 'apk',
    descAr: 'تحويل الملفات المضغوطة ZIP وروابط الويب إلى ملف APK مجاني بدون خبرة برمجية',
    descEn: 'Converts ZIP archives and web links to free Android APK binaries',
    badgeAr: 'مجاني وسريع',
    badgeEn: 'Free & Fast',
  },
  {
    id: 'median',
    name: 'Median.co (GoNative)',
    url: 'https://median.co',
    type: 'apk',
    descAr: 'تحويل مشاريع الويب والتطبيقات إلى تطبيقات أندرويد و iOS احترافية',
    descEn: 'Transforms web apps into native Android and iOS mobile applications',
    badgeAr: 'أندرويد + iOS',
    badgeEn: 'Android + iOS',
  },
  {
    id: 'voltbuilder',
    name: 'VoltBuilder Cloud',
    url: 'https://volt.build',
    type: 'apk',
    descAr: 'منصة سحابية لبناء وتوقيع تطبيقات أندرويد و iOS من ملفات ZIP مباشرة',
    descEn: 'Cloud platform to build signed APK and IPA packages directly from ZIP files',
    badgeAr: 'بناء سحابي',
    badgeEn: 'Cloud Build',
  },

  // ZIP -> Web Hosting
  {
    id: 'tiinyhost',
    name: 'Tiiny Host',
    url: 'https://tiiny.host',
    type: 'web',
    descAr: 'رفع ملف ZIP مباشرة وتحويله إلى موقع ويب مباشر خلال ثوانٍ معدودة',
    descEn: 'Upload any ZIP file and launch a live website in seconds',
    badgeAr: 'ZIP إلى موقع',
    badgeEn: 'ZIP to Web',
  },
  {
    id: 'netlify',
    name: 'Netlify Drop',
    url: 'https://app.netlify.com/drop',
    type: 'web',
    descAr: 'سحب وإسقاط ملف ZIP لنشر موقع ويب كامل مع رابط مباشر مجاني',
    descEn: 'Drag & drop ZIP to publish a full live website with free hosting',
    badgeAr: 'نشر مجاني',
    badgeEn: 'Free Hosting',
  },
  {
    id: 'vercel',
    name: 'Vercel Deploy',
    url: 'https://vercel.com',
    type: 'web',
    descAr: 'استضافة فائقة السرعة لمشاريع وتطبيقات الويب مع دعم النشر المباشر',
    descEn: 'Ultra-fast web deployment platform for apps and web packages',
    badgeAr: 'سرعة عالية',
    badgeEn: 'High Speed',
  },
  {
    id: 'render',
    name: 'Render Cloud',
    url: 'https://render.com',
    type: 'web',
    descAr: 'استضافة سحابية متكاملة لنشر مواقع الويب والتطبيقات مجاناً',
    descEn: 'Full-stack cloud hosting to deploy web apps and static sites for free',
    badgeAr: 'استضافة مجانية',
    badgeEn: 'Free Cloud',
  },
];

export const ApkGuideModal: React.FC<ApkGuideModalProps> = ({
  lang,
  app,
  onClose,
  onRunApp,
}) => {
  const isAr = lang === 'ar';
  const [selectedSiteId, setSelectedSiteId] = useState<string>(CONVERTER_SERVICES[0].id);

  const selectedSite = CONVERTER_SERVICES.find((s) => s.id === selectedSiteId) || CONVERTER_SERVICES[0];

  const handleDownloadSourceZip = async () => {
    const blob = await createZipBlobFromApp(app);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${app.name.toLowerCase().replace(/\s+/g, '-')}-project.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-5 sm:p-6 text-slate-100 shadow-2xl relative my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon & Title */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-2xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white">
              {isAr ? 'حل مشكلة تحليل الحزمة وتثبيت التطبيقات' : 'Package Parsing Fix & Converter Directory'}
            </h3>
            <p className="text-xs text-slate-400">
              {isAr ? `خيارات تحويل وتثبيت تطبيق "${app.name}" بسهولة` : `Conversion & installation options for "${app.name}"`}
            </p>
          </div>
        </div>

        {/* Why this error happens explanation */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 mb-5 text-xs text-slate-300 leading-relaxed">
          <span className="font-semibold text-amber-400">
            {isAr ? 'سبب مشكلة "تحليل الحزمة" في أندرويد:' : 'Why does Android show "Package Parsing" error?'}
          </span>
          <p className="mt-1">
            {isAr
              ? 'يتطلب نظام أندرويد توقيع أمني رسمي (Android Keystore Certificate). التثبيت المباشر من المتصفح قد يواجه الحظر من أندرويد. لحل المشكلة، يمكنك التثبيت المباشر عبر المتصفح كـ PWA أو استخدام مواقع تحويل ZIP المعتمدة أدناه.'
              : 'Android requires a native digital Keystore signature. You can install directly via browser as a Web PWA or use any of the vetted ZIP converter services below.'}
          </p>
        </div>

        {/* Solutions & Converter Selector Section */}
        <div className="space-y-4">
          {/* Method 1: Direct PWA Install via Browser */}
          <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-xl p-3.5 flex items-start gap-3">
            <div className="p-2 bg-indigo-500/20 text-indigo-300 rounded-lg shrink-0 mt-0.5">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold text-indigo-200 flex items-center justify-between">
                <span>{isAr ? 'الطريقة الأولى: التثبيت المباشر كتطبيق (PWA WebAPK)' : 'Method 1: Direct PWA WebAPK Install'}</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-medium px-2 py-0.5 rounded-full">
                  {isAr ? 'أسرع طريقة ⚡' : 'Fastest Method ⚡'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                {isAr
                  ? 'شغّل التطبيق في المتصفح، ثم اضغط قائمة (⋮) واختر "إضافة إلى الشاشة الرئيسية" أو "تثبيت التطبيق". سيعمل كتطبيق أندرويد مستقل بكافة الصلاحيات.'
                  : 'Run the app, open browser menu (⋮) and tap "Add to Home Screen" or "Install App" to run it as a standalone app.'}
              </p>
              {onRunApp && (
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => {
                      onClose();
                      onRunApp();
                    }}
                    className="bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
                  >
                    <Smartphone className="w-3.5 h-3.5 text-amber-300" />
                    <span>{isAr ? 'تشغيل التطبيق الآن للتثبيت (PWA)' : 'Run App Now to Install'}</span>
                  </button>

                  <button
                    onClick={() => {
                      const srcDoc = generateRunnableSrcDoc(app);
                      const blob = new Blob([srcDoc], { type: 'text/html;charset=utf-8' });
                      const url = URL.createObjectURL(blob);
                      window.open(url, '_blank');
                    }}
                    className="bg-slate-800 hover:bg-slate-700 active:bg-slate-700 text-indigo-300 border border-indigo-500/30 text-xs font-semibold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{isAr ? 'فتح في نافذة جديدة للتثبيت ⚡' : 'Open in New Window ⚡'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Method 2: Convert ZIP to App or Website via Dropdown Services */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-sky-500/20 text-sky-300 rounded-lg">
                  <Layers className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-slate-100">
                  {isAr ? 'مواقع تحويل ZIP إلى تطبيق أندرويد أو موقع ويب:' : 'ZIP to App or Web Converter Sites:'}
                </span>
              </div>

              {/* Download ZIP button */}
              <button
                onClick={handleDownloadSourceZip}
                className="bg-slate-700 hover:bg-slate-600 active:bg-slate-600 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-sky-400" />
                <span>{isAr ? 'تنزيل ملف ZIP أولاً' : 'Download ZIP First'}</span>
              </button>
            </div>

            {/* Dropdown Menu (القائمة المنسدلة للمواقع) */}
            <div className="space-y-2">
              <label className="block text-[11px] font-medium text-slate-400">
                {isAr ? 'اختر موقع التحويل المفضل من القائمة المنسدلة:' : 'Select preferred converter site from dropdown:'}
              </label>

              <div className="relative">
                <select
                  value={selectedSiteId}
                  onChange={(e) => setSelectedSiteId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-3.5 py-2.5 appearance-none focus:outline-none focus:border-sky-500 cursor-pointer transition pr-8 rtl:pr-3.5 rtl:pl-8 font-medium"
                >
                  <optgroup label={isAr ? '📱 تحويل ZIP إلى تطبيق أندرويد (ZIP -> APK)' : '📱 ZIP to Android App (APK)'}>
                    {CONVERTER_SERVICES.filter((s) => s.type === 'apk').map((site) => (
                      <option key={site.id} value={site.id}>
                        {site.name} — ({isAr ? site.badgeAr : site.badgeEn})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label={isAr ? '🌐 تحويل ZIP إلى موقع ويب مباشر (ZIP -> Web)' : '🌐 ZIP to Live Website'}>
                    {CONVERTER_SERVICES.filter((s) => s.type === 'web').map((site) => (
                      <option key={site.id} value={site.id}>
                        {site.name} — ({isAr ? site.badgeAr : site.badgeEn})
                      </option>
                    ))}
                  </optgroup>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 rtl:right-auto rtl:left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* Selected Converter Site Details Card */}
            <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fade-in">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-sky-300">{selectedSite.name}</span>
                  <span className="text-[10px] bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded-full font-medium">
                    {selectedSite.type === 'apk' ? (isAr ? 'تطبيقات' : 'App Builder') : (isAr ? 'موقع ويب' : 'Web Host')}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr ? selectedSite.descAr : selectedSite.descEn}
                </p>
              </div>

              <a
                href={selectedSite.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-sky-600 hover:bg-sky-500 active:bg-sky-500 text-white text-xs font-semibold px-4 py-2 rounded-xl transition flex items-center gap-1.5 shrink-0 self-end sm:self-center"
              >
                <span>{isAr ? 'الانتقال للموقع' : 'Visit Website'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-5 pt-3.5 border-t border-slate-800 flex items-center justify-between">
          <p className="text-[11px] text-slate-400">
            {isAr ? 'قم بتنزيل ملف ZIP ثم ارفعه إلى أي موقع من القائمة لتحصل على التطبيق.' : 'Download ZIP then upload to any converter site above.'}
          </p>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-xl transition shrink-0"
          >
            {isAr ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};

