import React, { useState } from 'react';
import { Play, FolderTree, CheckCircle2, AlertTriangle, Search, Plus, Sparkles, FolderArchive, Trash2, X, Check } from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { DownloadDropdown } from './DownloadDropdown';

interface AppCatalogProps {
  lang: Language;
  apps: AppMetadata[];
  onSelectApp: (app: AppMetadata) => void;
  onRunApp: (app: AppMetadata) => void;
  onUpdateApp: (app: AppMetadata) => void;
  onDeleteApp: (appId: string) => void;
  onGoToUpload: () => void;
}

export const AppCatalog: React.FC<AppCatalogProps> = ({
  lang,
  apps,
  onSelectApp,
  onRunApp,
  onUpdateApp,
  onDeleteApp,
  onGoToUpload,
}) => {
  const isAr = lang === 'ar';
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredApps = apps.filter((app) => {
    const matchesSearch = app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.description.toLowerCase().includes(searchTerm.toLowerCase());
    if (categoryFilter === 'all') return matchesSearch;
    return matchesSearch && app.category.toLowerCase() === categoryFilter.toLowerCase();
  });

  return (
    <div className="max-w-7xl mx-auto py-4 sm:py-8 px-3 sm:px-6 lg:px-8">
      {/* Banner / Intro */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 border border-slate-800 rounded-2xl sm:rounded-3xl p-5 sm:p-8 mb-6 sm:mb-8 relative overflow-hidden shadow-2xl">
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs px-2.5 py-1 rounded-full font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            {isAr ? 'مستعرض ومحلل التطبيقات الذكي' : 'ZIP Sandbox & App Browser'}
          </span>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-snug sm:leading-tight">
            {isAr ? 'إدارة وتصحيح ومشاهدة جميع تطبيقاتك' : 'Explore, Debug & Run Web Applications'}
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-2 sm:mt-3 leading-relaxed">
            {isAr
              ? 'ارفع أي ملف ZIP يحتوي على تطبيق ويب، وسيتولى النظام استخراجه، فحصه، تصحيح أخطائه، إعادة هيكلة ملفاته، وتشغيله في بيئة آمنة.'
              : 'Upload any web application ZIP. Inspect directory trees, run automated error diagnostic fixes, reorganize source code, and run live applications inside the interactive sandbox.'}
          </p>

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              onClick={onGoToUpload}
              className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-semibold px-5 py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 transition min-h-[44px]"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'رفع تطبيق جديد (ZIP)' : 'Upload App ZIP Archive'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center gap-3 sm:gap-4 mb-6 sm:mb-8">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 rtl:right-3.5 rtl:left-auto" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isAr ? 'البحث في التطبيقات...' : 'Search apps by name or description...'}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 rtl:pr-10 rtl:pl-4 transition min-h-[44px]"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {['all', 'utilities', 'productivity', 'react app'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium capitalize transition whitespace-nowrap min-h-[38px] ${
                categoryFilter === cat
                  ? 'bg-slate-700 text-white border border-slate-600 shadow-sm'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {cat === 'all' ? (isAr ? 'الكل' : 'All') : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Apps Grid */}
      {filteredApps.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 sm:p-12 text-center max-w-md mx-auto">
          <FolderArchive className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base sm:text-lg font-bold text-slate-300">
            {isAr ? 'لا توجد تطبيقات مطابقة' : 'No Applications Found'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {isAr ? 'قم برفع ملف ZIP جديد لبدء معالجته وتشغيله.' : 'Try uploading a new project ZIP file to start debugging.'}
          </p>
          <button
            onClick={onGoToUpload}
            className="mt-4 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl min-h-[40px]"
          >
            {isAr ? 'رفع ملف ZIP' : 'Upload ZIP'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredApps.map((app) => {
            const hasErrors = app.diagnostics.length > 0;

            return (
              <div
                key={app.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 sm:p-6 flex flex-col justify-between transition-all duration-300 hover:shadow-xl group"
              >
                <div>
                  {/* Card Header */}
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-[11px] font-mono bg-slate-800 text-slate-300 border border-slate-700 px-2.5 py-0.5 rounded-full">
                      {app.framework}
                    </span>
                    {hasErrors ? (
                      <span className="text-[11px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1 font-medium">
                        <AlertTriangle className="w-3 h-3" />
                        {app.diagnostics.length} {isAr ? 'خطأ' : 'Issues'}
                      </span>
                    ) : (
                      <span className="text-[11px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1 font-medium">
                        <CheckCircle2 className="w-3 h-3" />
                        {isAr ? 'جاهز للتشغيل' : 'Ready'}
                      </span>
                    )}
                  </div>

                  {/* App Title & Desc */}
                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-indigo-400 transition">
                    {app.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1.5 sm:mt-2 line-clamp-2 leading-relaxed">
                    {app.description}
                  </p>

                  <div className="mt-4 text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-800/80 pt-3">
                    <span>{Object.keys(app.files).length} {isAr ? 'ملف' : 'files'}</span>
                    <span className="font-mono text-slate-400 truncate max-w-[120px]">{app.entryPoint}</span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="mt-5 pt-4 border-t border-slate-800">
                  {deletingId === app.id ? (
                    <div className="bg-rose-950/80 border border-rose-500/40 rounded-xl p-2 flex items-center justify-between text-xs animate-fade-in">
                      <span className="text-rose-200 font-semibold px-1">
                        {isAr ? 'تأكيد الحذف؟' : 'Delete App?'}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            onDeleteApp(app.id);
                            setDeletingId(null);
                          }}
                          className="bg-rose-600 hover:bg-rose-500 text-white font-bold p-1.5 rounded-lg transition"
                          title={isAr ? 'حذف نهائي' : 'Confirm Delete'}
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeletingId(null)}
                          className="bg-slate-800 hover:bg-slate-700 text-slate-300 p-1.5 rounded-lg transition"
                          title={isAr ? 'إلغاء' : 'Cancel'}
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onRunApp(app)}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow-sm min-h-[40px]"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>{isAr ? 'تشغيل' : 'Run App'}</span>
                      </button>

                      <button
                        onClick={() => onSelectApp(app)}
                        title={isAr ? 'مستعرض ملفات التطبيق' : 'App File Browser'}
                        className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 p-2.5 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center"
                      >
                        <FolderTree className="w-4 h-4 text-indigo-400" />
                      </button>

                      <DownloadDropdown lang={lang} app={app} variant="icon" onRunApp={() => onRunApp(app)} />

                      <button
                        onClick={() => setDeletingId(app.id)}
                        title={isAr ? 'حذف التطبيق' : 'Delete Application'}
                        className="bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-300 border border-slate-700 hover:border-rose-500/40 p-2.5 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
