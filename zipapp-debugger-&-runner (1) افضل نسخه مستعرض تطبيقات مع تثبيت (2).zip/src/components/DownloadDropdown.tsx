import React, { useState, useRef, useEffect } from 'react';
import { Download, FileArchive, Smartphone, ChevronDown, Loader2, CheckCircle2, HelpCircle } from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { createZipBlobFromApp } from '../utils/zipParser';
import { generateApkBlobFromApp } from '../utils/apkGenerator';
import { ApkGuideModal } from './ApkGuideModal';

interface DownloadDropdownProps {
  lang: Language;
  app: AppMetadata;
  variant?: 'icon' | 'button' | 'compact';
  customClass?: string;
  onRunApp?: () => void;
}

export const DownloadDropdown: React.FC<DownloadDropdownProps> = ({
  lang,
  app,
  variant = 'button',
  customClass,
  onRunApp,
}) => {
  const isAr = lang === 'ar';
  const [isOpen, setIsOpen] = useState(false);
  const [loadingType, setLoadingType] = useState<'zip' | 'apk' | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDownloadZip = async () => {
    try {
      setLoadingType('zip');
      setIsOpen(false);
      const blob = await createZipBlobFromApp(app);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${app.name.toLowerCase().replace(/\s+/g, '-')}-source.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      setSuccessMsg(isAr ? 'تم تنزيل ملف ZIP' : 'ZIP downloaded');
      setTimeout(() => setSuccessMsg(null), 2500);
    } catch (e) {
      console.error('ZIP generation error:', e);
    } finally {
      setLoadingType(null);
    }
  };

  const handleDownloadApk = async () => {
    try {
      setLoadingType('apk');
      setIsOpen(false);

      let blob: Blob;

      try {
        const response = await fetch('/api/generate-apk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ app }),
        });

        if (response.ok) {
          blob = await response.blob();
        } else {
          blob = await generateApkBlobFromApp(app);
        }
      } catch (err) {
        console.warn('Server signing endpoint failed, falling back to client generation:', err);
        blob = await generateApkBlobFromApp(app);
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${app.name.toLowerCase().replace(/\s+/g, '-')}-signed.apk`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      setSuccessMsg(isAr ? 'تم تحويل وتوقيع APK بنجاح' : 'Signed APK generated & downloaded');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (e) {
      console.error('APK generation error:', e);
    } finally {
      setLoadingType(null);
    }
  };

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      {/* Trigger Button */}
      {variant === 'icon' ? (
        <button
          onClick={() => setIsOpen(!isOpen)}
          disabled={loadingType !== null}
          title={isAr ? 'خيارات التنزيل (ZIP / APK)' : 'Download Options (ZIP / APK)'}
          className={`bg-slate-800 hover:bg-slate-700 active:bg-slate-700 text-slate-300 border border-slate-700 p-2.5 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center relative ${
            customClass || ''
          }`}
        >
          {loadingType ? (
            <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
          ) : (
            <Download className="w-4 h-4 text-sky-400" />
          )}
        </button>
      ) : variant === 'compact' ? (
        <button
          onClick={() => setIsOpen(!isOpen)}
          disabled={loadingType !== null}
          className={`bg-slate-800 hover:bg-slate-700 active:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition min-h-[40px] ${
            customClass || ''
          }`}
        >
          {loadingType ? (
            <Loader2 className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
          ) : (
            <Download className="w-3.5 h-3.5 text-sky-400" />
          )}
          <span>{isAr ? 'تنزيل' : 'Download'}</span>
          <ChevronDown className={`w-3 h-3 text-slate-400 transition ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      ) : (
        <button
          onClick={() => setIsOpen(!isOpen)}
          disabled={loadingType !== null}
          className={`bg-slate-800 hover:bg-slate-700 active:bg-slate-700 text-slate-200 border border-slate-700 px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition min-h-[40px] ${
            customClass || ''
          }`}
        >
          {loadingType ? (
            <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
          ) : (
            <Download className="w-4 h-4 text-sky-400" />
          )}
          <span>{isAr ? 'تنزيل التطبيق' : 'Download App'}</span>
          <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      )}

      {/* Floating Status Notification */}
      {successMsg && (
        <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-[11px] font-medium px-2.5 py-1 rounded-lg shadow-lg flex items-center gap-1.5 z-50 animate-fade-in">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-52 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden divide-y divide-slate-800/80 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="p-1.5 space-y-1">
            {/* 1. ZIP Download Option */}
            <button
              onClick={handleDownloadZip}
              className="w-full text-left rtl:text-right px-3 py-2.5 rounded-xl hover:bg-slate-800 transition flex items-center gap-2.5 group"
            >
              <div className="p-1.5 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-lg group-hover:bg-sky-500/20 transition">
                <FileArchive className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-200 group-hover:text-white flex items-center gap-1">
                  <span>1. ZIP</span>
                  <span className="text-[10px] text-slate-400 font-normal">(.zip)</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  {isAr ? 'حزمة الأكواد والملفات المضغوطة' : 'Source code archive'}
                </div>
              </div>
            </button>

            {/* 2. APK Download Option */}
            <button
              onClick={handleDownloadApk}
              className="w-full text-left rtl:text-right px-3 py-2.5 rounded-xl hover:bg-indigo-950/60 transition flex items-center gap-2.5 group"
            >
              <div className="p-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg group-hover:bg-emerald-500/20 transition">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-200 group-hover:text-emerald-300 flex items-center gap-1">
                  <span>2. APK</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1 rounded font-mono">Android</span>
                </div>
                <div className="text-[10px] text-slate-400">
                  {isAr ? 'تطبيق أندرويد جاهز للتثبيت' : 'Installable Android App (.apk)'}
                </div>
              </div>
            </button>

            {/* 3. Fix Parse Error & PWA Guide */}
            <button
              onClick={() => {
                setIsOpen(false);
                setShowGuideModal(true);
              }}
              className="w-full text-left rtl:text-right px-3 py-2 rounded-xl hover:bg-slate-800 transition flex items-center gap-2.5 group text-amber-400"
            >
              <div className="p-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-lg">
                <HelpCircle className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px] font-medium text-slate-300 group-hover:text-amber-300">
                {isAr ? 'حل مشكلة تحليل الحزمة والتثبيت' : 'Fix "Problem Parsing Package"'}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* APK Guide & Fix Modal */}
      {showGuideModal && (
        <ApkGuideModal
          lang={lang}
          app={app}
          onClose={() => setShowGuideModal(false)}
          onRunApp={onRunApp}
        />
      )}
    </div>
  );
};
