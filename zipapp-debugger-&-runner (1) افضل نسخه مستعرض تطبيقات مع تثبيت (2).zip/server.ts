import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { buildAndSignApk } from "./server/apkSigner";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // API Endpoints
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "App Browser Server Running" });
  });

  // API to generate and sign Android APK using debug keystore
  app.post("/api/generate-apk", async (req, res) => {
    try {
      const { app } = req.body;
      if (!app || !app.name || !app.files) {
        res.status(400).json({ error: "Invalid app object received" });
        return;
      }

      const apkBuffer = await buildAndSignApk(app);

      const fileName = `${app.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}-signed.apk`;
      res.setHeader("Content-Type", "application/vnd.android.package-archive");
      res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
      res.setHeader("Content-Length", apkBuffer.length);
      res.send(apkBuffer);
    } catch (err: any) {
      console.error("Error generating signed APK:", err);
      res.status(500).json({ error: err.message || "APK Signing Failed" });
    }
  });

  // API to upload and analyze app ZIP metadata
  app.post("/api/analyze-app", (req, res) => {
    try {
      const { name, files, structure } = req.body;
      res.json({
        success: true,
        summary: {
          name: name || "Uploaded App",
          fileCount: files ? Object.keys(files).length : 0,
          analyzedAt: new Date().toISOString(),
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware for development vs static fallback for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get("*", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[App Browser Server] Running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
