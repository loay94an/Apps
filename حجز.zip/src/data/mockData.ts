import { User, Pitch, OpenMatch, Tournament, PitchRequest, LevelInfo, Team, VisitorLog } from '../types';

export const LEVEL_TIERS: LevelInfo[] = [
  {
    levelRange: 'Level 1 - 5',
    title: 'مبتدئ (Beginner)',
    badge: '🥉',
    color: 'from-slate-600 to-slate-800',
    benefits: [
      'إنضمام للمباريات المفتوحة',
      'حجز الملاعب الأساسية',
      'مشاركة تقسيم الفاتورة'
    ],
    refereeUnlocked: false,
    videoUnlocked: false,
  },
  {
    levelRange: 'Level 6 - 15',
    title: 'هاوي (Amateur)',
    badge: '🥈',
    color: 'from-blue-500 to-cyan-500',
    benefits: [
      '🔓 تفعيل ميزة طلب حكم معتمد للمباراة (+15 JOD)',
      'شارات الأداء والتقييم المميز',
      'أولوية الانضمام للمباريات السريعة'
    ],
    refereeUnlocked: true,
    videoUnlocked: false,
  },
  {
    levelRange: 'Level 16 - 30',
    title: 'محترف (Professional)',
    badge: '🥇',
    color: 'from-amber-400 to-orange-500',
    benefits: [
      '🔓 تفعيل ميزة طلب تصوير وتوثيق فيديو HD للمباراة (+20 JOD)',
      'إنشاء وتدريب الفرق والبطولات',
      'خصم 10% على حجز الملاعب في أوقات الظهيرة'
    ],
    refereeUnlocked: true,
    videoUnlocked: true,
  },
  {
    levelRange: 'Level 35+',
    title: 'نجم محلي (Local Star)',
    badge: '🏆',
    color: 'from-emerald-400 via-teal-300 to-green-500',
    benefits: [
      'شارة النجم المحلي الفسفورية الفاخرة VIP',
      'جميع الميزات الإضافية مجانية أو بأسعار مخفضة',
      'دعوات خاصة لبطولات النخبة في الأردن'
    ],
    refereeUnlocked: true,
    videoUnlocked: true,
  },
];

export const INITIAL_USER: User = {
  id: '',
  name: 'لاعب جديد / زائر',
  phone: '',
  email: '',
  role: 'user',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  city: 'عمان',
  level: 1,
  xp: 0,
  maxXp: 1000,
  rankTitle: 'مبتدئ (Beginner)',
  matchesPlayed: 0,
  matchesWon: 0,
  preferredPosition: 'مهاجم صريح',
  isGuest: true,
  walletBalance: 0.00,
};

export const INITIAL_PITCHES: Pitch[] = [];

export const INITIAL_OPEN_MATCHES: OpenMatch[] = [];

export const INITIAL_TOURNAMENTS: Tournament[] = [];

export const INITIAL_PITCH_REQUESTS: PitchRequest[] = [];

export const INITIAL_TEAMS: Team[] = [];

export const INITIAL_VISITOR_LOGS: VisitorLog[] = [];
