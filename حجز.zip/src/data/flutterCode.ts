export interface FlutterFile {
  fileName: string;
  path: string;
  code: string;
  description: string;
}

export const FLUTTER_CODE_FILES: FlutterFile[] = [
  {
    fileName: 'main.dart',
    path: 'lib/main.dart',
    description: 'نقطة الانطلاق الرئيسية للتطبيق، إعدادات الثيم الداكن الهجين، والروتس Navigation',
    code: `import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/admin_screen.dart';
import 'screens/pitch_owner_screen.dart';

void main() {
  runApp(const MalaebakApp());
}

class MalaebakApp extends StatelessWidget {
  const MalaebakApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ملعبك - Jordan Pitch Booking',
      debugShowCheckedModeBanner: false,
      
      // إعدادات اللغة العربية بالكامل RTL
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar', 'JO'),
      ],
      locale: const Locale('ar', 'JO'),

      // الهوية البصرية: أسلوب ألعاب حديث Dark Gamified (#0F172A + #39FF14)
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0F172A), // كحلي داكن
        primaryColor: const Color(0xFF39FF14), // نيون فسفوري
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF39FF14),
          secondary: Color(0xFF00E5FF),
          surface: Color(0xFF1E293B),
          background: Color(0xFF0F172A),
        ),
        fontFamily: 'Tajawal',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F172A),
          elevation: 0,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF39FF14),
            foregroundColor: Colors.black,
            textStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
      initialRoute: '/auth',
      routes: {
        '/auth': (context) => const AuthScreen(),
        '/home': (context) => const HomeScreen(),
        '/admin': (context) => const AdminScreen(),
        '/owner': (context) => const PitchOwnerScreen(),
      },
    );
  }
}
`,
  },
  {
    fileName: 'models.dart',
    path: 'lib/models.dart',
    description: 'نماذج البيانات لنظام XP، المستويات، الملاعب، المباريات المفتوحة، والبطولات',
    code: `// models.dart - Malaebak Models

enum SportType { football, padel, basketball, volleyball }

class UserModel {
  final String id;
  final String name;
  final String phone;
  final String email;
  final String role; // 'user', 'owner', 'admin'
  final int level;
  final int xp;
  final int maxXp;
  final String rankTitle;
  final String city;

  UserModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.role,
    required this.level,
    required this.xp,
    required this.maxXp,
    required this.rankTitle,
    required this.city,
  });

  // فحص صلاحية طلب حكم معتمد (فتح في Level 10+)
  bool get canRequestReferee => level >= 10;

  // فحص صلاحية طلب تصوير فيديو للمباراة (فتح في Level 20+)
  bool get canRequestVideo => level >= 20;
}

class PitchModel {
  final String id;
  final String name;
  final String city;
  final String district;
  final double hourlyRateJod;
  final String surfaceType;
  final String imageUrl;
  final double rating;

  PitchModel({
    required this.id,
    required this.name,
    required this.city,
    required this.district,
    required this.hourlyRateJod,
    required this.surfaceType,
    required this.imageUrl,
    required this.rating,
  });
}

class MatchModel {
  final String id;
  final String title;
  final SportType sport;
  final String pitchName;
  final String city;
  final String date;
  final String timeSlot;
  final int totalPlayersNeeded;
  final int joinedCount;
  final double costPerPlayerJod;
  final bool refereeRequested;
  final bool videoRequested;
  final bool splitBill;

  MatchModel({
    required this.id,
    required this.title,
    required this.sport,
    required this.pitchName,
    required this.city,
    required this.date,
    required this.timeSlot,
    required this.totalPlayersNeeded,
    required this.joinedCount,
    required this.costPerPlayerJod,
    required this.refereeRequested,
    required this.videoRequested,
    required this.splitBill,
  });
}
`,
  },
  {
    fileName: 'home_screen.dart',
    path: 'lib/screens/home_screen.dart',
    description: 'الشاشة الرئيسية - نظام الأعمدة الثلاثة الرأسية (إيجاد لعبة - إنشاء لعبة - البطولات) والشريط العلوي مع BottomSheet الرياضة',
    code: `import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedSport = '⚽ كرة القدم';
  int userLevel = 12;
  int userXp = 1450;
  int maxXp = 2000;
  String rankTitle = 'هاوي (Amateur)';

  void _showSportBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E293B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        final sports = [
          '⚽ كرة القدم',
          '🎾 بادل',
          '🏀 كرة السلة',
          '🏐 كرة الطائرة',
        ];
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[600],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'اختر الرياضة المفضلة',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 12),
              ...sports.map((sport) => ListTile(
                title: Text(
                  sport,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                trailing: selectedSport == sport
                    ? const Icon(Icons.check_circle, color: Color(0xFF39FF14))
                    : null,
                onTap: () {
                  setState(() {
                    selectedSport = sport;
                  });
                  Navigator.pop(context);
                },
              )),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(
        child: Column(
          children: [
            // [1. الشريط العلوي Header]
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: const BoxDecoration(
                color: Color(0xFF1E293B),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
              ),
              child: Column(
                children: [
                  // اسم الرياضة بخط صغير جداً قابل للنقر
                  GestureDetector(
                    onTap: _showSportBottomSheet,
                    child: Row(
                      mainAxisAlignment: MainPageRoute.center,
                      children: [
                        Text(
                          '$selectedSport  ▼',
                          style: const TextStyle(
                            fontSize: 11,
                            color: Color(0xFF39FF14),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  // اسم المستخدم والمستوى وشريط XP
                  Row(
                    children: [
                      const CircleAvatar(
                        radius: 20,
                        backgroundColor: Color(0xFF39FF14),
                        child: Text('ورد', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'ورد الرواشدة | Level $userLevel - $rankTitle',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                            ),
                            const SizedBox(height: 4),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: userXp / maxXp,
                                minHeight: 6,
                                backgroundColor: Colors.slate[700],
                                valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF39FF14)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '$userXp/$maxXp XP',
                        style: const TextStyle(color: Colors.grey, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // [2. الشاشة الرئيسية - نظام الأعمدة الثلاثة الرأسية]
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: [
                    // العمود الأول: أزرق - 🔍 إيجاد لعبة
                    Expanded(
                      child: _buildGamifiedColumnCard(
                        title: 'إيجاد لعبة',
                        subtitle: 'مباريات مفتوحة والتكملة',
                        icon: Icons.search_rounded,
                        accentColor: const Color(0xFF00E5FF),
                        badgeText: '12 مباراة',
                        onTap: () {
                          // View Matchmaking Open Matches List
                        },
                      ),
                    ),
                    const SizedBox(width: 8),

                    // العمود الثاني: برتقالي - ➕ إنشاء لعبة
                    Expanded(
                      child: _buildGamifiedColumnCard(
                        title: 'إنشاء لعبة',
                        subtitle: 'حجز + حكم + تصوير + Split Bill',
                        icon: Icons.add_circle_outline,
                        accentColor: const Color(0xFFFF9100),
                        badgeText: 'حجز مباشر',
                        onTap: () {
                          // Navigate to Pitch Booking Wizard
                        },
                      ),
                    ),
                    const SizedBox(width: 8),

                    // العمود الثالث: ذهبي - 🏆 البطولات
                    Expanded(
                      child: _buildGamifiedColumnCard(
                        title: 'البطولات',
                        subtitle: 'الدوريات وشجرة التصفيات',
                        icon: Icons.emoji_events_rounded,
                        accentColor: const Color(0xFFFFD700),
                        badgeText: 'جوائز 1000 JOD',
                        onTap: () {
                          // Navigate to Tournaments list
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildGamifiedColumnCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color accentColor,
    required String badgeText,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1E293B),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: accentColor.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: accentColor.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: accentColor, size: 36),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: TextStyle(
                color: accentColor,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 11,
              ),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                badgeText,
                style: TextStyle(color: accentColor, fontSize: 10, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
`,
  },
  {
    fileName: 'auth_screen.dart',
    path: 'lib/screens/auth_screen.dart',
    description: 'واجهة تسجيل الدخول مع الخيارات الثلاثة (لاعب جديد، إدارة، صاحب ملعب) وتغيير كلمة سر الإدارة أول مرة',
    code: `import 'package:flutter/material.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  int selectedRoleIndex = 0; // 0: لاعب جديد, 1: إدارة, 2: صاحب ملعب
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passController = TextEditingController();

  void _login() {
    if (selectedRoleIndex == 1) {
      // Admin Check
      if (_passController.text == '123123') {
        _showForceChangePasswordDialog();
      } else {
        Navigator.pushReplacementNamed(context, '/admin');
      }
    } else if (selectedRoleIndex == 2) {
      Navigator.pushReplacementNamed(context, '/owner');
    } else {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  void _showForceChangePasswordDialog() {
    final newPassController = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        title: const Text('⚠️ تغيير كلمة المرور المبدئية', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'كلمة مرور الإدارة المبدئية هي 123123. يرجى إدخال كلمة مرور جديدة لأمان النظام.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: newPassController,
              obscureText: true,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'كلمة المرور الجديدة',
                labelStyle: TextStyle(color: Color(0xFF39FF14)),
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/admin');
            },
            child: const Text('حفظ والانتقال للوحة التحكم'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                '⚽ مـلـعـبـك',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.black,
                  color: Color(0xFF39FF14),
                ),
              ),
              const Text(
                'منصة حجز الملاعب وتنظيم المباريات في الأردن',
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 32),

              // الخيارات الثلاثة للدخول
              Row(
                children: [
                  _roleTab('لاعب جديد', 0),
                  _roleTab('إدارة', 1),
                  _roleTab('صاحب ملعب', 2),
                ],
              ),
              const SizedBox(height: 20),

              // حقول الإدخال
              if (selectedRoleIndex == 0) ...[
                TextField(
                  controller: _phoneController,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    labelText: 'رقم الهاتف (الأردن +962)',
                    hintText: '07 9123 4567',
                    prefixIcon: Icon(Icons.phone, color: Color(0xFF39FF14)),
                    border: OutlineInputBorder(),
                  ),
                ),
              ] else ...[
                TextField(
                  controller: _emailController,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    labelText: 'البريد الإلكتروني',
                    prefixIcon: Icon(Icons.email, color: Color(0xFF39FF14)),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _passController,
                  obscureText: true,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'كلمة المرور',
                    hintText: selectedRoleIndex == 1 ? 'كلمة المرور المبدئية 123123' : '',
                    prefixIcon: const Icon(Icons.lock, color: Color(0xFF39FF14)),
                    border: const OutlineInputBorder(),
                  ),
                ),
              ],
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _login,
                  child: const Text('تسجيل الدخول'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleTab(String title, int index) {
    final isSelected = selectedRoleIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => selectedRoleIndex = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xFF39FF14) : const Color(0xFF1E293B),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isSelected ? Colors.black : Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}
`,
  },
];
