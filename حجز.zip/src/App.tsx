import React, { useState, useEffect } from 'react';
import {
  INITIAL_USER,
  INITIAL_PITCHES,
  INITIAL_OPEN_MATCHES,
  INITIAL_TOURNAMENTS,
  INITIAL_PITCH_REQUESTS,
  INITIAL_TEAMS,
  INITIAL_VISITOR_LOGS,
} from './data/mockData';
import { User, Pitch, OpenMatch, Tournament, PitchRequest, SportType, Role, SupportTicket, StaffMember, PaymentGatewayConfig, Team, TeamMember, VisitorLog, AppPlatformConfig, INITIAL_PLATFORM_CONFIG } from './types';
import { Header } from './components/Header';
import { ThreeColumnsHome } from './components/ThreeColumnsHome';
import { MatchmakingModal } from './components/MatchmakingModal';
import { CreateMatchModal } from './components/CreateMatchModal';
import { TournamentsModal } from './components/TournamentsModal';
import { PitchOwnerPortal } from './components/PitchOwnerPortal';
import { AdminPortal } from './components/AdminPortal';
import { AuthModal } from './components/AuthModal';
import { GamificationWidget } from './components/GamificationWidget';
import { FlutterCodeViewer } from './components/FlutterCodeViewer';
import { DeviceFrame } from './components/DeviceFrame';
import { SupportContactModal } from './components/SupportContactModal';
import { PaymentGatewayModal } from './components/PaymentGatewayModal';
import { UserProfileModal } from './components/UserProfileModal';
import { PlayerRatingModal, PlayerRating } from './components/PlayerRatingModal';
import { TeamsClubsSection } from './components/TeamsClubsSection';
import { getSportTheme } from './lib/sportThemes';
import { Home, Search, PlusCircle, Trophy, User as UserIcon, ShieldAlert, Store, Headphones, CreditCard, Star, Shield } from 'lucide-react';

export default function App() {
  // Main State
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USER);
  const [selectedSport, setSelectedSport] = useState<SportType>('football');
  const [activeViewMode, setActiveViewMode] = useState<'app' | 'flutter_code' | 'gamification_details'>('app');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // Sync dark mode class on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Admin Credentials & Profile Security State
  const [adminUsername, setAdminUsername] = useState<string>('0790000000');
  const [adminPassword, setAdminPassword] = useState<string>('admin123'); // Initial launch admin password
  const [adminName, setAdminName] = useState<string>('مدير النظام الأساسي (الإدارة العليا)');

  // Database Collections State
  const [pitches, setPitches] = useState<Pitch[]>(INITIAL_PITCHES);
  const [openMatches, setOpenMatches] = useState<OpenMatch[]>(INITIAL_OPEN_MATCHES);
  const [tournaments, setTournaments] = useState<Tournament[]>(INITIAL_TOURNAMENTS);
  const [pitchRequests, setPitchRequests] = useState<PitchRequest[]>(INITIAL_PITCH_REQUESTS);
  const [usersList, setUsersList] = useState<User[]>([]);

  // Support Tickets & Messages State
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);

  // Admin Staff & Assistants State
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);

  // Payment Gateways & Rates Config
  const [paymentConfig, setPaymentConfig] = useState<PaymentGatewayConfig>({
    cliqAlias: 'MALAEBAKJO',
    cliqEnabled: true,
    bankIban: 'JO96CBJO0000000000001234567890',
    bankIbanEnabled: true,
    zainCashPhone: '0790001122',
    zainCashEnabled: true,
    orangeMoneyPhone: '0770001122',
    orangeMoneyEnabled: true,
    efawateerCode: '88392',
    efawateerEnabled: true,
    cardEnabled: true,
    cashEnabled: true,
    commissionRate: 10,
    defaultMatchFee: 2.5,
    taxPercent: 16,
  });

  // App Platform Global Configuration (Modifiable by Super Admin)
  const [platformConfig, setPlatformConfig] = useState<AppPlatformConfig>(INITIAL_PLATFORM_CONFIG);

  const handleUpdatePlatformConfig = (updatedFields: Partial<AppPlatformConfig>) => {
    setPlatformConfig(prev => ({ ...prev, ...updatedFields }));
  };

  // Player Ratings Feed State
  const [ratingsList, setRatingsList] = useState<PlayerRating[]>([]);

  // Modal Open States
  const [isMatchmakingOpen, setIsMatchmakingOpen] = useState<boolean>(false);
  const [isCreateMatchOpen, setIsCreateMatchOpen] = useState<boolean>(false);
  const [isTournamentsOpen, setIsTournamentsOpen] = useState<boolean>(false);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isSupportOpen, setIsSupportOpen] = useState<boolean>(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isRatingOpen, setIsRatingOpen] = useState<boolean>(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(10.00);
  const [paymentItemTitle, setPaymentItemTitle] = useState<string>('شحن رصيد المحفظة والتكميلة');

  // Teams & Community State
  const [teams, setTeams] = useState<Team[]>(INITIAL_TEAMS);
  const [visitorLogs, setVisitorLogs] = useState<VisitorLog[]>(INITIAL_VISITOR_LOGS);

  // Bottom Navigation Active Tab
  const [activeNavTab, setActiveNavTab] = useState<'home' | 'search' | 'teams' | 'create' | 'tournaments' | 'profile'>('home');

  // Team Action Handlers
  const handleCreateTeam = (newTeamData: Omit<Team, 'id' | 'members' | 'pendingRequests' | 'chatMessages' | 'createdAt' | 'isChatLocked'>) => {
    const newTeam: Team = {
      ...newTeamData,
      id: `tm_${Date.now()}`,
      members: [
        {
          id: `m_${Date.now()}`,
          userId: currentUser.id,
          name: currentUser.name,
          position: 'مؤسس ورئيس الفريق 👑',
          role: 'founder',
          joinedAt: 'اليوم',
          canManageJoinRequests: true,
        },
      ],
      pendingRequests: [],
      chatMessages: [
        {
          id: `cm_${Date.now()}`,
          senderId: currentUser.id,
          senderName: currentUser.name,
          message: `أهلاً وسهلاً بالجميع في مجتمع (${newTeamData.name})! نتطلع لخوض أجمل المباريات.`,
          timestamp: 'الآن',
        },
      ],
      isChatLocked: false,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setTeams((prev) => [newTeam, ...prev]);
  };

  const handleJoinTeamRequest = (
    teamId: string,
    requestOrPosition: string | { userId: string; userName: string; position?: string; userAvatar?: string; userLevel?: number; message?: string }
  ) => {
    if (!currentUser || currentUser.isGuest) {
      setIsAuthOpen(true);
      return;
    }

    const requestData =
      typeof requestOrPosition === 'string'
        ? { userId: currentUser.id, userName: currentUser.name, position: requestOrPosition, userAvatar: currentUser.avatar, message: 'طلب انضمام لكادر الفريق' }
        : requestOrPosition;

    setTeams((prev) =>
      prev.map((tm) => {
        if (tm.id === teamId) {
          const existsInMembers = tm.members.some((m) => m.userId === currentUser.id);
          const pendingList = tm.pendingRequests || tm.joinRequests || [];
          const existsInPending = pendingList.some((p) => p.userId === currentUser.id);
          if (existsInMembers || existsInPending) return tm;

          const newReq = {
            id: `pr_${Date.now()}`,
            userId: currentUser.id,
            userName: currentUser.name,
            position: requestData.position || 'لاعب متكامل (All-round)',
            userAvatar: currentUser.avatar,
            userLevel: currentUser.level || 1,
            message: requestData.message || 'طلب انضمام لكادر الفريق',
            status: 'pending' as const,
            requestedAt: 'الآن',
          };

          const updatedPending = [...pendingList, newReq];
          return {
            ...tm,
            pendingRequests: updatedPending,
            joinRequests: updatedPending as any,
          };
        }
        return tm;
      })
    );
  };

  const handleHandleTeamJoinRequest = (teamId: string, requestId: string, action: 'approve' | 'reject' | boolean) => {
    const isApprove = action === 'approve' || action === true;
    setTeams((prev) =>
      prev.map((tm) => {
        if (tm.id === teamId) {
          const pendingList = tm.pendingRequests || tm.joinRequests || [];
          const req = pendingList.find((r) => r.id === requestId);
          const updatedPending = pendingList.filter((r) => r.id !== requestId);
          if (isApprove && req) {
            const newMember: TeamMember = {
              id: `m_${Date.now()}`,
              userId: req.userId,
              name: req.userName,
              position: req.position || 'لاعب',
              role: 'player',
              joinedAt: 'اليوم',
              canApproveRequests: false,
              canManageJoinRequests: false,
            };
            return {
              ...tm,
              pendingRequests: updatedPending,
              joinRequests: updatedPending as any,
              members: [...tm.members, newMember],
              chatMessages: [
                ...tm.chatMessages,
                {
                  id: `cm_${Date.now()}`,
                  senderId: 'sys',
                  senderName: 'النظام 🤖',
                  message: `انضم اللاعب (${req.userName}) بنجاح إلى الفريق 🎉`,
                  timestamp: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
                },
              ],
            };
          }
          return {
            ...tm,
            pendingRequests: updatedPending,
            joinRequests: updatedPending as any,
          };
        }
        return tm;
      })
    );
  };

  const handleSendTeamChatMessage = (teamId: string, message: string) => {
    setTeams((prev) =>
      prev.map((tm) => {
        if (tm.id === teamId) {
          if (tm.isChatLocked) return tm;
          const newMsg = {
            id: `cm_${Date.now()}`,
            senderId: currentUser.id,
            senderName: currentUser.name,
            message,
            timestamp: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
          };
          return { ...tm, chatMessages: [...tm.chatMessages, newMsg] };
        }
        return tm;
      })
    );
  };

  const handleToggleTeamMemberPermission = (teamId: string, memberId: string) => {
    setTeams((prev) =>
      prev.map((tm) => {
        if (tm.id === teamId) {
          return {
            ...tm,
            members: tm.members.map((m) =>
              m.id === memberId || m.userId === memberId
                ? {
                    ...m,
                    canApproveRequests: !m.canApproveRequests,
                    canManageJoinRequests: !m.canManageJoinRequests,
                  }
                : m
            ),
          };
        }
        return tm;
      })
    );
  };

  const handleDeleteTeamByAdmin = (teamId: string) => {
    setTeams((prev) => prev.filter((tm) => tm.id !== teamId));
  };

  const handleToggleLockTeamChatByAdmin = (teamId: string) => {
    setTeams((prev) =>
      prev.map((tm) => (tm.id === teamId ? { ...tm, isChatLocked: !tm.isChatLocked } : tm))
    );
  };

  const handleBanPlayerFromTeamByAdmin = (teamId: string, userId: string) => {
    setTeams((prev) =>
      prev.map((tm) =>
        tm.id === teamId
          ? {
              ...tm,
              members: tm.members.filter((m) => m.userId !== userId),
            }
          : tm
      )
    );
  };

  // Handlers for User & Pitch Management
  const handleUpdateUser = (updatedData: Partial<User>) => {
    setCurrentUser((prev) => {
      const nextUser = { ...prev, ...updatedData };
      if (prev.role === 'admin' && !prev.isStaff) {
        if (updatedData.phone) setAdminUsername(updatedData.phone);
        if (updatedData.name) setAdminName(updatedData.name);
        if (updatedData.password) setAdminPassword(updatedData.password);
      }
      return nextUser;
    });
    setUsersList((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, ...updatedData } : u))
    );
  };

  const handleUpdateAdminProfile = (updated: { name?: string; username?: string; password?: string; avatar?: string; email?: string }) => {
    if (updated.username) setAdminUsername(updated.username);
    if (updated.password) setAdminPassword(updated.password);
    if (updated.name) setAdminName(updated.name);

    setCurrentUser((prev) => {
      if (prev.role === 'admin' && !prev.isStaff) {
        return {
          ...prev,
          name: updated.name || prev.name,
          phone: updated.username || prev.phone,
          email: updated.email || prev.email,
          avatar: updated.avatar || prev.avatar,
          password: updated.password || prev.password,
        };
      }
      return prev;
    });

    setUsersList((prev) =>
      prev.map((u) =>
        u.id === 'adm_001'
          ? {
              ...u,
              name: updated.name || u.name,
              phone: updated.username || u.phone,
              email: updated.email || u.email,
              avatar: updated.avatar || u.avatar,
              password: updated.password || u.password,
            }
          : u
      )
    );
  };

  const handleToggleBanUser = (userId: string) => {
    setUsersList((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, isBanned: !u.isBanned } : u))
    );
  };

  const handleToggleBanPitch = (pitchId: string) => {
    setPitches((prev) =>
      prev.map((p) => (p.id === pitchId ? { ...p, isBanned: !p.isBanned } : p))
    );
  };

  const handleUpdatePitchRate = (pitchId: string, newRate: number) => {
    setPitches((prev) =>
      prev.map((p) => (p.id === pitchId ? { ...p, hourlyRate: newRate } : p))
    );
  };

  const handleDeleteUser = (userId: string) => {
    setUsersList((prev) => prev.filter((u) => u.id !== userId));
    if (currentUser.id === userId) {
      setCurrentUser(INITIAL_USER);
    }
    setOpenMatches((prev) =>
      prev.map((m) => {
        const filteredJoined = m.joinedPlayers ? m.joinedPlayers.filter((p) => p.id !== userId) : [];
        return {
          ...m,
          joinedPlayers: filteredJoined,
          joinedPlayersCount: filteredJoined.length,
        };
      })
    );
  };

  const handleCreateSupportTicket = (ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'status'>) => {
    const newTicket: SupportTicket = {
      ...ticket,
      id: `st_${Date.now()}`,
      status: 'open',
      createdAt: 'الآن',
    };
    setSupportTickets((prev) => [newTicket, ...prev]);
  };

  const handleReplySupportTicket = (ticketId: string, reply: string) => {
    setSupportTickets((prev) =>
      prev.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              status: 'replied',
              reply,
              repliedAt: 'الآن',
            }
          : t
      )
    );
  };

  const handleCreateTournament = (newTourney: Omit<Tournament, 'id' | 'teamsCount' | 'brackets'>) => {
    const tourney: Tournament = {
      ...newTourney,
      id: `trn_${Date.now()}`,
      teamsCount: 0,
      brackets: [],
    };
    setTournaments((prev) => [tourney, ...prev]);
  };

  const handleDeleteTournament = (tourneyId: string) => {
    setTournaments((prev) => prev.filter((t) => t.id !== tourneyId));
  };

  const handleCreateStaffMember = (staff: Omit<StaffMember, 'id' | 'createdAt'>) => {
    const newStaff: StaffMember = {
      ...staff,
      id: `stf_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setStaffMembers((prev) => [...prev, newStaff]);
  };

  const handleUpdateStaffMember = (staffId: string, updatedFields: Partial<StaffMember>) => {
    setStaffMembers((prev) =>
      prev.map((s) => (s.id === staffId ? { ...s, ...updatedFields } : s))
    );
  };

  const handleDeleteStaffMember = (staffId: string) => {
    setStaffMembers((prev) => prev.filter((s) => s.id !== staffId));
  };

  // Handler: Password Reset for Super Admin, Staff, Owners, and Players
  const handleResetUserPassword = (identifier: string, newPassword: string): boolean => {
    const norm = identifier.trim().toLowerCase().replace(/[\s\-\+]/g, '');

    // 1. Check Super Admin
    const superAdminUserNorm = adminUsername.trim().toLowerCase().replace(/[\s\-\+]/g, '');
    if (norm === superAdminUserNorm || norm === 'admin' || norm === 'admin@malaebak.jo' || norm === '0790000000') {
      setAdminPassword(newPassword);
      if (currentUser.role === 'admin' && !currentUser.isStaff) {
        setCurrentUser(prev => ({ ...prev, password: newPassword }));
      }
      return true;
    }

    // 2. Check Staff Members
    let staffUpdated = false;
    setStaffMembers(prev =>
      prev.map(s => {
        const uNorm = (s.username || '').trim().toLowerCase().replace(/[\s\-\+]/g, '');
        const eNorm = (s.email || '').trim().toLowerCase().replace(/[\s\-\+]/g, '');
        if (uNorm === norm || eNorm === norm) {
          staffUpdated = true;
          return { ...s, password: newPassword };
        }
        return s;
      })
    );
    if (staffUpdated) return true;

    // 3. Check Users List (Players & Pitch Owners)
    let userUpdated = false;
    setUsersList(prev =>
      prev.map(u => {
        const pNorm = (u.phone || '').trim().toLowerCase().replace(/[\s\-\+]/g, '');
        const eNorm = (u.email || '').trim().toLowerCase().replace(/[\s\-\+]/g, '');
        if (pNorm === norm || eNorm === norm || (pNorm.includes(norm) && norm.length >= 7)) {
          userUpdated = true;
          return { ...u, password: newPassword };
        }
        return u;
      })
    );

    if (currentUser) {
      const curPNorm = (currentUser.phone || '').trim().toLowerCase().replace(/[\s\-\+]/g, '');
      const curENorm = (currentUser.email || '').trim().toLowerCase().replace(/[\s\-\+]/g, '');
      if (curPNorm === norm || curENorm === norm) {
        setCurrentUser(prev => ({ ...prev, password: newPassword }));
      }
    }

    return userUpdated;
  };

  // Handler: Role Selection & Login
  const handleSelectRole = (role: Role, userDetails?: Partial<User>) => {
    if (userDetails && userDetails.id) {
      // Login directly with existing matched user object
      const matchedUser = userDetails as User;
      setCurrentUser(matchedUser);
      setUsersList((prev) => {
        const exists = prev.some((u) => u.id === matchedUser.id);
        if (!exists) return [matchedUser, ...prev];
        return prev.map((u) => (u.id === matchedUser.id ? { ...u, ...matchedUser } : u));
      });
      return;
    }

    if (role === 'admin') {
      // Check if this credential matches any created assistant/staff member
      const matchingStaff = staffMembers.find(
        (s) =>
          (s.username === userDetails?.phone || s.username === userDetails?.email) &&
          s.password === userDetails?.password
      );

      if (matchingStaff) {
        setCurrentUser({
          id: matchingStaff.id,
          name: matchingStaff.name,
          phone: matchingStaff.username,
          email: `${matchingStaff.username}@malaebak.jo`,
          password: matchingStaff.password,
          role: 'admin',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          city: 'عمان',
          level: 20,
          xp: 2000,
          maxXp: 3000,
          rankTitle: 'مساعد إدارة 💼',
          matchesPlayed: 0,
          matchesWon: 0,
          isStaff: true,
          staffPermissions: matchingStaff.permissions,
        });
      } else {
        // Logged in as Primary Super Admin
        setCurrentUser({
          id: 'adm_001',
          name: adminName,
          phone: userDetails?.phone || adminUsername,
          email: userDetails?.email || 'admin@malaebak.jo',
          password: userDetails?.password || adminPassword,
          role: 'admin',
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          city: 'عمان',
          level: 99,
          xp: 9999,
          maxXp: 9999,
          rankTitle: 'مدير النظام الأساسي 🛡️',
          matchesPlayed: 100,
          matchesWon: 80,
          isStaff: false,
        });
      }
    } else if (role === 'owner') {
      const existingOwner = usersList.find(u => u.role === 'owner' && (u.phone === userDetails?.phone || u.email === userDetails?.email));
      if (existingOwner) {
        setCurrentUser({ ...existingOwner, ...userDetails });
      } else {
        const newOwner: User = {
          id: `own_${Date.now()}`,
          name: userDetails?.name || 'الكابتن طارق المجالي',
          phone: userDetails?.phone || '0788889999',
          email: userDetails?.email || 'owner@malaebak.jo',
          password: userDetails?.password || '123456',
          role: 'owner',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
          city: userDetails?.city || 'عمان',
          level: 25,
          xp: 3500,
          maxXp: 5000,
          rankTitle: 'صاحب ملعب 🏪',
          matchesPlayed: 10,
          matchesWon: 5,
          accountType: 'owner',
        };
        setCurrentUser(newOwner);
        setUsersList(prev => [newOwner, ...prev]);
      }
    } else {
      const existingUser = usersList.find(u => u.role === 'user' && (u.phone === userDetails?.phone || u.email === userDetails?.email));
      if (existingUser) {
        setCurrentUser({ ...existingUser, ...userDetails });
      } else {
        const newUser: User = {
          ...INITIAL_USER,
          id: `usr_${Date.now()}`,
          name: userDetails?.name || INITIAL_USER.name,
          phone: userDetails?.phone || INITIAL_USER.phone,
          email: userDetails?.email || INITIAL_USER.email,
          password: userDetails?.password || '123456',
          city: userDetails?.city || INITIAL_USER.city,
          preferredPosition: userDetails?.preferredPosition || 'مهاجم صريح',
          role: 'user',
          accountType: userDetails?.accountType || 'player',
        };
        setCurrentUser(newUser);
        setUsersList((prev) => [newUser, ...prev]);
      }
    }
  };

  // Handler: Gain XP
  const handleGainXp = (amount: number, reason: string) => {
    setCurrentUser((prev) => {
      const newXp = prev.xp + amount;
      let newLevel = prev.level;
      let newMaxXp = prev.maxXp;
      let newRank = prev.rankTitle;

      if (newXp >= prev.maxXp) {
        newLevel += 1;
        newMaxXp += 500;
        if (newLevel >= 35) newRank = 'نجم محلي 🏆';
        else if (newLevel >= 20) newRank = 'محترف 🥇';
        else if (newLevel >= 10) newRank = 'هاوي 🥈';
      }

      return {
        ...prev,
        xp: newXp,
        level: newLevel,
        maxXp: newMaxXp,
        rankTitle: newRank,
      };
    });
  };

  const handleAddRating = (rating: PlayerRating) => {
    setRatingsList((prev) => [rating, ...prev]);
    handleGainXp(25, 'تقديم تقييم للاعب');
  };

  // Handler: Join Match
  const handleJoinMatch = (matchId: string, position: string) => {
    setOpenMatches((prev) =>
      prev.map((m) => {
        if (m.id === matchId) {
          return {
            ...m,
            joinedPlayersCount: m.joinedPlayersCount + 1,
            joinedPlayers: [
              ...m.joinedPlayers,
              {
                id: currentUser.id,
                name: currentUser.name,
                avatar: currentUser.avatar,
                level: currentUser.level,
                position,
                paid: true,
              },
            ],
          };
        }
        return m;
      })
    );
    handleGainXp(100, 'الانضمام لمباراة مفتوحة');
  };

  // Handler: Create Match
  const handleCreateMatch = (newMatchData: Omit<OpenMatch, 'id'>) => {
    const newMatch: OpenMatch = {
      ...newMatchData,
      id: `mtc_${Date.now()}`,
    };
    setOpenMatches((prev) => [newMatch, ...prev]);
    handleGainXp(150, 'إنشاء حجز مباراة جديد');
  };

  // Handler: Pitch Addition Request from Pitch Owner
  const handleSubmitPitchRequest = (req: Omit<PitchRequest, 'id' | 'createdAt' | 'status'>) => {
    const newReq: PitchRequest = {
      ...req,
      id: `req_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'pending',
    };
    setPitchRequests((prev) => [newReq, ...prev]);
  };

  // Handler: Send Negotiation Message & Update Pitch Contract Terms
  const handleSendNegotiationMessage = (
    reqId: string,
    message: string,
    proposedRate?: number,
    proposedCommission?: number,
    proposedTerms?: string
  ) => {
    setPitchRequests((prev) =>
      prev.map((r) => {
        if (r.id === reqId) {
          const newHistory = r.negotiationHistory || [];
          const newMsg = {
            id: `msg_${Date.now()}`,
            sender: currentUser.role === 'admin' ? ('admin' as const) : ('owner' as const),
            senderName: currentUser.name,
            message,
            createdAt: 'الآن',
          };
          return {
            ...r,
            status: 'negotiating',
            negotiatedRate: proposedRate ?? r.negotiatedRate ?? r.hourlyRate,
            negotiatedCommission: proposedCommission ?? r.negotiatedCommission ?? 10,
            negotiatedTerms: proposedTerms ?? r.negotiatedTerms,
            negotiationHistory: [...newHistory, newMsg],
          };
        }
        return r;
      })
    );
  };

  // Handler: Admin approves pitch request
  const handleApprovePitchRequest = (
    reqId: string,
    negotiatedDetails?: { rate?: number; commission?: number; terms?: string }
  ) => {
    const req = pitchRequests.find((r) => r.id === reqId);
    if (!req) return;

    // Convert request to actual pitch in the database
    const newPitch: Pitch = {
      id: `ptc_${Date.now()}`,
      name: req.pitchName,
      city: req.city,
      district: req.district,
      sports: req.sports,
      surfaceType: req.surfaceType as any,
      hourlyRate: negotiatedDetails?.rate || req.negotiatedRate || req.hourlyRate,
      image: req.image,
      ownerId: 'own_approved',
      ownerName: req.ownerName,
      rating: 5.0,
      reviewsCount: 1,
      amenities: req.amenities,
      isAvailable: true,
    };

    setPitches((prev) => [newPitch, ...prev]);
    setPitchRequests((prev) =>
      prev.map((r) => (r.id === reqId ? { ...r, status: 'approved' } : r))
    );
  };

  const handleRejectPitchRequest = (reqId: string) => {
    setPitchRequests((prev) =>
      prev.map((r) => (r.id === reqId ? { ...r, status: 'rejected' } : r))
    );
  };

  // Handler: Admin Updates User/Player profile
  const handleUpdateUserByAdmin = (userId: string, updatedFields: Partial<User>) => {
    setUsersList((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, ...updatedFields } : u))
    );
  };

  // Handler: Admin Updates Pitch details
  const handleUpdatePitchByAdmin = (pitchId: string, updatedFields: Partial<Pitch>) => {
    setPitches((prev) =>
      prev.map((p) => (p.id === pitchId ? { ...p, ...updatedFields } : p))
    );
  };

  // Handler: Admin Updates Match Status
  const handleUpdateMatchStatus = (matchId: string, status: 'open' | 'full' | 'completed' | 'cancelled') => {
    setOpenMatches((prev) =>
      prev.map((m) => (m.id === matchId ? { ...m, status } : m))
    );
  };

  // Handler: Register Team for Tournament
  const handleRegisterTeam = (tournamentId: string, teamName: string) => {
    setTournaments((prev) =>
      prev.map((t) => {
        if (t.id === tournamentId) {
          return { ...t, teamsCount: Math.min(t.maxTeams, t.teamsCount + 1) };
        }
        return t;
      })
    );
    handleGainXp(200, `تسجيل فريق ${teamName} في البطولة`);
  };

  const currentSportTheme = getSportTheme(selectedSport, isDarkMode);

  return (
    <DeviceFrame>
      {/* If Flutter Code Mode is active */}
      {activeViewMode === 'flutter_code' ? (
        <FlutterCodeViewer onBackToApp={() => setActiveViewMode('app')} />
      ) : (
        <div className={`flex-1 flex flex-col min-h-0 relative overflow-hidden transition-colors duration-500 ${currentSportTheme.bgGradient}`}>
          {/* Header Bar */}
          <Header
            user={currentUser}
            selectedSport={selectedSport}
            onSelectSport={setSelectedSport}
            activeViewMode={activeViewMode}
            onChangeViewMode={setActiveViewMode}
            onOpenAuth={() => setIsAuthOpen(true)}
            onLogout={() => {
              setCurrentUser(INITIAL_USER);
            }}
            isDarkMode={isDarkMode}
            onToggleTheme={() => setIsDarkMode(!isDarkMode)}
            onOpenSupport={() => setIsSupportOpen(true)}
            onOpenPayment={() => {
              setPaymentAmount(45.50);
              setPaymentItemTitle('شحن رصيد المحفظة عبر طرق الدفع المباشرة');
              setIsPaymentOpen(true);
            }}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenRating={() => setIsRatingOpen(true)}
          />

          {/* Main Body View based on Role */}
          {currentUser.role === 'admin' ? (
            <AdminPortal
              currentUser={currentUser}
              pitchRequests={pitchRequests}
              pitches={pitches}
              usersList={usersList}
              tournaments={tournaments}
              supportTickets={supportTickets}
              staffMembers={staffMembers}
              paymentConfig={paymentConfig}
              openMatches={openMatches}
              onApprovePitchRequest={handleApprovePitchRequest}
              onRejectPitchRequest={handleRejectPitchRequest}
              onSendNegotiationMessage={handleSendNegotiationMessage}
              onToggleBanUser={handleToggleBanUser}
              onDeleteUser={handleDeleteUser}
              onUpdateUserByAdmin={handleUpdateUserByAdmin}
              onToggleBanPitch={handleToggleBanPitch}
              onUpdatePitchByAdmin={handleUpdatePitchByAdmin}
              onUpdatePitchRate={handleUpdatePitchRate}
              currentAdminPassword={adminPassword}
              currentAdminUsername={adminUsername}
              onAdminPasswordChanged={(newPass) => setAdminPassword(newPass)}
              onUpdateAdminProfile={handleUpdateAdminProfile}
              onCreateTournament={handleCreateTournament}
              onDeleteTournament={handleDeleteTournament}
              onReplySupportTicket={handleReplySupportTicket}
              onCreateStaffMember={handleCreateStaffMember}
              onUpdateStaffMember={handleUpdateStaffMember}
              onDeleteStaffMember={handleDeleteStaffMember}
              onUpdatePaymentConfig={(newConfig) => setPaymentConfig((prev) => ({ ...prev, ...newConfig }))}
              platformConfig={platformConfig}
              onUpdatePlatformConfig={handleUpdatePlatformConfig}
              onUpdateMatchStatus={handleUpdateMatchStatus}
              visitorLogs={visitorLogs}
              teams={teams}
              onDeleteTeamByAdmin={handleDeleteTeamByAdmin}
              onToggleLockTeamChatByAdmin={handleToggleLockTeamChatByAdmin}
              onBanPlayerFromTeamByAdmin={handleBanPlayerFromTeamByAdmin}
            />
          ) : currentUser.role === 'owner' ? (
            <PitchOwnerPortal
              currentUser={currentUser}
              pitches={pitches}
              pitchRequests={pitchRequests}
              onSubmitPitchRequest={handleSubmitPitchRequest}
              onSendNegotiationMessage={handleSendNegotiationMessage}
            />
          ) : activeNavTab === 'teams' ? (
            /* Teams & Clubs Section View */
            <div className="flex-1 overflow-y-auto p-3 sm:p-4">
              <TeamsClubsSection
                currentUser={currentUser}
                teams={teams}
                onCreateTeam={handleCreateTeam}
                onJoinRequest={handleJoinTeamRequest}
                onHandleJoinRequest={handleHandleTeamJoinRequest}
                onSendChatMessage={handleSendTeamChatMessage}
                onToggleMemberPermission={handleToggleTeamMemberPermission}
                onRequireRealAccount={(msg) => {
                  setIsAuthOpen(true);
                }}
                showToast={(msg) => {
                  // Notification handled inside component & console
                  console.log('Toast:', msg);
                }}
              />
            </div>
          ) : (
            /* Standard User / Player 3-Column Home Layout */
            <ThreeColumnsHome
              selectedSport={selectedSport}
              onOpenMatchmaking={() => setIsMatchmakingOpen(true)}
              onOpenCreateMatch={() => setIsCreateMatchOpen(true)}
              onOpenTournaments={() => setIsTournamentsOpen(true)}
              openMatchesCount={openMatches.filter((m) => m.sport === selectedSport).length}
              tournamentsCount={tournaments.filter((t) => t.sport === selectedSport).length}
              openMatches={openMatches}
              tournaments={tournaments}
              pitches={pitches}
              onJoinMatch={handleJoinMatch}
              isDarkMode={isDarkMode}
              announcementBanner={platformConfig.announcementBanner}
            />
          )}

          {/* Bottom Mobile Navigation Dock - Dynamic Sport Theme */}
          {currentUser.role === 'user' && (() => {
            return (
              <nav className={`p-2 grid grid-cols-5 gap-0.5 shrink-0 z-50 backdrop-blur-md border-t-2 ${currentSportTheme.navBorder} ${currentSportTheme.navBg} text-white shadow-2xl shadow-black relative transition-colors duration-500`}>
                {/* Tab 1: الرئيسية */}
                <button
                  onClick={() => {
                    setActiveNavTab('home');
                    setIsMatchmakingOpen(false);
                    setIsCreateMatchOpen(false);
                    setIsTournamentsOpen(false);
                    setIsProfileOpen(false);
                  }}
                  className={`group flex flex-col items-center gap-0.5 py-1.5 px-1 rounded-2xl text-[9px] sm:text-[10px] font-bold transition-all ${
                    activeNavTab === 'home'
                      ? `${currentSportTheme.navActiveBg} ${currentSportTheme.navActiveText}`
                      : 'text-white/40 hover:text-white/80 border border-transparent hover:bg-white/5'
                  }`}
                >
                  <Home className={`w-5 h-5 transition-all ${
                    activeNavTab === 'home'
                      ? `${currentSportTheme.navActiveText} scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]`
                      : 'text-white/40 group-hover:text-white/80'
                  }`} />
                  <span className={activeNavTab === 'home' ? `font-black ${currentSportTheme.navActiveText}` : 'font-bold'}>الرئيسية</span>
                </button>

                {/* Tab 2: إيجاد لعبة */}
                <button
                  onClick={() => {
                    setActiveNavTab('search');
                    setIsCreateMatchOpen(false);
                    setIsTournamentsOpen(false);
                    setIsProfileOpen(false);
                    setIsMatchmakingOpen(true);
                  }}
                  className={`group flex flex-col items-center gap-0.5 py-1.5 px-1 rounded-2xl text-[9px] sm:text-[10px] font-bold transition-all ${
                    activeNavTab === 'search'
                      ? `${currentSportTheme.navActiveBg} ${currentSportTheme.navActiveText}`
                      : 'text-white/40 hover:text-white/80 border border-transparent hover:bg-white/5'
                  }`}
                >
                  <Search className={`w-5 h-5 transition-all ${
                    activeNavTab === 'search'
                      ? `${currentSportTheme.navActiveText} scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]`
                      : 'text-white/40 group-hover:text-white/80'
                  }`} />
                  <span className={activeNavTab === 'search' ? `font-black ${currentSportTheme.navActiveText}` : 'font-bold'}>إيجاد لعبة</span>
                </button>

                {/* Tab 3: إضافة / إنشاء */}
                <button
                  onClick={() => {
                    setActiveNavTab('create');
                    setIsMatchmakingOpen(false);
                    setIsTournamentsOpen(false);
                    setIsProfileOpen(false);
                    setIsCreateMatchOpen(true);
                  }}
                  className={`group flex flex-col items-center gap-0.5 py-1.5 px-1 rounded-2xl text-[9px] sm:text-[10px] font-bold transition-all ${
                    activeNavTab === 'create'
                      ? `${currentSportTheme.navActiveBg} ${currentSportTheme.navActiveText}`
                      : 'text-white/40 hover:text-white/80 border border-transparent hover:bg-white/5'
                  }`}
                >
                  <PlusCircle className={`w-5 h-5 transition-all ${
                    activeNavTab === 'create'
                      ? `${currentSportTheme.navActiveText} scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]`
                      : 'text-white/40 group-hover:text-white/80'
                  }`} />
                  <span className={activeNavTab === 'create' ? `font-black ${currentSportTheme.navActiveText}` : 'font-bold'}>إنشاء حجز</span>
                </button>

                {/* Tab 4: الفرق والنادي */}
                <button
                  onClick={() => {
                    setActiveNavTab('teams');
                    setIsMatchmakingOpen(false);
                    setIsCreateMatchOpen(false);
                    setIsTournamentsOpen(false);
                    setIsProfileOpen(false);
                  }}
                  className={`group flex flex-col items-center gap-0.5 py-1.5 px-1 rounded-2xl text-[9px] sm:text-[10px] font-bold transition-all ${
                    activeNavTab === 'teams'
                      ? `${currentSportTheme.navActiveBg} ${currentSportTheme.navActiveText}`
                      : 'text-white/40 hover:text-white/80 border border-transparent hover:bg-white/5'
                  }`}
                >
                  <Shield className={`w-5 h-5 transition-all ${
                    activeNavTab === 'teams'
                      ? `${currentSportTheme.navActiveText} scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]`
                      : 'text-white/40 group-hover:text-white/80'
                  }`} />
                  <span className={activeNavTab === 'teams' ? `font-black ${currentSportTheme.navActiveText}` : 'font-bold'}>الفرق والنادي</span>
                </button>

                {/* Tab 5: البطولات */}
                <button
                  onClick={() => {
                    setActiveNavTab('tournaments');
                    setIsMatchmakingOpen(false);
                    setIsCreateMatchOpen(false);
                    setIsProfileOpen(false);
                    setIsTournamentsOpen(true);
                  }}
                  className={`group flex flex-col items-center gap-0.5 py-1.5 px-1 rounded-2xl text-[9px] sm:text-[10px] font-bold transition-all ${
                    activeNavTab === 'tournaments'
                      ? `${currentSportTheme.navActiveBg} ${currentSportTheme.navActiveText}`
                      : 'text-white/40 hover:text-white/80 border border-transparent hover:bg-white/5'
                  }`}
                >
                  <Trophy className={`w-5 h-5 transition-all ${
                    activeNavTab === 'tournaments'
                      ? `${currentSportTheme.navActiveText} scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]`
                      : 'text-white/40 group-hover:text-white/80'
                  }`} />
                  <span className={activeNavTab === 'tournaments' ? `font-black ${currentSportTheme.navActiveText}` : 'font-bold'}>البطولات</span>
                </button>
              </nav>
            );
          })()}

          {/* Column 1 Modal: Matchmaking Open Matches */}
          <MatchmakingModal
            isOpen={isMatchmakingOpen}
            onClose={() => setIsMatchmakingOpen(false)}
            matches={openMatches}
            selectedSport={selectedSport}
            currentUser={currentUser}
            onJoinMatch={handleJoinMatch}
          />

          {/* Column 2 Modal: Create Match & Pitch Booking Wizard */}
          <CreateMatchModal
            isOpen={isCreateMatchOpen}
            onClose={() => setIsCreateMatchOpen(false)}
            pitches={pitches}
            selectedSport={selectedSport}
            currentUser={currentUser}
            onCreateMatch={handleCreateMatch}
          />

          {/* Column 3 Modal: Tournaments */}
          <TournamentsModal
            isOpen={isTournamentsOpen}
            onClose={() => setIsTournamentsOpen(false)}
            tournaments={tournaments}
            selectedSport={selectedSport}
            currentUser={currentUser}
            onRegisterTeam={handleRegisterTeam}
          />

          {/* Role Selection & Auth Modal */}
          <AuthModal
            isOpen={isAuthOpen}
            onClose={() => setIsAuthOpen(false)}
            onSelectRole={handleSelectRole}
            currentAdminPassword={adminPassword}
            adminUsername={adminUsername}
            usersList={usersList}
            staffMembers={staffMembers}
            onResetPassword={handleResetUserPassword}
          />

          {/* Gamification Level Breakdown Modal */}
          <GamificationWidget
            isOpen={activeViewMode === 'gamification_details'}
            onClose={() => setActiveViewMode('app')}
            currentUser={currentUser}
            onGainXp={handleGainXp}
          />

          {/* User Profile & Player Stats Modal */}
          <UserProfileModal
            isOpen={isProfileOpen}
            onClose={() => setIsProfileOpen(false)}
            user={currentUser}
            onUpdateUser={handleUpdateUser}
            isDarkMode={isDarkMode}
          />

          {/* Support & Admin / Pitch Contact Modal */}
          <SupportContactModal
            isOpen={isSupportOpen}
            onClose={() => setIsSupportOpen(false)}
            isDarkMode={isDarkMode}
            currentUser={currentUser}
            platformConfig={platformConfig}
            onCreateSupportTicket={handleCreateSupportTicket}
          />

          {/* Payment Gateway Modal (eFAWATEERcom, CliQ, Zain Cash, Credit Card) */}
          <PaymentGatewayModal
            isOpen={isPaymentOpen}
            onClose={() => setIsPaymentOpen(false)}
            amountJOD={paymentAmount}
            itemTitle={paymentItemTitle}
            onPaymentSuccess={(txId) => {
              setCurrentUser(prev => ({
                ...prev,
                walletBalance: (prev.walletBalance || 0) + paymentAmount,
              }));
            }}
            isDarkMode={isDarkMode}
          />

          {/* Player Rating Modal */}
          <PlayerRatingModal
            isOpen={isRatingOpen}
            onClose={() => setIsRatingOpen(false)}
            currentUser={currentUser}
            usersList={usersList}
            onAddRating={handleAddRating}
            ratingsList={ratingsList}
            isDarkMode={isDarkMode}
          />
        </div>
      )}
    </DeviceFrame>
  );
}
