export type Role = 'user' | 'owner' | 'admin';

export type SportType = 'football' | 'padel' | 'basketball' | 'volleyball';

export type StaffPermission =
  | 'manage_requests'
  | 'manage_users'
  | 'manage_pitches'
  | 'manage_tournaments'
  | 'manage_payments'
  | 'manage_support';

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: Role;
  avatar: string;
  city: 'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش';
  level: number;
  xp: number;
  maxXp: number;
  rankTitle: string;
  matchesPlayed: number;
  matchesWon: number;
  tournamentsPlayed?: number;
  tournamentsWon?: number;
  goalsScored?: number;
  assistsCount?: number;
  cleanSheets?: number;
  preferredPosition?: string;
  positionsPlayed?: { position: string; matches: number }[];
  unlockedBadges?: string[];
  isVip?: boolean;
  isBanned?: boolean;
  isStaff?: boolean;
  jobTitle?: string;
  workHours?: string;
  staffRating?: number;
  staffPermissions?: StaffPermission[];
  staffActivityLogs?: StaffActivityLog[];
  accountType?: 'player' | 'owner' | 'guest';
  isGuest?: boolean;
  password?: string;
  walletBalance?: number;
}

export interface VisitorLog {
  id: string;
  visitorName: string;
  enteredAt: string;
  actionsAttemptedCount: number;
}

export interface TeamChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  message: string;
  timestamp: string;
  isSystem?: boolean;
}

export interface TeamMember {
  id: string;
  userId: string;
  name: string;
  avatar?: string;
  role: 'founder' | 'coach' | 'admin' | 'player' | 'member';
  position?: string;
  joinedAt: string;
  canApproveRequests?: boolean;
  canManageJoinRequests?: boolean;
}

export interface TeamJoinRequest {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userLevel?: number;
  position?: string;
  message?: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
}

export interface Team {
  id: string;
  name: string;
  logo: string;
  type: 'team' | 'club';
  sport: SportType;
  city: string;
  description: string;
  founderId: string;
  founderName: string;
  members: TeamMember[];
  pendingRequests: {
    id: string;
    userId: string;
    userName: string;
    position: string;
    userAvatar?: string;
    requestedAt: string;
  }[];
  joinRequests?: TeamJoinRequest[];
  chatMessages: TeamChatMessage[];
  isChatLocked?: boolean;
  bannedUserIds?: string[];
  winsCount?: number;
  matchesPlayed?: number;
  trophiesCount?: number;
  createdAt: string;
}

export interface StaffActivityLog {
  id: string;
  staffId: string;
  staffName: string;
  actionType: 'تفاوض ملعب' | 'موافقة طلب' | 'تعديل سعر' | 'رد دعم فني' | 'حظر/تفعيل' | 'إنشاء بطولة' | 'تعديل لاعب';
  description: string;
  timestamp: string;
}

export interface StaffMember {
  id: string;
  name: string;
  username: string; // phone or email
  password: string;
  jobTitle?: string; // التسمية الوظيفية
  permissions: StaffPermission[];
  workHours?: string; // ساعات العمل
  rating?: number; // تقييم الموظف (1-5)
  tasksCompletedCount?: number;
  achievementsCount?: number;
  activityLogs?: StaffActivityLog[];
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  userEmail: string;
  subject: string;
  message: string;
  category?: 'حجز' | 'شحن رصيد' | 'شكوى ملعب' | 'استفسار عام' | 'أخرى';
  status: 'open' | 'replied' | 'closed';
  reply?: string;
  createdAt: string;
  repliedAt?: string;
}

export interface PaymentGatewayConfig {
  cliqAlias: string;
  cliqEnabled: boolean;
  bankIban: string;
  bankIbanEnabled: boolean;
  zainCashPhone: string;
  zainCashEnabled: boolean;
  orangeMoneyPhone: string;
  orangeMoneyEnabled: boolean;
  efawateerCode: string;
  efawateerEnabled: boolean;
  cardEnabled: boolean;
  cashEnabled: boolean;
  commissionRate: number;
  defaultMatchFee: number;
  taxPercent: number;
}

export interface AppPlatformConfig {
  appName: string;
  appDescription: string;
  supportPhone: string;
  supportWhatsapp: string;
  supportEmail: string;
  headquartersAddress: string;
  workingHours: string;
  announcementBanner: string;
  termsAndConditions: string;
  privacyPolicy: string;
  facebookUrl?: string;
  instagramUrl?: string;
  tiktokUrl?: string;
  enableGuestBooking: boolean;
  maintenanceMode: boolean;
}

export const INITIAL_PLATFORM_CONFIG: AppPlatformConfig = {
  appName: 'ملعبك - منصة حجز الملاعب والرياضة والتكميلات الأردنية',
  appDescription: 'المنصة الأولى والأشمل لحجز ملاعب الخماسي، البادل، والسلة، وتنظيم المباريات والبطولات في جميع محافظات المملكة الأردنية الهاشمية 🇯🇴',
  supportPhone: '+962 6 500 0000',
  supportWhatsapp: '+962 7 9123 4567',
  supportEmail: 'support@malaebak.jo',
  headquartersAddress: 'عمان - شارع المدينة المنورة - مجمع الملاعب الرياضية - الطابق 3',
  workingHours: 'يومياً من 8:00 صباحاً حتى 2:00 بعد منتصف الليل',
  announcementBanner: '⚽ شبكة ملاعب الأردن المباشرة 🇯🇴 - حجز ومباريات فورية مفعلة الآن',
  termsAndConditions: 'تلتزم كافة الأطراف بالحجز الإلكتروني المسبق، الحضور قبل 15 دقيقة من موعد المباراة، والمحافظة على النظافة العامة ومرافق الملعب. في حال الإلغاء قبل 24 ساعة يتم استرجاع المبلغ بالكامل.',
  privacyPolicy: 'تضمن منصة "ملعبك" سرية كامل بيانات المستخدمين ورقم الهاتف ولا يتم مشاركتها مع أي طرف ثالث خارج إطار تأكيد الحجز.',
  facebookUrl: 'https://facebook.com/malaebak.jo',
  instagramUrl: 'https://instagram.com/malaebak.jo',
  tiktokUrl: 'https://tiktok.com/@malaebak.jo',
  enableGuestBooking: true,
  maintenanceMode: false,
};

export interface Pitch {
  id: string;
  name: string;
  city: 'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش';
  district: string;
  sports: SportType[];
  surfaceType: 'حشيش صناعي ممتاز' | 'حشيش طبيعي' | 'بادل زجاجي فاخر' | 'أرضية مطاطية' | 'خشب باركيه';
  hourlyRate: number; // in JOD (الدينار الأردني)
  image: string;
  ownerId: string;
  ownerName: string;
  rating: number;
  reviewsCount: number;
  amenities: string[];
  isAvailable: boolean;
  isBanned?: boolean;
  activeOffer?: {
    title: string;
    discountPercent: number;
    validUntil: string;
  };
}

export interface OpenMatch {
  id: string;
  title: string;
  sport: SportType;
  pitchId: string;
  pitchName: string;
  city: string;
  district: string;
  date: string;
  timeSlot: string;
  totalPlayersNeeded: number;
  joinedPlayersCount: number;
  missingPositions: string[];
  costPerPlayer: number; // JOD
  totalCost: number; // JOD
  organizerName: string;
  organizerAvatar: string;
  organizerLevel: number;
  refereeRequested: boolean;
  videoRequested: boolean;
  splitBillEnabled: boolean;
  status: 'open' | 'full' | 'completed' | 'cancelled';
  joinedPlayers: {
    id: string;
    name: string;
    avatar: string;
    level: number;
    position: string;
    paid: boolean;
  }[];
}

export interface Tournament {
  id: string;
  title: string;
  sport: SportType;
  city: string;
  pitchName: string;
  startDate: string;
  endDate: string;
  teamsCount: number;
  maxTeams: number;
  entryFeePerTeam: number; // JOD
  firstPrize: number; // JOD
  secondPrize: number; // JOD
  trophyTitle: string;
  status: 'upcoming' | 'ongoing' | 'finished';
  bannerImage: string;
  brackets?: {
    roundName: string; // 'ربع النهائي' | 'نصف النهائي' | 'النهائي'
    matches: {
      id: string;
      teamA: string;
      teamB: string;
      scoreA?: number;
      scoreB?: number;
      winner?: string;
      isLive?: boolean;
    }[];
  }[];
}

export interface NegotiationMessage {
  id: string;
  sender: 'admin' | 'owner';
  senderName: string;
  message: string;
  proposedRate?: number;
  proposedCommission?: number;
  proposedTerms?: string;
  createdAt: string;
}

export interface PitchRequest {
  id: string;
  ownerName: string;
  ownerEmail: string;
  ownerPhone: string;
  pitchName: string;
  city: 'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش';
  district: string;
  sports: SportType[];
  surfaceType: string;
  hourlyRate: number;
  negotiatedRate?: number;
  negotiatedCommission?: number;
  negotiatedTerms?: string;
  amenities: string[];
  image: string;
  status: 'pending' | 'negotiating' | 'approved' | 'rejected';
  createdAt: string;
  notes?: string;
  negotiationHistory?: NegotiationMessage[];
}

export interface LevelInfo {
  levelRange: string;
  title: string;
  badge: string;
  color: string;
  benefits: string[];
  refereeUnlocked: boolean;
  videoUnlocked: boolean;
}
