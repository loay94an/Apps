import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User } from '../types';
import {
  User as UserIcon,
  X,
  Edit3,
  Check,
  Trophy,
  Award,
  Shield,
  Target,
  Flame,
  Phone,
  MapPin,
  Sparkles,
  Zap,
  Activity,
  Star,
  CheckCircle2,
  Lock,
  PieChart,
  Clock,
  Briefcase,
  Upload,
  CheckCircle,
  FileText,
  TrendingUp,
  BarChart3,
  Key
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onUpdateUser: (updatedData: Partial<User>) => void;
  onAdminPasswordChanged?: (newPass: string) => void;
  isDarkMode: boolean;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
];

const POSITIONS = ['حارس مرمى', 'مدافع قلب', 'ظهير أيمن', 'ظهير أيسر', 'وسط دفاعي', 'صانع ألعاب', 'جناح', 'مهاجم صريح'];

export const UserProfileModal: React.FC<Props> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onAdminPasswordChanged,
  isDarkMode,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone);
  const [city, setCity] = useState(user.city);
  const [preferredPosition, setPreferredPosition] = useState(user.preferredPosition || 'مهاجم صريح');
  const [selectedAvatar, setSelectedAvatar] = useState(user.avatar);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // Default Stats if missing
  const matchesPlayed = user.matchesPlayed || 0;
  const matchesWon = user.matchesWon || 0;
  const tournamentsPlayed = user.tournamentsPlayed || 0;
  const tournamentsWon = user.tournamentsWon || 0;
  const goalsScored = user.goalsScored || 0;
  const assistsCount = user.assistsCount || 0;
  const winRate = matchesPlayed > 0 ? Math.round((matchesWon / matchesPlayed) * 100) : 0;

  // Default Staff Details
  const isAdminOrStaff = user.role === 'admin' || user.isStaff;
  const jobTitle = user.jobTitle || (user.role === 'admin' ? (user.isStaff ? 'مساعد مدير النظام' : 'مدير النظام الأساسي 🛡️') : 'لاعب/عميل');
  const workHours = user.workHours || '08:00 صباحاً - 04:00 مساءً (الدوام الرسمي)';
  const staffRating = user.staffRating || 5.0;
  const permissionsList = user.staffPermissions || [
    'manage_requests',
    'manage_users',
    'manage_pitches',
    'manage_tournaments',
    'manage_payments',
    'manage_support',
  ];

  // Default Staff Achievements Log
  const staffActivityLogs = user.staffActivityLogs || [];

  // Positions Played Histogram
  const positionsPlayed = user.positionsPlayed || [];
  const totalPosMatches = positionsPlayed.reduce((acc, curr) => acc + curr.matches, 0);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setSelectedAvatar(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyCustomUrl = () => {
    if (customAvatarUrl.trim()) {
      setSelectedAvatar(customAvatarUrl.trim());
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      name,
      phone,
      city,
      preferredPosition,
      avatar: selectedAvatar,
      password: newPassword ? newPassword : user.password,
    });

    if (newPassword && onAdminPasswordChanged) {
      onAdminPasswordChanged(newPassword);
    }

    setIsEditing(false);
    setSaveSuccessMessage('تم حفظ وتحديث بيانات الملف الشخصي بنجاح! ✅');
    setTimeout(() => setSaveSuccessMessage(null), 3000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-40 pb-16 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md overflow-y-auto">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className={`relative w-full max-w-lg rounded-3xl p-5 shadow-2xl space-y-4 my-auto border max-h-[92vh] flex flex-col ${
              isDarkMode
                ? 'bg-[#1E293B] border-emerald-500/40 text-white'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className={`absolute top-4 left-4 p-2 rounded-full transition-colors z-10 ${
                isDarkMode ? 'bg-slate-800 text-slate-400 hover:text-white' : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Profile Header Banner */}
            <div className="flex items-center gap-3 shrink-0 pt-1">
              <div className="relative shrink-0">
                <img
                  src={selectedAvatar}
                  alt={user.name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-[#39FF14] ring-2 ring-emerald-500/30 p-0.5 shadow-lg"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -bottom-1 -right-1 bg-[#39FF14] text-[#0F172A] text-xs font-black px-2 py-0.5 rounded-full shadow-md dir-ltr">
                  {isAdminOrStaff ? 'ADMIN' : `L${user.level}`}
                </span>
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black truncate">{user.name}</h2>
                  <span className="bg-[#39FF14] text-[#0F172A] text-[10px] font-black px-2 py-0.5 rounded shadow-sm shrink-0">
                    {user.rankTitle}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    {user.city}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1 dir-ltr">
                    <Phone className="w-3.5 h-3.5 text-emerald-400" />
                    {user.phone}
                  </span>
                </div>

                {isAdminOrStaff ? (
                  <div className="mt-1 flex items-center gap-1.5 text-[11px] font-bold text-amber-400">
                    <Briefcase className="w-3.5 h-3.5 text-amber-400" />
                    <span>التسمية الوظيفية: {jobTitle}</span>
                  </div>
                ) : (
                  <div className="mt-1 flex items-center gap-1.5 text-[11px] font-bold text-emerald-400">
                    <Shield className="w-3.5 h-3.5" />
                    <span>المركز المفضل: {user.preferredPosition || 'مهاجم'}</span>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={() => setIsEditing(!isEditing)}
                className={`p-2 rounded-2xl border text-xs font-bold transition-all flex items-center gap-1 shrink-0 ${
                  isEditing
                    ? 'bg-amber-500 text-slate-950 border-amber-400'
                    : isDarkMode
                    ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                <Edit3 className="w-4 h-4" />
                <span>{isEditing ? 'إلغاء' : 'تعديل البيانات'}</span>
              </button>
            </div>

            {saveSuccessMessage && (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500 text-xs text-emerald-400 font-bold text-center animate-fade-in">
                {saveSuccessMessage}
              </div>
            )}

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {/* EDIT MODE FORM */}
              {isEditing ? (
                <form onSubmit={handleSave} className="space-y-3.5 p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs">
                  <h3 className="font-extrabold text-amber-400 flex items-center gap-1.5 text-sm">
                    <Edit3 className="w-4 h-4" />
                    تحديث الملف الشخصي والصورة وكلمة المرور:
                  </h3>

                  {/* Avatar Picker & File Upload */}
                  <div className="space-y-2">
                    <label className="text-slate-300 font-bold block">تغيير الصورة الشخصية:</label>
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {AVATAR_PRESETS.map((avUrl, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setSelectedAvatar(avUrl)}
                          className={`w-11 h-11 rounded-full overflow-hidden border-2 shrink-0 transition-all ${
                            selectedAvatar === avUrl ? 'border-[#39FF14] ring-2 ring-[#39FF14]/50 scale-105' : 'border-slate-700 opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={avUrl} alt="Preset avatar" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>

                    {/* Upload File / Custom URL Input */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <label className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 hover:border-[#39FF14] cursor-pointer flex items-center justify-center gap-2 text-slate-300 font-bold text-[11px]">
                        <Upload className="w-4 h-4 text-[#39FF14]" />
                        <span>رفع صورة من الجهاز 📁</span>
                        <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                      </label>

                      <div className="flex gap-1">
                        <input
                          type="url"
                          placeholder="أو رابط صورة مباشرة..."
                          value={customAvatarUrl}
                          onChange={(e) => setCustomAvatarUrl(e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-[10px]"
                        />
                        <button
                          type="button"
                          onClick={handleApplyCustomUrl}
                          className="px-3 py-1.5 bg-[#39FF14] text-slate-950 font-black rounded-xl text-[10px] shrink-0"
                        >
                          تطبيق
                        </button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1">الاسم الكامل:</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">اسم المستخدم / رقم الهاتف للدخول:</label>
                      <input
                        type="text"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        required
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono dir-ltr text-right"
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">المدينة:</label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value as any)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                      >
                        <option value="عمان">عمان</option>
                        <option value="الزرقاء">الزرقاء</option>
                        <option value="إربد">إربد</option>
                        <option value="العقبة">العقبة</option>
                        <option value="السلط">السلط</option>
                        <option value="جرش">جرش</option>
                      </select>
                    </div>
                  </div>

                  {/* Password Reset Field */}
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1.5">
                    <label className="text-amber-400 font-bold flex items-center gap-1 text-[11px]">
                      <Key className="w-3.5 h-3.5" />
                      تحديث كلمة مرور الحساب (اختياري):
                    </label>
                    <input
                      type="password"
                      placeholder="أدخل كلمة مرور جديدة لو أردت التغيير..."
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-[#39FF14] text-slate-950 font-black text-xs hover:bg-[#32e012] shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    حفظ البيانات
                  </button>
                </form>
              ) : null}

              {/* IF ADMIN OR STAFF: DISPLAY JOB TITLE, PERMISSIONS, WORK HOURS, ACHIEVEMENTS, LOGS & STATS */}
              {isAdminOrStaff ? (
                <div className="space-y-3">
                  {/* Job Title & Shift Hours Card */}
                  <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-amber-500/40 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-amber-400 flex items-center gap-1.5 text-xs">
                        <Briefcase className="w-4 h-4" />
                        التفاصيل الوظيفية والدوام:
                      </span>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                        تقييم الأداء: ⭐ {staffRating} / 5
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                      <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700">
                        <span className="text-slate-400 text-[10px] block">المسمى الوظيفي:</span>
                        <span className="font-extrabold text-white text-xs">{jobTitle}</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700">
                        <span className="text-slate-400 text-[10px] block">ساعات العمل ودوام الموظف:</span>
                        <span className="font-bold text-[#39FF14] text-xs flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {workHours}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Permissions Granted */}
                  <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                    <span className="font-extrabold text-slate-200 flex items-center gap-1.5">
                      <Shield className="w-4 h-4 text-emerald-400" />
                      الصلاحيات والمهام الممنوحة للموظف:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {permissionsList.map((perm) => {
                        const labelMap: Record<string, string> = {
                          manage_requests: 'إدارة وتفاوض الملاعب',
                          manage_users: 'إدارة المستخدمين والحظر',
                          manage_pitches: 'تعديل أسعار الملاعب',
                          manage_tournaments: 'إنشاء وإدارة البطولات',
                          manage_payments: 'إدارة الطرق والعمولات',
                          manage_support: 'ردود رسائل الدعم الفني',
                        };
                        return (
                          <span key={perm} className="px-2.5 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-bold text-[10px] flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-[#39FF14]" />
                            {labelMap[perm] || perm}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  {/* Staff Performance Statistics */}
                  <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                    <span className="font-extrabold text-white flex items-center gap-1.5">
                      <BarChart3 className="w-4 h-4 text-cyan-400" />
                      إحصائيات إنجاز الموظف داخل المنصة:
                    </span>

                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-center">
                        <span className="text-[10px] text-slate-400 block">المهام المكتملة</span>
                        <span className="text-base font-black text-white">48 عملية</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-center">
                        <span className="text-[10px] text-slate-400 block">سرعة معالجة الطلب</span>
                        <span className="text-base font-black text-[#39FF14]">3.2 دقيقة</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-center">
                        <span className="text-[10px] text-slate-400 block">رضا العملاء والملاعب</span>
                        <span className="text-base font-black text-amber-400">98%</span>
                      </div>
                    </div>
                  </div>

                  {/* Achievements & Activity History Log */}
                  <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold text-white flex items-center gap-1.5">
                        <Activity className="w-4 h-4 text-[#39FF14]" />
                        سجل الأعمال والإنجازات المنجزة ونوعها:
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">({staffActivityLogs.length} إنجازات)</span>
                    </div>

                    <div className="space-y-2">
                      {staffActivityLogs.map((log) => (
                        <div key={log.id} className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded text-[9px] font-black bg-amber-500/20 border border-amber-500/40 text-amber-300">
                                [{log.actionType}]
                              </span>
                              <span className="font-bold text-slate-200 text-[11px]">{log.description}</span>
                            </div>
                          </div>
                          <span className="text-[9px] text-slate-500 font-mono shrink-0">{log.timestamp}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* REGULAR PLAYER STATS OVERVIEW CARDS */
                <div className="space-y-3">
                  <div className="space-y-2">
                    <h3 className="font-extrabold text-xs text-slate-400 uppercase tracking-wider flex items-center gap-1">
                      <Activity className="w-3.5 h-3.5 text-emerald-400" />
                      سجل وإحصائيات اللاعب النشمي:
                    </h3>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
                        <span className="text-[10px] text-slate-400 font-bold block">المباريات الخوضة</span>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xl font-black text-white">{matchesPlayed}</span>
                          <span className="text-[10px] text-emerald-400 font-mono">مباراة</span>
                        </div>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
                        <span className="text-[10px] text-slate-400 font-bold block">انتصارات ونسبة الفوز</span>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xl font-black text-[#39FF14]">{matchesWon}</span>
                          <span className="text-xs font-extrabold text-emerald-400 bg-emerald-500/20 px-1.5 py-0.5 rounded dir-ltr">
                            {winRate}%
                          </span>
                        </div>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
                        <span className="text-[10px] text-slate-400 font-bold block">عدد البطولات</span>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xl font-black text-amber-400">{tournamentsPlayed}</span>
                          <span className="text-[10px] text-amber-300 font-bold">🏆 {tournamentsWon} فوز</span>
                        </div>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
                        <span className="text-[10px] text-slate-400 font-bold block">الأهداف والتمريرات</span>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-xl font-black text-cyan-400">{goalsScored}</span>
                          <span className="text-[10px] text-cyan-300 font-mono">⚽ / {assistsCount} أسيست</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* POSITIONS PLAYED HISTOGRAM */}
                  <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-white flex items-center gap-1.5">
                        <PieChart className="w-4 h-4 text-[#39FF14]" />
                        المراكز التي لعب بها بالمباريات السابقة:
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">إجمالي {totalPosMatches} مباراة</span>
                    </div>

                    <div className="space-y-2">
                      {positionsPlayed.map((posItem, i) => {
                        const percentage = Math.round((posItem.matches / Math.max(1, totalPosMatches)) * 100);
                        return (
                          <div key={i} className="space-y-1">
                            <div className="flex justify-between text-[11px] font-bold">
                              <span className="text-slate-200">{posItem.position}</span>
                              <span className="text-emerald-400 font-mono">{posItem.matches} مباراة ({percentage}%)</span>
                            </div>
                            <div className="h-2 rounded-full bg-slate-800 overflow-hidden border border-slate-700/50">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-[#39FF14]"
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
