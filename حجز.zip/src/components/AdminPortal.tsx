import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  PitchRequest,
  User,
  Pitch,
  Tournament,
  SupportTicket,
  StaffMember,
  PaymentGatewayConfig,
  StaffPermission,
  SportType,
  OpenMatch,
  VisitorLog,
  Team,
  AppPlatformConfig,
  INITIAL_PLATFORM_CONFIG,
} from '../types';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Users,
  Store,
  DollarSign,
  Key,
  AlertTriangle,
  CreditCard,
  Ban,
  Edit3,
  Sliders,
  Sparkles,
  PlusCircle,
  Trophy,
  MessageSquare,
  UserPlus,
  Trash2,
  Send,
  Shield,
  Search,
  Building2,
  Calendar,
  Clock,
  Star,
  Activity,
  X,
  Filter,
  Check,
  Zap,
  TrendingUp,
  FileCheck,
  RefreshCw,
  BarChart3,
  PieChart as PieChartIcon,
  ArrowUpRight,
  Download,
  UserCheck,
  Award,
  Lock,
  Eye,
  CheckSquare,
  Square,
  ChevronRight,
  UserCog,
  Briefcase,
  Layers,
  EyeOff,
  User as UserIcon,
  Mail,
  Phone,
  Upload,
} from 'lucide-react';

interface Props {
  currentUser: User;
  pitchRequests: PitchRequest[];
  pitches: Pitch[];
  usersList: User[];
  tournaments: Tournament[];
  supportTickets: SupportTicket[];
  staffMembers: StaffMember[];
  paymentConfig: PaymentGatewayConfig;
  openMatches?: OpenMatch[];
  visitorLogs?: VisitorLog[];
  teams?: Team[];
  onApprovePitchRequest: (reqId: string, negotiatedDetails?: { rate?: number; commission?: number; terms?: string }) => void;
  onRejectPitchRequest: (reqId: string) => void;
  onSendNegotiationMessage?: (reqId: string, message: string, proposedRate?: number, proposedCommission?: number, proposedTerms?: string) => void;
  onToggleBanUser?: (userId: string) => void;
  onDeleteUser?: (userId: string) => void;
  onUpdateUserByAdmin?: (userId: string, updatedFields: Partial<User>) => void;
  onToggleBanPitch?: (pitchId: string) => void;
  onUpdatePitchByAdmin?: (pitchId: string, updatedFields: Partial<Pitch>) => void;
  onUpdatePitchRate?: (pitchId: string, newRate: number) => void;
  onAdminPasswordChanged?: (newPass: string) => void;
  onUpdateAdminProfile?: (updated: { name?: string; username?: string; password?: string; avatar?: string; email?: string }) => void;
  currentAdminPassword: string;
  currentAdminUsername?: string;
  onCreateTournament?: (newTourney: Omit<Tournament, 'id' | 'teamsCount' | 'brackets'>) => void;
  onDeleteTournament?: (tourneyId: string) => void;
  onReplySupportTicket?: (ticketId: string, reply: string) => void;
  onCreateStaffMember?: (staff: Omit<StaffMember, 'id' | 'createdAt'>) => void;
  onUpdateStaffMember?: (staffId: string, updatedFields: Partial<StaffMember>) => void;
  onDeleteStaffMember?: (staffId: string) => void;
  onUpdatePaymentConfig?: (config: Partial<PaymentGatewayConfig>) => void;
  platformConfig?: AppPlatformConfig;
  onUpdatePlatformConfig?: (updated: Partial<AppPlatformConfig>) => void;
  onUpdateMatchStatus?: (matchId: string, status: 'open' | 'full' | 'completed' | 'cancelled') => void;
  onDeleteTeamByAdmin?: (teamId: string) => void;
  onToggleLockTeamChatByAdmin?: (teamId: string) => void;
  onBanPlayerFromTeamByAdmin?: (teamId: string, userId: string) => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
];

const SUPPORT_QUICK_REPLIES = [
  'أهلاً بك! تم التأكد من تفاصيل طلبك وتحديث حالة الحجز بنجاح.',
  'تم إخطار صاحب الملعب وتأكيد مواعيد التكميلة.',
  'شكرًا للتواصل! تم إضافة المكافأة/الرصيد إلى حسابك مباشرة.',
  'جاري متابعة الاستفسار مع القسم المالي وسيتم تحديث الحالة فوراً.'
];

export const AdminPortal: React.FC<Props> = ({
  currentUser,
  pitchRequests,
  pitches,
  usersList,
  tournaments,
  supportTickets,
  staffMembers,
  paymentConfig,
  openMatches = [],
  visitorLogs = [],
  teams = [],
  onApprovePitchRequest,
  onRejectPitchRequest,
  onSendNegotiationMessage,
  onToggleBanUser,
  onDeleteUser,
  onUpdateUserByAdmin,
  onToggleBanPitch,
  onUpdatePitchByAdmin,
  onAdminPasswordChanged,
  onUpdateAdminProfile,
  currentAdminPassword,
  currentAdminUsername,
  onCreateTournament,
  onDeleteTournament,
  onReplySupportTicket,
  onCreateStaffMember,
  onUpdateStaffMember,
  onDeleteStaffMember,
  onUpdatePaymentConfig,
  platformConfig,
  onUpdatePlatformConfig,
  onUpdateMatchStatus,
  onDeleteTeamByAdmin,
  onToggleLockTeamChatByAdmin,
  onBanPlayerFromTeamByAdmin,
}) => {
  const [adminTab, setAdminTab] = useState<
    'analytics' | 'requests' | 'users' | 'pitches' | 'matches' | 'tournaments' | 'teams' | 'payments' | 'support' | 'staff' | 'settings'
  >('analytics');

  const [analyticsTimeframe, setAnalyticsTimeframe] = useState<'week' | 'month' | 'year'>('week');

  // Notification Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Permissions Check Helper
  const isSuperAdmin = !currentUser.isStaff;
  const hasPermission = (perm: StaffPermission) => {
    if (isSuperAdmin) return true;
    return currentUser.staffPermissions?.includes(perm) ?? false;
  };

  // Super Admin Profile & Credentials Editing State
  const isUsingDefaultPassword = currentAdminPassword === '123123';
  const [adminNameInput, setAdminNameInput] = useState<string>(currentUser.name || 'مدير النظام الأساسي (الإدارة العليا)');
  const [adminUsernameInput, setAdminUsernameInput] = useState<string>(currentAdminUsername || currentUser.phone || '0790000000');
  const [adminPasswordInput, setAdminPasswordInput] = useState<string>(currentAdminPassword || '123123');
  const [adminEmailInput, setAdminEmailInput] = useState<string>(currentUser.email || 'admin@malaebak.jo');
  const [adminAvatarInput, setAdminAvatarInput] = useState<string>(currentUser.avatar || AVATAR_PRESETS[0]);
  const [showAdminPassword, setShowAdminPassword] = useState<boolean>(false);
  const [forceChangePassModalOpen, setForceChangePassModalOpen] = useState<boolean>(false);

  // Platform & Contact Settings State (Fully editable by Super Admin)
  const [settingsSubTab, setSettingsSubTab] = useState<'profile' | 'contacts' | 'branding' | 'system' | 'payments'>('profile');
  const [platformPhoneInput, setPlatformPhoneInput] = useState<string>(platformConfig?.supportPhone || '+962 6 500 0000');
  const [platformWhatsappInput, setPlatformWhatsappInput] = useState<string>(platformConfig?.supportWhatsapp || '+962 7 9123 4567');
  const [platformEmailInput, setPlatformEmailInput] = useState<string>(platformConfig?.supportEmail || 'support@malaebak.jo');
  const [platformAddressInput, setPlatformAddressInput] = useState<string>(platformConfig?.headquartersAddress || 'عمان - شارع المدينة المنورة - مجمع الملاعب الرياضية - الطابق 3');
  const [platformHoursInput, setPlatformHoursInput] = useState<string>(platformConfig?.workingHours || 'يومياً من 8:00 صباحاً حتى 2:00 بعد منتصف الليل');
  const [platformAppNameInput, setPlatformAppNameInput] = useState<string>(platformConfig?.appName || 'ملعبك - منصة حجز الملاعب والرياضة والتكميلات الأردنية');
  const [platformBannerInput, setPlatformBannerInput] = useState<string>(platformConfig?.announcementBanner || '⚽ شبكة ملاعب الأردن المباشرة 🇯🇴 - حجز ومباريات فورية مفعلة الآن');
  const [platformTermsInput, setPlatformTermsInput] = useState<string>(platformConfig?.termsAndConditions || 'تلتزم كافة الأطراف بالحجز الإلكتروني المسبق، الحضور قبل 15 دقيقة من موعد المباراة، والمحافظة على النظافة العامة ومرافق الملعب. في حال الإلغاء قبل 24 ساعة يتم استرجاع المبلغ بالكامل.');
  const [platformPrivacyInput, setPlatformPrivacyInput] = useState<string>(platformConfig?.privacyPolicy || 'تضمن منصة "ملعبك" سرية كامل بيانات المستخدمين ورقم الهاتف ولا يتم مشاركتها مع أي طرف ثالث خارج إطار تأكيد الحجز.');
  const [platformFacebookInput, setPlatformFacebookInput] = useState<string>(platformConfig?.facebookUrl || 'https://facebook.com/malaebak.jo');
  const [platformInstagramInput, setPlatformInstagramInput] = useState<string>(platformConfig?.instagramUrl || 'https://instagram.com/malaebak.jo');
  const [platformTiktokInput, setPlatformTiktokInput] = useState<string>(platformConfig?.tiktokUrl || 'https://tiktok.com/@malaebak.jo');
  const [platformGuestBooking, setPlatformGuestBooking] = useState<boolean>(platformConfig?.enableGuestBooking ?? true);
  const [platformMaintenance, setPlatformMaintenance] = useState<boolean>(platformConfig?.maintenanceMode ?? false);

  // Payment Form State
  const [localPayment, setLocalPayment] = useState<PaymentGatewayConfig>(paymentConfig);

  // Pitch Request Negotiation Modal State
  const [negotiatingReq, setNegotiatingReq] = useState<PitchRequest | null>(null);
  const [negotiationMsg, setNegotiationMsg] = useState('');
  const [negotiatedRateInput, setNegotiatedRateInput] = useState<number>(30);
  const [negotiatedCommInput, setNegotiatedCommInput] = useState<number>(10);
  const [negotiatedTermsInput, setNegotiatedTermsInput] = useState('شروط العقد: حجز إلكتروني مسبق، خصم 10% عمولة التطبيق، إلتزام بنظافة المرافق.');

  // Edit User Modal State
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editUserName, setEditUserName] = useState('');
  const [editUserPhone, setEditUserPhone] = useState('');
  const [editUserCity, setEditUserCity] = useState<'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش'>('عمان');
  const [editUserAvatar, setEditUserAvatar] = useState('');
  const [editUserPos, setEditUserPos] = useState('');

  // Edit Pitch Modal State
  const [editingPitch, setEditingPitch] = useState<Pitch | null>(null);
  const [editPitchName, setEditPitchName] = useState('');
  const [editPitchImage, setEditPitchImage] = useState('');
  const [editPitchRate, setEditPitchRate] = useState<number>(25);
  const [editPitchCity, setEditPitchCity] = useState<'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش'>('عمان');
  const [editPitchDistrict, setEditPitchDistrict] = useState('');

  // Create Tournament Form Modal State
  const [isCreateTourneyOpen, setIsCreateTourneyOpen] = useState(false);
  const [tourneyTitle, setTourneyTitle] = useState('');
  const [tourneySport, setTourneySport] = useState<SportType>('football');
  const [tourneyCity, setTourneyCity] = useState('عمان');
  const [tourneyPitchName, setTourneyPitchName] = useState('ملعب عمان الدولي الخماسي');
  const [tourneyStartDate, setTourneyStartDate] = useState('2026-08-15');
  const [tourneyEndDate, setTourneyEndDate] = useState('2026-08-25');
  const [tourneyMaxTeams, setTourneyMaxTeams] = useState(16);
  const [tourneyEntryFee, setTourneyEntryFee] = useState(50);
  const [tourneyFirstPrize, setTourneyFirstPrize] = useState(500);
  const [tourneySecondPrize, setTourneySecondPrize] = useState(200);
  const [tourneyTrophyTitle, setTourneyTrophyTitle] = useState('كأس الملاعب الخماسية 🏆');
  const [tourneyBanner, setTourneyBanner] = useState('https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800&auto=format&fit=crop&q=80');

  // Create Staff Member Form State
  const [isCreateStaffOpen, setIsCreateStaffOpen] = useState(false);
  const [staffName, setStaffName] = useState('');
  const [staffUsername, setStaffUsername] = useState('');
  const [staffPass, setStaffPass] = useState('');
  const [staffJobTitle, setStaffJobTitle] = useState('مشرف الملاعب والعقود');
  const [staffWorkHours, setStaffWorkHours] = useState('08:00 صباحاً - 04:00 مساءً');
  const [staffPerms, setStaffPerms] = useState<StaffPermission[]>([
    'manage_requests',
    'manage_users',
    'manage_support',
  ]);

  // Edit Staff Member Modal State (Super Admin)
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);

  // Admin Team Chat Inspection Modal State
  const [selectedTeamForAdminChat, setSelectedTeamForAdminChat] = useState<Team | null>(null);
  const [editStaffName, setEditStaffName] = useState('');
  const [editStaffUsername, setEditStaffUsername] = useState('');
  const [editStaffPass, setEditStaffPass] = useState('');
  const [editStaffJobTitle, setEditStaffJobTitle] = useState('');
  const [editStaffWorkHours, setEditStaffWorkHours] = useState('');
  const [editStaffRating, setEditStaffRating] = useState<number>(5.0);
  const [editStaffPerms, setEditStaffPerms] = useState<StaffPermission[]>([]);

  // Detailed Staff Statistics & Profile Modal State
  const [selectedStaffForStats, setSelectedStaffForStats] = useState<StaffMember | null>(null);
  const [newActivityActionType, setNewActivityActionType] = useState<
    'موافقة طلب' | 'رد دعم فني' | 'تفاوض ملعب' | 'تعديل سعر' | 'حظر/تفعيل' | 'إنشاء بطولة' | 'تعديل لاعب'
  >('موافقة طلب');
  const [newActivityDesc, setNewActivityDesc] = useState('');

  // Support Ticket Reply State
  const [replyingTicketId, setReplyingTicketId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  // User Filter State
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'user' | 'owner' | 'staff'>('all');

  // Matches Filter State
  const [matchStatusFilter, setMatchStatusFilter] = useState<'all' | 'open' | 'full' | 'completed' | 'cancelled'>('all');

  // Handlers
  const handleForcePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminPasswordInput || adminPasswordInput.length < 4) {
      alert('يرجى إدخال كلمة مرور جديدة تتكون من 4 خانات على الأقل.');
      return;
    }
    if (onAdminPasswordChanged) {
      onAdminPasswordChanged(adminPasswordInput);
    }
    setForceChangePassModalOpen(false);
    showToast('تم تغيير كلمة مرور الإدارة بنجاح! 🔒');
  };

  const handleSavePaymentSettings = () => {
    if (onUpdatePaymentConfig) {
      onUpdatePaymentConfig(localPayment);
    }
    showToast('تم حفظ جميع إعدادات الدفع والعمولات بنجاح! 💳');
  };

  const handleSendNegotiationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!negotiatingReq) return;

    if (onSendNegotiationMessage) {
      onSendNegotiationMessage(
        negotiatingReq.id,
        negotiationMsg.trim() || 'تم اقتراح شروط وسعر جديد لعقد الملعب.',
        negotiatedRateInput,
        negotiatedCommInput,
        negotiatedTermsInput
      );
    }

    setNegotiationMsg('');
    showToast('تم إرسال رسالة التفاوض بنجاح! 💬');
  };

  const handleApproveWithNegotiation = () => {
    if (!negotiatingReq) return;
    onApprovePitchRequest(negotiatingReq.id, {
      rate: negotiatedRateInput,
      commission: negotiatedCommInput,
      terms: negotiatedTermsInput,
    });
    setNegotiatingReq(null);
    showToast('تم اعتماد وتفعيل الملعب رسمياً بالشروط المتفاوض عليها! 🎉');
  };

  const handleSaveUserEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    if (onUpdateUserByAdmin) {
      onUpdateUserByAdmin(editingUser.id, {
        name: editUserName,
        phone: editUserPhone,
        city: editUserCity,
        avatar: editUserAvatar,
        preferredPosition: editUserPos,
      });
    }
    setEditingUser(null);
    showToast('تم تحديث بيانات اللاعب بنجاح! 👤');
  };

  const handleSavePitchEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPitch) return;
    if (onUpdatePitchByAdmin) {
      onUpdatePitchByAdmin(editingPitch.id, {
        name: editPitchName,
        image: editPitchImage,
        hourlyRate: editPitchRate,
        city: editPitchCity,
        district: editPitchDistrict,
      });
    }
    setEditingPitch(null);
    showToast('تم تحديث بيانات وصورة الملعب بنجاح! 🏟️');
  };

  const handleCreateTournamentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tourneyTitle.trim()) return;

    if (onCreateTournament) {
      onCreateTournament({
        title: tourneyTitle,
        sport: tourneySport,
        city: tourneyCity,
        pitchName: tourneyPitchName,
        startDate: tourneyStartDate,
        endDate: tourneyEndDate,
        maxTeams: Number(tourneyMaxTeams),
        entryFeePerTeam: Number(tourneyEntryFee),
        firstPrize: Number(tourneyFirstPrize),
        secondPrize: Number(tourneySecondPrize),
        trophyTitle: tourneyTrophyTitle,
        bannerImage: tourneyBanner,
        status: 'upcoming',
      });
    }

    setIsCreateTourneyOpen(false);
    setTourneyTitle('');
    showToast('تم نشر البطولة الجديدة بنجاح! 🏆');
  };

  const handleCreateStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName || !staffUsername || !staffPass) {
      alert('يرجى تعبئة كامل بيانات المساعد بشكل صحيح.');
      return;
    }

    if (onCreateStaffMember) {
      onCreateStaffMember({
        name: staffName,
        username: staffUsername,
        password: staffPass,
        jobTitle: staffJobTitle,
        workHours: staffWorkHours,
        permissions: staffPerms,
        rating: 5.0,
        tasksCompletedCount: 0,
        achievementsCount: 0,
        activityLogs: [
          {
            id: `log_${Date.now()}`,
            staffId: `stf_${Date.now()}`,
            staffName,
            actionType: 'موافقة طلب',
            description: 'إنشاء حساب المساعد واعتماد الصلاحيات',
            timestamp: 'الآن',
          }
        ]
      });
    }

    setIsCreateStaffOpen(false);
    setStaffName('');
    setStaffUsername('');
    setStaffPass('');
    showToast('تم إضافة المساعد الجديد وتعيين الصلاحيات! 💼');
  };

  const handleOpenEditStaff = (stf: StaffMember) => {
    setEditingStaff(stf);
    setEditStaffName(stf.name);
    setEditStaffUsername(stf.username);
    setEditStaffPass(stf.password);
    setEditStaffJobTitle(stf.jobTitle || 'مشرف إداري');
    setEditStaffWorkHours(stf.workHours || '08:00 صباحاً - 04:00 مساءً');
    setEditStaffRating(stf.rating || 5.0);
    setEditStaffPerms(stf.permissions || []);
  };

  const handleEditStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStaff) return;

    const updatedFields: Partial<StaffMember> = {
      name: editStaffName,
      username: editStaffUsername,
      password: editStaffPass,
      jobTitle: editStaffJobTitle,
      workHours: editStaffWorkHours,
      rating: editStaffRating,
      permissions: editStaffPerms,
    };

    if (onUpdateStaffMember) {
      onUpdateStaffMember(editingStaff.id, updatedFields);
    }

    if (selectedStaffForStats?.id === editingStaff.id) {
      setSelectedStaffForStats((prev) => (prev ? { ...prev, ...updatedFields } : null));
    }

    setEditingStaff(null);
    showToast(`تم تحديث معلومات وصلاحيات الموظف (${editStaffName}) بنجاح! ⚡`);
  };

  const handleToggleStaffPermInEdit = (perm: StaffPermission) => {
    setEditStaffPerms((prev) =>
      prev.includes(perm) ? prev.filter((p) => p !== perm) : [...prev, perm]
    );
  };

  const handleAddActivityLog = (staffId: string) => {
    if (!newActivityDesc.trim()) return;

    const targetStaff = staffMembers.find((s) => s.id === staffId);
    if (!targetStaff) return;

    const newLog = {
      id: `l_${Date.now()}`,
      staffId: targetStaff.id,
      staffName: targetStaff.name,
      actionType: newActivityActionType,
      description: newActivityDesc,
      timestamp: 'الآن',
    };

    const updatedLogs = [newLog, ...(targetStaff.activityLogs || [])];
    const updatedTasksCount = (targetStaff.tasksCompletedCount || 0) + 1;

    if (onUpdateStaffMember) {
      onUpdateStaffMember(staffId, {
        activityLogs: updatedLogs,
        tasksCompletedCount: updatedTasksCount,
      });
    }

    if (selectedStaffForStats?.id === staffId) {
      setSelectedStaffForStats((prev) =>
        prev
          ? {
              ...prev,
              activityLogs: updatedLogs,
              tasksCompletedCount: updatedTasksCount,
            }
          : null
      );
    }

    setNewActivityDesc('');
    showToast('تم تسجيل الإنجاز والنشاط في سجل الموظف المباشر! 📝');
  };

  const handleTogglePermissionDirectly = (staffId: string, perm: StaffPermission) => {
    const targetStaff = staffMembers.find((s) => s.id === staffId);
    if (!targetStaff) return;

    const currentPerms = targetStaff.permissions || [];
    const newPerms = currentPerms.includes(perm)
      ? currentPerms.filter((p) => p !== perm)
      : [...currentPerms, perm];

    if (onUpdateStaffMember) {
      onUpdateStaffMember(staffId, { permissions: newPerms });
    }

    if (selectedStaffForStats?.id === staffId) {
      setSelectedStaffForStats((prev) => (prev ? { ...prev, permissions: newPerms } : null));
    }

    showToast('تم تعديل صلاحية الموظف بنجاح! 🔑');
  };

  const handleSendReply = (ticketId: string) => {
    if (!replyText.trim()) return;
    if (onReplySupportTicket) {
      onReplySupportTicket(ticketId, replyText);
    }
    setReplyingTicketId(null);
    setReplyText('');
    showToast('تم إرسال رد الدعم الفني للمستخدم! 💬');
  };

  const toggleStaffPerm = (perm: StaffPermission) => {
    if (staffPerms.includes(perm)) {
      setStaffPerms(staffPerms.filter((p) => p !== perm));
    } else {
      setStaffPerms([...staffPerms, perm]);
    }
  };

  const filteredUsers = usersList.filter((u) => {
    const matchesSearch = u.name.includes(userSearchQuery) || u.phone.includes(userSearchQuery);
    if (userRoleFilter === 'owner') return matchesSearch && u.role === 'owner';
    if (userRoleFilter === 'user') return matchesSearch && u.role === 'user' && !u.isStaff;
    if (userRoleFilter === 'staff') return matchesSearch && u.isStaff;
    return matchesSearch;
  });

  const filteredMatches = openMatches.filter((m) => {
    if (matchStatusFilter === 'all') return true;
    return m.status === matchStatusFilter;
  });

  // Recharts Analytics Datasets
  const dailyBookingsData = [
    { day: 'السبت', bookings: 38, revenue: 760, commission: 76, players: 45 },
    { day: 'الأحد', bookings: 42, revenue: 840, commission: 84, players: 52 },
    { day: 'الإثنين', bookings: 29, revenue: 580, commission: 58, players: 38 },
    { day: 'الثلاثاء', bookings: 51, revenue: 1020, commission: 102, players: 68 },
    { day: 'الأربعاء', bookings: 64, revenue: 1280, commission: 128, players: 82 },
    { day: 'الخميس', bookings: 88, revenue: 1760, commission: 176, players: 110 },
    { day: 'الجمعة', bookings: 96, revenue: 1920, commission: 192, players: 135 },
  ];

  const userGrowthData = [
    { month: 'يناير', players: 180, owners: 12, total: 192 },
    { month: 'فبراير', players: 290, owners: 22, total: 312 },
    { month: 'مارس', players: 430, owners: 35, total: 465 },
    { month: 'أبريل', players: 610, owners: 48, total: 658 },
    { month: 'مايو', players: 840, owners: 62, total: 902 },
    { month: 'يونيو', players: 1120, owners: 80, total: 1200 },
    { month: 'يوليو', players: 1480, owners: 98, total: 1578 },
    { month: 'أغسطس', players: 1890, owners: 115, total: 2005 },
  ];

  const sportsDistributionData = [
    { name: 'كرة القدم الخماسية', value: 52, color: '#39FF14' },
    { name: 'الباديل', value: 24, color: '#3B82F6' },
    { name: 'كرة السلة', value: 12, color: '#F59E0B' },
    { name: 'التنس الأرضي', value: 8, color: '#EC4899' },
    { name: 'الكرة الطائرة', value: 4, color: '#8B5CF6' },
  ];

  const cityPerformanceData = [
    { city: 'عمان', bookings: 480, pitches: pitches.filter((p) => p.city === 'عمان').length || 8 },
    { city: 'إربد', bookings: 240, pitches: pitches.filter((p) => p.city === 'إربد').length || 4 },
    { city: 'الزرقاء', bookings: 190, pitches: pitches.filter((p) => p.city === 'الزرقاء').length || 3 },
    { city: 'العقبة', bookings: 150, pitches: pitches.filter((p) => p.city === 'العقبة').length || 2 },
    { city: 'السلط', bookings: 110, pitches: pitches.filter((p) => p.city === 'السلط').length || 2 },
    { city: 'جرش', bookings: 75, pitches: pitches.filter((p) => p.city === 'جرش').length || 1 },
  ];

  const totalCalculatedRevenue = dailyBookingsData.reduce((acc, curr) => acc + curr.revenue, 0);
  const totalCalculatedCommission = dailyBookingsData.reduce((acc, curr) => acc + curr.commission, 0);
  const totalCalculatedBookings = dailyBookingsData.reduce((acc, curr) => acc + curr.bookings, 0);

  // Calculate System KPIs
  const pendingRequestsCount = pitchRequests.filter((r) => r.status === 'pending' || r.status === 'negotiating').length;
  const activePitchesCount = pitches.filter((p) => !p.isBanned).length;
  const totalPlayersCount = usersList.filter((u) => u.role === 'user').length;
  const openSupportTicketsCount = supportTickets.filter((t) => t.status === 'open').length;

  return (
    <div className="flex-1 flex flex-col p-3 sm:p-5 bg-[#0B0F19] overflow-y-auto space-y-4 text-xs font-sans">
      {/* Toast Notification Alert */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-2xl bg-[#39FF14] text-slate-950 font-black shadow-2xl flex items-center gap-2 border border-slate-950/20 animate-bounce">
          <CheckCircle2 className="w-5 h-5" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Mandatory Change Password Modal */}
      {forceChangePassModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="w-full max-w-md bg-[#161F33] border-2 border-red-500 rounded-3xl p-6 shadow-2xl space-y-4 text-right">
            <div className="p-3 rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30 flex items-center gap-3">
              <AlertTriangle className="w-7 h-7 text-red-400 shrink-0" />
              <div>
                <h3 className="text-base font-extrabold text-white">⚠️ تنبيه أمني: تغيير كلمة المرور</h3>
                <p className="text-xs text-slate-300">
                  كلمة مرور الإدارة الحالية مبدئية (123123). يرجى تعيين كلمة مرور جديدة قوية.
                </p>
              </div>
            </div>

            <form onSubmit={handleForcePasswordSubmit} className="space-y-3">
              <div>
                <label className="text-slate-300 font-bold block mb-1">كلمة المرور الجديدة الخاصة بك:</label>
                <input
                  type="password"
                  value={adminPasswordInput}
                  onChange={(e) => setAdminPasswordInput(e.target.value)}
                  placeholder="أدخل كلمة مرور جديدة قوية"
                  required
                  className="w-full bg-slate-900 border border-[#39FF14] rounded-xl px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-[#39FF14] text-slate-950 font-black hover:bg-[#32e012] shadow-lg shadow-[#39FF14]/20"
              >
                تحديث كلمة المرور والدخول للوحة الإدارة
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modern Dashboard Header */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-[#161F33] via-[#1E293B] to-[#161F33] border border-slate-800/80 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 shadow-inner shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-black text-white">
                {isSuperAdmin ? 'مركز التحكم والقيادة العليا للنظام' : `لوحة الإشراف والمتابعة: ${currentUser.name}`}
              </h2>
              <span className="text-[10px] bg-red-500/20 border border-red-500/40 text-red-300 px-2 py-0.5 rounded-full font-extrabold">
                {isSuperAdmin ? 'Super Admin 🛡️' : 'Staff Account 💼'}
              </span>
            </div>
            <p className="text-slate-400 text-[11px] mt-0.5">
              منظومة متكاملة لإدارة الملاعب، عقود التفاوض، اللاعبين، المباريات والتكميلات، والبطولات والمالية
            </p>
          </div>
        </div>

        {/* Compact Additional Tabs Bar (Minimalist Pills) */}
        <div className="flex items-center gap-1 flex-wrap text-[11px] font-bold">
          <button
            type="button"
            onClick={() => setAdminTab('analytics')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'analytics' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            📊 الإحصائيات
          </button>
          <button
            type="button"
            onClick={() => setAdminTab('matches')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'matches' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            ⚡ التكميلات
          </button>
          <button
            type="button"
            onClick={() => setAdminTab('tournaments')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'tournaments' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            🏆 البطولات
          </button>
          <button
            type="button"
            onClick={() => setAdminTab('teams')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'teams' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            🛡️ الفرق
          </button>
          <button
            type="button"
            onClick={() => setAdminTab('payments')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'payments' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            💳 المالية
          </button>
          <button
            type="button"
            onClick={() => setAdminTab('staff')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'staff' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            💼 الموظفين
          </button>
          <button
            type="button"
            onClick={() => setAdminTab('settings')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              adminTab === 'settings' ? 'bg-[#39FF14] text-slate-950 font-black' : 'text-slate-400 hover:text-white bg-slate-900/60'
            }`}
          >
            🔒 الأمان
          </button>
        </div>
      </div>

      {/* Interactive Compact Metric Tab Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {/* Card 1: Pending Pitch Requests */}
        <button
          type="button"
          onClick={() => setAdminTab('requests')}
          className={`p-2.5 rounded-xl text-right transition-all cursor-pointer flex items-center justify-between border ${
            adminTab === 'requests'
              ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40 shadow-lg shadow-amber-500/20 text-amber-300'
              : 'bg-[#161F33] border-slate-800 text-slate-300 hover:border-amber-500/50 hover:bg-[#1C2840]'
          }`}
        >
          <div className="space-y-0.5">
            <span className={`text-[10px] block font-bold ${adminTab === 'requests' ? 'text-amber-300' : 'text-slate-400'}`}>
              طلبات الملاعب المعلقة
            </span>
            <strong className={`text-sm font-black block ${adminTab === 'requests' ? 'text-amber-300' : 'text-amber-400'}`}>
              {pendingRequestsCount} طلبات
            </strong>
          </div>
          <div className={`p-2 rounded-lg border ${
            adminTab === 'requests'
              ? 'bg-amber-500/30 border-amber-400 text-amber-200'
              : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
          }`}>
            <FileCheck className="w-4 h-4" />
          </div>
        </button>

        {/* Card 2: Active Pitches */}
        <button
          type="button"
          onClick={() => setAdminTab('pitches')}
          className={`p-2.5 rounded-xl text-right transition-all cursor-pointer flex items-center justify-between border ${
            adminTab === 'pitches'
              ? 'bg-emerald-500/20 border-[#39FF14] ring-2 ring-[#39FF14]/40 shadow-lg shadow-[#39FF14]/20 text-[#39FF14]'
              : 'bg-[#161F33] border-slate-800 text-slate-300 hover:border-[#39FF14]/50 hover:bg-[#1C2840]'
          }`}
        >
          <div className="space-y-0.5">
            <span className={`text-[10px] block font-bold ${adminTab === 'pitches' ? 'text-[#39FF14]' : 'text-slate-400'}`}>
              الملاعب النشطة
            </span>
            <strong className={`text-sm font-black block ${adminTab === 'pitches' ? 'text-[#39FF14]' : 'text-[#39FF14]'}`}>
              {activePitchesCount} ملاعب
            </strong>
          </div>
          <div className={`p-2 rounded-lg border ${
            adminTab === 'pitches'
              ? 'bg-emerald-500/30 border-[#39FF14] text-[#39FF14]'
              : 'bg-emerald-500/10 border-emerald-500/20 text-[#39FF14]'
          }`}>
            <Store className="w-4 h-4" />
          </div>
        </button>

        {/* Card 3: Total Registered Players */}
        <button
          type="button"
          onClick={() => setAdminTab('users')}
          className={`p-2.5 rounded-xl text-right transition-all cursor-pointer flex items-center justify-between border ${
            adminTab === 'users'
              ? 'bg-blue-500/20 border-blue-400 ring-2 ring-blue-400/40 shadow-lg shadow-blue-500/20 text-blue-300'
              : 'bg-[#161F33] border-slate-800 text-slate-300 hover:border-blue-500/50 hover:bg-[#1C2840]'
          }`}
        >
          <div className="space-y-0.5">
            <span className={`text-[10px] block font-bold ${adminTab === 'users' ? 'text-blue-300' : 'text-slate-400'}`}>
              إجمالي اللاعبين المسجلين
            </span>
            <strong className={`text-sm font-black block ${adminTab === 'users' ? 'text-blue-300' : 'text-blue-400'}`}>
              {totalPlayersCount} لاعب
            </strong>
          </div>
          <div className={`p-2 rounded-lg border ${
            adminTab === 'users'
              ? 'bg-blue-500/30 border-blue-400 text-blue-200'
              : 'bg-blue-500/10 border-blue-500/20 text-blue-400'
          }`}>
            <Users className="w-4 h-4" />
          </div>
        </button>

        {/* Card 4: Open Support Tickets */}
        <button
          type="button"
          onClick={() => setAdminTab('support')}
          className={`p-2.5 rounded-xl text-right transition-all cursor-pointer flex items-center justify-between border ${
            adminTab === 'support'
              ? 'bg-rose-500/20 border-rose-400 ring-2 ring-rose-400/40 shadow-lg shadow-rose-500/20 text-rose-300'
              : 'bg-[#161F33] border-slate-800 text-slate-300 hover:border-rose-500/50 hover:bg-[#1C2840]'
          }`}
        >
          <div className="space-y-0.5">
            <span className={`text-[10px] block font-bold ${adminTab === 'support' ? 'text-rose-300' : 'text-slate-400'}`}>
              رسائل الدعم المفتوحة
            </span>
            <strong className={`text-sm font-black block ${adminTab === 'support' ? 'text-rose-300' : 'text-rose-400'}`}>
              {openSupportTicketsCount} رسائل
            </strong>
          </div>
          <div className={`p-2 rounded-lg border ${
            adminTab === 'support'
              ? 'bg-rose-500/30 border-rose-400 text-rose-200'
              : 'bg-rose-500/10 border-rose-500/20 text-rose-400'
          }`}>
            <MessageSquare className="w-4 h-4" />
          </div>
        </button>
      </div>

      {/* TAB 0: LIVE RECHARTS ANALYTICS DASHBOARD */}
      {adminTab === 'analytics' && (
        <div className="space-y-4">
          {/* Controls Bar & Timeframe Switcher */}
          <div className="p-4 rounded-3xl bg-[#161F33] border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#39FF14]" />
              <div>
                <h3 className="font-extrabold text-white text-sm">لوحة البيانات التحليلية المباشرة (Live Analytics)</h3>
                <p className="text-slate-400 text-[11px]">مراقبة أداء الحجوزات، الأرباح اليومية، والنمو الدوري لقاعدة المستخدمين</p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end md:self-center">
              <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-[11px]">
                <button
                  onClick={() => setAnalyticsTimeframe('week')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all ${
                    analyticsTimeframe === 'week' ? 'bg-[#39FF14] text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الشهري/الأسبوعي
                </button>
                <button
                  onClick={() => setAnalyticsTimeframe('month')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all ${
                    analyticsTimeframe === 'month' ? 'bg-[#39FF14] text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الربع سنوي
                </button>
                <button
                  onClick={() => setAnalyticsTimeframe('year')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all ${
                    analyticsTimeframe === 'year' ? 'bg-[#39FF14] text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  السنوي الشامل
                </button>
              </div>

              <button
                onClick={() => showToast('تم تصدير التقرير التحليلي بصيغة PDF/Excel بنجاح! 📄')}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 font-bold text-[11px] transition-all"
              >
                <Download className="w-3.5 h-3.5 text-[#39FF14]" />
                <span>تصدير التقرير</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#161F33] to-[#1a253d] border border-slate-800/90 shadow-md">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 text-[11px] font-bold">الحجوزات اليومية المتوقعة</span>
                <span className="text-[10px] bg-emerald-500/20 text-[#39FF14] border border-emerald-500/30 px-2 py-0.5 rounded-full font-black flex items-center gap-0.5">
                  <ArrowUpRight className="w-3 h-3" /> +18.4%
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-white">{totalCalculatedBookings}</span>
                <span className="text-slate-400 text-xs">حجز / أسبوع</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">متوسط {Math.round(totalCalculatedBookings / 7)} حجز يومياً عبر الملاعب النشطة</p>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#161F33] to-[#1a253d] border border-slate-800/90 shadow-md">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 text-[11px] font-bold">إجمالي أرباح وحجوزات المنصة</span>
                <span className="text-[10px] bg-blue-500/20 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded-full font-black flex items-center gap-0.5">
                  <ArrowUpRight className="w-3 h-3" /> +24.2%
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-[#39FF14] dir-ltr">{totalCalculatedRevenue}</span>
                <span className="text-slate-400 text-xs">JOD</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">صافي عمولات المنصة: <strong className="text-amber-400">{totalCalculatedCommission} JOD</strong></p>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#161F33] to-[#1a253d] border border-slate-800/90 shadow-md">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 text-[11px] font-bold">نمو قاعدة اللاعبين والمستخدمين</span>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-full font-black flex items-center gap-0.5">
                  <ArrowUpRight className="w-3 h-3" /> +32.0%
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-white">{usersList.length + 1890}</span>
                <span className="text-slate-400 text-xs">لاعب ومستقبل</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">تسجيل +342 لاعب جديد في آخر 30 يوم</p>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#161F33] to-[#1a253d] border border-slate-800/90 shadow-md">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 text-[11px] font-bold">نسبة إشغال الملاعب (Occupancy)</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-black flex items-center gap-0.5">
                  <ArrowUpRight className="w-3 h-3" /> +12.5%
                </span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-amber-400">84.5%</span>
                <span className="text-slate-400 text-xs">ذروة المساء</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">أعلى إشغال في ملاعب عمان وإربد الخماسية</p>
            </div>
          </div>

          {/* Visitor Traffic & Guest Analytics Card */}
          <div className="p-4 rounded-3xl bg-gradient-to-r from-sky-950/40 via-slate-900 to-slate-900 border border-sky-500/30 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-sky-500/20 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40">
                  <Eye className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="font-black text-white text-sm flex items-center gap-2">
                    <span>إحصائيات حركة الزوار بدون تسجيل (Guest Visitors Analytics)</span>
                    <span className="px-2 py-0.5 text-[10px] rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold">
                      حسابات زائر 👤
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400">متابعة الزوار الذين دخلوا بصفة زائر، ومحاولات التحويل للحجز أو التسجيل الحقيقي</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-xs font-bold">
                <div className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-sky-400">
                  إجمالي الزوار اليوم: <strong className="text-white text-sm font-black mr-1">{visitorLogs.length + 42}</strong>
                </div>
                <div className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-emerald-400">
                  تحويل لتسجيل حقيقي: <strong className="text-white text-sm font-black mr-1">68.5%</strong>
                </div>
              </div>
            </div>

            {/* Visitor Logs Preview Table */}
            <div className="space-y-2">
              <h5 className="text-xs font-bold text-slate-300">أحدث سجّلات دخول حسابات الزوار والتفاعل المباشر:</h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {(visitorLogs.length === 0
                  ? [
                      { id: 'v1', visitorName: 'الكابتن سامر (زائر)', enteredAt: 'اليوم 05:20 م', actionsAttemptedCount: 4 },
                      { id: 'v2', visitorName: 'أحمد التميمي (زائر)', enteredAt: 'اليوم 04:10 م', actionsAttemptedCount: 2 },
                      { id: 'v3', visitorName: 'متابع ملاعب إربد (زائر)', enteredAt: 'اليوم 02:45 م', actionsAttemptedCount: 6 },
                    ]
                  : visitorLogs
                ).map((v) => (
                  <div key={v.id} className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800/80 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-black text-sky-300 block">{v.visitorName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">وقت الدخول: {v.enteredAt}</span>
                    </div>
                    <div className="text-left shrink-0">
                      <span className="px-2 py-1 rounded-lg bg-sky-500/10 text-sky-300 border border-sky-500/30 text-[10px] font-black block">
                        {v.actionsAttemptedCount || 3} محاولات حجز/انضمام
                      </span>
                      <span className="text-[9px] text-emerald-400 block mt-0.5 font-bold">تم تحويله للتسجيل 🚀</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Charts Row 1: Daily Bookings & Revenue Trend (AreaChart) + User Growth (BarChart) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Area Chart: Daily Bookings & Revenue */}
            <div className="lg:col-span-7 p-4 sm:p-5 rounded-3xl bg-[#161F33] border border-slate-800/90 shadow-xl space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-[#39FF14]" />
                  <div>
                    <h4 className="font-extrabold text-white text-xs sm:text-sm">مخطط الحجوزات والأرباح اليومية</h4>
                    <p className="text-[10px] text-slate-400">توزيع الحجوزات بالعدد والإيرادات بالدينار الأردني</p>
                  </div>
                </div>
                <span className="text-[10px] bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg text-slate-300 font-bold">
                  تتبع مباشر 🟢
                </span>
              </div>

              <div className="h-64 sm:h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={dailyBookingsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#39FF14" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#39FF14" stopOpacity={0.0} />
                      </linearGradient>
                      <linearGradient id="colorBookings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                    <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} />
                    <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderColor: '#334155',
                        borderRadius: '16px',
                        color: '#FFF',
                        fontSize: '12px',
                        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)',
                      }}
                      formatter={(val: any, name: any) => [
                        name === 'revenue' ? `${val} JOD` : `${val} حجز`,
                        name === 'revenue' ? 'الأرباح' : 'عدد الحجوزات',
                      ]}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Area
                      type="monotone"
                      dataKey="revenue"
                      name="الأرباح (JOD)"
                      stroke="#39FF14"
                      strokeWidth={3}
                      fillOpacity={1}
                      fill="url(#colorRevenue)"
                    />
                    <Area
                      type="monotone"
                      dataKey="bookings"
                      name="عدد الحجوزات"
                      stroke="#3B82F6"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorBookings)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Bar Chart: User Base Growth Trajectory */}
            <div className="lg:col-span-5 p-4 sm:p-5 rounded-3xl bg-[#161F33] border border-slate-800/90 shadow-xl space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-400" />
                  <div>
                    <h4 className="font-extrabold text-white text-xs sm:text-sm">تراكم نمو المستخدمين</h4>
                    <p className="text-[10px] text-slate-400">مقارنة بين اللاعبين وأصحاب الملاعب</p>
                  </div>
                </div>
                <span className="text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded-lg font-bold">
                  2026 📈
                </span>
              </div>

              <div className="h-64 sm:h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userGrowthData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                    <XAxis dataKey="month" stroke="#64748B" fontSize={10} tickLine={false} />
                    <YAxis stroke="#64748B" fontSize={10} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderColor: '#334155',
                        borderRadius: '16px',
                        color: '#FFF',
                        fontSize: '11px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Bar dataKey="players" name="اللاعبين" fill="#3B82F6" radius={[6, 6, 0, 0]} />
                    <Bar dataKey="owners" name="أصحاب الملاعب" fill="#F59E0B" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Charts Row 2: Sports Distribution Donut & City Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Pie / Donut Chart: Sports Occupancy */}
            <div className="lg:col-span-5 p-4 sm:p-5 rounded-3xl bg-[#161F33] border border-slate-800/90 shadow-xl space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <PieChartIcon className="w-5 h-5 text-purple-400" />
                  <div>
                    <h4 className="font-extrabold text-white text-xs sm:text-sm">توزيع الحجوزات حسب الرياضة</h4>
                    <p className="text-[10px] text-slate-400">نسبة الإقبال على الرياضات المختلفة</p>
                  </div>
                </div>
              </div>

              <div className="h-56 sm:h-64 w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={sportsDistributionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={85}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {sportsDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderColor: '#334155',
                        borderRadius: '12px',
                        color: '#FFF',
                        fontSize: '11px',
                      }}
                      formatter={(val: any) => [`${val}%`, 'نسبة الحجز']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px]">
                {sportsDistributionData.map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-xl bg-slate-900/80 border border-slate-800">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                      <span className="text-slate-300 font-bold">{s.name}</span>
                    </div>
                    <span className="font-black text-white">{s.value}%</span>
                  </div>
                ))}
              </div>
            </div>

            {/* City Performance Horizontal Bar Chart */}
            <div className="lg:col-span-7 p-4 sm:p-5 rounded-3xl bg-[#161F33] border border-slate-800/90 shadow-xl space-y-3">
              <div className="flex justify-between items-center border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-amber-400" />
                  <div>
                    <h4 className="font-extrabold text-white text-xs sm:text-sm">أداء الملاعب والحجوزات حسب المدينة</h4>
                    <p className="text-[10px] text-slate-400">مقارنة النشاط الرياضي في مختلف محافظات المملكة</p>
                  </div>
                </div>
              </div>

              <div className="h-64 sm:h-72 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={cityPerformanceData}
                    margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" horizontal={false} />
                    <XAxis type="number" stroke="#64748B" fontSize={10} tickLine={false} />
                    <YAxis dataKey="city" type="category" stroke="#CBD5E1" fontSize={11} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0F172A',
                        borderColor: '#334155',
                        borderRadius: '12px',
                        color: '#FFF',
                        fontSize: '11px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Bar dataKey="bookings" name="إجمالي الحجوزات" fill="#39FF14" radius={[0, 6, 6, 0]} />
                    <Bar dataKey="pitches" name="عدد الملاعب المعتمدة" fill="#3B82F6" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: PITCH REQUESTS & NEGOTIATIONS */}
      {adminTab === 'requests' && (
        <div className="space-y-3">
          {!hasPermission('manage_requests') ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30">
              ⛔ عذراً، لا تملك صلاحية إدارة الطلبات والتفاوض.
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-slate-200 text-sm flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-amber-400" />
                  طلبات إضافة الملاعب والتفاوض العقدي:
                </h3>
                <span className="text-slate-400 text-xs">إجمالي الطلبات: {pitchRequests.length}</span>
              </div>

              {pitchRequests.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-[#161F33] rounded-2xl border border-slate-800">
                  لا توجد طلبات ملاعب معلقة حالياً.
                </div>
              ) : (
                pitchRequests.map((req) => (
                  <div key={req.id} className="p-4 rounded-2xl bg-[#161F33] border border-slate-800/80 space-y-3 hover:border-slate-700 transition-all">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] px-2.5 py-0.5 rounded-lg font-black ${
                            req.status === 'negotiating' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                          }`}>
                            {req.status === 'negotiating' ? 'قيد التفاوض 💬' : `طلب جديد - ${req.city}`}
                          </span>
                        </div>
                        <h4 className="text-sm font-extrabold text-white mt-1.5">{req.pitchName}</h4>
                        <p className="text-slate-400 mt-0.5 text-xs">صاحب الملعب: <strong className="text-slate-200">{req.ownerName}</strong> ({req.ownerPhone})</p>
                      </div>

                      <div className="sm:text-left">
                        <span className="text-base font-black text-[#39FF14] dir-ltr block">
                          {req.negotiatedRate ? `${req.negotiatedRate} JOD (متفاوض عليه)` : `${req.hourlyRate} JOD/ساعة`}
                        </span>
                        <span className="text-[10px] text-slate-400 block">نوع الأرضية: {req.surfaceType}</span>
                      </div>
                    </div>

                    <p className="text-slate-300 text-xs bg-slate-900/90 p-3 rounded-xl border border-slate-800 leading-relaxed">
                      <strong className="text-amber-400">ملاحظات وشروط الملعب:</strong> {req.notes || req.negotiatedTerms || 'لا توجد شروط خاصة.'}
                    </p>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      <button
                        onClick={() => {
                          setNegotiatingReq(req);
                          setNegotiatedRateInput(req.negotiatedRate || req.hourlyRate);
                          setNegotiatedCommInput(req.negotiatedCommission || 10);
                          setNegotiatedTermsInput(req.negotiatedTerms || 'حجز إلكتروني مسبق، خصم 10% عمولة التطبيق، إلتزام بمواعيد المباريات.');
                        }}
                        className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center justify-center gap-1.5 shadow-md text-xs"
                      >
                        <MessageSquare className="w-4 h-4" />
                        التفاوض وتعديل العقد والشروط
                      </button>

                      <button
                        onClick={() => {
                          onApprovePitchRequest(req.id);
                          showToast(`تم قبول واعتماد ملعب ${req.pitchName} بنجاح! 🎉`);
                        }}
                        className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black flex items-center gap-1 text-xs"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        اعتماد فوري
                      </button>

                      <button
                        onClick={() => {
                          onRejectPitchRequest(req.id);
                          showToast('تم رفض الطلب');
                        }}
                        className="px-3.5 py-2.5 rounded-xl bg-red-500/20 border border-red-500/50 hover:bg-red-500/30 text-red-300 font-bold flex items-center gap-1 text-xs"
                      >
                        <XCircle className="w-4 h-4" />
                        رفض
                      </button>
                    </div>
                  </div>
                ))
              )}

              {/* Pitch Negotiation Modal */}
              {negotiatingReq && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
                  <div className="w-full max-w-xl bg-[#161F33] border-2 border-amber-500/60 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-5 h-5 text-amber-400" />
                        <h3 className="font-extrabold text-white text-sm">التفاوض وتعديل بنود عقد {negotiatingReq.pitchName}</h3>
                      </div>
                      <button onClick={() => setNegotiatingReq(null)} className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">سعر الساعة المقترح (JOD):</label>
                        <input
                          type="number"
                          value={negotiatedRateInput}
                          onChange={(e) => setNegotiatedRateInput(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">نسبة العمولة المقترحة (%):</label>
                        <input
                          type="number"
                          value={negotiatedCommInput}
                          onChange={(e) => setNegotiatedCommInput(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1 text-xs">تعديل بنود العقد والشروط قبل القبول:</label>
                      <textarea
                        rows={2}
                        value={negotiatedTermsInput}
                        onChange={(e) => setNegotiatedTermsInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white text-xs"
                      />
                    </div>

                    <div className="space-y-2 bg-slate-900/90 p-3 rounded-2xl border border-slate-800 max-h-40 overflow-y-auto">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1">سجل رسائل التفاوض:</span>
                      {negotiatingReq.negotiationHistory && negotiatingReq.negotiationHistory.length > 0 ? (
                        negotiatingReq.negotiationHistory.map((m) => (
                          <div
                            key={m.id}
                            className={`p-2.5 rounded-xl text-xs ${
                              m.sender === 'admin' ? 'bg-amber-500/15 border border-amber-500/30 text-amber-200 mr-4' : 'bg-slate-800 text-slate-200 ml-4'
                            }`}
                          >
                            <div className="flex justify-between items-center text-[10px] text-slate-400 mb-0.5">
                              <span className="font-bold">{m.senderName}</span>
                              <span>{m.createdAt}</span>
                            </div>
                            <p>{m.message}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-[11px] text-slate-500 text-center py-2">لا توجد رسائل تفاوض سابقة.</p>
                      )}
                    </div>

                    <form onSubmit={handleSendNegotiationSubmit} className="space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={negotiationMsg}
                          onChange={(e) => setNegotiationMsg(e.target.value)}
                          placeholder="اكتب رسالة تفاوض جديدة لصاحب الملعب..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs"
                        />
                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-black shrink-0 text-xs flex items-center gap-1"
                        >
                          <Send className="w-3.5 h-3.5" />
                          إرسال
                        </button>
                      </div>
                    </form>

                    <button
                      type="button"
                      onClick={handleApproveWithNegotiation}
                      className="w-full py-3.5 rounded-xl bg-[#39FF14] text-slate-950 font-black text-xs hover:bg-[#32e012] flex items-center justify-center gap-1.5 shadow-lg shadow-[#39FF14]/20"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      قبول الطلب واعتماده بالسعر والعقد المعدل أعلاه
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB 2: PLAYERS & USERS MANAGEMENT */}
      {adminTab === 'users' && (
        <div className="space-y-3">
          {!hasPermission('manage_users') ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30">
              ⛔ عذراً، لا تملك صلاحية إدارة المستخدمين واللاعبين.
            </div>
          ) : (
            <>
              <div className="flex flex-col sm:flex-row items-center justify-between gap-2 bg-[#161F33] p-3 rounded-2xl border border-slate-800">
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                  <input
                    type="text"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    placeholder="بحث بالاسم أو رقم الهاتف..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-9 pl-3 py-1.5 text-white text-xs"
                  />
                </div>

                <div className="flex items-center gap-1 text-[11px] font-bold w-full sm:w-auto overflow-x-auto">
                  <button
                    onClick={() => setUserRoleFilter('all')}
                    className={`px-3 py-1.5 rounded-xl ${userRoleFilter === 'all' ? 'bg-red-500 text-white font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    الكل ({usersList.length})
                  </button>
                  <button
                    onClick={() => setUserRoleFilter('user')}
                    className={`px-3 py-1.5 rounded-xl ${userRoleFilter === 'user' ? 'bg-red-500 text-white font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    اللاعبين ({usersList.filter((u) => u.role === 'user' && !u.isStaff).length})
                  </button>
                  <button
                    onClick={() => setUserRoleFilter('owner')}
                    className={`px-3 py-1.5 rounded-xl ${userRoleFilter === 'owner' ? 'bg-red-500 text-white font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    أصحاب الملاعب ({usersList.filter((u) => u.role === 'owner').length})
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                {filteredUsers.map((usr) => (
                  <div key={usr.id} className="p-3.5 rounded-2xl bg-[#161F33] border border-slate-800/80 flex items-center justify-between gap-2 hover:border-slate-700 transition-all">
                    <div className="flex items-center gap-3 min-w-0">
                      <img src={usr.avatar} alt={usr.name} className="w-10 h-10 rounded-full object-cover shrink-0 border border-emerald-500/40" referrerPolicy="no-referrer" />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-white truncate text-xs">{usr.name}</span>
                          <span className={`text-[9px] px-2 py-0.2 rounded font-black shrink-0 ${
                            usr.role === 'owner' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          }`}>
                            {usr.role === 'owner' ? 'صاحب ملعب 🏪' : 'لاعب ⚽'}
                          </span>
                          {usr.isBanned && (
                            <span className="bg-red-500/20 border border-red-500/40 text-red-400 text-[9px] px-2 py-0.2 rounded font-black shrink-0">
                              محظور 🔴
                            </span>
                          )}
                        </div>
                        <div className="text-slate-400 text-[10px] dir-ltr text-right mt-0.5">{usr.phone} | {usr.city}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => {
                          setEditingUser(usr);
                          setEditUserName(usr.name);
                          setEditUserPhone(usr.phone);
                          setEditUserCity(usr.city);
                          setEditUserAvatar(usr.avatar);
                          setEditUserPos(usr.preferredPosition || 'مهاجم صريح');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold border border-slate-700 flex items-center gap-1 text-[11px]"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>تعديل</span>
                      </button>

                      <button
                        onClick={() => {
                          if (onToggleBanUser) onToggleBanUser(usr.id);
                          showToast(usr.isBanned ? 'تم إلغاء حظر المستخدم' : 'تم حظر المستخدم');
                        }}
                        className={`px-3 py-1.5 rounded-xl border font-black flex items-center gap-1 transition-all text-[11px] ${
                          usr.isBanned
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 hover:bg-emerald-500/30'
                            : 'bg-red-500/20 border-red-500 text-red-400 hover:bg-red-500/30'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{usr.isBanned ? 'إلغاء الحظر' : 'حظر'}</span>
                      </button>

                      {onDeleteUser && (
                        <button
                          onClick={() => {
                            if (confirm(`هل أنت متأكد من حذف حساب ${usr.name} (${usr.role === 'owner' ? 'صاحب ملعب' : 'لاعب'}) تماماً ومسح كافة بياناته من المنصة؟`)) {
                              onDeleteUser(usr.id);
                              showToast(`تم حذف حساب ${usr.name} بنجاح`);
                            }
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 font-bold border border-red-500/40 flex items-center gap-1 text-[11px] transition-all"
                          title="حذف الحساب نهائياً"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Edit Player Modal */}
              {editingUser && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
                  <div className="w-full max-w-md bg-[#161F33] border border-amber-500/50 rounded-3xl p-5 shadow-2xl space-y-3">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                      <h3 className="font-extrabold text-amber-400 text-sm">تعديل بيانات وصورة: {editingUser.name}</h3>
                      <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <form onSubmit={handleSaveUserEdit} className="space-y-3 text-xs">
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">اختر صورة رمادية أو أدخل الرابط:</label>
                        <div className="flex gap-1.5 overflow-x-auto pb-1 mb-2">
                          {AVATAR_PRESETS.map((url, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => setEditUserAvatar(url)}
                              className={`w-9 h-9 rounded-full overflow-hidden border ${editUserAvatar === url ? 'border-[#39FF14] ring-2 ring-[#39FF14]/50' : 'border-slate-700'}`}
                            >
                              <img src={url} alt="preset" className="w-full h-full object-cover" />
                            </button>
                          ))}
                        </div>
                        <input
                          type="url"
                          value={editUserAvatar}
                          onChange={(e) => setEditUserAvatar(e.target.value)}
                          placeholder="رابط صورة مباشرة..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">الاسم الكامل:</label>
                        <input
                          type="text"
                          value={editUserName}
                          onChange={(e) => setEditUserName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-slate-300 font-bold block mb-1">رقم الهاتف:</label>
                          <input
                            type="text"
                            value={editUserPhone}
                            onChange={(e) => setEditUserPhone(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white dir-ltr text-right"
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 font-bold block mb-1">المدينة:</label>
                          <select
                            value={editUserCity}
                            onChange={(e: any) => setEditUserCity(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                          >
                            <option value="عمان">عمان</option>
                            <option value="الزرقاء">الزرقاء</option>
                            <option value="إربد">إربد</option>
                            <option value="العقبة">العقبة</option>
                            <option value="السلط">السلط</option>
                            <option value="جرش">جرش</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-2">
                        {onDeleteUser ? (
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`هل أنت متأكد من حذف حساب ${editingUser.name} نهائياً ومسح كافة بياناته؟`)) {
                                onDeleteUser(editingUser.id);
                                setEditingUser(null);
                                showToast(`تم حذف حساب ${editingUser.name} بنجاح`);
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/40 font-bold flex items-center gap-1 text-xs transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف الحساب</span>
                          </button>
                        ) : <div />}

                        <div className="flex items-center gap-2">
                          <button type="button" onClick={() => setEditingUser(null)} className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-300">
                            إلغاء
                          </button>
                          <button type="submit" className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black">
                            حفظ التعديلات
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB 3: PITCHES MANAGEMENT */}
      {adminTab === 'pitches' && (
        <div className="space-y-3">
          {!hasPermission('manage_pitches') ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30">
              ⛔ عذراً، لا تملك صلاحية إدارة الملاعب والأسعار.
            </div>
          ) : (
            <>
              <h3 className="font-extrabold text-slate-200 text-sm flex items-center gap-2">
                <Store className="w-4 h-4 text-[#39FF14]" />
                قائمة وصور الملاعب المعتمدة بالنظام:
              </h3>

              <div className="space-y-2">
                {pitches.map((pitch) => (
                  <div key={pitch.id} className="p-3.5 rounded-2xl bg-[#161F33] border border-slate-800/80 space-y-2 hover:border-slate-700 transition-all">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <img src={pitch.image} alt={pitch.name} className="w-14 h-14 rounded-xl object-cover shrink-0 border border-slate-700" referrerPolicy="no-referrer" />
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-extrabold text-white text-sm">{pitch.name}</h4>
                            {pitch.isBanned ? (
                              <span className="bg-red-500/20 border border-red-500 text-red-400 text-[9px] px-2 py-0.2 rounded font-black">
                                معطل 🔴
                              </span>
                            ) : (
                              <span className="bg-emerald-500/20 text-[#39FF14] text-[9px] px-2 py-0.2 rounded font-black">
                                متاح وفعّال 🟢
                              </span>
                            )}
                          </div>
                          <p className="text-slate-400 text-xs mt-0.5">{pitch.city} - {pitch.district} | صاحب الملعب: {pitch.ownerName}</p>
                        </div>
                      </div>

                      <div className="text-left shrink-0">
                        <span className="text-base font-black text-[#39FF14] dir-ltr">{pitch.hourlyRate} JOD/ساعة</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px]">
                      <button
                        onClick={() => {
                          setEditingPitch(pitch);
                          setEditPitchName(pitch.name);
                          setEditPitchImage(pitch.image);
                          setEditPitchRate(pitch.hourlyRate);
                          setEditPitchCity(pitch.city);
                          setEditPitchDistrict(pitch.district);
                        }}
                        className="text-amber-400 hover:underline font-bold flex items-center gap-1"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        تعديل بيانات وصورة الملعب
                      </button>

                      <button
                        onClick={() => {
                          if (onToggleBanPitch) onToggleBanPitch(pitch.id);
                          showToast(pitch.isBanned ? 'تم تفعيل الملعب' : 'تم تعطيل الملعب');
                        }}
                        className={`px-3 py-1 rounded-xl font-bold flex items-center gap-1 border ${
                          pitch.isBanned
                            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                            : 'bg-red-500/20 text-red-400 border-red-500/40'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{pitch.isBanned ? 'تفعيل الملعب' : 'حظر الملعب'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Edit Pitch Modal */}
              {editingPitch && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
                  <div className="w-full max-w-md bg-[#161F33] border border-amber-500/50 rounded-3xl p-5 shadow-2xl space-y-3">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                      <h3 className="font-extrabold text-amber-400 text-sm">تعديل وصورة: {editingPitch.name}</h3>
                      <button onClick={() => setEditingPitch(null)} className="text-slate-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <form onSubmit={handleSavePitchEdit} className="space-y-3 text-xs">
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">اسم الملعب:</label>
                        <input
                          type="text"
                          value={editPitchName}
                          onChange={(e) => setEditPitchName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">رابط صورة الملعب:</label>
                        <input
                          type="url"
                          value={editPitchImage}
                          onChange={(e) => setEditPitchImage(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-slate-300 font-bold block mb-1">السعر بالساعة (JOD):</label>
                          <input
                            type="number"
                            value={editPitchRate}
                            onChange={(e) => setEditPitchRate(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-bold"
                          />
                        </div>

                        <div>
                          <label className="text-slate-300 font-bold block mb-1">المدينة:</label>
                          <select
                            value={editPitchCity}
                            onChange={(e: any) => setEditPitchCity(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                          >
                            <option value="عمان">عمان</option>
                            <option value="الزرقاء">الزرقاء</option>
                            <option value="إربد">إربد</option>
                            <option value="العقبة">العقبة</option>
                            <option value="السلط">السلط</option>
                            <option value="جرش">جرش</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 pt-2">
                        <button type="button" onClick={() => setEditingPitch(null)} className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-300">
                          إلغاء
                        </button>
                        <button type="submit" className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black">
                          حفظ التعديلات
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB 4: OPEN MATCHES & TAKMEELAT MANAGEMENT */}
      {adminTab === 'matches' && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 bg-[#161F33] p-3 rounded-2xl border border-slate-800">
            <h3 className="font-extrabold text-slate-200 text-sm flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#39FF14]" />
              مباريات التكميلة النشطة بالنظام ({openMatches.length}):
            </h3>

            <div className="flex items-center gap-1 text-xs font-bold">
              <button
                onClick={() => setMatchStatusFilter('all')}
                className={`px-3 py-1.5 rounded-xl ${matchStatusFilter === 'all' ? 'bg-red-500 text-white font-black' : 'text-slate-400 hover:text-white'}`}
              >
                الكل
              </button>
              <button
                onClick={() => setMatchStatusFilter('open')}
                className={`px-3 py-1.5 rounded-xl ${matchStatusFilter === 'open' ? 'bg-red-500 text-white font-black' : 'text-slate-400 hover:text-white'}`}
              >
                مفتوحة 🟢
              </button>
              <button
                onClick={() => setMatchStatusFilter('full')}
                className={`px-3 py-1.5 rounded-xl ${matchStatusFilter === 'full' ? 'bg-red-500 text-white font-black' : 'text-slate-400 hover:text-white'}`}
              >
                مكتملة 🟡
              </button>
            </div>
          </div>

          <div className="space-y-2">
            {filteredMatches.length === 0 ? (
              <div className="p-8 text-center text-slate-400 bg-[#161F33] rounded-2xl border border-slate-800">
                لا توجد مباريات بالفلتر المحدد.
              </div>
            ) : (
              filteredMatches.map((m) => (
                <div key={m.id} className="p-3.5 rounded-2xl bg-[#161F33] border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-700 transition-all">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-white text-sm">{m.pitchName}</h4>
                      <span className={`text-[9px] px-2 py-0.5 rounded font-black ${
                        m.status === 'open' ? 'bg-emerald-500/20 text-[#39FF14]' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {m.status === 'open' ? 'مفتوحة ينقص لاعبين 🟢' : 'مكتملة 🟡'}
                      </span>
                    </div>
                    <p className="text-slate-400 text-xs mt-0.5">
                      {m.city} | المنظم: <strong className="text-slate-200">{m.organizerName}</strong> ({m.organizerPhone})
                    </p>
                    <span className="text-slate-300 text-[11px] font-mono mt-1 block">
                      الموعد: {m.date} - {m.time} | عدد اللاعبين: {m.currentPlayersCount} / {m.totalPlayersNeeded}
                    </span>
                  </div>

                  {onUpdateMatchStatus && (
                    <div className="flex items-center gap-1 shrink-0 self-end sm:self-center text-[11px]">
                      <button
                        onClick={() => {
                          onUpdateMatchStatus(m.id, m.status === 'open' ? 'full' : 'open');
                          showToast('تم تغيير حالة المباراة بنجاح');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold border border-slate-700"
                      >
                        تبديل الحالة ({m.status})
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 5: TOURNAMENTS MANAGEMENT */}
      {adminTab === 'tournaments' && (
        <div className="space-y-3">
          {!hasPermission('manage_tournaments') ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30">
              ⛔ عذراً، لا تملك صلاحية إدارة البطولات.
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-slate-200 text-sm flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  بطولات وكؤوس الملاعب الخماسية ({tournaments.length}):
                </h3>
                <button
                  onClick={() => setIsCreateTourneyOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center gap-1.5 shadow-md text-xs"
                >
                  <PlusCircle className="w-4 h-4" />
                  إنشاء بطولة جديدة 🏆
                </button>
              </div>

              {/* Create Tournament Form Modal */}
              {isCreateTourneyOpen && (
                <div className="p-4 rounded-2xl bg-[#161F33] border-2 border-amber-500/50 space-y-3">
                  <h4 className="font-black text-amber-400 text-sm">إضافة ونشر بطولة كروية جديدة:</h4>
                  <form onSubmit={handleCreateTournamentSubmit} className="space-y-3 text-xs">
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">اسم/عنوان البطولة:</label>
                      <input
                        type="text"
                        required
                        value={tourneyTitle}
                        onChange={(e) => setTourneyTitle(e.target.value)}
                        placeholder="مثال: بطولة صيف عمان الخماسية 2026"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">المدينة:</label>
                        <select
                          value={tourneyCity}
                          onChange={(e) => setTourneyCity(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                        >
                          <option value="عمان">عمان</option>
                          <option value="الزرقاء">الزرقاء</option>
                          <option value="إربد">إربد</option>
                          <option value="العقبة">العقبة</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">الملعب المستضيف:</label>
                        <input
                          type="text"
                          value={tourneyPitchName}
                          onChange={(e) => setTourneyPitchName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">عدد الفرق:</label>
                        <input
                          type="number"
                          value={tourneyMaxTeams}
                          onChange={(e) => setTourneyMaxTeams(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-bold"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">رسوم الفريق (JOD):</label>
                        <input
                          type="number"
                          value={tourneyEntryFee}
                          onChange={(e) => setTourneyEntryFee(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-bold"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">الجائزة الأولى (JOD):</label>
                        <input
                          type="number"
                          value={tourneyFirstPrize}
                          onChange={(e) => setTourneyFirstPrize(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-bold"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setIsCreateTourneyOpen(false)}
                        className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold"
                      >
                        إلغاء
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black"
                      >
                        نشر البطولة فوراً
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Tournaments List */}
              <div className="space-y-3">
                {tournaments.map((t) => (
                  <div key={t.id} className="p-3.5 rounded-2xl bg-[#161F33] border border-slate-800/80 flex items-center justify-between gap-3 hover:border-slate-700 transition-all">
                    <div className="flex items-center gap-3">
                      <img src={t.bannerImage} alt={t.title} className="w-14 h-14 rounded-xl object-cover shrink-0" referrerPolicy="no-referrer" />
                      <div>
                        <h4 className="font-extrabold text-white text-sm">{t.title}</h4>
                        <p className="text-slate-400 text-[11px] mt-0.5">
                          {t.city} - {t.pitchName} | رسوم الفريق: {t.entryFeePerTeam} JOD | الجائزة: {t.firstPrize} JOD
                        </p>
                        <span className="text-[10px] text-amber-400 font-bold mt-1 inline-block">
                          المسجلين: {t.teamsCount} / {t.maxTeams} فريق
                        </span>
                      </div>
                    </div>

                    {onDeleteTournament && (
                      <button
                        onClick={() => {
                          if (confirm(`هل أنت متأكد من إلغاء بطولة ${t.title}؟`)) {
                            onDeleteTournament(t.id);
                            showToast('تم إلغاء البطولة');
                          }
                        }}
                        className="p-2 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/40 border border-red-500/30"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 6: PAYMENT GATEWAYS & FINANCE */}
      {adminTab === 'payments' && (
        <div className="p-4 rounded-2xl bg-[#161F33] border border-slate-800/80 space-y-4">
          {!hasPermission('manage_payments') ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30">
              ⛔ عذراً، لا تملك صلاحية إدارة طرق الدفع والمالية.
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-[#39FF14]" />
                  التحكم ببيانات وطرق الدفع والعمولات بالنظام:
                </h3>
                <button
                  onClick={handleSavePaymentSettings}
                  className="px-4 py-2 rounded-xl bg-[#39FF14] text-slate-950 font-black shadow-md hover:bg-[#32e012] text-xs"
                >
                  حفظ الإعدادات
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* CliQ */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">كليك (CliQ Jordan)</span>
                    <button
                      onClick={() => setLocalPayment({ ...localPayment, cliqEnabled: !localPayment.cliqEnabled })}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[10px] ${
                        localPayment.cliqEnabled ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {localPayment.cliqEnabled ? 'مفعل ✅' : 'معطل ❌'}
                    </button>
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block">اسم المستعار / CliQ Alias:</label>
                    <input
                      type="text"
                      value={localPayment.cliqAlias}
                      onChange={(e) => setLocalPayment({ ...localPayment, cliqAlias: e.target.value })}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono dir-ltr text-right"
                    />
                  </div>
                </div>

                {/* Bank IBAN */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">التحويل البنكي المباشر (IBAN)</span>
                    <button
                      onClick={() => setLocalPayment({ ...localPayment, bankIbanEnabled: !localPayment.bankIbanEnabled })}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[10px] ${
                        localPayment.bankIbanEnabled ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {localPayment.bankIbanEnabled ? 'مفعل ✅' : 'معطل ❌'}
                    </button>
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block">رقم الآيبان البنكي (IBAN):</label>
                    <input
                      type="text"
                      value={localPayment.bankIban}
                      onChange={(e) => setLocalPayment({ ...localPayment, bankIban: e.target.value })}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono dir-ltr text-right"
                    />
                  </div>
                </div>

                {/* Zain Cash */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">محفظة زين كاش (Zain Cash)</span>
                    <button
                      onClick={() => setLocalPayment({ ...localPayment, zainCashEnabled: !localPayment.zainCashEnabled })}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[10px] ${
                        localPayment.zainCashEnabled ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {localPayment.zainCashEnabled ? 'مفعل ✅' : 'معطل ❌'}
                    </button>
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block">رقم محفظة زين كاش:</label>
                    <input
                      type="text"
                      value={localPayment.zainCashPhone}
                      onChange={(e) => setLocalPayment({ ...localPayment, zainCashPhone: e.target.value })}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono dir-ltr text-right"
                    />
                  </div>
                </div>

                {/* eFAWATEERcom */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">إي فواتيركم (eFAWATEERcom)</span>
                    <button
                      onClick={() => setLocalPayment({ ...localPayment, efawateerEnabled: !localPayment.efawateerEnabled })}
                      className={`px-2.5 py-1 rounded-lg font-bold text-[10px] ${
                        localPayment.efawateerEnabled ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {localPayment.efawateerEnabled ? 'مفعل ✅' : 'معطل ❌'}
                    </button>
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block">رمز الخدمة المترابط:</label>
                    <input
                      type="text"
                      value={localPayment.efawateerCode}
                      onChange={(e) => setLocalPayment({ ...localPayment, efawateerCode: e.target.value })}
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono dir-ltr text-right"
                    />
                  </div>
                </div>
              </div>

              {/* Commission Rates */}
              <div className="pt-3 border-t border-slate-800 space-y-3">
                <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                  <Sliders className="w-4 h-4" />
                  نسب العمولات والرسوم بالنظام:
                </h4>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-slate-300 font-bold block mb-1">عمولة المنصة (%):</label>
                    <input
                      type="number"
                      value={localPayment.commissionRate}
                      onChange={(e) => setLocalPayment({ ...localPayment, commissionRate: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-bold text-center"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1">رسوم التكميلة (JOD):</label>
                    <input
                      type="number"
                      step="0.5"
                      value={localPayment.defaultMatchFee}
                      onChange={(e) => setLocalPayment({ ...localPayment, defaultMatchFee: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-bold text-center"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1">الضريبة (%):</label>
                    <input
                      type="number"
                      value={localPayment.taxPercent}
                      onChange={(e) => setLocalPayment({ ...localPayment, taxPercent: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-bold text-center"
                    />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 7: SUPPORT TICKETS & QUICK REPLIES */}
      {adminTab === 'support' && (
        <div className="space-y-3">
          {!hasPermission('manage_support') ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30">
              ⛔ عذراً، لا تملك صلاحية الوصول إلى رسائل الدعم الفني.
            </div>
          ) : (
            <>
              <h3 className="font-extrabold text-slate-200 text-sm flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                رسائل واستفسارات الدعم الفني:
              </h3>

              {supportTickets.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-[#161F33] rounded-2xl border border-slate-800">
                  لا توجد رسائل دعم حالياً.
                </div>
              ) : (
                <div className="space-y-3">
                  {supportTickets.map((t) => (
                    <div key={t.id} className="p-4 rounded-2xl bg-[#161F33] border border-slate-800/80 space-y-2 hover:border-slate-700 transition-all">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-white text-sm">{t.userName}</span>
                            <span className="text-slate-400 text-[10px] dir-ltr">({t.userPhone})</span>
                            <span className={`text-[9px] px-2 py-0.5 rounded font-bold ${
                              t.status === 'open'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            }`}>
                              {t.status === 'open' ? 'مفتوحة 🟡' : 'تم الرد ✅'}
                            </span>
                          </div>
                          <h5 className="font-bold text-emerald-400 text-xs mt-1">{t.subject}</h5>
                        </div>
                        <span className="text-slate-500 text-[10px] font-mono">{t.createdAt}</span>
                      </div>

                      <p className="p-3 rounded-xl bg-slate-900/90 text-slate-200 text-xs leading-relaxed border border-slate-800">
                        {t.message}
                      </p>

                      {t.reply && (
                        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs space-y-1">
                          <strong className="block text-emerald-400 font-extrabold">رد الإدارة:</strong>
                          <p>{t.reply}</p>
                        </div>
                      )}

                      {/* Quick AI/Template Reply Presets */}
                      {replyingTicketId === t.id ? (
                        <div className="space-y-2 pt-2 border-t border-slate-800">
                          <div className="space-y-1">
                            <span className="text-[10px] text-slate-400 font-bold block">ردود سريعة بضغطة زر:</span>
                            <div className="flex flex-wrap gap-1">
                              {SUPPORT_QUICK_REPLIES.map((preset, idx) => (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => setReplyText(preset)}
                                  className="text-[10px] bg-slate-800 hover:bg-slate-700 text-emerald-300 px-2.5 py-1 rounded-lg border border-slate-700 text-right truncate max-w-xs"
                                >
                                  {preset}
                                </button>
                              ))}
                            </div>
                          </div>

                          <textarea
                            rows={2}
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            placeholder="اكتب رد الإدارة المباشر..."
                            className="w-full bg-slate-900 border border-emerald-500/60 rounded-xl p-2.5 text-white text-xs"
                          />
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => setReplyingTicketId(null)}
                              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400 text-xs"
                            >
                              إلغاء
                            </button>
                            <button
                              onClick={() => handleSendReply(t.id)}
                              className="px-4 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-black flex items-center gap-1 text-xs"
                            >
                              <Send className="w-3.5 h-3.5" />
                              إرسال الرد المباشر
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setReplyingTicketId(t.id);
                            setReplyText(t.reply || '');
                          }}
                          className="text-emerald-400 hover:underline font-bold text-xs flex items-center gap-1 pt-1"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{t.reply ? 'تعديل الرد' : 'الرد على المستخدم'}</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB 8: STAFF & ASSISTANTS MANAGEMENT */}
      {adminTab === 'staff' && (
        <div className="space-y-4">
          {!isSuperAdmin ? (
            <div className="p-6 text-center text-red-400 bg-[#161F33] rounded-2xl border border-red-500/30 font-bold">
              ⛔ إشعار أمني: إدارة وتعيين وتعديل صلاحيات وتقييم المساعدين مقتصرة حصرياً على المدير الأساسي للنظام.
            </div>
          ) : (
            <>
              {/* Header & New Staff Button */}
              <div className="p-4 rounded-3xl bg-[#161F33] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-[#39FF14]/10 text-[#39FF14] border border-[#39FF14]/20">
                    <UserCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-white text-sm sm:text-base">
                      إدارة الكادر والموظفين والصلاحيات المباشرة
                    </h3>
                    <p className="text-slate-400 text-xs mt-0.5">
                      يمكنك كمدير أساسي تعديل معلومات الموظفين، منح وسحب الصلاحيات، واستعراض إحصائيات الأداء والسجل بضغطة واحدة.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsCreateStaffOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black flex items-center gap-2 shadow-lg shadow-[#39FF14]/20 transition-all text-xs shrink-0 self-start sm:self-center"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>إضافة موظف جديد ➕</span>
                </button>
              </div>

              {/* Create Staff Form Modal / Card */}
              {isCreateStaffOpen && (
                <div className="p-5 rounded-3xl bg-[#161F33] border-2 border-emerald-500/60 shadow-2xl space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h4 className="font-black text-emerald-400 text-sm flex items-center gap-2">
                      <UserPlus className="w-4 h-4" />
                      إضافة موظف/مساعد جديد لكادر الإدارة
                    </h4>
                    <button
                      onClick={() => setIsCreateStaffOpen(false)}
                      className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <form onSubmit={handleCreateStaffSubmit} className="space-y-3.5 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-300 block mb-1 font-bold">اسم الموظف الكامل:</label>
                        <input
                          type="text"
                          required
                          value={staffName}
                          onChange={(e) => setStaffName(e.target.value)}
                          placeholder="مثال: المهندس يوسف العبداللات"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-bold">التسمية الوظيفية:</label>
                        <input
                          type="text"
                          required
                          value={staffJobTitle}
                          onChange={(e) => setStaffJobTitle(e.target.value)}
                          placeholder="مثال: مشرف عقود الملاعب والصيانة"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-300 block mb-1 font-bold">حساب الدخول / اسم المستخدم:</label>
                        <input
                          type="text"
                          required
                          value={staffUsername}
                          onChange={(e) => setStaffUsername(e.target.value)}
                          placeholder="yousef@malaebak.jo"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-right focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-slate-300 block mb-1 font-bold">ساعات الدوام الشفاف:</label>
                        <input
                          type="text"
                          required
                          value={staffWorkHours}
                          onChange={(e) => setStaffWorkHours(e.target.value)}
                          placeholder="08:00 صباحاً - 04:00 مساءً"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">كلمة المرور الخاصة بالمساعد:</label>
                      <input
                        type="text"
                        required
                        value={staffPass}
                        onChange={(e) => setStaffPass(e.target.value)}
                        placeholder="أدخل كلمة مرور قوية"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-right focus:border-[#39FF14] focus:outline-none"
                      />
                    </div>

                    {/* Permissions Selection */}
                    <div className="pt-2">
                      <label className="text-slate-200 font-extrabold block mb-2">
                        تعيين الصلاحيات الممنوحة للموظف:
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                        {[
                          { key: 'manage_requests', label: '📋 إدارة وتفاوض الملاعب' },
                          { key: 'manage_users', label: '👥 إدارة المستخدمين' },
                          { key: 'manage_pitches', label: '🏟️ إدارة الملاعب والأسعار' },
                          { key: 'manage_tournaments', label: '🏆 إدارة البطولات والكؤوس' },
                          { key: 'manage_payments', label: '💳 إدارة الطرق المالية' },
                          { key: 'manage_support', label: '💬 إدارة الدعم الفني' },
                        ].map((p) => {
                          const isChecked = staffPerms.includes(p.key as StaffPermission);
                          return (
                            <label
                              key={p.key}
                              className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer transition-all ${
                                isChecked
                                  ? 'bg-[#39FF14]/10 border-[#39FF14]/50 text-white font-bold'
                                  : 'bg-slate-900/80 border-slate-800 text-slate-400'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => toggleStaffPerm(p.key as StaffPermission)}
                                className="accent-[#39FF14]"
                              />
                              <span>{p.label}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                      <button
                        type="button"
                        onClick={() => setIsCreateStaffOpen(false)}
                        className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700"
                      >
                        إلغاء
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-lg"
                      >
                        اعتماد وإنشاء المساعد
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Staff Cards List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {staffMembers.length === 0 ? (
                  <div className="col-span-2 p-10 text-center text-slate-400 bg-[#161F33] rounded-3xl border border-slate-800">
                    لم يتم تعيين أي مساعدين حالياً. اضغط على زر "إضافة موظف جديد" للبدء.
                  </div>
                ) : (
                  staffMembers.map((stf) => {
                    const rating = stf.rating || 4.9;
                    const job = stf.jobTitle || 'مشرف إداري بالنظام';
                    const shift = stf.workHours || '08:00 صباحاً - 04:00 مساءً';
                    const logs = stf.activityLogs || [];
                    const defaultAvatar = `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`;

                    return (
                      <div
                        key={stf.id}
                        className="p-4 rounded-3xl bg-[#161F33] border border-slate-800/90 shadow-xl hover:border-slate-700 transition-all space-y-3 flex flex-col justify-between"
                      >
                        <div className="space-y-3">
                          {/* Staff Member Top Bar */}
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-3">
                              {/* Clickable Staff Profile Image */}
                              <div
                                onClick={() => setSelectedStaffForStats(stf)}
                                className="relative cursor-pointer group shrink-0"
                                title="اضغط لمشاهدة إحصائيات الموظف والسجل"
                              >
                                <img
                                  src={stf.avatar || defaultAvatar}
                                  alt={stf.name}
                                  className="w-12 h-12 rounded-2xl object-cover border-2 border-[#39FF14]/40 group-hover:border-[#39FF14] transition-all group-hover:scale-105 shadow-md"
                                />
                                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#161F33] animate-pulse" />
                              </div>

                              <div>
                                <div className="flex items-center gap-2">
                                  <h4
                                    onClick={() => setSelectedStaffForStats(stf)}
                                    className="font-extrabold text-white text-sm hover:text-[#39FF14] cursor-pointer transition-colors"
                                  >
                                    {stf.name}
                                  </h4>
                                </div>
                                <span className="text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-md font-bold mt-1 inline-block">
                                  {job}
                                </span>
                              </div>
                            </div>

                            {/* Performance Rating Badge */}
                            <div className="p-2 rounded-xl bg-slate-900/90 border border-slate-800 text-center shrink-0">
                              <span className="text-[9px] text-slate-400 block font-bold">التقييم:</span>
                              <div className="flex items-center gap-1 text-amber-400 font-black text-xs dir-ltr">
                                <Star className="w-3.5 h-3.5 fill-amber-400" />
                                <span>{rating}</span>
                              </div>
                            </div>
                          </div>

                          {/* Work Shift & Username */}
                          <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 grid grid-cols-2 gap-2 text-[11px]">
                            <div>
                              <span className="text-slate-400 block text-[10px] font-bold">ساعات العمل:</span>
                              <span className="text-emerald-400 font-bold flex items-center gap-1 mt-0.5">
                                <Clock className="w-3 h-3 text-emerald-400" />
                                {shift}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[10px] font-bold">حساب الدخول:</span>
                              <span className="text-white font-mono font-bold block mt-0.5 truncate">
                                {stf.username}
                              </span>
                            </div>
                          </div>

                          {/* Permissions Chips */}
                          <div>
                            <span className="text-[10px] text-slate-400 font-extrabold block mb-1">
                              الصلاحيات الممنوحة ({stf.permissions?.length || 0}):
                            </span>
                            <div className="flex flex-wrap gap-1">
                              {stf.permissions && stf.permissions.length > 0 ? (
                                stf.permissions.map((p) => (
                                  <span
                                    key={p}
                                    className="text-[10px] bg-slate-900 text-slate-300 border border-slate-800 px-2 py-0.5 rounded-lg font-bold"
                                  >
                                    {p === 'manage_requests'
                                      ? '📋 الملاعب والتفاوض'
                                      : p === 'manage_users'
                                      ? '👥 المستخدمين'
                                      : p === 'manage_pitches'
                                      ? '🏟️ إدارة الملاعب'
                                      : p === 'manage_tournaments'
                                      ? '🏆 البطولات'
                                      : p === 'manage_payments'
                                      ? '💳 الطرق المالية'
                                      : '💬 الدعم الفني'}
                                  </span>
                                ))
                              ) : (
                                <span className="text-[10px] text-slate-500 italic">لا توجد صلاحيات مخصصة</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons Bar */}
                        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                          <button
                            onClick={() => setSelectedStaffForStats(stf)}
                            className="flex-1 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-extrabold flex items-center justify-center gap-1.5 border border-slate-700/80 text-[11px] transition-all"
                          >
                            <BarChart3 className="w-3.5 h-3.5 text-[#39FF14]" />
                            <span>الإحصائيات والسجل ({logs.length})</span>
                          </button>

                          <button
                            onClick={() => handleOpenEditStaff(stf)}
                            className="py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-extrabold flex items-center gap-1 border border-amber-500/40 text-[11px] transition-all"
                            title="تعديل بيانات ومعلومات الموظف والصلاحيات"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>تعديل</span>
                          </button>

                          {onDeleteStaffMember && (
                            <button
                              onClick={() => {
                                if (confirm(`هل أنت تأكد من حذف الموظف (${stf.name})؟`)) {
                                  onDeleteStaffMember(stf.id);
                                  showToast('تم حذف حساب الموظف من النظام');
                                }
                              }}
                              className="p-2 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/40 border border-red-500/30 transition-all"
                              title="حذف حساب الموظف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </>
          )}

          {/* EDIT STAFF MEMBER MODAL (SUPER ADMIN ONLY) */}
          {editingStaff && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
              <div className="w-full max-w-xl bg-[#161F33] border-2 border-amber-500/60 rounded-3xl p-5 shadow-2xl space-y-4 text-right max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <UserCog className="w-5 h-5 text-amber-400" />
                    <h3 className="font-extrabold text-white text-base">
                      تعديل بيانات وصلاحيات الموظف: <span className="text-amber-400">{editingStaff.name}</span>
                    </h3>
                  </div>
                  <button
                    onClick={() => setEditingStaff(null)}
                    className="p-1.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleEditStaffSubmit} className="space-y-3.5 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">الاسم الكامل:</label>
                      <input
                        type="text"
                        required
                        value={editStaffName}
                        onChange={(e) => setEditStaffName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">التسمية الوظيفية:</label>
                      <input
                        type="text"
                        required
                        value={editStaffJobTitle}
                        onChange={(e) => setEditStaffJobTitle(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">حساب الدخول / البريد:</label>
                      <input
                        type="text"
                        required
                        value={editStaffUsername}
                        onChange={(e) => setEditStaffUsername(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-right focus:border-amber-400 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">ساعات الدوام الشفاف:</label>
                      <input
                        type="text"
                        required
                        value={editStaffWorkHours}
                        onChange={(e) => setEditStaffWorkHours(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:border-amber-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">كلمة المرور:</label>
                      <input
                        type="text"
                        required
                        value={editStaffPass}
                        onChange={(e) => setEditStaffPass(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-right focus:border-amber-400 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1 font-bold">
                        تقييم الأداء (من 1 إلى 5): <span className="text-amber-400 font-extrabold">{editStaffRating} ⭐️</span>
                      </label>
                      <input
                        type="range"
                        min="1"
                        max="5"
                        step="0.1"
                        value={editStaffRating}
                        onChange={(e) => setEditStaffRating(Number(e.target.value))}
                        className="w-full accent-amber-400 mt-2"
                      />
                    </div>
                  </div>

                  {/* Interactive Permissions List */}
                  <div className="pt-2">
                    <label className="text-slate-200 font-extrabold block mb-2">
                      تعديل الصلاحيات الممنوحة:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                      {[
                        { key: 'manage_requests', label: '📋 إدارة وتفاوض الملاعب' },
                        { key: 'manage_users', label: '👥 إدارة المستخدمين' },
                        { key: 'manage_pitches', label: '🏟️ إدارة الملاعب والأسعار' },
                        { key: 'manage_tournaments', label: '🏆 إدارة البطولات والكؤوس' },
                        { key: 'manage_payments', label: '💳 إدارة الطرق المالية' },
                        { key: 'manage_support', label: '💬 إدارة الدعم الفني' },
                      ].map((p) => {
                        const isChecked = editStaffPerms.includes(p.key as StaffPermission);
                        return (
                          <label
                            key={p.key}
                            className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer transition-all ${
                              isChecked
                                ? 'bg-amber-500/10 border-amber-500/50 text-white font-bold'
                                : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => handleToggleStaffPermInEdit(p.key as StaffPermission)}
                              className="accent-amber-400"
                            />
                            <span>{p.label}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setEditingStaff(null)}
                      className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700"
                    >
                      إلغاء
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow-lg"
                    >
                      حفظ التعديلات والصلاحيات ⚡
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* DETAILED STAFF PROFILE & STATISTICS MODAL */}
          {selectedStaffForStats && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
              <div className="w-full max-w-2xl bg-[#161F33] border-2 border-[#39FF14]/50 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-5 text-right max-h-[90vh] overflow-y-auto">
                {/* Profile Header */}
                <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-4">
                    <img
                      src={
                        selectedStaffForStats.avatar ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                      }
                      alt={selectedStaffForStats.name}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-[#39FF14] shadow-xl"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-white text-lg">
                          {selectedStaffForStats.name}
                        </h3>
                        <span className="text-[10px] bg-emerald-500/20 text-[#39FF14] border border-emerald-500/40 px-2.5 py-0.5 rounded-full font-black">
                          متواجد على رأس عمله 🟢
                        </span>
                      </div>
                      <p className="text-slate-300 text-xs font-bold mt-0.5">
                        {selectedStaffForStats.jobTitle || 'مشرف إداري بالنظام'}
                      </p>
                      <div className="flex items-center gap-3 text-slate-400 text-[11px] mt-1 font-mono">
                        <span>ساعات الدوام: <strong className="text-emerald-400">{selectedStaffForStats.workHours}</strong></span>
                        <span>•</span>
                        <span>الحساب: <strong className="text-white">{selectedStaffForStats.username}</strong></span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedStaffForStats(null)}
                    className="p-2 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Key Performance Indicators (4 Cards) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
                    <span className="text-slate-400 text-[10px] block font-bold">تقييم الأداء العام:</span>
                    <strong className="text-amber-400 text-lg font-black mt-0.5 block dir-ltr">
                      ⭐️ {selectedStaffForStats.rating || 5.0} / 5
                    </strong>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
                    <span className="text-slate-400 text-[10px] block font-bold">المهام المنجزة:</span>
                    <strong className="text-[#39FF14] text-lg font-black mt-0.5 block">
                      {selectedStaffForStats.tasksCompletedCount || (selectedStaffForStats.activityLogs?.length || 12)} عملية
                    </strong>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
                    <span className="text-slate-400 text-[10px] block font-bold">الجوائز والأوسمة:</span>
                    <strong className="text-purple-400 text-lg font-black mt-0.5 block">
                      {selectedStaffForStats.achievementsCount || 5} أوسمة 🏆
                    </strong>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
                    <span className="text-slate-400 text-[10px] block font-bold">ساعات الالتزام:</span>
                    <strong className="text-blue-400 text-lg font-black mt-0.5 block">
                      100% شفاف
                    </strong>
                  </div>
                </div>

                {/* Direct Toggle Permissions Section */}
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
                  <h4 className="font-extrabold text-white text-xs flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[#39FF14]" />
                    الصلاحيات الممنوحة (اضغط على الصلاحية لمنحها أو سحبها فوراً):
                  </h4>
                  <div className="flex flex-wrap gap-1.5 text-[11px]">
                    {[
                      { key: 'manage_requests', label: '📋 إدارة الملاعب والتفاوض' },
                      { key: 'manage_users', label: '👥 إدارة اللاعبين' },
                      { key: 'manage_pitches', label: '🏟️ إدارة الملاعب والأسعار' },
                      { key: 'manage_tournaments', label: '🏆 إدارة البطولات' },
                      { key: 'manage_payments', label: '💳 الطرق المالية' },
                      { key: 'manage_support', label: '💬 الدعم الفني' },
                    ].map((p) => {
                      const isGranted = (selectedStaffForStats.permissions || []).includes(p.key as StaffPermission);
                      return (
                        <button
                          key={p.key}
                          onClick={() => handleTogglePermissionDirectly(selectedStaffForStats.id, p.key as StaffPermission)}
                          className={`px-3 py-1.5 rounded-xl border text-[11px] font-bold flex items-center gap-1.5 transition-all ${
                            isGranted
                              ? 'bg-[#39FF14]/20 border-[#39FF14] text-[#39FF14]'
                              : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300'
                          }`}
                        >
                          {isGranted ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                          <span>{p.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Add New Activity Log Directly */}
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2.5">
                  <h4 className="font-extrabold text-emerald-400 text-xs flex items-center gap-1.5">
                    <PlusCircle className="w-4 h-4" />
                    تسجيل إنجاز أو نشاط مباشر لمسيرة الموظف:
                  </h4>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <select
                      value={newActivityActionType}
                      onChange={(e) =>
                        setNewActivityActionType(
                          e.target.value as 'موافقة طلب' | 'رد دعم فني' | 'تفاوض ملعب' | 'تعديل سعر' | 'حظر/تفعيل' | 'إنشاء بطولة' | 'تعديل لاعب'
                        )
                      }
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs font-bold focus:outline-none shrink-0"
                    >
                      <option value="موافقة طلب">موافقة طلب ملعب</option>
                      <option value="رد دعم فني">رد دعم فني</option>
                      <option value="تفاوض ملعب">تفاوض شروط ملعب</option>
                      <option value="تعديل سعر">تعديل أسعار</option>
                      <option value="حظر/تفعيل">حظر / تفعيل حساب</option>
                      <option value="إنشاء بطولة">إنشاء بطولة جديدة</option>
                      <option value="تعديل لاعب">تعديل بيانات لاعب</option>
                    </select>

                    <input
                      type="text"
                      value={newActivityDesc}
                      onChange={(e) => setNewActivityDesc(e.target.value)}
                      placeholder="وصف الإنجاز أو العملية..."
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-[#39FF14]"
                    />

                    <button
                      onClick={() => handleAddActivityLog(selectedStaffForStats.id)}
                      className="px-4 py-2 rounded-xl bg-[#39FF14] text-slate-950 font-black hover:bg-[#32e012] text-xs shrink-0"
                    >
                      تسجيل الإنجاز 📝
                    </button>
                  </div>
                </div>

                {/* Activity Logs History List */}
                <div className="space-y-2">
                  <h4 className="font-extrabold text-white text-xs flex items-center gap-2">
                    <Activity className="w-4 h-4 text-amber-400" />
                    سجل العمليات والإنجازات اليومية ({(selectedStaffForStats.activityLogs || []).length} سجلات):
                  </h4>

                  <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 max-h-52 overflow-y-auto space-y-2">
                    {(selectedStaffForStats.activityLogs || []).length === 0 ? (
                      <p className="text-slate-500 text-xs text-center py-4">لا توجد عمليات مسجلة حتى الآن.</p>
                    ) : (
                      selectedStaffForStats.activityLogs?.map((lg) => (
                        <div
                          key={lg.id}
                          className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs gap-2"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] bg-emerald-500/20 text-[#39FF14] border border-emerald-500/40 px-2 py-0.5 rounded-md font-extrabold shrink-0">
                              [{lg.actionType}]
                            </span>
                            <span className="text-slate-200 font-bold">{lg.description}</span>
                          </div>
                          <span className="text-[10px] text-slate-500 font-mono shrink-0">{lg.timestamp}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="flex justify-between items-center pt-3 border-t border-slate-800">
                  <button
                    onClick={() => {
                      const stf = selectedStaffForStats;
                      setSelectedStaffForStats(null);
                      handleOpenEditStaff(stf);
                    }}
                    className="px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 text-xs font-extrabold flex items-center gap-1.5"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>تعديل الموظف والصلاحيات</span>
                  </button>

                  <button
                    onClick={() => setSelectedStaffForStats(null)}
                    className="px-5 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700 text-xs"
                  >
                    إغلاق النافذة
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 8: TEAMS & CLUBS COMMUNITY MANAGEMENT */}
      {adminTab === 'teams' && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-[#161F33] border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-2xl bg-[#39FF14]/10 text-[#39FF14] border border-[#39FF14]/20">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-sm">إدارة وتراخيص الفرق والأندية ومراقبة المحادثات</h3>
                <p className="text-slate-400 text-[11px]">التحكم بالفرق، قفل الشات الداخلي للمجموعات المخالفة، حظر اللاعبين، وتفتيش السجلات</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold shrink-0">
              <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
                إجمالي الفرق والأندية: <strong className="text-[#39FF14]">{teams.length}</strong>
              </span>
            </div>
          </div>

          {/* Teams & Clubs Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {teams.length === 0 ? (
              <div className="col-span-full p-12 text-center bg-[#161F33] rounded-3xl border border-slate-800 text-slate-400">
                لا توجد فرق أو أندية مسجلة حالياً للنظام.
              </div>
            ) : (
              teams.map((tm) => (
                <div
                  key={tm.id}
                  className="p-4 rounded-3xl bg-[#161F33] border border-slate-800 shadow-xl space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-start gap-3">
                      <img
                        src={tm.logo}
                        alt={tm.name}
                        className="w-12 h-12 rounded-2xl object-cover border border-[#39FF14]/40 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span
                            className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${
                              tm.type === 'club'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                : 'bg-emerald-500/20 text-[#39FF14] border-emerald-500/30'
                            }`}
                          >
                            {tm.type === 'club' ? 'نادي رسمي 🏛️' : 'فريق خماسي ⚽'}
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold">{tm.city}</span>
                        </div>
                        <h4 className="font-extrabold text-white text-sm truncate mt-1">{tm.name}</h4>
                        <p className="text-[10px] text-slate-400">
                          المؤسس: <strong className="text-slate-200">{tm.founderName}</strong>
                        </p>
                      </div>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-[11px] text-slate-300">
                      <span>الأعضاء: <strong className="text-white font-extrabold">{tm.members.length}</strong></span>
                      <span>الرسائل: <strong className="text-amber-400 font-extrabold">{tm.chatMessages.length}</strong></span>
                      <span className={tm.isChatLocked ? 'text-red-400 font-bold' : 'text-[#39FF14] font-bold'}>
                        {tm.isChatLocked ? 'الشات مقفل 🔒' : 'الشات مفتوح ✅'}
                      </span>
                    </div>
                  </div>

                  {/* Actions for Admin */}
                  <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-1.5 text-xs font-bold">
                    <button
                      onClick={() => setSelectedTeamForAdminChat(tm)}
                      className="py-2 px-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 flex items-center justify-center gap-1"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                      <span>سجل الشات</span>
                    </button>

                    <button
                      onClick={() => {
                        if (onToggleLockTeamChatByAdmin) {
                          onToggleLockTeamChatByAdmin(tm.id);
                          showToast(`تم ${tm.isChatLocked ? 'فتح' : 'قفل'} شات الفريق (${tm.name}) بنجاح! 🔒`);
                        }
                      }}
                      className={`py-2 px-2 rounded-xl border flex items-center justify-center gap-1 font-extrabold ${
                        tm.isChatLocked
                          ? 'bg-emerald-500/20 text-[#39FF14] border-emerald-500/40 hover:bg-emerald-500/30'
                          : 'bg-red-500/20 text-red-400 border-red-500/40 hover:bg-red-500/30'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{tm.isChatLocked ? 'فتح الشات' : 'قفل الشات'}</span>
                    </button>

                    <button
                      onClick={() => {
                        if (onDeleteTeamByAdmin) {
                          if (confirm(`هل أنت تأكد من إلغاء وحذف فريق (${tm.name}) نهائياً من النظام؟`)) {
                            onDeleteTeamByAdmin(tm.id);
                            showToast(`تم حذف فريق (${tm.name}) بنجاح.`);
                          }
                        }
                      }}
                      className="col-span-2 py-2 px-2 rounded-xl bg-red-600/20 text-red-300 border border-red-500/30 hover:bg-red-600/30 flex items-center justify-center gap-1 text-[11px]"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>حذف الفريق أو النادي من النظام 🗑️</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Modal for Inspecting Team Chat History (Admin Oversight) */}
          {selectedTeamForAdminChat && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
              <div className="w-full max-w-xl bg-[#161F33] border-2 border-sky-500 rounded-3xl p-5 shadow-2xl space-y-4 text-right">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-sky-400" />
                    <div>
                      <h4 className="font-extrabold text-white text-sm">
                        رقابة وسجل محادثات فريق: {selectedTeamForAdminChat.name}
                      </h4>
                      <p className="text-[10px] text-slate-400">اطلاع مدير النظام على جميع الرسائل واللاعبين بالمجموعة</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedTeamForAdminChat(null)}
                    className="p-1.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Messages Box */}
                <div className="h-64 overflow-y-auto space-y-2 p-3 bg-slate-950 rounded-2xl border border-slate-800 text-xs dir-rtl">
                  {selectedTeamForAdminChat.chatMessages.length === 0 ? (
                    <p className="text-center text-slate-500 py-16 italic">لا توجد رسائل شات مسجلة في هذا الفريق.</p>
                  ) : (
                    selectedTeamForAdminChat.chatMessages.map((msg) => (
                      <div key={msg.id} className="p-2 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-extrabold text-sky-300">{msg.senderName}</span>
                          <span className="text-slate-500 font-mono">{msg.timestamp}</span>
                        </div>
                        <p className="text-slate-200">{msg.message}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Team Members List inside Admin Inspector */}
                <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <h5 className="font-extrabold text-white text-xs">قائمة الأعضاء وحظر العناصر المخالفة:</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {selectedTeamForAdminChat.members.map((m) => (
                      <div key={m.id} className="p-2 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                        <span className="font-bold text-slate-200">{m.name} ({m.position})</span>
                        {m.role !== 'founder' && onBanPlayerFromTeamByAdmin && (
                          <button
                            onClick={() => {
                              onBanPlayerFromTeamByAdmin(selectedTeamForAdminChat.id, m.userId);
                              showToast(`تم حظر اللاعب (${m.name}) من هذا الفريق.`);
                            }}
                            className="px-2 py-0.5 rounded-md bg-red-500/20 text-red-400 border border-red-500/40 text-[10px] font-bold"
                          >
                            حظر من الفريق ⛔
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end pt-2 border-t border-slate-800">
                  <button
                    onClick={() => setSelectedTeamForAdminChat(null)}
                    className="px-5 py-2 rounded-xl bg-slate-800 text-slate-200 font-bold hover:bg-slate-700 text-xs"
                  >
                    إغلاق المعاينة
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 9: SETTINGS & SECURITY - SUPER ADMIN MASTER CONFIGURATION & CONTROL */}
      {adminTab === 'settings' && (
        <div className="space-y-5">
          {/* Header Banner */}
          <div className="p-4 rounded-3xl bg-[#161F33] border border-[#39FF14]/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-[#39FF14]/10 text-[#39FF14] border border-[#39FF14]/30 shrink-0">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                  مركز تحكم وإعدادات مدير النظام الأساسي (Super Admin Control Hub) 🛡️
                </h3>
                <p className="text-slate-400 text-xs mt-0.5">
                  إمكانية تعديل وتخصيص كل شيء في التطبيق: أرقام الدعم، واتساب الإدارة، بيانات الدخول، الشريط الإعلاني، والشروط.
                </p>
              </div>
            </div>

            <span className="px-3 py-1.5 rounded-full bg-emerald-500/20 text-[#39FF14] border border-emerald-500/40 text-xs font-black shrink-0">
              صلاحية الإدارة العليا المطلقة ⚡
            </span>
          </div>

          {/* Sub Navigation Bar for Settings */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setSettingsSubTab('profile')}
              className={`px-4 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 shrink-0 ${
                settingsSubTab === 'profile'
                  ? 'bg-[#39FF14] text-slate-950 shadow-md font-black'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <UserIcon className="w-4 h-4" />
              <span>بيانات ودخول مدير النظام</span>
            </button>

            <button
              type="button"
              onClick={() => setSettingsSubTab('contacts')}
              className={`px-4 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 shrink-0 ${
                settingsSubTab === 'contacts'
                  ? 'bg-[#39FF14] text-slate-950 shadow-md font-black'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Phone className="w-4 h-4" />
              <span>أرقام التواصل وخطوط الدعم</span>
            </button>

            <button
              type="button"
              onClick={() => setSettingsSubTab('branding')}
              className={`px-4 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 shrink-0 ${
                settingsSubTab === 'branding'
                  ? 'bg-[#39FF14] text-slate-950 shadow-md font-black'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>الإعلانات والشروط والهوية</span>
            </button>

            <button
              type="button"
              onClick={() => setSettingsSubTab('system')}
              className={`px-4 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 shrink-0 ${
                settingsSubTab === 'system'
                  ? 'bg-[#39FF14] text-slate-950 shadow-md font-black'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>إعدادات التشغيل والصيانة</span>
            </button>

            <button
              type="button"
              onClick={() => setSettingsSubTab('payments')}
              className={`px-4 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 shrink-0 ${
                settingsSubTab === 'payments'
                  ? 'bg-[#39FF14] text-slate-950 shadow-md font-black'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>بوابات الدفع والعمولات</span>
            </button>
          </div>

          {/* SUB-TAB 1: SUPER ADMIN CREDENTIALS */}
          {settingsSubTab === 'profile' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Main Form */}
              <div className="lg:col-span-2 p-5 rounded-3xl bg-[#161F33] border border-slate-800 shadow-xl space-y-4">
                <h4 className="font-extrabold text-white text-sm flex items-center gap-2 pb-2 border-b border-slate-800">
                  <Edit3 className="w-4 h-4 text-[#39FF14]" />
                  تحديث بيانات الاعتماد ومعلومات الدخول لمدير النظام:
                </h4>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!adminUsernameInput.trim() || !adminPasswordInput.trim()) {
                      showToast('يرجى إدخال اسم المستخدم وكلمة المرور بشكل صحيح.');
                      return;
                    }

                    if (onUpdateAdminProfile) {
                      onUpdateAdminProfile({
                        name: adminNameInput.trim(),
                        username: adminUsernameInput.trim(),
                        password: adminPasswordInput.trim(),
                        email: adminEmailInput.trim(),
                        avatar: adminAvatarInput,
                      });
                    }

                    if (onAdminPasswordChanged) {
                      onAdminPasswordChanged(adminPasswordInput.trim());
                    }

                    showToast('تم تحديث اسم المستخدم وكلمة المرور وبيانات مدير النظام الأساسي بنجاح! 🔒');
                  }}
                  className="space-y-4 text-xs"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <UserIcon className="w-3.5 h-3.5 text-[#39FF14]" />
                        الاسم الكامل لمدير النظام:
                      </label>
                      <input
                        type="text"
                        value={adminNameInput}
                        onChange={(e) => setAdminNameInput(e.target.value)}
                        placeholder="مدير النظام الأساسي"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-bold transition-all"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-[#39FF14]" />
                        اسم المستخدم / هاتف الدخول:
                      </label>
                      <input
                        type="text"
                        value={adminUsernameInput}
                        onChange={(e) => setAdminUsernameInput(e.target.value)}
                        placeholder="0790000000 أو اسم المستخدم"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-mono dir-ltr text-right transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <Key className="w-3.5 h-3.5 text-amber-400" />
                        كلمة المرور الجديدة للدخول:
                      </label>
                      <div className="relative">
                        <input
                          type={showAdminPassword ? 'text' : 'password'}
                          value={adminPasswordInput}
                          onChange={(e) => setAdminPasswordInput(e.target.value)}
                          placeholder="أدخل كلمة المرور الجديدة"
                          required
                          className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-mono transition-all pl-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowAdminPassword(!showAdminPassword)}
                          className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                        >
                          {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-sky-400" />
                        البريد الإلكتروني الرسمي:
                      </label>
                      <input
                        type="email"
                        value={adminEmailInput}
                        onChange={(e) => setAdminEmailInput(e.target.value)}
                        placeholder="admin@malaebak.jo"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-mono dir-ltr text-right transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 pt-1 border-t border-slate-800">
                    <label className="text-slate-300 block font-bold">اختيار الصورة الشخصية للمدير:</label>
                    <div className="flex items-center gap-2 overflow-x-auto pb-1">
                      {AVATAR_PRESETS.map((av, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setAdminAvatarInput(av)}
                          className={`w-11 h-11 rounded-full border-2 overflow-hidden shrink-0 transition-all ${
                            adminAvatarInput === av ? 'border-[#39FF14] ring-2 ring-[#39FF14]/50 scale-105' : 'border-slate-700 opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={av} alt="Avatar option" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>

                    <input
                      type="url"
                      value={adminAvatarInput}
                      onChange={(e) => setAdminAvatarInput(e.target.value)}
                      placeholder="أو أدخل رابط صورة مباشرة..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white text-[11px] font-mono"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-2xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-xs shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>حفظ وتعتمد بيانات الدخول والملف الشخصي ⚡</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Current Credentials Live Preview Card */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                    <img
                      src={adminAvatarInput || currentUser.avatar}
                      alt="Admin Avatar"
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-[#39FF14] shadow-md"
                    />
                    <div>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-md font-black">
                        مدير النظام الأساسي 👑
                      </span>
                      <h5 className="font-extrabold text-white text-sm mt-1">{adminNameInput || currentUser.name}</h5>
                      <p className="text-[11px] text-slate-400 font-mono">{adminEmailInput}</p>
                    </div>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <h6 className="font-extrabold text-slate-300 text-[11px]">بيانات الدخول المعتمدة حالياً:</h6>

                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between text-slate-300">
                        <span className="text-slate-400 text-[11px]">اسم المستخدم / الهاتف:</span>
                        <strong className="text-[#39FF14] font-mono text-xs dir-ltr">{adminUsernameInput}</strong>
                      </div>

                      <div className="flex items-center justify-between text-slate-300 pt-1.5 border-t border-slate-800/60">
                        <span className="text-slate-400 text-[11px]">كلمة المرور الحالية:</span>
                        <strong className="text-amber-400 font-mono text-xs dir-ltr">
                          {showAdminPassword ? adminPasswordInput : '••••••••'}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between text-slate-300 pt-1.5 border-t border-slate-800/60">
                        <span className="text-slate-400 text-[11px]">حالة الحساب:</span>
                        <span className="text-[#39FF14] font-bold text-[10px]">نشط ومستقر 🟢</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 space-y-1">
                  <div className="font-bold flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" />
                    <span>ملاحظة أمان:</span>
                  </div>
                  <p className="text-slate-400 text-[10px] leading-relaxed">
                    تأكد من الاحتفاظ باسم المستخدم وكلمة المرور الجديدة في مكان آمن لاستخدامهما في عمليات تسجيل الدخول القادمة.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 2: SUPPORT & CONTACT NUMBERS EDITING */}
          {settingsSubTab === 'contacts' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2 p-5 rounded-3xl bg-[#161F33] border border-slate-800 shadow-xl space-y-4">
                <h4 className="font-extrabold text-white text-sm flex items-center gap-2 pb-2 border-b border-slate-800">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  تعديل أرقام التواصل والدعم الفني وموقع الإدارة:
                </h4>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdatePlatformConfig) {
                      onUpdatePlatformConfig({
                        supportPhone: platformPhoneInput,
                        supportWhatsapp: platformWhatsappInput,
                        supportEmail: platformEmailInput,
                        headquartersAddress: platformAddressInput,
                        workingHours: platformHoursInput,
                      });
                    }
                    showToast('تم حفظ وتطبيق أرقام التواصل والدعم الفني بنجاح! 📞');
                  }}
                  className="space-y-4 text-xs"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-blue-400" />
                        رقم هاتف الدعم الفني المباشر:
                      </label>
                      <input
                        type="text"
                        value={platformPhoneInput}
                        onChange={(e) => setPlatformPhoneInput(e.target.value)}
                        placeholder="+962 6 500 0000"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-mono dir-ltr text-right transition-all"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                        رقم واتساب الإدارة والدعم الفوري:
                      </label>
                      <input
                        type="text"
                        value={platformWhatsappInput}
                        onChange={(e) => setPlatformWhatsappInput(e.target.value)}
                        placeholder="+962 7 9123 4567"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-mono dir-ltr text-right transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-sky-400" />
                        البريد الإلكتروني المخصص للدعم:
                      </label>
                      <input
                        type="email"
                        value={platformEmailInput}
                        onChange={(e) => setPlatformEmailInput(e.target.value)}
                        placeholder="support@malaebak.jo"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-mono dir-ltr text-right transition-all"
                      />
                    </div>

                    <div>
                      <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        أوقات عمل مركز خدمة العملاء:
                      </label>
                      <input
                        type="text"
                        value={platformHoursInput}
                        onChange={(e) => setPlatformHoursInput(e.target.value)}
                        placeholder="يومياً من 8:00 صباحاً حتى 2:00 بعد منتصف الليل"
                        required
                        className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-bold transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-purple-400" />
                      عنوان المقر والإدارة الرئيسية المعتمد:
                    </label>
                    <input
                      type="text"
                      value={platformAddressInput}
                      onChange={(e) => setPlatformAddressInput(e.target.value)}
                      placeholder="عمان - شارع المدينة المنورة - مجمع الملاعب..."
                      required
                      className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-bold transition-all"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-2xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-xs shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>حفظ وتطبيق أرقام الدعم لكافة المستخدمين ⚡</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Preview Box */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3.5">
                <h5 className="font-extrabold text-white text-xs flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Eye className="w-4 h-4 text-[#39FF14]" />
                  معاينة نافذة الدعم المباشر كما تظهر للمستخدم:
                </h5>

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <Building2 className="w-4 h-4" />
                    <span>خطوط التواصل المباشر 🇯🇴</span>
                  </div>

                  <div className="space-y-2">
                    <div className="p-2.5 rounded-xl bg-emerald-600 text-white flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>واتساب الإدارة</span>
                      </span>
                      <span className="font-mono text-[11px] dir-ltr font-bold">{platformWhatsappInput}</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-blue-600 text-white flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5" />
                        <span>الهاتف المباشر</span>
                      </span>
                      <span className="font-mono text-[11px] dir-ltr font-bold">{platformPhoneInput}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 space-y-1 text-[11px] text-slate-300">
                    <p className="text-slate-400 font-bold">المقر الرئيسي:</p>
                    <p className="text-white font-medium">{platformAddressInput}</p>
                    <p className="text-[#39FF14] text-[10px] font-mono pt-1">🕒 {platformHoursInput}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 3: BRANDING, ANNOUNCEMENTS & TERMS */}
          {settingsSubTab === 'branding' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2 p-5 rounded-3xl bg-[#161F33] border border-slate-800 shadow-xl space-y-4">
                <h4 className="font-extrabold text-white text-sm flex items-center gap-2 pb-2 border-b border-slate-800">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  تعديل اسم المنصة، الشريط الإعلاني العلوي والشروط والأحكام:
                </h4>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (onUpdatePlatformConfig) {
                      onUpdatePlatformConfig({
                        appName: platformAppNameInput,
                        announcementBanner: platformBannerInput,
                        termsAndConditions: platformTermsInput,
                        privacyPolicy: platformPrivacyInput,
                        facebookUrl: platformFacebookInput,
                        instagramUrl: platformInstagramInput,
                        tiktokUrl: platformTiktokInput,
                      });
                    }
                    showToast('تم تحديث هوية المنصة والإعلانات والشروط القانونية بنجاح! 📢');
                  }}
                  className="space-y-4 text-xs"
                >
                  <div>
                    <label className="text-slate-300 block mb-1.5 font-bold">عنوان واسم المنصة والتطبيق:</label>
                    <input
                      type="text"
                      value={platformAppNameInput}
                      onChange={(e) => setPlatformAppNameInput(e.target.value)}
                      placeholder="ملعبك - منصة حجز الملاعب والرياضة..."
                      required
                      className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-bold transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1.5 font-bold flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      نص الشريط الإعلاني والتنبيه العاجل العلوي (Announcement Banner):
                    </label>
                    <input
                      type="text"
                      value={platformBannerInput}
                      onChange={(e) => setPlatformBannerInput(e.target.value)}
                      placeholder="⚽ شبكة ملاعب الأردن المباشرة 🇯🇴..."
                      required
                      className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl px-3.5 py-2.5 text-white font-bold transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1.5 font-bold">شروط وأحكام الحجز والاستخدام (Terms & Conditions):</label>
                    <textarea
                      rows={3}
                      value={platformTermsInput}
                      onChange={(e) => setPlatformTermsInput(e.target.value)}
                      placeholder="اكتب شروط وأحكام الحجز..."
                      className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl p-3 text-white font-medium transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1.5 font-bold">سياسة الخصوصية والاسترجاع (Privacy Policy):</label>
                    <textarea
                      rows={2}
                      value={platformPrivacyInput}
                      onChange={(e) => setPlatformPrivacyInput(e.target.value)}
                      placeholder="اكتب سياسة الخصوصية..."
                      className="w-full bg-slate-900 border border-slate-700 focus:border-[#39FF14] rounded-xl p-3 text-white font-medium transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                    <div>
                      <label className="text-slate-400 block mb-1 text-[11px]">رابط فيس بوك:</label>
                      <input
                        type="url"
                        value={platformFacebookInput}
                        onChange={(e) => setPlatformFacebookInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-[11px] dir-ltr"
                      />
                    </div>
                    <div>
                      <label className="text-slate-400 block mb-1 text-[11px]">رابط انستغرام:</label>
                      <input
                        type="url"
                        value={platformInstagramInput}
                        onChange={(e) => setPlatformInstagramInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-[11px] dir-ltr"
                      />
                    </div>
                    <div>
                      <label className="text-slate-400 block mb-1 text-[11px]">رابط تيك توك:</label>
                      <input
                        type="url"
                        value={platformTiktokInput}
                        onChange={(e) => setPlatformTiktokInput(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-white text-[11px] dir-ltr"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-2xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-xs shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>حفظ ونشر الهوية والشريط الإعلاني ⚡</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Banner Live Preview */}
              <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3.5">
                <h5 className="font-extrabold text-white text-xs flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Eye className="w-4 h-4 text-amber-400" />
                  معاينة الشريط الإعلاني أعلى التطبيق:
                </h5>

                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-[#1E293B] to-slate-900 border border-[#39FF14]/40 shadow-lg text-white space-y-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#39FF14] animate-spin" />
                    <span className="text-xs font-black">{platformBannerInput}</span>
                  </div>
                  <p className="text-[10px] text-slate-300">هذا النص يظهر أعلى واجهة التطبيق الرئيسية مباشرةً لجميع الزوار.</p>
                </div>
              </div>
            </div>
          )}

          {/* SUB-TAB 4: SYSTEM FLAGS & MAINTENANCE MODE */}
          {settingsSubTab === 'system' && (
            <div className="p-5 rounded-3xl bg-[#161F33] border border-slate-800 shadow-xl space-y-4 max-w-3xl">
              <h4 className="font-extrabold text-white text-sm flex items-center gap-2 pb-2 border-b border-slate-800">
                <Sliders className="w-4 h-4 text-purple-400" />
                تحكم التشغيل، الصيانة وحسابات الزوار:
              </h4>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (onUpdatePlatformConfig) {
                    onUpdatePlatformConfig({
                      enableGuestBooking: platformGuestBooking,
                      maintenanceMode: platformMaintenance,
                    });
                  }
                  showToast('تم تحديث إعدادات النظام التشغيلية بنجاح! ⚙️');
                }}
                className="space-y-4 text-xs"
              >
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                  <div>
                    <h5 className="font-extrabold text-white text-xs">تفعيل حجز وتصفح الزوار بدون تسجيل حساب</h5>
                    <p className="text-slate-400 text-[11px] mt-0.5">
                      السماح للضيوف بالبحث عن المباريات وتصفح الملاعب بدون الحاجة لتسجيل دخول مسبق.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPlatformGuestBooking(!platformGuestBooking)}
                    className={`w-12 h-6 rounded-full transition-colors relative shrink-0 ${
                      platformGuestBooking ? 'bg-[#39FF14]' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-slate-950 transition-transform absolute top-0.5 ${
                        platformGuestBooking ? 'right-6' : 'right-0.5'
                      }`}
                    />
                  </button>
                </div>

                <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-between gap-3">
                  <div>
                    <h5 className="font-extrabold text-red-400 text-xs">وضع الصيانة المؤقت للمنصة (Maintenance Mode)</h5>
                    <p className="text-slate-400 text-[11px] mt-0.5">
                      عرض تنبيه صيانة للمستخدمين لمنع الحجوزات الجديدة أثناء التحديثات السريعة.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPlatformMaintenance(!platformMaintenance)}
                    className={`w-12 h-6 rounded-full transition-colors relative shrink-0 ${
                      platformMaintenance ? 'bg-red-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                        platformMaintenance ? 'right-6' : 'right-0.5'
                      }`}
                    />
                  </button>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-2xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-xs shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>حفظ إعدادات النظام التشغيلية ⚡</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* SUB-TAB 5: PAYMENT GATEWAYS & COMMISSIONS */}
          {settingsSubTab === 'payments' && (
            <div className="p-5 rounded-3xl bg-[#161F33] border border-slate-800 shadow-xl space-y-4">
              <h4 className="font-extrabold text-white text-sm flex items-center gap-2 pb-2 border-b border-slate-800">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                تعديل وسائل الدفع الإلكتروني والعمولات المالية الأردنية:
              </h4>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (onUpdatePaymentConfig) {
                    onUpdatePaymentConfig(localPayment);
                  }
                  showToast('تم حفظ إعدادات بوابات الدفع الإلكتروني بنجاح! 💳');
                }}
                className="space-y-4 text-xs"
              >
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-slate-300 block mb-1 font-bold">اسم مستعار كليك (CliQ Alias):</label>
                    <input
                      type="text"
                      value={localPayment.cliqAlias}
                      onChange={(e) => setLocalPayment({ ...localPayment, cliqAlias: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-left dir-ltr"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold">رقم محفظة زين كاش (Zain Cash):</label>
                    <input
                      type="text"
                      value={localPayment.zainCashPhone}
                      onChange={(e) => setLocalPayment({ ...localPayment, zainCashPhone: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-left dir-ltr"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold">رمز إيفواتيركم (eFAWATEERcom Code):</label>
                    <input
                      type="text"
                      value={localPayment.efawateerCode}
                      onChange={(e) => setLocalPayment({ ...localPayment, efawateerCode: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-left dir-ltr"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div>
                    <label className="text-slate-300 block mb-1 font-bold">نسبة عمولة التطبيق (%):</label>
                    <input
                      type="number"
                      value={localPayment.commissionRate}
                      onChange={(e) => setLocalPayment({ ...localPayment, commissionRate: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold">رسوم المباراة الافتراضية (JOD):</label>
                    <input
                      type="number"
                      value={localPayment.defaultMatchFee}
                      onChange={(e) => setLocalPayment({ ...localPayment, defaultMatchFee: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1 font-bold">نسبة الضريبة والخدمات (%):</label>
                    <input
                      type="number"
                      value={localPayment.taxPercent}
                      onChange={(e) => setLocalPayment({ ...localPayment, taxPercent: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-2xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-xs shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>حفظ إعدادات بوابات الدفع والعمولات ⚡</span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
