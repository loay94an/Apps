import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SportType } from '../types';
import { getSportTheme } from '../lib/sportThemes';
import { Trophy, Check, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  selectedSport: SportType;
  onSelectSport: (sport: SportType) => void;
}

export const SPORTS_LIST: { id: SportType; label: string; icon: string; count: number; desc: string }[] = [
  { id: 'football', label: 'كرة القدم ⚽', icon: '⚽', count: 18, desc: 'ملاعب سداسية وخماسية في عمان وإربد والزرقاء' },
  { id: 'padel', label: 'بادل 🎾', icon: '🎾', count: 9, desc: 'ملاعب بادل زجاجية فاخرة مع مضارب مجانية' },
  { id: 'basketball', label: 'كرة السلة 🏀', icon: '🏀', count: 6, desc: 'صالات خشبية وملاعب خارجية مكشوفة' },
  { id: 'volleyball', label: 'كرة الطائرة 🏐', icon: '🏐', count: 4, desc: 'ملاعب شاطئية وأرضيات مطاطية' },
];

export const SportSelectorBottomSheet: React.FC<Props> = ({
  isOpen,
  onClose,
  selectedSport,
  onSelectSport,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm">
          {/* Backdrop Click */}
          <div className="absolute inset-0" onClick={onClose} />

          {/* Bottom Sheet Drawer */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative z-10 w-full max-w-lg rounded-t-3xl bg-[#1E293B] border-t border-amber-400/30 p-6 shadow-2xl"
          >
            {/* Handle Bar */}
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-slate-600" />

            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-400" />
                  اختر الرياضة وطابع التطبيق
                </h3>
                <p className="text-xs text-slate-400">تتغير ألوان ومظهر التطبيق والملاعب تلقائياً بناءً على الرياضة المحددة</p>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 my-3">
              {SPORTS_LIST.map((sport) => {
                const isSelected = selectedSport === sport.id;
                const theme = getSportTheme(sport.id);
                return (
                  <button
                    key={sport.id}
                    onClick={() => {
                      onSelectSport(sport.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition-all text-right ${
                      isSelected
                        ? `${theme.bannerBg} ${theme.bannerBorder} text-white shadow-xl ring-2 ring-white/20 scale-[1.02]`
                        : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl p-2 rounded-xl bg-slate-900/80 border border-slate-700/50">
                        {sport.icon}
                      </span>
                      <div>
                        <div className="font-bold text-sm text-white flex items-center gap-2">
                          {sport.label}
                          {isSelected && (
                            <span className={`text-[10px] ${theme.primaryBtnBg} ${theme.primaryBtnText} px-2 py-0.5 rounded-full font-black`}>
                              الرياضة النشطة ⚡
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-300/80 mt-0.5">{sport.desc}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400 font-mono dir-ltr">{sport.count} ملعب</span>
                      {isSelected && <Check className={`w-5 h-5 ${theme.accentText}`} />}
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={onClose}
              className="mt-4 w-full py-3 rounded-xl bg-slate-800 text-slate-300 font-bold text-sm hover:bg-slate-700"
            >
              إغلاق
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

