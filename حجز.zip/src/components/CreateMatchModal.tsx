import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Pitch, SportType, User, OpenMatch } from '../types';
import { PlusCircle, ShieldCheck, Video, DollarSign, Calendar, Clock, MapPin, CheckCircle2, Lock, Share2, Copy, X, Sparkles, ChevronRight, Users } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  pitches: Pitch[];
  selectedSport: SportType;
  currentUser: User;
  onCreateMatch: (match: Omit<OpenMatch, 'id'>) => void;
}

export const CreateMatchModal: React.FC<Props> = ({
  isOpen,
  onClose,
  pitches,
  selectedSport,
  currentUser,
  onCreateMatch,
}) => {
  const [step, setStep] = useState<number>(1); // 1: Choose Pitch, 2: Date & Add-ons, 3: Split Bill & Confirm
  const [selectedPitch, setSelectedPitch] = useState<Pitch | null>(pitches[0] || null);
  const [matchTitle, setMatchTitle] = useState<string>('مباراة التحدي والخماسي ⚽');
  const [selectedDate, setSelectedDate] = useState<string>('اليوم');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('08:00 م - 09:00 م');
  const [playersCount, setPlayersCount] = useState<number>(10);

  // Add-on Switches
  const [requestReferee, setRequestReferee] = useState<boolean>(false);
  const [requestVideo, setRequestVideo] = useState<boolean>(false);
  const [enableSplitBill, setEnableSplitBill] = useState<boolean>(true);

  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [createdSuccess, setCreatedSuccess] = useState<boolean>(false);

  // Level requirements: Level 10 for Referee, Level 20 for Video
  const refereeUnlocked = currentUser.level >= 10;
  const videoUnlocked = currentUser.level >= 20;

  const filteredPitches = pitches.filter((p) => p.sports.includes(selectedSport));

  // Financial calculations in JOD
  const basePitchFee = selectedPitch ? selectedPitch.hourlyRate : 30;
  const refereeFee = requestReferee ? 15 : 0;
  const videoFee = requestVideo ? 20 : 0;
  const totalCostJod = basePitchFee + refereeFee + videoFee;
  const costPerPlayerJod = enableSplitBill ? Math.round((totalCostJod / playersCount) * 100) / 100 : totalCostJod;

  const handleFinishCreate = () => {
    if (!selectedPitch) return;

    onCreateMatch({
      title: matchTitle,
      sport: selectedSport,
      pitchId: selectedPitch.id,
      pitchName: selectedPitch.name,
      city: selectedPitch.city,
      district: selectedPitch.district,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      totalPlayersNeeded: playersCount,
      joinedPlayersCount: 1,
      missingPositions: ['مطلوب لاعبين', 'تكميلة سريعة'],
      costPerPlayer: costPerPlayerJod,
      totalCost: totalCostJod,
      organizerName: currentUser.name,
      organizerAvatar: currentUser.avatar,
      organizerLevel: currentUser.level,
      refereeRequested: requestReferee,
      videoRequested: requestVideo,
      splitBillEnabled: enableSplitBill,
      status: 'open',
      joinedPlayers: [
        {
          id: currentUser.id,
          name: currentUser.name,
          avatar: currentUser.avatar,
          level: currentUser.level,
          position: currentUser.preferredPosition || 'صانع ألعاب',
          paid: true,
        },
      ],
    });

    setCreatedSuccess(true);
    setTimeout(() => {
      setCreatedSuccess(false);
      onClose();
      setStep(1);
    }, 2800);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-40 pb-16 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-[#1E293B] border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <PlusCircle className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-extrabold text-white">إنشاء حجز مباراة + خدمات إضافية</h2>
                  <p className="text-xs text-slate-400">احجز الملعب واطلب حكم معتمد وتوثيق فيديو وتقسيم الفاتورة</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Header */}
            <div className="grid grid-cols-3 bg-slate-900/80 border-b border-slate-800 text-xs font-bold text-center">
              <button
                onClick={() => setStep(1)}
                className={`py-2.5 border-b-2 transition-all ${step === 1 ? 'border-amber-500 text-amber-400 bg-amber-500/10' : 'border-transparent text-slate-400'}`}
              >
                1. اختيار الملعب
              </button>
              <button
                onClick={() => selectedPitch && setStep(2)}
                className={`py-2.5 border-b-2 transition-all ${step === 2 ? 'border-amber-500 text-amber-400 bg-amber-500/10' : 'border-transparent text-slate-400'}`}
              >
                2. التوقيت والخدمات
              </button>
              <button
                onClick={() => selectedPitch && setStep(3)}
                className={`py-2.5 border-b-2 transition-all ${step === 3 ? 'border-amber-500 text-amber-400 bg-amber-500/10' : 'border-transparent text-slate-400'}`}
              >
                3. Split Bill وتأكيد
              </button>
            </div>

            {/* Body Wizard */}
            <div className="flex-1 overflow-y-auto p-4">
              {createdSuccess ? (
                <div className="p-8 text-center space-y-4 my-6">
                  <CheckCircle2 className="w-16 h-16 text-[#39FF14] mx-auto animate-bounce" />
                  <h3 className="text-xl font-extrabold text-white">تم نشر المباراة وحجز الملعب بنجاح! ⚽</h3>
                  <p className="text-sm text-slate-300">
                    تم إنشاء رابط الانضمام ورابط تقسيم الفاتورة. يمكنك الآن مشاركتها مع أصدقائك عبر الواتساب.
                  </p>
                  <div className="p-3 rounded-xl bg-slate-900 border border-[#39FF14]/40 font-mono text-xs text-[#39FF14] dir-ltr">
                    https://malaebak.jo/match/mtc_99872
                  </div>
                </div>
              ) : step === 1 ? (
                /* Step 1: Select Pitch */
                <div className="space-y-3">
                  <h3 className="text-sm font-bold text-white mb-2">اختر الملعب المفضل في الأردن:</h3>
                  {filteredPitches.map((pitch) => (
                    <div
                      key={pitch.id}
                      onClick={() => setSelectedPitch(pitch)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-3.5 ${
                        selectedPitch?.id === pitch.id
                          ? 'bg-amber-500/15 border-amber-500 shadow-lg shadow-amber-500/10'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <img src={pitch.image} alt={pitch.name} className="w-20 h-16 rounded-xl object-cover" referrerPolicy="no-referrer" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-bold text-white truncate">{pitch.name}</h4>
                          <span className="text-sm font-extrabold text-[#39FF14]">{pitch.hourlyRate} JOD/ساعة</span>
                        </div>
                        <div className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span>{pitch.city} - {pitch.district}</span>
                        </div>
                        <div className="text-[10px] text-amber-300/80 bg-amber-500/10 px-2 py-0.5 rounded mt-1.5 inline-block">
                          {pitch.surfaceType}
                        </div>
                      </div>
                    </div>
                  ))}

                  <button
                    disabled={!selectedPitch}
                    onClick={() => setStep(2)}
                    className="w-full mt-4 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/30"
                  >
                    <span>التالي: اختيار موعد المباراة والخدمات</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              ) : step === 2 ? (
                /* Step 2: Date, Time & Add-on Switches */
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1">اسم أو عنوان المباراة:</label>
                    <input
                      type="text"
                      value={matchTitle}
                      onChange={(e) => setMatchTitle(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Date & Time Selectors */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">تاريخ الحجز:</label>
                      <select
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      >
                        <option value="اليوم">اليوم (2026-08-06)</option>
                        <option value="غداً">غداً (2026-08-07)</option>
                        <option value="الجمعة">الجمعة (2026-08-08)</option>
                        <option value="السبت">السبت (2026-08-09)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-300 block mb-1">الفترة الزمنية:</label>
                      <select
                        value={selectedTimeSlot}
                        onChange={(e) => setSelectedTimeSlot(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      >
                        <option value="06:00 م - 07:00 م">06:00 م - 07:00 م</option>
                        <option value="07:00 م - 08:00 م">07:00 م - 08:00 م</option>
                        <option value="08:00 م - 09:00 م">08:00 م - 09:00 م</option>
                        <option value="09:00 م - 10:00 م">09:00 م - 10:00 م</option>
                        <option value="10:00 م - 11:00 م">10:00 م - 11:00 م</option>
                      </select>
                    </div>
                  </div>

                  {/* Add-on Switches System (نظام الخدمات الإضافية والمستويات) */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                    <h4 className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      الخدمات والميزات الإضافية (Add-ons System):
                    </h4>

                    {/* Switch 1: Certified Referee */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/80 border border-slate-700/80">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
                          <ShieldCheck className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            طلب حكم معتمد للمباراة 🏁
                            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-mono">
                              +15 JOD
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            يتولى إدارة المباراة وحساب الأخطاء والإنذارات
                          </p>
                        </div>
                      </div>

                      {refereeUnlocked ? (
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={requestReferee}
                            onChange={(e) => setRequestReferee(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#39FF14]"></div>
                        </label>
                      ) : (
                        <div className="flex items-center gap-1 text-[10px] text-red-400 bg-red-500/10 border border-red-500/30 px-2 py-1 rounded-lg">
                          <Lock className="w-3 h-3" />
                          مغلق (يتطلب Level 10)
                        </div>
                      )}
                    </div>

                    {/* Switch 2: Video Recording */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/80 border border-slate-700/80">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
                          <Video className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            طلب تصوير وتوثيق فيديو HD للمباراة 🎥
                            <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.2 rounded font-mono">
                              +20 JOD
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            كاميرا عالية الدقة وتوثيق أفضل اللقطات والملخصات
                          </p>
                        </div>
                      </div>

                      {videoUnlocked ? (
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={requestVideo}
                            onChange={(e) => setRequestVideo(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#39FF14]"></div>
                        </label>
                      ) : (
                        <div className="flex items-center gap-1 text-[10px] text-red-400 bg-red-500/10 border border-red-500/30 px-2 py-1 rounded-lg">
                          <Lock className="w-3 h-3" />
                          مغلق (يتطلب Level 20)
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setStep(1)}
                      className="w-1/3 py-3 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700"
                    >
                      سابق
                    </button>
                    <button
                      onClick={() => setStep(3)}
                      className="w-2/3 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/20"
                    >
                      التالي: تقسيم الفاتورة Split Bill
                    </button>
                  </div>
                </div>
              ) : (
                /* Step 3: Split Bill & Review */
                <div className="space-y-4">
                  {/* Split Bill Calculator Box */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 border border-[#39FF14]/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-[#39FF14]" />
                        <h4 className="text-sm font-extrabold text-white">حاسبة تقسيم الفاتورة (Split Bill)</h4>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={enableSplitBill}
                          onChange={(e) => setEnableSplitBill(e.target.checked)}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#39FF14]"></div>
                      </label>
                    </div>

                    {enableSplitBill && (
                      <div className="space-y-2 pt-2 border-t border-slate-700/80">
                        <div className="flex items-center justify-between text-xs text-slate-300">
                          <span>عدد اللاعبين المشاركين في التقسيم:</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setPlayersCount((c) => Math.max(2, c - 1))}
                              className="w-7 h-7 rounded-lg bg-slate-700 text-white font-bold"
                            >
                              -
                            </button>
                            <span className="font-extrabold text-white text-sm w-6 text-center">{playersCount}</span>
                            <button
                              onClick={() => setPlayersCount((c) => Math.min(20, c + 1))}
                              className="w-7 h-7 rounded-lg bg-slate-700 text-white font-bold"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 space-y-1 text-xs">
                          <div className="flex justify-between text-slate-400">
                            <span>رسوم الملعب الأساسية ({selectedPitch?.name}):</span>
                            <span>{basePitchFee} JOD</span>
                          </div>
                          {requestReferee && (
                            <div className="flex justify-between text-amber-400">
                              <span>رسوم الحكم المعتمد:</span>
                              <span>+15 JOD</span>
                            </div>
                          )}
                          {requestVideo && (
                            <div className="flex justify-between text-purple-400">
                              <span>رسوم توثيق الفيديو:</span>
                              <span>+20 JOD</span>
                            </div>
                          )}
                          <div className="flex justify-between text-white font-bold pt-1.5 border-t border-slate-800">
                            <span>المجموع الكلي للحجز:</span>
                            <span>{totalCostJod} JOD</span>
                          </div>
                          <div className="flex justify-between text-[#39FF14] font-black text-sm pt-1">
                            <span>حصة كل لاعب تلقائياً:</span>
                            <span>{costPerPlayerJod} JOD / شخص</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Share Invite Code Preview */}
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-300 block">رابط الدعوة وتقسيم الفاتورة للواتساب:</span>
                    <div className="flex items-center justify-between bg-slate-800 p-2 rounded-lg text-xs font-mono text-cyan-300 dir-ltr">
                      <span className="truncate">https://malaebak.jo/match/pay_split?id=99281</span>
                      <button
                        onClick={() => {
                          setCopiedLink(true);
                          setTimeout(() => setCopiedLink(false), 2000);
                        }}
                        className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-sans flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" />
                        {copiedLink ? 'تم النسخ!' : 'نسخ'}
                      </button>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setStep(2)}
                      className="w-1/3 py-3 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700"
                    >
                      سابق
                    </button>
                    <button
                      onClick={handleFinishCreate}
                      className="w-2/3 py-3.5 rounded-xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#39FF14]/30"
                    >
                      تأكيد الحجز والنشر المباشر ({totalCostJod} JOD)
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
