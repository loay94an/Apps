import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { OpenMatch, SportType, User } from '../types';
import { Search, MapPin, Clock, Users, ShieldCheck, Video, DollarSign, UserPlus, CheckCircle2, X, Filter } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  matches: OpenMatch[];
  selectedSport: SportType;
  currentUser: User;
  onJoinMatch: (matchId: string, position: string) => void;
}

export const MatchmakingModal: React.FC<Props> = ({
  isOpen,
  onClose,
  matches,
  selectedSport,
  currentUser,
  onJoinMatch,
}) => {
  const [cityFilter, setCityFilter] = useState<string>('الكل');
  const [selectedMatch, setSelectedMatch] = useState<OpenMatch | null>(null);
  const [chosenPosition, setChosenPosition] = useState<string>('');
  const [joinedSuccessMessage, setJoinedSuccessMessage] = useState<string | null>(null);

  const filteredMatches = matches.filter((m) => {
    const sportMatch = m.sport === selectedSport;
    const cityMatch = cityFilter === 'الكل' || m.city === cityFilter;
    return sportMatch && cityMatch;
  });

  const handleConfirmJoin = () => {
    if (!selectedMatch) return;
    const pos = chosenPosition || 'لاعب عام';
    onJoinMatch(selectedMatch.id, pos);
    setJoinedSuccessMessage(`تم انضمامك بنجاح لمباراة "${selectedMatch.title}" بصفة (${pos})! حصلت على +100 XP ⚡`);
    setTimeout(() => {
      setJoinedSuccessMessage(null);
      setSelectedMatch(null);
    }, 2500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-40 pb-16 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-[#1E293B] border border-cyan-500/40 rounded-3xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Search className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                    إيجاد لعبة - التكميلة والمباريات المفتوحة
                    <span className="text-xs bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-2 py-0.5 rounded-full">
                      {filteredMatches.length} متاحة
                    </span>
                  </h2>
                  <p className="text-xs text-slate-400">انضم لأقرب مباراة تنقصها لاعبين وتقاسم التكلفة فوراً</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* City Filter Pills */}
            <div className="p-3 bg-slate-900/60 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto">
              <Filter className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="text-xs text-slate-400 shrink-0">المدينة:</span>
              {['الكل', 'عمان', 'إربد', 'الزرقاء', 'العقبة', 'السلط'].map((city) => (
                <button
                  key={city}
                  onClick={() => setCityFilter(city)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-all shrink-0 ${
                    cityFilter === city
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {city}
                </button>
              ))}
            </div>

            {/* Main Matches List or Join Detail Drawer */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {joinedSuccessMessage ? (
                <div className="p-6 rounded-2xl bg-[#39FF14]/15 border border-[#39FF14] text-center space-y-3 my-8">
                  <CheckCircle2 className="w-12 h-12 text-[#39FF14] mx-auto animate-bounce" />
                  <h3 className="text-lg font-bold text-white">{joinedSuccessMessage}</h3>
                  <p className="text-xs text-slate-300">تم إرسال إشعار للمنظم وإضافة موعد المباراة لجدولك!</p>
                </div>
              ) : selectedMatch ? (
                /* Selected Match Join Flow */
                <div className="space-y-4">
                  <button
                    onClick={() => setSelectedMatch(null)}
                    className="text-xs text-cyan-400 font-bold hover:underline flex items-center gap-1"
                  >
                    &rarr; العودة لقائمة المباريات
                  </button>

                  <div className="p-4 rounded-2xl bg-slate-900 border border-cyan-500/40 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-base font-bold text-white">{selectedMatch.title}</h3>
                        <div className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                          <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{selectedMatch.pitchName} - {selectedMatch.city} ({selectedMatch.district})</span>
                        </div>
                      </div>
                      <div className="text-left dir-ltr">
                        <span className="text-lg font-black text-[#39FF14]">{selectedMatch.costPerPlayer} JOD</span>
                        <div className="text-[10px] text-slate-400">حصة اللاعب</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-300 bg-slate-800/80 p-2.5 rounded-xl">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-cyan-400" />
                        <span>{selectedMatch.date} ({selectedMatch.timeSlot})</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4 text-cyan-400" />
                        <span>مكتمل {selectedMatch.joinedPlayersCount} من {selectedMatch.totalPlayersNeeded}</span>
                      </div>
                    </div>

                    {/* Missing Positions Tags */}
                    <div>
                      <span className="text-xs font-bold text-slate-300 block mb-1.5">المراكز المطلوبة بالتحديد:</span>
                      <div className="flex flex-wrap gap-2">
                        {selectedMatch.missingPositions.map((pos, idx) => (
                          <button
                            key={idx}
                            onClick={() => setChosenPosition(pos)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                              chosenPosition === pos
                                ? 'bg-[#39FF14] text-slate-950 border-[#39FF14]'
                                : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-500'
                            }`}
                          >
                            {pos}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Add-on badges */}
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                      {selectedMatch.refereeRequested && (
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" />
                          حكم معتمد متوفر
                        </span>
                      )}
                      {selectedMatch.videoRequested && (
                        <span className="text-[10px] bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Video className="w-3 h-3" />
                          تصوير وتوثيق فيديو HD
                        </span>
                      )}
                    </div>

                    {/* Joined Players Roster */}
                    <div className="pt-2">
                      <span className="text-xs font-bold text-slate-300 block mb-2">قائمة اللاعبين المنضمين ({selectedMatch.joinedPlayers.length}):</span>
                      <div className="grid grid-cols-2 gap-2">
                        {selectedMatch.joinedPlayers.map((player) => (
                          <div key={player.id} className="flex items-center gap-2 p-2 rounded-xl bg-slate-800/60 border border-slate-700/50">
                            <img src={player.avatar} alt={player.name} className="w-7 h-7 rounded-full object-cover" referrerPolicy="no-referrer" />
                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-bold text-white truncate">{player.name}</div>
                              <div className="text-[10px] text-slate-400">{player.position}</div>
                            </div>
                            <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">مدفوع</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Confirm Join Button */}
                    <button
                      onClick={handleConfirmJoin}
                      className="w-full py-3.5 rounded-xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#39FF14]/30 transition-transform active:scale-95"
                    >
                      <UserPlus className="w-5 h-5" />
                      تأكيد الانضمام والدفع ({selectedMatch.costPerPlayer} JOD)
                    </button>
                  </div>
                </div>
              ) : filteredMatches.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  لا توجد مباريات مفتوحة حالياً في هذه المدينة لنوع الرياضة المحدد.
                </div>
              ) : (
                /* Matches List */
                filteredMatches.map((match) => (
                  <div
                    key={match.id}
                    className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full font-bold">
                          {match.city} - {match.district}
                        </span>
                        <h3 className="text-base font-bold text-white mt-1.5">{match.title}</h3>
                        <p className="text-xs text-slate-400">{match.pitchName}</p>
                      </div>

                      <div className="text-left dir-ltr">
                        <span className="text-base font-extrabold text-[#39FF14]">{match.costPerPlayer} JOD</span>
                        <span className="text-[10px] text-slate-400 block">لكل لاعب</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-300 bg-slate-800/60 p-2 rounded-xl">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-cyan-400" />
                        <span>{match.date} | {match.timeSlot}</span>
                      </div>
                      <div className="flex items-center gap-1 font-bold text-cyan-300">
                        <Users className="w-3.5 h-3.5" />
                        <span>نقص {match.totalPlayersNeeded - match.joinedPlayersCount} لاعبين</span>
                      </div>
                    </div>

                    {/* Missing Position Pills */}
                    <div className="flex flex-wrap gap-1.5">
                      {match.missingPositions.map((pos, i) => (
                        <span key={i} className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-md">
                          {pos}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                      <div className="flex items-center gap-2">
                        <img src={match.organizerAvatar} alt={match.organizerName} className="w-6 h-6 rounded-full object-cover" referrerPolicy="no-referrer" />
                        <span className="text-xs text-slate-300">المنظم: {match.organizerName} (L{match.organizerLevel})</span>
                      </div>

                      <button
                        onClick={() => setSelectedMatch(match)}
                        className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-xs flex items-center gap-1 transition-all shadow-md shadow-cyan-500/20"
                      >
                        انضمام الآن
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
