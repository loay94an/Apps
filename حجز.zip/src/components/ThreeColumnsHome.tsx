import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, PlusCircle, Trophy, Users, ShieldCheck, Video, DollarSign, Sparkles, ChevronLeft, MapPin, Clock, Star, CheckCircle2, Flame, ArrowRight } from 'lucide-react';
import { SportType, OpenMatch, Tournament, Pitch } from '../types';
import { getSportTheme } from '../lib/sportThemes';

interface Props {
  selectedSport: SportType;
  onOpenMatchmaking: () => void;
  onOpenCreateMatch: () => void;
  onOpenTournaments: () => void;
  openMatchesCount: number;
  tournamentsCount: number;
  openMatches?: OpenMatch[];
  tournaments?: Tournament[];
  pitches?: Pitch[];
  onJoinMatch?: (matchId: string, position: string) => void;
  isDarkMode?: boolean;
  announcementBanner?: string;
}

export const ThreeColumnsHome: React.FC<Props> = ({
  selectedSport,
  onOpenMatchmaking,
  onOpenCreateMatch,
  onOpenTournaments,
  openMatchesCount,
  tournamentsCount,
  openMatches = [],
  tournaments = [],
  pitches = [],
  onJoinMatch,
  isDarkMode = true,
  announcementBanner,
}) => {
  const [joinedNotice, setJoinedNotice] = useState<string | null>(null);

  const sportTheme = getSportTheme(selectedSport, isDarkMode);

  // Filter items by sport
  const sportMatches = openMatches.filter((m) => m.sport === selectedSport);
  const sportTournaments = tournaments.filter((t) => t.sport === selectedSport);
  const sportPitches = pitches.filter((p) => p.sports.includes(selectedSport));

  const handleQuickJoin = (match: OpenMatch) => {
    if (onJoinMatch) {
      const pos = match.missingPositions[0] || 'لاعب عام';
      onJoinMatch(match.id, pos);
      setJoinedNotice(`تم الانضمام لمباراة "${match.title}" بصفة (${pos})! +100 XP ⚡`);
      setTimeout(() => setJoinedNotice(null), 3000);
    } else {
      onOpenMatchmaking();
    }
  };

  return (
    <div className={`flex-1 flex flex-col justify-between p-3.5 gap-3 overflow-y-auto min-h-0 ${sportTheme.bgGradient} text-white transition-colors duration-500`}>
      {/* Banner Announcement */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        onClick={onOpenMatchmaking}
        className={`relative overflow-hidden rounded-2xl border-2 ${sportTheme.bannerBorder} p-3 cursor-pointer transition-all hover:brightness-110 active:scale-[0.995] ${sportTheme.bannerBg} shadow-xl shadow-black/30 text-white`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-2.5 rounded-xl border border-white/40 ${sportTheme.primaryBtnBg} ${sportTheme.primaryBtnText} shadow-md`}>
              <Sparkles className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <div>
              <div className={`text-xs font-black flex items-center gap-1.5 flex-wrap ${sportTheme.accentText}`}>
                {announcementBanner || `صالة وملاعب ${sportTheme.name} المباشرة 🇯🇴`}
                <span className={`text-[10px] ${sportTheme.badgeBg} ${sportTheme.badgeText} border ${sportTheme.accentBorder} px-2 py-0.5 rounded-full font-black shadow-sm`}>
                  {sportPitches.length || pitches.length} ملاعب متاحة الآن 🟢
                </span>
                <span className="text-[10px] bg-red-500/30 text-red-300 border border-red-500/50 px-2 py-0.5 rounded-full font-sans animate-pulse font-bold">
                  {sportTheme.themeLabel}
                </span>
              </div>
              <p className="text-[11px] mt-0.5 text-slate-100/80 font-medium">
                جميع الصناديق والمباريات مفعلة مباشرة - اختر طاولتك، احجز، وانضم فوراً للعب والتحدي
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Success Banner if user clicked quick join */}
      {joinedNotice && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`p-3 rounded-2xl ${sportTheme.badgeBg} border-2 ${sportTheme.accentBorder} text-center font-black text-xs ${sportTheme.accentText} flex items-center justify-center gap-2 shadow-xl`}
        >
          <CheckCircle2 className={`w-5 h-5 ${sportTheme.accentText}`} />
          <span>{joinedNotice}</span>
        </motion.div>
      )}

      {/* Jawaker VIP Club Lounge Main Dashboard */}
      <div className="flex-1 flex flex-col gap-3 min-h-0">
        
        {/* Quick Stats & Live Lounge Bar */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className={`p-3 rounded-2xl ${sportTheme.cardBg} border ${sportTheme.cardBorder} shadow-lg transition-colors`}>
            <span className="block text-[10px] opacity-70 font-bold">لاعب متصل الآن</span>
            <span className={`text-sm font-black ${sportTheme.accentText} font-mono`}>1,420 🟢</span>
          </div>

          <div className={`p-3 rounded-2xl ${sportTheme.cardBg} border ${sportTheme.cardBorder} shadow-lg transition-colors`}>
            <span className="block text-[10px] opacity-70 font-bold">الملاعب والطاولات</span>
            <span className={`text-sm font-black ${sportTheme.accentText} font-mono`}>{sportPitches.length || pitches.length || 18} ملعب</span>
          </div>

          <div className={`p-3 rounded-2xl ${sportTheme.cardBg} border ${sportTheme.cardBorder} shadow-lg transition-colors`}>
            <span className="block text-[10px] opacity-70 font-bold">البطولات النشطة</span>
            <span className={`text-sm font-black ${sportTheme.accentText} font-mono`}>{sportTournaments.length || tournamentsCount || 6} بطولة 🏆</span>
          </div>
        </div>

        {/* Jawaker Daily Lucky Wheel & VIP Tokens Box */}
        <div className={`p-4 rounded-3xl ${sportTheme.bannerBg} border-2 ${sportTheme.bannerBorder} shadow-2xl text-right flex items-center justify-between gap-3 transition-colors`}>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className={`p-2 rounded-xl ${sportTheme.primaryBtnBg} ${sportTheme.primaryBtnText} shadow-md text-xs`}>
                🎁
              </span>
              <h3 className={`font-black text-sm ${sportTheme.accentText}`}>عجلة الحظ ومكافأة التوكنات اليومية</h3>
            </div>
            <p className="text-[11px] text-slate-100/80">
              احصل على نقاط XP وتوكنات مجانية يومياً بضغطة زر لزيادة رتبة الـ VIP الخاصة بك!
            </p>
          </div>

          <button
            onClick={onOpenMatchmaking}
            className={`shrink-0 px-4 py-2.5 rounded-2xl ${sportTheme.primaryBtnBg} ${sportTheme.primaryBtnText} text-xs hover:scale-105 active:scale-95 transition-all shadow-lg border border-white/30`}
          >
            استلام المكافأة 🎡
          </button>
        </div>

        {/* Live Active Matches Summary & Club Activity Feed */}
        <div className={`flex-1 min-h-0 ${sportTheme.cardBg} rounded-3xl border ${sportTheme.cardBorder} p-4 space-y-3 flex flex-col justify-between shadow-xl transition-colors`}>
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-xl ${sportTheme.badgeBg} ${sportTheme.badgeText} border ${sportTheme.accentBorder}`}>
                <Flame className="w-4 h-4" />
              </div>
              <h3 className={`text-xs font-black ${sportTheme.accentText}`}>نشاطات نادي {sportTheme.name} المباشرة</h3>
            </div>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 px-2 py-0.5 rounded-full font-bold dir-rtl">
              تحديث مباشر 🟢
            </span>
          </div>

          {/* Quick List of Active Matches in the Club */}
          <div className="space-y-2 overflow-y-auto max-h-[220px] pr-1">
            {sportMatches.length === 0 ? (
              <div className={`p-4 text-center text-xs ${sportTheme.accentText} opacity-80`}>
                لا توجد مباريات نشطة حالياً لـ {sportTheme.name}. استخدم زر "إنشاء حجز" لإضافة مباراة جديدة!
              </div>
            ) : (
              sportMatches.slice(0, 4).map((m) => (
                <div
                  key={m.id}
                  onClick={() => {
                    handleQuickJoin(m);
                  }}
                  className={`p-3 rounded-2xl ${sportTheme.bannerBg} border ${sportTheme.cardBorder} flex items-center justify-between gap-2 hover:scale-[1.01] transition-all cursor-pointer`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                    <div className="truncate">
                      <h4 className="text-xs font-black text-white truncate">{m.title}</h4>
                      <p className="text-[10px] text-slate-200/80 flex items-center gap-1">
                        <MapPin className={`w-3 h-3 ${sportTheme.accentText} shrink-0`} />
                        {m.pitchName} • {m.timeSlot}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 text-left dir-ltr">
                    <span className={`text-xs font-black ${sportTheme.accentText} ${sportTheme.badgeBg} px-2 py-1 rounded-lg border ${sportTheme.accentBorder}`}>
                      {m.costPerPlayer} JOD
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Bottom Hint Indicator */}
          <div className={`p-2.5 rounded-2xl ${sportTheme.badgeBg} border ${sportTheme.accentBorder} text-center text-[11px] ${sportTheme.accentText} font-bold flex items-center justify-center gap-2`}>
            <span>تصفح "إيجاد لعبة"، "حجز الملاعب"، و "البطولات" متاح دائماً عبر الشريط السفلي ⬇️</span>
          </div>
        </div>

      </div>
    </div>
  );
};

