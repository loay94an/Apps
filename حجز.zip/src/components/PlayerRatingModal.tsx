import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User } from '../types';
import { Star, Shield, Award, Users, CheckCircle2, UserCheck, HeartHandshake, X, Send, Sparkles, AlertCircle, MessageSquare } from 'lucide-react';

export interface PlayerRating {
  id: string;
  targetUserId: string;
  targetUserName: string;
  raterRole: 'team' | 'referee' | 'admin' | 'owner';
  raterName: string;
  sportsmanshipRating: number;
  skillRating: number;
  punctualityRating: number;
  comment?: string;
  createdAt: string;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  usersList: User[];
  onAddRating: (rating: PlayerRating) => void;
  ratingsList: PlayerRating[];
  isDarkMode?: boolean;
}

export const PlayerRatingModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentUser,
  usersList,
  onAddRating,
  ratingsList,
  isDarkMode = true,
}) => {
  const [selectedTargetUserId, setSelectedTargetUserId] = useState<string>(
    usersList.find((u) => u.id !== currentUser.id)?.id || usersList[0]?.id || ''
  );
  const [raterRole, setRaterRole] = useState<'team' | 'referee' | 'admin' | 'owner'>('team');
  const [sportsmanship, setSportsmanship] = useState<number>(5);
  const [skill, setSkill] = useState<number>(5);
  const [punctuality, setPunctuality] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const targetUser = usersList.find((u) => u.id === selectedTargetUserId) || usersList[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUser) return;

    const newRating: PlayerRating = {
      id: `rate_${Date.now()}`,
      targetUserId: targetUser.id,
      targetUserName: targetUser.name,
      raterRole,
      raterName: currentUser.name,
      sportsmanshipRating: sportsmanship,
      skillRating: skill,
      punctualityRating: punctuality,
      comment: comment.trim(),
      createdAt: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
    };

    onAddRating(newRating);
    setSuccessNotice(`تم تقديم تقييمك للاعب "${targetUser.name}" بنجاح! +25 XP ⚡`);
    setComment('');
    setTimeout(() => setSuccessNotice(null), 3500);
  };

  const roleLabels = {
    team: { title: 'زميل بالملعب / لاعب', color: 'bg-blue-500/20 text-blue-400 border-blue-500/40', icon: '⚽' },
    referee: { title: 'الحكم المعتمد', color: 'bg-amber-500/20 text-amber-400 border-amber-500/40', icon: '🚩' },
    admin: { title: 'إدارة المنصة', color: 'bg-red-500/20 text-red-400 border-red-500/40', icon: '🛡️' },
    owner: { title: 'صاحب الملعب', color: 'bg-purple-500/20 text-purple-400 border-purple-500/40', icon: '🏟️' },
  };

  // Target player stats
  const targetRatings = ratingsList.filter((r) => r.targetUserId === selectedTargetUserId);
  const avgOverall = targetRatings.length > 0
    ? (targetRatings.reduce((acc, r) => acc + (r.sportsmanshipRating + r.skillRating + r.punctualityRating) / 3, 0) / targetRatings.length).toFixed(1)
    : '5.0';

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className={`relative w-full max-w-xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden ${
            isDarkMode ? 'bg-[#1E293B] border-amber-500/40 text-white' : 'bg-white border-slate-300 text-slate-900'
          }`}
        >
          {/* Header */}
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-right">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Star className="w-6 h-6 fill-amber-400" />
              </div>
              <div>
                <h2 className="text-base font-extrabold text-white">نظام تقييم اللاعبين الشامل 🌟</h2>
                <p className="text-xs text-slate-400">تقييم الروح الرياضية، والمهارة، والالتزام من الفريق، والحكم، والإدارة، وصاحب الملعب</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs text-right">
            {successNotice && (
              <div className="p-3 rounded-2xl bg-[#39FF14]/20 border border-[#39FF14] text-[#39FF14] font-bold text-center flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-[#39FF14]" />
                <span>{successNotice}</span>
              </div>
            )}

            {/* Rater Role Selector */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-300 block">1. حدد صفة المُقيّم (من يمنح التقييم):</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['team', 'referee', 'admin', 'owner'] as const).map((roleKey) => {
                  const roleData = roleLabels[roleKey];
                  const isSelected = raterRole === roleKey;
                  return (
                    <button
                      key={roleKey}
                      type="button"
                      onClick={() => setRaterRole(roleKey)}
                      className={`p-2.5 rounded-2xl border text-center font-bold transition-all flex flex-col items-center gap-1 ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-md scale-105'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                          : 'bg-slate-100 border-slate-200 text-slate-700'
                      }`}
                    >
                      <span className="text-base">{roleData.icon}</span>
                      <span className="text-[11px]">{roleData.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Select Target Player */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-300 block">2. اختر اللاعب المراد تقييمه:</label>
              <select
                value={selectedTargetUserId}
                onChange={(e) => setSelectedTargetUserId(e.target.value)}
                className={`w-full p-3 rounded-2xl border font-bold text-xs ${
                  isDarkMode
                    ? 'bg-slate-900 border-slate-700 text-white focus:border-amber-400'
                    : 'bg-slate-50 border-slate-300 text-slate-900'
                }`}
              >
                {usersList.map((usr) => (
                  <option key={usr.id} value={usr.id}>
                    {usr.name} ({usr.city}) - Level {usr.level} [{usr.rankTitle}]
                  </option>
                ))}
              </select>
            </div>

            {/* Target Player Summary Card */}
            {targetUser && (
              <div className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex items-center gap-3">
                  <img
                    src={targetUser.avatar}
                    alt={targetUser.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="font-extrabold text-sm text-white">{targetUser.name}</h3>
                    <p className="text-[10px] text-slate-400">{targetUser.rankTitle} • Level {targetUser.level} • {targetUser.matchesPlayed} مباراة</p>
                  </div>
                </div>

                <div className="text-left shrink-0 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-xl">
                  <div className="flex items-center gap-1 text-amber-400 font-black text-sm">
                    <Star className="w-4 h-4 fill-amber-400" />
                    <span>{avgOverall} / 5.0</span>
                  </div>
                  <span className="text-[9px] text-slate-400 block">{targetRatings.length} تقييمات سابقة</span>
                </div>
              </div>
            )}

            {/* Rating Stars Form */}
            <form onSubmit={handleSubmit} className="space-y-3 pt-2 border-t border-slate-800">
              <h3 className="font-extrabold text-amber-400">معايير التقييم الأساسية:</h3>

              {/* 1. Sportsmanship */}
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">1. الروح الرياضية واللعب النظيف 🤝</span>
                  <span className="text-[10px] text-slate-400">احترام الخصوم، والالتزام بقرارات الحكم</span>
                </div>
                <div className="flex gap-1 dir-ltr">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setSportsmanship(star)}
                      className="p-1 text-amber-400 hover:scale-125 transition-transform"
                    >
                      <Star className={`w-5 h-5 ${star <= sportsmanship ? 'fill-amber-400' : 'text-slate-600'}`} />
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Skill */}
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">2. المهارة والأداء الرياضي ⚽</span>
                  <span className="text-[10px] text-slate-400">القدرات الفنية، والتمرير، واللعب الجماعي</span>
                </div>
                <div className="flex gap-1 dir-ltr">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setSkill(star)}
                      className="p-1 text-amber-400 hover:scale-125 transition-transform"
                    >
                      <Star className={`w-5 h-5 ${star <= skill ? 'fill-amber-400' : 'text-slate-600'}`} />
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Punctuality */}
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">3. الالتزام بالحضور والمواعيد ⏰</span>
                  <span className="text-[10px] text-slate-400">الوصول بالوقت ودفع حصة الملعب</span>
                </div>
                <div className="flex gap-1 dir-ltr">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setPunctuality(star)}
                      className="p-1 text-amber-400 hover:scale-125 transition-transform"
                    >
                      <Star className={`w-5 h-5 ${star <= punctuality ? 'fill-amber-400' : 'text-slate-600'}`} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Comment Input */}
              <div>
                <label className="text-slate-300 font-bold block mb-1">ملاحظات وتعليق إضافي (اختياري):</label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="اكتب ملاحظة حول أداء اللاعب بالملعب..."
                  rows={2}
                  className={`w-full p-3 rounded-2xl border text-xs focus:outline-none ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-700 text-white focus:border-amber-400'
                      : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black text-xs hover:brightness-110 shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4 rotate-180" />
                <span>اعتماد التقييم وإرساله (+25 XP)</span>
              </button>
            </form>

            {/* Previous Player Reviews Feed */}
            {targetRatings.length > 0 && (
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <h4 className="font-bold text-slate-300 flex items-center gap-1">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  تقييمات اللاعب السابقة ({targetRatings.length}):
                </h4>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {targetRatings.map((r) => (
                    <div key={r.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className={`px-2 py-0.5 rounded font-bold ${roleLabels[r.raterRole].color}`}>
                          {roleLabels[r.raterRole].icon} {roleLabels[r.raterRole].title}: {r.raterName}
                        </span>
                        <span className="text-slate-400">{r.createdAt}</span>
                      </div>
                      <div className="flex items-center gap-1 text-amber-400 font-bold text-xs pt-1">
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                        <span>معدل {((r.sportsmanshipRating + r.skillRating + r.punctualityRating) / 3).toFixed(1)} / 5</span>
                      </div>
                      {r.comment && <p className="text-slate-300 text-[11px] mt-1">{r.comment}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
