import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User } from '../types';
import { LEVEL_TIERS } from '../data/mockData';
import { Flame, Award, ShieldCheck, Video, Zap, CheckCircle2, Lock, ChevronRight, X, Trophy, Sparkles, Star, Gift } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onGainXp: (amount: number, reason: string) => void;
}

export const GamificationWidget: React.FC<Props> = ({
  isOpen,
  onClose,
  currentUser,
  onGainXp,
}) => {
  const [claimedRewards, setClaimedRewards] = useState<Record<number, boolean>>({});
  const [lastActionNotice, setLastActionNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleClaimReward = (tierIdx: number, title: string) => {
    if (claimedRewards[tierIdx]) return;
    setClaimedRewards((prev) => ({ ...prev, [tierIdx]: true }));
    onGainXp(200, `مكافأة فتح المستوى (${title})`);
    setLastActionNotice(`تم المطالبة بالمكافأة وتزويدك بـ +200 XP ووسام جديد! 🎉`);
    setTimeout(() => setLastActionNotice(null), 3000);
  };

  const handleQuickXpAction = (amount: number, reason: string) => {
    onGainXp(amount, reason);
    setLastActionNotice(`أحسنت! حصلت على +${amount} XP (${reason}) ⚡`);
    setTimeout(() => setLastActionNotice(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative w-full max-w-xl max-h-[90vh] flex flex-col bg-[#1E293B] border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden text-right"
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#092e1e] via-[#0d422c] to-[#072417] border-b border-amber-500/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/50 shadow-lg">
              <Flame className="w-6 h-6 animate-pulse text-amber-400" />
            </div>
            <div>
              <h2 className="text-base font-black text-yellow-300">نظام المستويات والترفيه التفاعلي الجواكر (Jawaker Level Engine) ⚡</h2>
              <p className="text-xs text-amber-100/70">كسب التوكنات، عجلة الحظ اليومية، الترقية لرتب VIP والشارة الذهبية</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-900/80 text-amber-300 hover:text-white border border-amber-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs bg-gradient-to-b from-[#062115] via-[#093321] to-[#041910] text-white">
          {lastActionNotice && (
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="p-3 rounded-2xl bg-amber-500/20 border-2 border-amber-400 text-yellow-300 font-black text-center flex items-center justify-center gap-2 shadow-xl"
            >
              <Sparkles className="w-5 h-5 text-yellow-300" />
              <span>{lastActionNotice}</span>
            </motion.div>
          )}

          {/* Current Interactive Status Card - Jawaker Golden Profile Banner */}
          <div className="p-4 rounded-3xl bg-gradient-to-r from-[#0d422c] via-[#14563a] to-[#092e1e] border-2 border-amber-400/80 flex items-center gap-3 shadow-2xl">
            <div className="text-3xl p-3 bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 rounded-2xl border border-yellow-200 shrink-0 font-black shadow-lg">
              👑
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-center">
                <span className="text-sm font-black text-yellow-300 truncate">
                  Level {currentUser.level} - {currentUser.rankTitle || 'كابتن الجواكر الذهبي'}
                </span>
                <span className="text-[10px] bg-amber-500/30 text-yellow-300 border border-amber-400/60 px-2 py-0.5 rounded-full font-black">
                  VIP {currentUser.level} 🟢
                </span>
              </div>

              {/* Progress Bar */}
              <div className="mt-2 flex items-center gap-2">
                <div className="flex-1 bg-slate-950 h-3 rounded-full overflow-hidden border border-amber-500/40 p-0.5">
                  <div
                    className="bg-gradient-to-r from-emerald-400 via-amber-400 to-yellow-300 h-full rounded-full transition-all duration-500 shadow-[0_0_12px_rgba(245,158,11,0.8)]"
                    style={{ width: `${Math.min(100, (currentUser.xp / currentUser.maxXp) * 100)}%` }}
                  />
                </div>
                <span className="text-yellow-300 font-mono font-black dir-ltr text-xs shrink-0">
                  {currentUser.xp}/{currentUser.maxXp} XP
                </span>
              </div>
            </div>
          </div>

          {/* Jawaker Interactive Lucky Wheel Spin Section */}
          <div className="p-4 rounded-3xl bg-gradient-to-b from-[#0a3a25] to-[#062417] border-2 border-amber-400/60 shadow-xl text-center space-y-3">
            <div className="flex items-center justify-center gap-2">
              <Gift className="w-5 h-5 text-amber-400 animate-bounce" />
              <h3 className="font-black text-sm text-yellow-300">عجلة الجواكر والجوائز اليومية (Interactive Lucky Wheel) 🎡</h3>
            </div>
            <p className="text-[11px] text-amber-100/80">
              انقر على عجلة الحظ الآن لتحصل على مكافآت توكنات وXP ورتب VIP مجانية!
            </p>

            <button
              onClick={() => {
                const xpWon = [100, 150, 200, 250, 300][Math.floor(Math.random() * 5)];
                handleQuickXpAction(xpWon, 'عجلة الجواكر اليومية 🎡');
              }}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs hover:scale-105 active:scale-95 transition-all shadow-lg shadow-amber-500/30 border border-yellow-200 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>تدوير عجلة الحظ واستلام المكافأة اليومية 🎁</span>
            </button>
          </div>

          {/* Interactive Boost Buttons */}
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-amber-500/30 space-y-2">
            <h3 className="font-black text-amber-300 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              أداء المهام اليومية لكسب نقاط XP والارتقاء بالمستوى:
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={() => handleQuickXpAction(100, 'إكمال مباراة خماسية')}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-500/20 text-right flex items-center justify-between group transition-all"
              >
                <div>
                  <div className="font-bold text-white group-hover:text-yellow-300">إكمال مباراة بالملعب ⚽</div>
                  <div className="text-[10px] text-amber-200/60">انضم وأكمل حجز أي مباراة</div>
                </div>
                <span className="text-xs font-black text-yellow-300 bg-amber-500/20 border border-amber-400/40 px-2 py-1 rounded-lg dir-ltr shrink-0">+100 XP</span>
              </button>

              <button
                onClick={() => handleQuickXpAction(150, 'الفوز بمباراة معتمدة')}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-500/20 text-right flex items-center justify-between group transition-all"
              >
                <div>
                  <div className="font-bold text-white group-hover:text-yellow-300">الفوز في مباراة 🥇</div>
                  <div className="text-[10px] text-amber-200/60">تسجيل النتيجة الرسمية</div>
                </div>
                <span className="text-xs font-black text-yellow-300 bg-amber-500/20 border border-amber-400/40 px-2 py-1 rounded-lg dir-ltr shrink-0">+150 XP</span>
              </button>

              <button
                onClick={() => handleQuickXpAction(200, 'أفضل لاعب بالمباراة MOTM')}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-500/20 text-right flex items-center justify-between group transition-all"
              >
                <div>
                  <div className="font-bold text-white group-hover:text-yellow-300">رجل المباراة (MOTM) ⭐</div>
                  <div className="text-[10px] text-amber-200/60">حصول على أعلى تقييم</div>
                </div>
                <span className="text-xs font-black text-yellow-300 bg-amber-500/20 border border-amber-400/40 px-2 py-1 rounded-lg dir-ltr shrink-0">+200 XP</span>
              </button>

              <button
                onClick={() => handleQuickXpAction(300, 'الفوز ببطولة رسمية')}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-500/20 text-right flex items-center justify-between group transition-all"
              >
                <div>
                  <div className="font-bold text-white group-hover:text-yellow-300">التتويج ببطولة 🏆</div>
                  <div className="text-[10px] text-amber-200/60">المركز الأول بالدوري</div>
                </div>
                <span className="text-xs font-black text-yellow-300 bg-amber-500/20 border border-amber-400/40 px-2 py-1 rounded-lg dir-ltr shrink-0">+300 XP</span>
              </button>
            </div>
          </div>

          {/* Level Progression Tiers Roadmap */}
          <div className="space-y-2">
            <h3 className="font-bold text-slate-300">خريطة فتح المستويات والميزات والمكافآت:</h3>
            {LEVEL_TIERS.map((tier, idx) => {
              const reqLevel = idx === 0 ? 1 : idx === 1 ? 10 : idx === 2 ? 20 : 35;
              const isUnlocked = currentUser.level >= reqLevel;
              const isClaimed = claimedRewards[idx];

              return (
                <div
                  key={idx}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    isUnlocked
                      ? 'bg-slate-900 border-[#39FF14]/50 text-white'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 opacity-80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{tier.badge}</span>
                      <span className="font-extrabold text-sm">{tier.title}</span>
                      <span className="text-[10px] bg-slate-800 border border-slate-700 px-2 py-0.5 rounded-full font-mono text-cyan-300">
                        {tier.levelRange}
                      </span>
                    </div>

                    {isUnlocked ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleClaimReward(idx, tier.title)}
                          disabled={isClaimed}
                          className={`px-2.5 py-1 rounded-xl text-[10px] font-black flex items-center gap-1 transition-all ${
                            isClaimed
                              ? 'bg-slate-800 text-slate-500 cursor-default'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md animate-bounce'
                          }`}
                        >
                          <Gift className="w-3 h-3" />
                          <span>{isClaimed ? 'تمت المطالبة ✅' : 'استلام المكافأة (+200 XP)'}</span>
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] bg-red-500/10 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        يتطلب Level {reqLevel}
                      </span>
                    )}
                  </div>

                  <ul className="space-y-1 text-[11px] text-slate-300 pr-2">
                    {tier.benefits.map((b, bIdx) => (
                      <li key={bIdx} className="flex items-center gap-1.5">
                        <span className="text-[#39FF14]">•</span>
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
