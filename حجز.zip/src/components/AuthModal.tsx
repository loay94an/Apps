import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Role, User, StaffMember } from '../types';
import { ShieldAlert, Store, UserCheck, Phone, Mail, Lock, User as UserIcon, CheckCircle2, AlertCircle, X, KeyRound, ArrowRight, RefreshCw, Copy, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSelectRole: (role: Role, userDetails?: Partial<User>) => void;
  currentAdminPassword: string;
  adminUsername: string;
  usersList: User[];
  staffMembers: StaffMember[];
  onResetPassword: (identifier: string, newPassword: string) => boolean;
}

export const AuthModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSelectRole,
  currentAdminPassword,
  adminUsername,
  usersList,
  staffMembers,
  onResetPassword,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot_password'>('login');
  const [selectedRole, setSelectedRole] = useState<Role>('user');

  // Login Form States
  const [loginIdentifier, setLoginIdentifier] = useState<string>('');
  const [password, setPassword] = useState<string>('');

  // Sign Up Form States
  const [signupAccountType, setSignupAccountType] = useState<'player' | 'owner' | 'guest'>('player');
  const [fullName, setFullName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [city, setCity] = useState<'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش'>('عمان');
  const [preferredPosition, setPreferredPosition] = useState<string>('مهاجم صريح');
  const [signupPassword, setSignupPassword] = useState<string>('');

  // Password Reset States
  const [resetStep, setResetStep] = useState<1 | 2 | 3 | 4>(1);
  const [resetMethod, setResetMethod] = useState<'phone' | 'email'>('phone');
  const [resetTarget, setResetTarget] = useState<string>('');
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [inputOtp, setInputOtp] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmNewPassword, setConfirmNewPassword] = useState<string>('');
  const [codeCopied, setCodeCopied] = useState<boolean>(false);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Helper to normalize identifiers (phone numbers, emails, usernames)
  const normalizeStr = (str: string) => {
    if (!str) return '';
    return str
      .trim()
      .toLowerCase()
      .replace(/[\s\-\+]/g, '')
      .replace(/^962/, '0')
      .replace(/^00962/, '0');
  };

  const handleSelectRoleTab = (role: Role) => {
    setSelectedRole(role);
    setErrorMessage(null);
  };

  const handleSubmitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!loginIdentifier || !password) {
      setErrorMessage('يرجى تعبئة اسم المستخدم/رقم الهاتف وكلمة المرور.');
      return;
    }

    const normId = normalizeStr(loginIdentifier);

    if (selectedRole === 'admin') {
      // 1. Check Primary Super Admin
      const normAdminUser = normalizeStr(adminUsername);
      const isSuperAdminUserMatch =
        normId === normAdminUser ||
        normId === normalizeStr('admin@malaebak.jo') ||
        normId === 'admin' ||
        normId === '0790000000';

      if (isSuperAdminUserMatch) {
        if (password === currentAdminPassword) {
          onSelectRole('admin', {
            id: 'adm_001',
            name: 'مدير النظام الأساسي 🛡️',
            phone: adminUsername,
            email: 'admin@malaebak.jo',
            password: currentAdminPassword,
            role: 'admin',
          });
          onClose();
          return;
        } else {
          setErrorMessage('كلمة المرور غير صحيحة لمدير النظام الأساسي.');
          return;
        }
      }

      // 2. Check Assistant Staff Admin Members
      const matchingStaff = staffMembers.find((s) => {
        const uNorm = normalizeStr(s.username);
        const eNorm = normalizeStr(s.email || '');
        return uNorm === normId || eNorm === normId;
      });

      if (matchingStaff) {
        if (matchingStaff.password === password) {
          onSelectRole('admin', {
            id: matchingStaff.id,
            name: matchingStaff.name,
            phone: matchingStaff.username,
            email: `${matchingStaff.username}@malaebak.jo`,
            password: matchingStaff.password,
            role: 'admin',
          });
          onClose();
          return;
        } else {
          setErrorMessage('كلمة المرور غير صحيحة لحساب المساعد الإداري.');
          return;
        }
      }

      setErrorMessage('اسم المستخدم أو البريد الإلكتروني غير مسجل كـ مدير أو مساعد نظام.');
      return;
    } else if (selectedRole === 'owner') {
      // Check Pitch Owner
      const matchedOwner = usersList.find((u) => {
        if (u.role !== 'owner') return false;
        const pNorm = normalizeStr(u.phone);
        const eNorm = normalizeStr(u.email);
        return pNorm === normId || eNorm === normId;
      });

      if (matchedOwner) {
        if (matchedOwner.isBanned) {
          setErrorMessage('هذا الحساب محظور حالياً من دخول المنصة. يرجى التواصل مع الإدارة.');
          return;
        }
        if (matchedOwner.password === password) {
          onSelectRole('owner', matchedOwner);
          onClose();
          return;
        } else {
          setErrorMessage('كلمة المرور غير صحيحة لحساب صاحب الملعب.');
          return;
        }
      }

      setErrorMessage('لم نتمكن من العثور على حساب صاحب ملعب بهذا الرقم أو البريد. يرجى التأكد من البيانات أو إنشاء حساب جديد.');
      return;
    } else {
      // Player / User Role
      const matchedUser = usersList.find((u) => {
        if (u.role === 'admin') return false;
        const pNorm = normalizeStr(u.phone);
        const eNorm = normalizeStr(u.email);
        return pNorm === normId || eNorm === normId;
      });

      if (matchedUser) {
        if (matchedUser.isBanned) {
          setErrorMessage('هذا الحساب محظور حالياً من قبل إدارة المنصة.');
          return;
        }
        if (password === matchedUser.password) {
          onSelectRole('user', matchedUser);
          onClose();
          return;
        } else {
          setErrorMessage('كلمة المرور غير صحيحة للحساب.');
          return;
        }
      }

      setErrorMessage('لم نتمكن من العثور على حساب بهذا الرقم أو البريد. يرجى التأكد من البيانات أو إنشاء حساب جديد.');
      return;
    }
  };

  const handleSubmitSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (signupAccountType === 'guest') {
      if (!fullName.trim()) {
        setErrorMessage('يرجى إدخال اسمك للبدء كزائر.');
        return;
      }
      onSelectRole('user', {
        name: fullName.trim(),
        phone: `079${Math.floor(1000000 + Math.random() * 9000000)}`,
        email: `guest_${Date.now()}@malaebak.jo`,
        city,
        accountType: 'guest',
        isGuest: true,
      });
      onClose();
      return;
    }

    if (!fullName || !phone || !signupPassword) {
      setErrorMessage('يرجى ملء جميع حقول التسجيل المطلوبة.');
      return;
    }
    if (signupPassword.length < 6) {
      setErrorMessage('كلمة المرور يجب أن تكون 6 أحرف أو أرقام على الأقل.');
      return;
    }

    const assignedRole: Role = signupAccountType === 'owner' ? 'owner' : 'user';

    onSelectRole(assignedRole, {
      name: fullName,
      phone,
      email: email || `${phone}@malaebak.jo`,
      city,
      preferredPosition: signupAccountType === 'player' ? preferredPosition : undefined,
      accountType: signupAccountType,
      isGuest: false,
      password: signupPassword,
    });
    onClose();
  };

  // Password Reset Flow Steps
  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!resetTarget.trim()) {
      setErrorMessage('يرجى إدخال رقم الموبايل أو البريد الإلكتروني الخاص بالحساب.');
      return;
    }

    const norm = normalizeStr(resetTarget);

    // Verify account exists
    const normAdminUser = normalizeStr(adminUsername);
    const isSuperAdminMatch =
      norm === normAdminUser ||
      norm === normalizeStr('admin@malaebak.jo') ||
      norm === 'admin' ||
      norm === '0790000000';

    const staffMatch = staffMembers.some((s) => {
      const uNorm = normalizeStr(s.username);
      const eNorm = normalizeStr(s.email || '');
      return uNorm === norm || eNorm === norm;
    });

    const userMatch = usersList.some((u) => {
      const pNorm = normalizeStr(u.phone);
      const eNorm = normalizeStr(u.email);
      return pNorm === norm || eNorm === norm || (pNorm.includes(norm) && norm.length >= 7);
    });

    if (!isSuperAdminMatch && !staffMatch && !userMatch && norm !== normalizeStr('0791234567') && norm !== normalizeStr('0788889999')) {
      setErrorMessage('لم نتمكن من العثور على حساب مرتبط بهذا الرقم أو البريد الإلكتروني.');
      return;
    }

    // Generate 4-digit verification code
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setResetStep(2);
    setErrorMessage(null);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!inputOtp || inputOtp.trim() !== generatedOtp) {
      setErrorMessage('رمز التفعيل غير صحيح! يرجى إدخال الرمز المكون من 4 أرقام الموضح أعلاه.');
      return;
    }

    setResetStep(3);
    setErrorMessage(null);
  };

  const handleConfirmNewPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!newPassword || newPassword.length < 6) {
      setErrorMessage('كلمة المرور الجديدة يجب أن تكون 6 أحرف أو أرقام على الأقل.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setErrorMessage('كلمة المرور الجديدة وتأكيدها غير متطابقين.');
      return;
    }

    const updated = onResetPassword(resetTarget, newPassword);
    if (updated) {
      setResetStep(4);
      setSuccessMessage('تم تحديث كلمة المرور بنجاح! يمكنك الآن تسجيل الدخول.');
    } else {
      setErrorMessage('حدث خطأ أثناء تحديث كلمة المرور. يرجى المحاولة مجدداً.');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md dir-rtl">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md bg-[#1E293B] border border-[#39FF14]/40 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto"
          >
            <button
              onClick={onClose}
              className="absolute top-4 left-4 p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Title Header */}
            <div className="text-center space-y-1">
              <h2 className="text-2xl font-black text-[#39FF14] flex items-center justify-center gap-2">
                ⚽ مـلـعـبـك الأردن
              </h2>
              <p className="text-xs text-slate-400 font-bold">
                منصة الملاعب والتكميلة الأولى بالأردن
              </p>
            </div>

            {/* Top Auth Mode Switcher */}
            {authMode !== 'forgot_password' ? (
              <div className="grid grid-cols-2 gap-1 bg-slate-900 p-1 rounded-2xl border border-slate-800 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className={`py-2 rounded-xl transition-all ${
                    authMode === 'login'
                      ? 'bg-[#39FF14] text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  تسجيل الدخول
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('signup');
                    setSelectedRole('user');
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className={`py-2 rounded-xl transition-all ${
                    authMode === 'signup'
                      ? 'bg-[#39FF14] text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  إنشاء حساب جديد
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between bg-slate-900/80 p-2 rounded-2xl border border-amber-500/30 text-xs font-bold text-amber-400">
                <div className="flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>إعادة تعيين كلمة المرور</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setResetStep(1);
                    setErrorMessage(null);
                  }}
                  className="text-xs text-slate-400 hover:text-white underline flex items-center gap-1"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>العودة للدخول</span>
                </button>
              </div>
            )}

            {/* Error Message Box */}
            {errorMessage && (
              <div className="p-3 rounded-2xl bg-red-500/20 border border-red-500 text-xs text-red-200 font-bold flex items-start gap-2 animate-shake">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                <span className="leading-relaxed">{errorMessage}</span>
              </div>
            )}

            {/* Success Message Box */}
            {successMessage && (
              <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500 text-xs text-emerald-200 font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* 1. LOGIN MODE */}
            {authMode === 'login' && (
              <div className="space-y-4">
                {/* Role Tabs */}
                <div className="grid grid-cols-3 gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => handleSelectRoleTab('user')}
                    className={`py-2 rounded-xl transition-all flex flex-col items-center gap-1 ${
                      selectedRole === 'user'
                        ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>لاعب</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSelectRoleTab('owner')}
                    className={`py-2 rounded-xl transition-all flex flex-col items-center gap-1 ${
                      selectedRole === 'owner'
                        ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>صاحب ملعب</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSelectRoleTab('admin')}
                    className={`py-2 rounded-xl transition-all flex flex-col items-center gap-1 ${
                      selectedRole === 'admin'
                        ? 'bg-red-500 text-white font-black shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <ShieldAlert className="w-4 h-4" />
                    <span>مدير النظام</span>
                  </button>
                </div>

                {/* LOGIN FORM */}
                <form onSubmit={handleSubmitLogin} className="space-y-3.5 text-xs">
                  <div>
                    <label className="text-slate-300 font-bold block mb-1">
                      {selectedRole === 'admin'
                        ? 'اسم المستخدم أو رقم الموبايل:'
                        : selectedRole === 'owner'
                        ? 'رقم الهاتف أو البريد الإلكتروني:'
                        : 'رقم الهاتف أو البريد الإلكتروني:'}
                    </label>
                    <div className="relative">
                      {selectedRole === 'user' ? (
                        <Phone className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                      ) : (
                        <Mail className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                      )}
                      <input
                        type="text"
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        placeholder={
                          selectedRole === 'admin'
                            ? 'أدخل اسم المستخدم أو الموبايل'
                            : selectedRole === 'owner'
                            ? 'أدخل رقم الموبايل أو البريد'
                            : 'أدخل رقم الموبايل أو البريد'
                        }
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2.5 text-white dir-ltr text-right font-bold focus:border-[#39FF14] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-slate-300 font-bold">كلمة المرور:</label>
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('forgot_password');
                          setResetStep(1);
                          setResetTarget(loginIdentifier);
                          setErrorMessage(null);
                        }}
                        className="text-[11px] text-[#39FF14] hover:underline font-extrabold flex items-center gap-1"
                      >
                        <KeyRound className="w-3 h-3" />
                        <span>نسيت كلمة المرور؟</span>
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2.5 text-white dir-ltr text-right focus:border-[#39FF14] focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className={`w-full py-3.5 rounded-xl font-black text-xs transition-all shadow-lg flex items-center justify-center gap-2 ${
                      selectedRole === 'admin'
                        ? 'bg-red-500 text-white hover:bg-red-400 shadow-red-500/30'
                        : selectedRole === 'owner'
                        ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/30'
                        : 'bg-[#39FF14] text-slate-950 hover:bg-[#32e012] shadow-[#39FF14]/30'
                    }`}
                  >
                    <span>تسجيل الدخول كـ ({selectedRole === 'admin' ? 'مدير النظام' : selectedRole === 'owner' ? 'صاحب ملعب' : 'لاعب'})</span>
                  </button>
                </form>
              </div>
            )}

            {/* 2. FORGOT PASSWORD MODE */}
            {authMode === 'forgot_password' && (
              <div className="space-y-4 text-xs">
                {/* STEP 1: Request Verification Code */}
                {resetStep === 1 && (
                  <form onSubmit={handleRequestOtp} className="space-y-3">
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      يرجى إدخال رقم الهاتف أو البريد الإلكتروني المسجل في حسابك لتلقي رمز تفعيل مكون من <strong className="text-[#39FF14]">4 أرقام</strong> لإعادة تعيين كلمة المرور.
                    </p>

                    {/* Method Toggle */}
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">طريقة استقبال الرمز:</label>
                      <div className="grid grid-cols-2 gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 font-bold text-[11px]">
                        <button
                          type="button"
                          onClick={() => setResetMethod('phone')}
                          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                            resetMethod === 'phone'
                              ? 'bg-[#39FF14] text-slate-950 font-black'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>رقم الموبايل / واتساب</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setResetMethod('email')}
                          className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                            resetMethod === 'email'
                              ? 'bg-[#39FF14] text-slate-950 font-black'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>البريد الإلكتروني</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">
                        {resetMethod === 'phone' ? 'رقم الهاتف (الأردن):' : 'البريد الإلكتروني الحساب:'}
                      </label>
                      <div className="relative">
                        {resetMethod === 'phone' ? (
                          <Phone className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                        ) : (
                          <Mail className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                        )}
                        <input
                          type="text"
                          value={resetTarget}
                          onChange={(e) => setResetTarget(e.target.value)}
                          placeholder={resetMethod === 'phone' ? '0791234567' : 'ward@malaebak.jo'}
                          required
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2.5 text-white dir-ltr text-right font-bold focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl font-black text-xs bg-[#39FF14] text-slate-950 hover:bg-[#32e012] shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2"
                    >
                      <KeyRound className="w-4 h-4" />
                      <span>إرسال رمز التفعيل (4 أرقام) 🚀</span>
                    </button>
                  </form>
                )}

                {/* STEP 2: Input Verification Code */}
                {resetStep === 2 && (
                  <form onSubmit={handleVerifyOtp} className="space-y-4">
                    {/* Simulated SMS Notification Card */}
                    <div className="p-3.5 rounded-2xl bg-amber-500/10 border-2 border-amber-500/40 text-amber-200 space-y-2 relative">
                      <div className="flex items-center justify-between text-xs font-black text-amber-300">
                        <span className="flex items-center gap-1.5">
                          <span>📩</span>
                          <span>تم إرسال رمز التفعيل بنجاح!</span>
                        </span>
                        <span className="text-[10px] bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
                          الآن
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300">
                        رمز التفعيل المكون من 4 أرقام لاستعادة كلمة مرور حسابك هو:
                      </p>
                      <div className="flex items-center justify-between bg-slate-900/90 p-2.5 rounded-xl border border-amber-500/50">
                        <span className="font-mono text-2xl font-black text-[#39FF14] tracking-widest dir-ltr">
                          {generatedOtp}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setInputOtp(generatedOtp);
                            setCodeCopied(true);
                            setTimeout(() => setCodeCopied(false), 2000);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center gap-1 hover:bg-amber-400"
                        >
                          {codeCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          <span>{codeCopied ? 'تم النسخ والتعبئة' : 'تعبئة تلقائية'}</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1 text-center">
                        أدخل الرمز المكون من 4 أرقام:
                      </label>
                      <input
                        type="text"
                        maxLength={4}
                        value={inputOtp}
                        onChange={(e) => setInputOtp(e.target.value.replace(/[^0-9]/g, ''))}
                        placeholder="••••"
                        required
                        className="w-full bg-slate-900 border-2 border-[#39FF14] rounded-2xl py-3 text-center text-3xl font-mono text-[#39FF14] tracking-widest focus:outline-none shadow-inner"
                      />
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const code = Math.floor(1000 + Math.random() * 9000).toString();
                          setGeneratedOtp(code);
                          setInputOtp('');
                          setErrorMessage('تمت إعادة إرسال رمز تفعيل جديد بنجاح.');
                        }}
                        className="flex-1 py-3 rounded-xl font-bold bg-slate-800 text-slate-300 hover:text-white border border-slate-700 flex items-center justify-center gap-1"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>إعادة الإرسال</span>
                      </button>

                      <button
                        type="submit"
                        className="flex-1 py-3 rounded-xl font-black bg-[#39FF14] text-slate-950 hover:bg-[#32e012] shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-1"
                      >
                        <span>تأكيد الرمز 🔐</span>
                      </button>
                    </div>
                  </form>
                )}

                {/* STEP 3: Set New Password */}
                {resetStep === 3 && (
                  <form onSubmit={handleConfirmNewPassword} className="space-y-3">
                    <div>
                      <label className="text-slate-300 font-bold block mb-1">كلمة المرور الجديدة (6 خانات على الأقل):</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                        <input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="••••••••"
                          required
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2.5 text-white dir-ltr text-right focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">تأكيد كلمة المرور الجديدة:</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                        <input
                          type="password"
                          value={confirmNewPassword}
                          onChange={(e) => setConfirmNewPassword(e.target.value)}
                          placeholder="••••••••"
                          required
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2.5 text-white dir-ltr text-right focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl font-black text-xs bg-[#39FF14] text-slate-950 hover:bg-[#32e012] shadow-lg shadow-[#39FF14]/20 flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>حفظ كلمة المرور الجديدة وتحديث الحساب ⚡</span>
                    </button>
                  </form>
                )}

                {/* STEP 4: Success & Login */}
                {resetStep === 4 && (
                  <div className="text-center space-y-4 py-2">
                    <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto text-emerald-400">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>

                    <div className="space-y-1">
                      <h3 className="text-lg font-black text-white">تمت إعادة تعيين كلمة المرور بنجاح! 🎉</h3>
                      <p className="text-xs text-slate-400">
                        يمكنك الآن الدخول مباشرة للحساب باستخدام كلمة المرور الجديدة.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('login');
                        setLoginIdentifier(resetTarget);
                        setPassword(newPassword);
                        setResetStep(1);
                        setSuccessMessage('تم تعبئة البيانات الجديدة بنجاح. انقر على دخول.');
                      }}
                      className="w-full py-3.5 rounded-xl font-black text-xs bg-[#39FF14] text-slate-950 hover:bg-[#32e012] shadow-lg shadow-[#39FF14]/30"
                    >
                      الانتقال لتسجيل الدخول المباشر 🚀
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* 3. SIGNUP MODE */}
            {authMode === 'signup' && (
              <form onSubmit={handleSubmitSignup} className="space-y-3 text-xs">
                {/* Account Type Selector */}
                <div>
                  <label className="text-slate-300 font-bold block mb-1">حدد نوع الحساب المراد إنشاؤه:</label>
                  <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-2xl border border-slate-700 text-[11px] font-extrabold">
                    <button
                      type="button"
                      onClick={() => setSignupAccountType('player')}
                      className={`py-2 px-1 rounded-xl transition-all flex flex-col items-center gap-1 ${
                        signupAccountType === 'player'
                          ? 'bg-[#39FF14] text-slate-950 font-black shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>لاعب جديد</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSignupAccountType('owner')}
                      className={`py-2 px-1 rounded-xl transition-all flex flex-col items-center gap-1 ${
                        signupAccountType === 'owner'
                          ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Store className="w-3.5 h-3.5" />
                      <span>صاحب ملعب</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSignupAccountType('guest')}
                      className={`py-2 px-1 rounded-xl transition-all flex flex-col items-center gap-1 ${
                        signupAccountType === 'guest'
                          ? 'bg-sky-400 text-slate-950 font-black shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <UserIcon className="w-3.5 h-3.5" />
                      <span>حساب زائر 👤</span>
                    </button>
                  </div>
                </div>

                {signupAccountType === 'guest' ? (
                  <div className="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/30 text-[11px] text-sky-200 space-y-1">
                    <p className="font-extrabold flex items-center gap-1.5 text-sky-300">
                      ⚡ دخول سريع ومباشر كزائر:
                    </p>
                    <p className="text-slate-300 leading-relaxed">
                      ادخل اسمك فقط لتستكشف التطبيق الملاعب، التكميلات والبطولات فوراً!
                    </p>
                  </div>
                ) : null}

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {signupAccountType === 'guest' ? 'اسم الزائر / اللقب المفضّل:' : 'الاسم الكامل:'}
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={
                        signupAccountType === 'guest'
                          ? 'مثال: الكابتن سامر (زائر)'
                          : signupAccountType === 'owner'
                          ? 'مثال: الكابتن طارق المجالي'
                          : 'مثال: أحمد الشمالي'
                      }
                      required
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2 text-white font-bold focus:border-[#39FF14] focus:outline-none"
                    />
                  </div>
                </div>

                {signupAccountType !== 'guest' && (
                  <>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">رقم الهاتف (الأردن):</label>
                        <div className="relative">
                          <Phone className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                          <input
                            type="text"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            placeholder="0791234567"
                            required
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-2 py-2 text-white font-mono dir-ltr text-right focus:border-[#39FF14] focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-slate-300 font-bold block mb-1">المحافظة/المدينة:</label>
                        <select
                          value={city}
                          onChange={(e) => setCity(e.target.value as any)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2 py-2 text-white font-bold focus:border-[#39FF14] focus:outline-none"
                        >
                          <option value="عمان">عمان</option>
                          <option value="الزرقاء">الزرقاء</option>
                          <option value="إربد">إربد</option>
                          <option value="العقبة">العقبة</option>
                          <option value="السلط">السلط</option>
                          <option value="جرش">جرش</option>
                        </select>
                      </div>
                    </div>

                    {signupAccountType === 'player' && (
                      <div>
                        <label className="text-slate-300 font-bold block mb-1">المركز المفضل بالميدان:</label>
                        <select
                          value={preferredPosition}
                          onChange={(e) => setPreferredPosition(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:border-[#39FF14] focus:outline-none"
                        >
                          <option value="حارس مرمى">حارس مرمى</option>
                          <option value="مدافع قلب">مدافع قلب</option>
                          <option value="ظهير">ظهير</option>
                          <option value="وسط دفاعي">وسط دفاعي</option>
                          <option value="صانع ألعاب">صانع ألعاب</option>
                          <option value="جناح">جناح</option>
                          <option value="مهاجم صريح">مهاجم صريح</option>
                        </select>
                      </div>
                    )}

                    <div>
                      <label className="text-slate-300 font-bold block mb-1">كلمة مرور الحساب (6 خانات على الأقل):</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-[#39FF14] absolute right-3 top-3" />
                        <input
                          type="password"
                          value={signupPassword}
                          onChange={(e) => setSignupPassword(e.target.value)}
                          placeholder="••••••••"
                          required
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-10 pl-3 py-2 text-white dir-ltr text-right focus:border-[#39FF14] focus:outline-none"
                        />
                      </div>
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  className={`w-full py-3.5 rounded-xl font-black text-xs transition-all shadow-lg ${
                    signupAccountType === 'guest'
                      ? 'bg-sky-400 hover:bg-sky-300 text-slate-950 shadow-sky-500/30'
                      : 'bg-[#39FF14] text-slate-950 hover:bg-[#32e012] shadow-[#39FF14]/30'
                  }`}
                >
                  {signupAccountType === 'guest'
                    ? 'دخول فوراً كزائر 🚀'
                    : signupAccountType === 'owner'
                    ? 'إنشاء حساب صاحب ملعب'
                    : 'إنشاء حساب لاعب جديد'}
                </button>
              </form>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
