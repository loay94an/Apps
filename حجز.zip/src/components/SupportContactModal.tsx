import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, MessageSquare, Send, X, Headphones, CheckCircle2, Building2, MapPin, ExternalLink, ShieldCheck, Clock, User as UserIcon, Mail } from 'lucide-react';
import { User, SupportTicket, AppPlatformConfig, INITIAL_PLATFORM_CONFIG } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  pitchName?: string;
  isDarkMode?: boolean;
  currentUser?: User;
  platformConfig?: AppPlatformConfig;
  onCreateSupportTicket?: (ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'status'>) => void;
}

export const SupportContactModal: React.FC<Props> = ({
  isOpen,
  onClose,
  pitchName = 'إدارة التطبيق والملاعب',
  isDarkMode = true,
  currentUser,
  platformConfig = INITIAL_PLATFORM_CONFIG,
  onCreateSupportTicket,
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'call' | 'ticket'>('chat');
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'support'; text: string; time: string }>>([
    {
      sender: 'support',
      text: 'مرحباً بك في خدمة دعم "ملعبك"! كيف يمكننا مساعدتك اليوم بخصوص الحجوزات، الملاعب، أو التقسيم المالية؟',
      time: 'الآن',
    },
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [ticketSent, setTicketSent] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketBody, setTicketBody] = useState('');

  if (!isOpen) return null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;

    const msgText = inputMsg.trim();
    const newMsg = { sender: 'user' as const, text: msgText, time: 'الآن' };
    setMessages((prev) => [...prev, newMsg]);
    setInputMsg('');

    if (onCreateSupportTicket) {
      onCreateSupportTicket({
        userId: currentUser?.id || 'usr_guest',
        userName: currentUser?.name || 'مستخدم الزائر',
        userPhone: currentUser?.phone || '0790000000',
        userEmail: currentUser?.email || 'user@malaebak.jo',
        subject: 'محادثة مباشرة من التطبيق',
        message: msgText,
        category: 'استفسار عام',
      });
    }

    // Response from Jordan Support Team
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'support',
          text: 'وصلت رسالتك مباشرة إلى لوحة تحكم الإدارة وسيتم الرد عليك فوراً! 🇯🇴',
          time: 'الآن',
        },
      ]);
    }, 1000);
  };

  const handleSendTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketBody.trim()) return;

    if (onCreateSupportTicket) {
      onCreateSupportTicket({
        userId: currentUser?.id || 'usr_guest',
        userName: currentUser?.name || 'مستخدم التطبيق',
        userPhone: currentUser?.phone || '0790000000',
        userEmail: currentUser?.email || 'user@malaebak.jo',
        subject: ticketSubject.trim(),
        message: ticketBody.trim(),
        category: 'شكوى ملعب',
      });
    }

    setTicketSent(true);
    setTimeout(() => {
      setTicketSent(false);
      setTicketSubject('');
      setTicketBody('');
      onClose();
    }, 2500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-40 pb-16 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-colors ${
            isDarkMode
              ? 'bg-[#0F172A] border-slate-800 text-white'
              : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          {/* Modal Header */}
          <div className="p-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-md border border-white/20 shadow-md">
                <Headphones className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-base font-black flex items-center gap-1.5">
                  <span>الدعم الفني والتواصل المباشر</span>
                  <span className="text-[10px] bg-emerald-400 text-slate-950 font-black px-2 py-0.5 rounded-full">
                    24/7 متاحة
                  </span>
                </h3>
                <p className="text-xs text-white/80 font-medium">تواصل مباشر مع إدارة {pitchName}</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Contact Mode Tabs */}
          <div className={`grid grid-cols-3 p-1.5 border-b text-xs font-bold gap-1 shrink-0 ${
            isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'
          }`}>
            <button
              onClick={() => setActiveTab('chat')}
              className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'chat'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                  : isDarkMode
                  ? 'text-slate-400 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>محادثة مباشرة</span>
            </button>

            <button
              onClick={() => setActiveTab('call')}
              className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'call'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                  : isDarkMode
                  ? 'text-slate-400 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Phone className="w-4 h-4" />
              <span>اتصال هاتفي</span>
            </button>

            <button
              onClick={() => setActiveTab('ticket')}
              className={`py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'ticket'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                  : isDarkMode
                  ? 'text-slate-400 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>إرسال شكوى/طلب</span>
            </button>
          </div>

          {/* Modal Content */}
          <div className="p-4 flex-1 overflow-y-auto min-h-0">
            {/* TAB 1: LIVE CHAT */}
            {activeTab === 'chat' && (
              <div className="flex flex-col h-full min-h-[320px]">
                {/* Chat Messages Stream */}
                <div className="flex-1 space-y-3 overflow-y-auto p-2 mb-3">
                  {messages.map((m, idx) => (
                    <div
                      key={idx}
                      className={`flex flex-col ${
                        m.sender === 'user' ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`max-w-[85%] p-3 rounded-2xl text-xs font-medium leading-relaxed ${
                          m.sender === 'user'
                            ? 'bg-emerald-600 text-white rounded-tl-none shadow-md'
                            : isDarkMode
                            ? 'bg-slate-800 text-slate-200 border border-slate-700 rounded-tr-none'
                            : 'bg-slate-100 text-slate-800 border border-slate-200 rounded-tr-none shadow-sm'
                        }`}
                      >
                        <p>{m.text}</p>
                        <span className="block text-[9px] opacity-60 text-left dir-ltr mt-1">{m.time}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Input Bar */}
                <form onSubmit={handleSendMessage} className="flex items-center gap-2 pt-2 border-t border-slate-700/50">
                  <input
                    type="text"
                    value={inputMsg}
                    onChange={(e) => setInputMsg(e.target.value)}
                    placeholder="اكتب رسالتك للإدارة أو صاحب الملعب..."
                    className={`flex-1 px-3.5 py-2.5 rounded-xl text-xs border outline-none font-medium transition-colors ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-white focus:border-emerald-500'
                        : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-600'
                    }`}
                  />
                  <button
                    type="submit"
                    className="p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all shrink-0 shadow-md"
                  >
                    <Send className="w-4 h-4 rotate-180" />
                  </button>
                </form>
              </div>
            )}

            {/* TAB 2: DIRECT CALL & WHATSAPP */}
            {activeTab === 'call' && (
              <div className="space-y-4 py-2">
                <div className={`p-4 rounded-2xl border text-right space-y-3 ${
                  isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}>
                  <h4 className="text-sm font-black text-emerald-500 flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    <span>خطوط التواصل المباشر المعتمدة في الإدارة 🇯🇴</span>
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    يمكنك الاتصال بمركز خدمة العملاء أو مراسلتنا فوراً عبر الواتساب للاستفسارات عن التكميلات والحجوزات.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                    {/* WhatsApp Direct Link */}
                    <a
                      href={`https://wa.me/${(platformConfig.supportWhatsapp || '+962791234567').replace(/[^0-9]/g, '')}?text=${encodeURIComponent('مرحبا، أرغب بالاستفسار عن خدمات ملاعبك')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-between transition-all shadow-md group"
                    >
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-emerald-200" />
                        <span>واتساب الإدارة</span>
                      </div>
                      <span className="font-mono text-[11px] dir-ltr font-bold">{platformConfig.supportWhatsapp}</span>
                    </a>

                    {/* Phone Call Hotline */}
                    <a
                      href={`tel:${(platformConfig.supportPhone || '+96265000000').replace(/\s+/g, '')}`}
                      className="p-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-between transition-all shadow-md group"
                    >
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-blue-200" />
                        <span>الهاتف المباشر</span>
                      </div>
                      <span className="font-mono text-[11px] dir-ltr font-bold">{platformConfig.supportPhone}</span>
                    </a>
                  </div>

                  {platformConfig.supportEmail && (
                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-300">
                      <span className="flex items-center gap-1.5 text-slate-400">
                        <Mail className="w-3.5 h-3.5 text-sky-400" />
                        <span>البريد الإلكتروني للدعم:</span>
                      </span>
                      <strong className="font-mono text-[#39FF14] text-[11px] dir-ltr">{platformConfig.supportEmail}</strong>
                    </div>
                  )}
                </div>

                {/* Pitch Location Info */}
                <div className={`p-3.5 rounded-2xl border text-xs space-y-2 ${
                  isDarkMode ? 'bg-slate-900/50 border-slate-800 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
                }`}>
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5 text-emerald-500">
                      <MapPin className="w-4 h-4" />
                      <span>موقع إدارة الملاعب الرئيسية:</span>
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Jordan</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">{platformConfig.headquartersAddress}</p>
                  <div className="flex items-center gap-2 text-[10px] text-emerald-400 font-semibold pt-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>أوقات العمل: {platformConfig.workingHours}</span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: ADMIN TICKET / FORM */}
            {activeTab === 'ticket' && (
              <form onSubmit={handleSendTicket} className="space-y-3.5 py-1">
                {ticketSent ? (
                  <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-6 text-center space-y-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl"
                  >
                    <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                    <h4 className="text-sm font-black text-emerald-400">تم إرسال طلبك بنجاح!</h4>
                    <p className="text-xs text-slate-300">
                      رقم التذكرة: <strong className="font-mono text-emerald-300">#JO-88349</strong>. سيصلك رد الإدارة إشعار فور مراجعته.
                    </p>
                  </motion.div>
                ) : (
                  <>
                    <div className="text-right">
                      <label className="block text-xs font-bold mb-1">عنوان الموضوع أو الملاحظة:</label>
                      <input
                        type="text"
                        required
                        value={ticketSubject}
                        onChange={(e) => setTicketSubject(e.target.value)}
                        placeholder="مثال: استفسار عن حجز ملعب خماسي / مشكلة بالرصيد..."
                        className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none font-medium ${
                          isDarkMode
                            ? 'bg-slate-900 border-slate-700 text-white focus:border-emerald-500'
                            : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-600'
                        }`}
                      />
                    </div>

                    <div className="text-right">
                      <label className="block text-xs font-bold mb-1">تفاصيل الرسالة:</label>
                      <textarea
                        required
                        rows={4}
                        value={ticketBody}
                        onChange={(e) => setTicketBody(e.target.value)}
                        placeholder="اكتب كامل التفاصيل لمساعدتك بسرعة..."
                        className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none font-medium ${
                          isDarkMode
                            ? 'bg-slate-900 border-slate-700 text-white focus:border-emerald-500'
                            : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-600'
                        }`}
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-all shadow-md flex items-center justify-center gap-2"
                    >
                      <Send className="w-4 h-4" />
                      <span>إرسال الطلب للإدارة</span>
                    </button>
                  </>
                )}
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
