import React, { useState } from 'react';
import { FLUTTER_CODE_FILES, FlutterFile } from '../data/flutterCode';
import { Code2, Copy, Check, Download, FileCode, Folder, Search, ArrowRight, Sparkles } from 'lucide-react';

interface Props {
  onBackToApp: () => void;
}

export const FlutterCodeViewer: React.FC<Props> = ({ onBackToApp }) => {
  const [selectedFile, setSelectedFile] = useState<FlutterFile>(FLUTTER_CODE_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredFiles = FLUTTER_CODE_FILES.filter(
    (f) =>
      f.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0F172A] min-h-0 text-white overflow-hidden">
      {/* Top Banner */}
      <div className="p-3 bg-[#1E293B] border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={onBackToApp}
            className="p-1.5 rounded-xl bg-slate-800 text-[#39FF14] hover:bg-slate-700 font-bold text-xs flex items-center gap-1"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للتطبيق التفاعلي</span>
          </button>

          <div className="hidden sm:flex items-center gap-2 border-r border-slate-700 pr-2.5">
            <Code2 className="w-5 h-5 text-[#39FF14]" />
            <span className="text-xs font-extrabold text-white">Flutter Source Code Architecture</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyCode}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-cyan-300 flex items-center gap-1.5 border border-slate-700"
          >
            {copied ? <Check className="w-4 h-4 text-[#39FF14]" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
          </button>

          <button
            onClick={handleDownloadFile}
            className="px-3 py-1.5 rounded-xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shadow-md shadow-[#39FF14]/20"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل {selectedFile.fileName}</span>
          </button>
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="flex-1 flex flex-col sm:flex-row min-h-0 overflow-hidden">
        {/* Left Sidebar File Explorer */}
        <div className="w-full sm:w-64 bg-[#182234] border-b sm:border-b-0 sm:border-l border-slate-800 p-3 flex flex-col gap-2 shrink-0 overflow-y-auto">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5" />
            <input
              type="text"
              placeholder="بحث في ملفات فلاتر..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-8 pl-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#39FF14]"
            />
          </div>

          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 mt-1">
            <Folder className="w-3.5 h-3.5 text-amber-400" />
            <span>ملفات المشروع (Flutter Widgets & Models):</span>
          </div>

          <div className="space-y-1">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.fileName === file.fileName;
              return (
                <button
                  key={file.fileName}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-right p-2 rounded-xl text-xs font-mono transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-[#39FF14]/15 border border-[#39FF14] text-[#39FF14] font-bold'
                      : 'bg-slate-900/60 border border-slate-800/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="flex items-center gap-2 truncate dir-ltr">
                    <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span className="truncate">{file.fileName}</span>
                  </span>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-[#39FF14] animate-ping" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Code Editor Display */}
        <div className="flex-1 flex flex-col bg-[#0B101D] overflow-hidden min-h-0">
          {/* File Meta Header */}
          <div className="p-2.5 bg-[#131B2E] border-b border-slate-800 text-xs flex items-center justify-between text-slate-300">
            <div className="flex items-center gap-2 dir-ltr font-mono text-cyan-300 font-bold">
              <FileCode className="w-4 h-4 text-[#39FF14]" />
              <span>{selectedFile.path}</span>
            </div>
            <span className="text-[11px] text-slate-400 font-sans truncate max-w-xs">{selectedFile.description}</span>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="flex-1 p-4 overflow-auto font-mono text-xs leading-relaxed dir-ltr text-slate-200">
            <pre className="whitespace-pre">
              <code>{selectedFile.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
