import React, { useState } from 'react';
import { Smartphone, Monitor, Wifi, Battery, Signal } from 'lucide-react';

interface Props {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<Props> = ({ children }) => {
  const [isMobileMode, setIsMobileMode] = useState<boolean>(true);

  return (
    <div className="w-full h-screen bg-slate-950 flex flex-col items-center justify-center p-0 sm:p-4 overflow-hidden select-none font-sans">
      {/* Frame Mode Switcher Bar */}
      <div className="hidden sm:flex items-center justify-between w-full max-w-4xl mb-2 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-2 font-bold text-slate-200">
          <span className="w-2.5 h-2.5 rounded-full bg-[#39FF14] animate-ping" />
          <span>تطبيق ملعبك الهجين (Jordan Flutter Mobile UI)</span>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-xl">
          <button
            onClick={() => setIsMobileMode(true)}
            className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
              isMobileMode
                ? 'bg-[#39FF14] text-slate-950 shadow-md shadow-[#39FF14]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>عرض الهاتف (Mobile Frame)</span>
          </button>
          <button
            onClick={() => setIsMobileMode(false)}
            className={`px-3 py-1 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
              !isMobileMode
                ? 'bg-[#39FF14] text-slate-950 shadow-md shadow-[#39FF14]/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>الشاشة الكاملة (Full Screen)</span>
          </button>
        </div>
      </div>

      {/* Main Outer Container */}
      <div
        className={`relative flex flex-col bg-[#0F172A] overflow-hidden transition-all duration-300 ${
          isMobileMode
            ? 'w-full max-w-[430px] h-full sm:h-[880px] sm:rounded-[48px] border-0 sm:border-[10px] border-slate-800 shadow-2xl ring-1 ring-slate-700/50'
            : 'w-full h-full rounded-none sm:rounded-3xl border border-slate-800 shadow-2xl'
        }`}
      >


        {/* Dynamic App Content */}
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
          {children}
        </div>

        {/* Mobile Bottom Navigation Bar / Home Bar */}
        {isMobileMode && (
          <div className="w-full bg-[#0F172A] pt-1 pb-2 flex justify-center shrink-0 border-t border-slate-800/40">
            <div className="w-32 h-1 bg-slate-600 rounded-full" />
          </div>
        )}
      </div>
    </div>
  );
};
