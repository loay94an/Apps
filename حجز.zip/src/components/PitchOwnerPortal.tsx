import React, { useState } from 'react';
import { Pitch, PitchRequest, User, SportType } from '../types';
import { Store, PlusCircle, CheckCircle2, MapPin, DollarSign, Clock, Tag, Sparkles, Send, MessageSquare } from 'lucide-react';

interface Props {
  currentUser: User;
  pitches: Pitch[];
  pitchRequests?: PitchRequest[];
  onSubmitPitchRequest: (req: Omit<PitchRequest, 'id' | 'createdAt' | 'status'>) => void;
  onSendNegotiationMessage?: (reqId: string, message: string) => void;
}

export const PitchOwnerPortal: React.FC<Props> = ({
  currentUser,
  pitches,
  pitchRequests = [],
  onSubmitPitchRequest,
  onSendNegotiationMessage,
}) => {
  const [activeTab, setActiveTab] = useState<'my_pitches' | 'add_request' | 'offers' | 'my_requests'>('my_pitches');

  // Pitch Addition Request Form state
  const [pitchName, setPitchName] = useState<string>('مجمع الملوك الرياضي السداسي');
  const [city, setCity] = useState<'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش'>('عمان');
  const [district, setDistrict] = useState<string>('تلاع العلي - بجانب أسواق السلطان');
  const [sports, setSports] = useState<SportType[]>(['football']);
  const [surfaceType, setSurfaceType] = useState<string>('حشيش صناعي ممتاز (الجيل الخامس)');
  const [hourlyRate, setHourlyRate] = useState<number>(35);
  const [amenities, setAmenities] = useState<string>('إضاءة كاشفة LED, غرف تبديل وملابس, كافيه ومشروبات, موقف سيارات واسع');
  const [notes, setNotes] = useState<string>('الملعب مجهز بأحدث معايير الأمان ونود اعتماده في التطبيق.');
  const [requestSubmitted, setRequestSubmitted] = useState<boolean>(false);

  // Promo offer state
  const [offerTitle, setOfferTitle] = useState<string>('خصم الصيف الصباحي 25%');
  const [discountPercent, setDiscountPercent] = useState<number>(25);

  // Negotiation reply text state
  const [replyTextMap, setReplyTextMap] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitPitchRequest({
      ownerName: currentUser.name,
      ownerEmail: currentUser.email,
      ownerPhone: currentUser.phone,
      pitchName,
      city,
      district,
      sports,
      surfaceType,
      hourlyRate,
      amenities: amenities.split(',').map((a) => a.trim()),
      image: 'https://images.unsplash.com/photo-1529900748604-07564a03e7a6?w=800&auto=format&fit=crop&q=80',
      notes,
    });

    setRequestSubmitted(true);
    setTimeout(() => {
      setRequestSubmitted(false);
      setActiveTab('my_requests');
    }, 2500);
  };

  const myPitches = pitches.filter((p) => p.ownerName.includes(currentUser.name) || p.ownerId === currentUser.id || true);
  const myRequests = pitchRequests.filter(
    (r) => r.ownerName.includes(currentUser.name) || r.ownerEmail === currentUser.email || r.ownerPhone === currentUser.phone || true
  );

  return (
    <div className="flex-1 flex flex-col p-4 bg-[#0F172A] overflow-y-auto space-y-4">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border border-amber-500/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-white">بوابة أصحاب الملاعب - Pitch Owner Portal</h2>
            <p className="text-xs text-slate-400">إدارة الملاعب والمواعيد وتقديم طلبات إضافة ملاعب جديدة والتفاوض مع الإدارة</p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="grid grid-cols-4 gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-[11px] font-bold">
        <button
          onClick={() => setActiveTab('my_pitches')}
          className={`py-2 rounded-xl transition-all ${activeTab === 'my_pitches' ? 'bg-amber-500 text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'}`}
        >
          ملاعي ({myPitches.length})
        </button>
        <button
          onClick={() => setActiveTab('my_requests')}
          className={`py-2 rounded-xl transition-all ${activeTab === 'my_requests' ? 'bg-amber-500 text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'}`}
        >
          طلباتي والتفاوض ({myRequests.length})
        </button>
        <button
          onClick={() => setActiveTab('add_request')}
          className={`py-2 rounded-xl transition-all ${activeTab === 'add_request' ? 'bg-amber-500 text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'}`}
        >
          ➕ طلب ملعب جديد
        </button>
        <button
          onClick={() => setActiveTab('offers')}
          className={`py-2 rounded-xl transition-all ${activeTab === 'offers' ? 'bg-amber-500 text-slate-950 font-black shadow-md' : 'text-slate-400 hover:text-white'}`}
        >
          🏷️ العروض والخصومات
        </button>
      </div>

      {/* Tab Content 1: MY PITCHES */}
      {activeTab === 'my_pitches' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <span className="text-slate-400 block">إجمالي الإيرادات هذا الشهر:</span>
              <strong className="text-xl font-black text-[#39FF14] mt-1 block">840 JOD</strong>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <span className="text-slate-400 block">الحجوزات المكتملة:</span>
              <strong className="text-xl font-black text-amber-400 mt-1 block">24 حجز</strong>
            </div>
          </div>

          <h3 className="text-xs font-bold text-slate-300">قائمة الملاعب التابعة لك:</h3>
          {myPitches.map((pitch) => (
            <div key={pitch.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex justify-between items-start">
                <div className="flex gap-3">
                  <img src={pitch.image} alt={pitch.name} className="w-16 h-16 rounded-xl object-cover" referrerPolicy="no-referrer" />
                  <div>
                    <h4 className="text-sm font-bold text-white">{pitch.name}</h4>
                    <p className="text-xs text-slate-400">{pitch.city} - {pitch.district}</p>
                    <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded mt-1 inline-block">
                      {pitch.surfaceType}
                    </span>
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-base font-extrabold text-[#39FF14] dir-ltr">{pitch.hourlyRate} JOD/ساعة</span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded block mt-1">
                    مُعتمد ومفعل
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab Content 2: MY REQUESTS & NEGOTIATIONS */}
      {activeTab === 'my_requests' && (
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-300">طلباتك ورسائل التفاوض مع إدارة التطبيق:</h3>
          {myRequests.length === 0 ? (
            <div className="p-6 text-center text-slate-400 bg-slate-900 rounded-2xl border border-slate-800">
              لم تقدم أي طلبات بعد.
            </div>
          ) : (
            myRequests.map((req) => (
              <div key={req.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-white text-sm">{req.pitchName}</h4>
                      <span className={`text-[9px] px-2 py-0.5 rounded font-black ${
                        req.status === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : req.status === 'negotiating'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-blue-500/20 text-blue-300'
                      }`}>
                        {req.status === 'approved'
                          ? 'مقبول ومفعل 🎉'
                          : req.status === 'negotiating'
                          ? 'جاري التفاوض مع الإدارة 💬'
                          : 'قيد المراجعة ⏳'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{req.city} - {req.district}</p>
                  </div>

                  <div className="text-left">
                    <span className="text-sm font-black text-[#39FF14] dir-ltr">
                      {req.negotiatedRate ? `${req.negotiatedRate} JOD (سعر متفاوض عليه)` : `${req.hourlyRate} JOD/ساعة`}
                    </span>
                  </div>
                </div>

                {req.negotiatedTerms && (
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
                    <strong>شروط العقد المقترحة من الإدارة:</strong>
                    <p className="mt-0.5">{req.negotiatedTerms}</p>
                  </div>
                )}

                {/* Negotiation Chat */}
                <div className="p-3 rounded-xl bg-slate-800/80 space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 block">محادثة التفاوض المباشرة:</span>
                  {req.negotiationHistory && req.negotiationHistory.length > 0 ? (
                    req.negotiationHistory.map((msg) => (
                      <div
                        key={msg.id}
                        className={`p-2 rounded-xl text-xs ${
                          msg.sender === 'owner' ? 'bg-amber-500/20 text-amber-200 border border-amber-500/30 mr-4' : 'bg-slate-700 text-slate-200 ml-4'
                        }`}
                      >
                        <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                          <span>{msg.senderName}</span>
                          <span>{msg.createdAt}</span>
                        </div>
                        <p>{msg.message}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-slate-500">لا توجد رسائل سابقة. يمكنك إرسال استفسار للإدارة هنا.</p>
                  )}

                  <div className="flex gap-2 pt-1">
                    <input
                      type="text"
                      value={replyTextMap[req.id] || ''}
                      onChange={(e) => setReplyTextMap({ ...replyTextMap, [req.id]: e.target.value })}
                      placeholder="اكتب ردك أو موافقتك للإدارة..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-white text-xs"
                    />
                    <button
                      onClick={() => {
                        const msg = replyTextMap[req.id];
                        if (!msg || !msg.trim()) return;
                        if (onSendNegotiationMessage) {
                          onSendNegotiationMessage(req.id, msg);
                        }
                        setReplyTextMap({ ...replyTextMap, [req.id]: '' });
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs shrink-0 flex items-center gap-1"
                    >
                      <Send className="w-3.5 h-3.5" />
                      إرسال الرد
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab Content 3: ADD PITCH REQUEST FORM */}
      {activeTab === 'add_request' && (
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          {requestSubmitted ? (
            <div className="p-8 text-center space-y-3">
              <CheckCircle2 className="w-16 h-16 text-[#39FF14] mx-auto animate-bounce" />
              <h3 className="text-lg font-bold text-white">تم تقديم طلب إضافة الملعب بنجاح! 📝</h3>
              <p className="text-xs text-slate-300">
                تم إرسال طلبك إلى لوحة تحكم صاحب التطبيق للإصدار والموافقة الرسمية.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div className="flex items-center gap-2 text-amber-400 font-bold border-b border-slate-800 pb-2">
                <PlusCircle className="w-4 h-4" />
                <span>تقديم طلب إضافة ملعب جديد لصاحب التطبيق:</span>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">اسم الملعب:</label>
                <input
                  type="text"
                  value={pitchName}
                  onChange={(e) => setPitchName(e.target.value)}
                  required
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">المدينة:</label>
                  <select
                    value={city}
                    onChange={(e: any) => setCity(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="عمان">عمان</option>
                    <option value="إربد">إربد</option>
                    <option value="الزرقاء">الزرقاء</option>
                    <option value="العقبة">العقبة</option>
                    <option value="السلط">السلط</option>
                    <option value="جرش">جرش</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">المنطقة / العنوان:</label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    required
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">نوع الأرضية:</label>
                  <input
                    type="text"
                    value={surfaceType}
                    onChange={(e) => setSurfaceType(e.target.value)}
                    required
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">السعر بالساعة (JOD):</label>
                  <input
                    type="number"
                    value={hourlyRate}
                    onChange={(e) => setHourlyRate(Number(e.target.value))}
                    required
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">الخدمات والمرافق (مفصولة بفاصلة):</label>
                <input
                  type="text"
                  value={amenities}
                  onChange={(e) => setAmenities(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">ملاحظات إضافية للإدارة:</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
              >
                <Send className="w-4 h-4" />
                إرسال الطلب للإدارة للموافقة
              </button>
            </form>
          )}
        </div>
      )}

      {/* Tab Content 4: OFFERS */}
      {activeTab === 'offers' && (
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
            <Tag className="w-4 h-4" />
            إنشاء عرض خصم جديد لملاعبك:
          </h3>

          <div className="space-y-2 text-xs">
            <div>
              <label className="text-slate-300 block mb-1">عنوان العرض:</label>
              <input
                type="text"
                value={offerTitle}
                onChange={(e) => setOfferTitle(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1">نسبة الخصم (%):</label>
              <input
                type="number"
                value={discountPercent}
                onChange={(e) => setDiscountPercent(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>

            <button
              onClick={() => alert(`تم نشر العرض "${offerTitle}" بنسبة ${discountPercent}% على جميع ملاعبك!`)}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              تفعيل العرض فوراً
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
