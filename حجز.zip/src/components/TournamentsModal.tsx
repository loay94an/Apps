import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Tournament, SportType, User } from '../types';
import { Trophy, Award, Calendar, MapPin, Users, DollarSign, CheckCircle2, X, ChevronRight, Sparkles } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  tournaments: Tournament[];
  selectedSport: SportType;
  currentUser: User;
  onRegisterTeam: (tournamentId: string, teamName: string) => void;
}

export const TournamentsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  tournaments,
  selectedSport,
  currentUser,
  onRegisterTeam,
}) => {
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [teamName, setTeamName] = useState<string>('فريق فرسان عمان ⚽');
  const [registeredSuccess, setRegisteredSuccess] = useState<boolean>(false);

  const filteredTournaments = tournaments.filter((t) => t.sport === selectedSport);

  const handleRegister = () => {
    if (!selectedTournament) return;
    onRegisterTeam(selectedTournament.id, teamName);
    setRegisteredSuccess(true);
    setTimeout(() => {
      setRegisteredSuccess(false);
      setSelectedTournament(null);
    }, 2500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-40 pb-16 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-[#1E293B] border border-yellow-500/40 rounded-3xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                  <Trophy className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                    البطولات والدوريات الأردنية 🏆
                  </h2>
                  <p className="text-xs text-slate-400">سجل فريقك في الدوريات المتاحة وشجرة التصفيات المباشرة</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {registeredSuccess ? (
                <div className="p-8 text-center space-y-3 my-6">
                  <CheckCircle2 className="w-16 h-16 text-[#39FF14] mx-auto animate-bounce" />
                  <h3 className="text-lg font-extrabold text-white">تم تسجيل فريقك "{teamName}" بنجاح!</h3>
                  <p className="text-xs text-slate-300">
                    تم إدراج اسم فريقك في جدول مباريات البطولة وشجرة التصفيات الرسمية.
                  </p>
                </div>
              ) : selectedTournament ? (
                /* Detail & Knockout Bracket View */
                <div className="space-y-4">
                  <button
                    onClick={() => setSelectedTournament(null)}
                    className="text-xs text-yellow-400 font-bold hover:underline flex items-center gap-1"
                  >
                    &rarr; العودة لقائمة البطولات
                  </button>

                  <div className="p-4 rounded-2xl bg-slate-900 border border-yellow-500/40 space-y-3">
                    <img
                      src={selectedTournament.bannerImage}
                      alt={selectedTournament.title}
                      className="w-full h-32 object-cover rounded-xl"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-base font-extrabold text-white">{selectedTournament.title}</h3>
                        <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                          <MapPin className="w-3.5 h-3.5 text-yellow-400" />
                          <span>{selectedTournament.pitchName} - {selectedTournament.city}</span>
                        </p>
                      </div>

                      <div className="text-left dir-ltr">
                        <span className="text-lg font-black text-[#39FF14]">{selectedTournament.firstPrize} JOD</span>
                        <span className="text-[10px] text-slate-400 block">الجائزة الأولى 🥇</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs bg-slate-800/80 p-2.5 rounded-xl text-slate-300">
                      <div>رسوم الاشتراك للفريق: <strong>{selectedTournament.entryFeePerTeam} JOD</strong></div>
                      <div>الفرق المسجلة: <strong>{selectedTournament.teamsCount} / {selectedTournament.maxTeams} فريق</strong></div>
                    </div>

                    {/* Knockout Bracket Visualizer Tree (شجرة التصفيات) */}
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                      <h4 className="text-xs font-extrabold text-yellow-400 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-yellow-400" />
                        شجرة التصفيات الرسمية (Knockout Bracket Tree):
                      </h4>

                      <div className="space-y-4">
                        {selectedTournament.brackets.map((round, rIdx) => (
                          <div key={rIdx} className="space-y-2">
                            <span className="text-[11px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded">
                              {round.roundName}
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {round.matches.map((bm) => (
                                <div
                                  key={bm.id}
                                  className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1"
                                >
                                  <div className="flex justify-between items-center text-white">
                                    <span className={bm.winner === bm.teamA ? 'font-bold text-[#39FF14]' : ''}>
                                      {bm.teamA}
                                    </span>
                                    <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-amber-400">
                                      {bm.scoreA ?? '-'}
                                    </span>
                                  </div>
                                  <div className="flex justify-between items-center text-white">
                                    <span className={bm.winner === bm.teamB ? 'font-bold text-[#39FF14]' : ''}>
                                      {bm.teamB}
                                    </span>
                                    <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-amber-400">
                                      {bm.scoreB ?? '-'}
                                    </span>
                                  </div>
                                  {bm.isLive && (
                                    <span className="text-[9px] text-red-400 bg-red-500/10 px-1.5 py-0.2 rounded font-bold animate-pulse block text-center">
                                      مباشر الآن ⚽
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Registration Form */}
                    <div className="pt-2 border-t border-slate-800 space-y-2">
                      <label className="text-xs font-bold text-slate-300 block">اسم فريقك المتقدم:</label>
                      <input
                        type="text"
                        value={teamName}
                        onChange={(e) => setTeamName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-yellow-500"
                      />
                      <button
                        onClick={handleRegister}
                        className="w-full py-3.5 rounded-xl bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black text-sm shadow-lg shadow-yellow-500/30 mt-2"
                      >
                        تسجيل الفريق ودفع رسوم الاشتراك ({selectedTournament.entryFeePerTeam} JOD)
                      </button>
                    </div>
                  </div>
                </div>
              ) : filteredTournaments.length === 0 ? (
                <div className="p-8 text-center text-slate-400">
                  لا توجد بطولات جارية حالياً لنوع الرياضة المحدد.
                </div>
              ) : (
                /* Tournaments List */
                filteredTournaments.map((trn) => (
                  <div
                    key={trn.id}
                    className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-yellow-500/50 transition-all space-y-3"
                  >
                    <div className="relative h-28 rounded-xl overflow-hidden">
                      <img src={trn.bannerImage} alt={trn.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-3 flex flex-col justify-end">
                        <span className="text-[10px] bg-yellow-500 text-slate-950 font-black px-2 py-0.5 rounded-full w-fit">
                          {trn.city} - {trn.pitchName}
                        </span>
                        <h3 className="text-base font-extrabold text-white mt-1">{trn.title}</h3>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center text-xs bg-slate-800/60 p-2 rounded-xl">
                      <div>
                        <span className="text-[10px] text-slate-400 block">الجائزة الأولى</span>
                        <strong className="text-[#39FF14]">{trn.firstPrize} JOD</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">رسوم الاشتراك</span>
                        <strong className="text-white">{trn.entryFeePerTeam} JOD</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">الفرق المسجلة</span>
                        <strong className="text-amber-400">{trn.teamsCount}/{trn.maxTeams}</strong>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs text-slate-400 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-yellow-400" />
                        {trn.startDate} - {trn.endDate}
                      </span>
                      <button
                        onClick={() => setSelectedTournament(trn)}
                        className="px-4 py-2 rounded-xl bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black text-xs shadow-md shadow-yellow-500/20"
                      >
                        عرض التفاصيل والشجرة
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
