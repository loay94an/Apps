import React, { useState } from 'react';
import { User, SportType } from '../types';
import { SPORTS_LIST, SportSelectorBottomSheet } from './SportSelectorBottomSheet';
import { getSportTheme } from '../lib/sportThemes';
import { Award, ChevronDown, Sparkles, UserCheck, ShieldAlert, Store, Flame, Sun, Moon, Headphones, CreditCard, PlusCircle, Star } from 'lucide-react';

interface Props {
  user: User;
  selectedSport: SportType;
  onSelectSport: (sport: SportType) => void;
  activeViewMode: 'app' | 'flutter_code' | 'gamification_details';
  onChangeViewMode: (mode: 'app' | 'flutter_code' | 'gamification_details') => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onOpenSupport?: () => void;
  onOpenPayment?: () => void;
  onOpenProfile?: () => void;
  onOpenRating?: () => void;
}

export const Header: React.FC<Props> = ({
  user,
  selectedSport,
  onSelectSport,
  activeViewMode,
  onChangeViewMode,
  onOpenAuth,
  onLogout,
  isDarkMode,
  onToggleTheme,
  onOpenSupport,
  onOpenPayment,
  onOpenProfile,
  onOpenRating,
}) => {
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);

  const activeSportObj = SPORTS_LIST.find((s) => s.id === selectedSport) || SPORTS_LIST[0];
  const sportTheme = getSportTheme(selectedSport, isDarkMode);
  const xpPercentage = Math.min(100, Math.round((user.xp / user.maxXp) * 100));

  return (
    <>
      <header className={`sticky top-0 z-30 backdrop-blur-md border-b shadow-xl px-3 sm:px-5 py-2 transition-colors ${sportTheme.headerBg} ${sportTheme.headerBorder} text-white shadow-black/60`}>
        {/* Topmost Navigation Bar: Sport Selector + Jawaker Golden Balance Pill */}
        <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-white/10 gap-2">
          {/* Clickable Sport Selector - Styled like a Jawaker Club Chip */}
          <button
            onClick={() => setIsBottomSheetOpen(true)}
            className={`group flex items-center gap-1.5 px-3 py-1 rounded-full border ${sportTheme.chipBorder} ${sportTheme.chipBg} text-amber-300 text-xs font-black transition-all hover:scale-105 active:scale-95 shadow-md shadow-black/40`}
          >
            <span className="text-[10px] opacity-80">النادي:</span>
            <span className="text-xs font-extrabold flex items-center gap-1 text-white">
              <span>{activeSportObj.icon}</span>
              <span>{activeSportObj.label}</span>
              <ChevronDown className="w-3.5 h-3.5 text-amber-400 transition-transform group-hover:translate-y-0.5" />
            </span>
          </button>

          {/* Prominent Payment Balance Button - Jawaker Gold Tokens Pill */}
          <button
            onClick={onOpenPayment}
            className="px-3.5 py-1.5 rounded-full border-2 border-amber-400/80 bg-gradient-to-r from-amber-500/20 via-yellow-500/30 to-amber-600/20 text-amber-300 text-xs font-black transition-all flex items-center gap-2 hover:scale-105 active:scale-95 shadow-lg shadow-amber-500/20 hover:border-amber-300"
            title="انقر لشحن رصيد المحفظة والتوكنات"
          >
            <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 font-black flex items-center justify-center text-[10px] shadow-sm border border-yellow-200">
              🪙
            </div>
            <span className="text-[10px] text-amber-200/90 font-medium">الرصيد:</span>
            <span className="font-mono text-xs font-black dir-ltr text-yellow-300 tracking-wide">
              {(user.walletBalance || 0).toFixed(2)} JOD
            </span>
            <PlusCircle className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
          </button>
        </div>

        {/* User Info Bar & Quick Action Controls */}
        <div className="flex items-center justify-between gap-2.5">
          {/* User Info Avatar & Stats - Styled with Golden Frame */}
          <button
            onClick={onOpenProfile}
            className="flex items-center gap-2.5 min-w-0 flex-1 text-right hover:opacity-95 transition-opacity group"
            title="انقر لعرض وتعديل ملفك الشخصي وإحصائياتك"
          >
            <div className="relative shrink-0">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-10 h-10 rounded-full object-cover border-2 border-amber-400 ring-2 ring-amber-500/40 bg-slate-900 p-0.5 shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform"
                referrerPolicy="no-referrer"
              />
              <span className="absolute -bottom-1 -right-1 bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 text-[8px] font-black px-1.5 py-0.2 rounded-full shadow-md border border-amber-200 dir-ltr">
                ⭐ L{user.level}
              </span>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-xs font-black truncate max-w-[100px] sm:max-w-[150px] text-amber-100 group-hover:text-yellow-300 transition-colors">
                  {user.name}
                </span>
                <span className="bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 text-[9px] px-2 py-0.2 rounded-md font-black shadow-md border border-yellow-200 shrink-0">
                  👑 {user.rankTitle || `VIP ${user.level}`}
                </span>
              </div>

              {/* XP Bar */}
              <div className="mt-1 flex items-center gap-1.5">
                <div className="flex-1 h-2 rounded-full overflow-hidden bg-slate-950/80 border border-amber-500/30 p-0.5">
                  <div
                    className="bg-gradient-to-r from-emerald-400 via-amber-400 to-yellow-300 h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]"
                    style={{ width: `${xpPercentage}%` }}
                  />
                </div>
                <span className="text-[9px] font-mono dir-ltr shrink-0 font-bold text-amber-300">
                  {user.xp}/{user.maxXp} XP
                </span>
              </div>
            </div>
          </button>

          {/* Action Icons Layout */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Player Rating System Button */}
            {onOpenRating && (
              <button
                onClick={onOpenRating}
                className="p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border border-amber-500/40 bg-slate-900/80 text-amber-400 hover:bg-amber-500/20 shadow-md"
                title="تقييم اللاعبين والحكام"
              >
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              </button>
            )}

            {/* Support & Direct Chat Icon Button */}
            <button
              onClick={onOpenSupport}
              className="p-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border border-emerald-500/40 bg-slate-900/80 text-emerald-400 hover:bg-emerald-500/20 shadow-md relative"
              title="الدعم الفني والخدمة المباشرة"
            >
              <Headphones className="w-4 h-4 text-emerald-400" />
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse absolute -top-0.5 -right-0.5 border border-slate-900" />
            </button>

            {/* Day / Night Theme Switch */}
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center border border-amber-500/30 bg-slate-900/80 text-amber-300 hover:bg-amber-500/20 shadow-md"
              title={isDarkMode ? 'تفعيل وضع النهار (☀️)' : 'تفعيل وضع الليل (🌙)'}
            >
              {isDarkMode ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-amber-300" />
              )}
            </button>

            {/* Gamification Levels Trigger */}
            <button
              onClick={() => onChangeViewMode('gamification_details')}
              className={`p-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center border shadow-md ${
                activeViewMode === 'gamification_details'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 border-yellow-300 shadow-amber-500/30'
                  : 'bg-slate-900/80 text-amber-400 border-amber-500/30 hover:bg-amber-500/20'
              }`}
              title="مستويات الجواكر وسجل XP"
            >
              <Flame className="w-4 h-4 text-amber-400" />
            </button>

            {/* User Account Role Switcher */}
            <button
              onClick={onOpenAuth}
              className="p-2 rounded-xl transition-colors border border-amber-500/30 bg-slate-900/80 text-slate-300 hover:bg-slate-800 shadow-md"
              title="تبديل الحساب"
            >
              {user.role === 'admin' ? (
                <ShieldAlert className="w-4 h-4 text-red-500" />
              ) : user.role === 'owner' ? (
                <Store className="w-4 h-4 text-amber-400" />
              ) : (
                <UserCheck className="w-4 h-4 text-emerald-400" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Sport Selector Bottom Sheet Modal */}
      <SportSelectorBottomSheet
        isOpen={isBottomSheetOpen}
        onClose={() => setIsBottomSheetOpen(false)}
        selectedSport={selectedSport}
        onSelectSport={onSelectSport}
      />
    </>
  );
};
