import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Team, TeamMember, TeamJoinRequest, TeamChatMessage, User, SportType } from '../types';
import {
  Users,
  Shield,
  Plus,
  Send,
  UserPlus,
  CheckCircle2,
  XCircle,
  Trophy,
  Award,
  Lock,
  MessageSquare,
  Search,
  Crown,
  Sparkles,
  ChevronRight,
  UserCheck,
  ShieldAlert,
  X,
  VolumeX,
  Building2,
  Filter,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  teams: Team[];
  onCreateTeam: (teamData: Omit<Team, 'id' | 'createdAt' | 'members' | 'joinRequests' | 'chatMessages' | 'winsCount' | 'matchesPlayed' | 'trophiesCount'>) => void;
  onJoinRequest?: (teamId: string, request: Omit<TeamJoinRequest, 'id' | 'status' | 'requestedAt'>) => void;
  onJoinTeamRequest?: (teamId: string, position: string) => void;
  onHandleJoinRequest: (teamId: string, requestId: string, action: 'approve' | 'reject') => void;
  onSendChatMessage: (teamId: string, message: string) => void;
  onToggleMemberPermission: (teamId: string, memberUserId: string) => void;
  onRequireRealAccount: (actionMessage: string) => void;
  showToast?: (msg: string) => void;
}

export const TeamsClubsSection: React.FC<Props> = ({
  currentUser,
  teams,
  onCreateTeam,
  onJoinRequest,
  onJoinTeamRequest,
  onHandleJoinRequest,
  onSendChatMessage,
  onToggleMemberPermission,
  onRequireRealAccount,
  showToast,
}) => {
  const [selectedSportFilter, setSelectedSportFilter] = useState<SportType | 'all'>('all');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'all' | 'team' | 'club'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);

  // Local Notification Toast
  const [localToast, setLocalToast] = useState<string | null>(null);

  const notify = (msg: string) => {
    setLocalToast(msg);
    if (showToast) showToast(msg);
    setTimeout(() => setLocalToast(null), 3000);
  };

  // Create Team Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamType, setNewTeamType] = useState<'team' | 'club'>('team');
  const [newTeamSport, setNewTeamSport] = useState<SportType>('football');
  const [newTeamCity, setNewTeamCity] = useState<'عمان' | 'إربد' | 'الزرقاء' | 'العقبة' | 'السلط' | 'جرش'>('عمان');
  const [newTeamDesc, setNewTeamDesc] = useState('');
  const [newTeamLogo, setNewTeamLogo] = useState(
    'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=150&auto=format&fit=crop&q=80'
  );

  // Chat message input state inside team modal
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Active Team object derived dynamically from teams list
  const activeTeam = teams.find((t) => t.id === selectedTeamId) || null;

  // Safe helper to resolve pending/join requests array
  const getTeamRequests = (team: Team) => {
    if (team.joinRequests && Array.isArray(team.joinRequests)) return team.joinRequests;
    if (team.pendingRequests && Array.isArray(team.pendingRequests)) {
      return team.pendingRequests.map((r: any) => ({
        id: r.id,
        userId: r.userId,
        userName: r.userName,
        userAvatar: r.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        position: r.position || 'لاعب',
        message: r.message || 'طلب انضمام للفريق',
        status: (r.status as 'pending' | 'approved' | 'rejected') || 'pending',
        requestedAt: r.requestedAt || 'الآن',
      }));
    }
    return [];
  };

  // Auto-scroll chat to bottom when activeTeam's chatMessages change
  useEffect(() => {
    if (activeTeam && chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [activeTeam?.chatMessages?.length, selectedTeamId]);

  // Filter teams
  const filteredTeams = teams.filter((t) => {
    const matchesSport = selectedSportFilter === 'all' || t.sport === selectedSportFilter;
    const matchesType = selectedTypeFilter === 'all' || t.type === selectedTypeFilter;
    const matchesSearch =
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.founderName && t.founderName.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesSport && matchesType && matchesSearch;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onRequireRealAccount('لإنشاء فريقك الخاص أو ناديك، يرجى التسجيل بحساب حقيقي!');
      return;
    }
    if (currentUser.isGuest) {
      onRequireRealAccount('عزيزي الزائر، يرجى إنشاء حساب رسمي ببيانات حقيقية لإنشاء وتأسيس الفريق!');
      return;
    }

    if (!newTeamName.trim()) return;

    onCreateTeam({
      name: newTeamName.trim(),
      type: newTeamType,
      sport: newTeamSport,
      city: newTeamCity,
      description: newTeamDesc.trim() || 'فريق رياضي مميز ينافس في ملاعب وتكميلات المملكة',
      logo: newTeamLogo,
      founderId: currentUser.id,
      founderName: currentUser.name,
    });

    setIsCreateModalOpen(false);
    setNewTeamName('');
    setNewTeamDesc('');
    notify(`تم إنشاء ${newTeamType === 'club' ? 'النادي' : 'الفريق'} (${newTeamName}) بنجاح! 🏆`);
  };

  const handleSendRequestToJoin = (team: Team) => {
    if (!currentUser) {
      onRequireRealAccount('الانضمام للفرق والأندية يتطلب حساباً مسجلاً!');
      return;
    }
    if (currentUser.isGuest) {
      onRequireRealAccount('عزيزي الزائر، يرجى تسجيل حساب ببياناتك الحقيقية للالتحاق بالفرق والأندية!');
      return;
    }

    // Check if user is already a member
    if (team.members && team.members.some((m) => m.userId === currentUser.id)) {
      notify('أنت عضو بالفعل في هذا الفريق! ⚽');
      return;
    }

    // Check if user is banned
    if (team.bannedUserIds?.includes(currentUser.id)) {
      notify('⛔ معذرةً، تم تقييد انضمامك لهذا الفريق.');
      return;
    }

    // Check if user has pending request
    const requests = getTeamRequests(team);
    if (requests.some((r) => r.userId === currentUser.id && r.status === 'pending')) {
      notify('طلب انضمامك قيد المراجعة لدى كابتن أو مدرب الفريق ⏳');
      return;
    }

    if (onJoinRequest) {
      onJoinRequest(team.id, {
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        userLevel: currentUser.level,
        position: currentUser.preferredPosition || 'لاعب',
        message: 'أرغب بالانضمام لكادر الفريق والمشاركة بالبطولات!',
      });
    } else if (onJoinTeamRequest) {
      onJoinTeamRequest(team.id, currentUser.preferredPosition || 'لاعب');
    }

    notify('تم إرسال طلب الانضمام إلى إدارة الفريق بنجاح! 📩');
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTeam || !chatInput.trim()) return;

    if (!currentUser) {
      onRequireRealAccount('المحادثة تتطلب تسجيلاً حقيقياً!');
      return;
    }
    if (currentUser.isGuest) {
      onRequireRealAccount('المحادثات مقتصرة على الحسابات المسجلة ببيانات حقيقية.');
      return;
    }

    if (activeTeam.isChatLocked) {
      notify('⛔ شات الفريق مغلق حالياً بقرار من الإدارة العامة.');
      return;
    }

    onSendChatMessage(activeTeam.id, chatInput.trim());
    setChatInput('');
  };

  return (
    <div className="space-y-6 text-right relative">
      {/* Toast Notification Banner */}
      <AnimatePresence>
        {localToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl bg-[#39FF14] text-slate-950 font-black text-xs sm:text-sm shadow-2xl flex items-center gap-2 border border-white/20"
          >
            <Sparkles className="w-4 h-4" />
            <span>{localToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Banner / Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -top-10 -left-10 w-48 h-48 bg-[#39FF14]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#39FF14]/20 border border-[#39FF14]/40 text-[#39FF14] text-xs font-black">
                مجتمع ملاعبك للأندية والفرق 🛡️
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-2">
              الفرق، الأندية والتواصل الداخلي
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              أنشئ فريقك الخماسي أو ناديك الرسمي، دعِ اللاعبين ينضمون إليك، تواصل عبر الشات الداخلي للمجموعة، ونافس في بطولات المملكة بثقة!
            </p>
          </div>

          <button
            onClick={() => {
              if (currentUser?.isGuest) {
                onRequireRealAccount('عزيزي الزائر، يرجى إنشاء حساب رسمي حقيقي لتأسيس فريق أو نادي جديد!');
              } else {
                setIsCreateModalOpen(true);
              }
            }}
            className="px-5 py-3 rounded-2xl bg-[#39FF14] hover:bg-[#32e012] text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-[#39FF14]/20 transition-all shrink-0"
          >
            <Plus className="w-5 h-5" />
            <span>تأسيس فريق / نادي جديد ➕</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-[#161F33] border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث عن اسم الفريق أو المدينة..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#39FF14]"
          />
        </div>

        {/* Entity Type & Sport Filters */}
        <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto no-scrollbar w-full sm:w-auto text-xs font-bold">
          {/* Entity Type Selector */}
          <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800 shrink-0">
            <button
              onClick={() => setSelectedTypeFilter('all')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                selectedTypeFilter === 'all'
                  ? 'bg-slate-800 text-white font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل
            </button>
            <button
              onClick={() => setSelectedTypeFilter('team')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                selectedTypeFilter === 'team'
                  ? 'bg-emerald-500/20 text-[#39FF14] font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الفرق الخماسية ⚽
            </button>
            <button
              onClick={() => setSelectedTypeFilter('club')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                selectedTypeFilter === 'club'
                  ? 'bg-amber-500/20 text-amber-300 font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الأندية الرسمية 🏛️
            </button>
          </div>

          {/* Sport Selector */}
          <button
            onClick={() => setSelectedSportFilter('all')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              selectedSportFilter === 'all'
                ? 'bg-[#39FF14] text-slate-950 font-black'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            جميع الرياضات
          </button>
          <button
            onClick={() => setSelectedSportFilter('football')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              selectedSportFilter === 'football'
                ? 'bg-[#39FF14] text-slate-950 font-black'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            ⚽ كرة قدم
          </button>
          <button
            onClick={() => setSelectedSportFilter('padel')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              selectedSportFilter === 'padel'
                ? 'bg-[#39FF14] text-slate-950 font-black'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            🎾 بادل
          </button>
          <button
            onClick={() => setSelectedSportFilter('basketball')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              selectedSportFilter === 'basketball'
                ? 'bg-[#39FF14] text-slate-950 font-black'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            🏀 سلة
          </button>
        </div>
      </div>

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTeams.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-[#161F33] rounded-3xl border border-slate-800 text-slate-400 space-y-2">
            <Users className="w-10 h-10 mx-auto text-slate-600 mb-2" />
            <p className="font-bold text-white">لا يوجد فرق أو أندية مطابقة حالياً.</p>
            <p className="text-xs">كن أول من ينشئ فريقاً رياضياً جديداً وينظم اللاعبين!</p>
          </div>
        ) : (
          filteredTeams.map((team) => {
            const isUserMember = currentUser && team.members && team.members.some((m) => m.userId === currentUser.id);
            const isUserFounder = currentUser && team.founderId === currentUser.id;
            const requests = getTeamRequests(team);
            const pendingRequestsCount = requests.filter((r) => r.status === 'pending').length;

            return (
              <div
                key={team.id}
                className="p-5 rounded-3xl bg-[#161F33] border border-slate-800/90 shadow-xl hover:border-emerald-500/50 transition-all flex flex-col justify-between space-y-4 group"
              >
                <div className="space-y-3">
                  {/* Top Bar: Logo, Name, Type */}
                  <div className="flex items-start gap-3">
                    <img
                      src={team.logo}
                      alt={team.name}
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500/40 group-hover:scale-105 transition-transform shrink-0 shadow-lg"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${
                            team.type === 'club'
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                              : 'bg-emerald-500/20 text-[#39FF14] border-emerald-500/40'
                          }`}
                        >
                          {team.type === 'club' ? 'نادي رسمي 🏛️' : 'فريق حارة ⚽'}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold">{team.city}</span>
                      </div>
                      <h3 className="text-base font-extrabold text-white truncate mt-1">
                        {team.name}
                      </h3>
                      <p className="text-[11px] text-slate-400 font-bold">
                        المؤسس: <strong className="text-slate-200">{team.founderName || 'كابتن الفريق'}</strong>
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed bg-slate-900/50 p-2.5 rounded-xl border border-slate-800/80">
                    {team.description}
                  </p>

                  {/* Team Stats & Members Count */}
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-bold">الأعضاء:</span>
                      <strong className="text-white font-extrabold">{team.members ? team.members.length : 0} لاعب</strong>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-bold">الانتصارات:</span>
                      <strong className="text-[#39FF14] font-extrabold">{team.winsCount || 0} فوز</strong>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-bold">الكؤوس:</span>
                      <strong className="text-amber-400 font-extrabold">{team.trophiesCount || 0} 🏆</strong>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setSelectedTeamId(team.id)}
                    className="flex-1 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-extrabold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-all"
                  >
                    <MessageSquare className="w-4 h-4 text-[#39FF14]" />
                    <span>مقر الفريق والشات</span>
                    {pendingRequestsCount > 0 && isUserFounder && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-red-500 text-white animate-pulse">
                        {pendingRequestsCount}
                      </span>
                    )}
                  </button>

                  {!isUserMember ? (
                    <button
                      onClick={() => handleSendRequestToJoin(team)}
                      className="px-3.5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1 shadow-md shrink-0"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>انضمام</span>
                    </button>
                  ) : (
                    <span className="px-3 py-2 rounded-xl bg-emerald-500/20 text-[#39FF14] border border-emerald-500/40 text-[11px] font-black shrink-0 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      عضو
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* CREATE TEAM MODAL */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg bg-[#161F33] border-2 border-emerald-500/60 rounded-3xl p-6 shadow-2xl space-y-4 text-right max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#39FF14]" />
                  <h3 className="font-extrabold text-white text-base">
                    تأسيس فريق أو نادي جديد
                  </h3>
                </div>
                <button
                  onClick={() => setIsCreateModalOpen(false)}
                  className="p-1.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
                {/* Type selection: Team vs Club */}
                <div>
                  <label className="text-slate-300 font-bold block mb-1">نوع الكيان الرياضي:</label>
                  <div className="grid grid-cols-2 gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800 font-bold">
                    <button
                      type="button"
                      onClick={() => setNewTeamType('team')}
                      className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                        newTeamType === 'team'
                          ? 'bg-[#39FF14] text-slate-950 font-black shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>فريق خماسي / حارة ⚽</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setNewTeamType('club')}
                      className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                        newTeamType === 'club'
                          ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>نادي رسمي 🏛️</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">اسم الفريق / النادي:</label>
                  <input
                    type="text"
                    required
                    value={newTeamName}
                    onChange={(e) => setNewTeamName(e.target.value)}
                    placeholder="مثال: نسور عمان الخماسية / نادي نشامى العقبة"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:border-[#39FF14] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-300 font-bold block mb-1">الرياضة:</label>
                    <select
                      value={newTeamSport}
                      onChange={(e) => setNewTeamSport(e.target.value as SportType)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                    >
                      <option value="football">⚽ كرة قدم</option>
                      <option value="padel">🎾 بادل</option>
                      <option value="basketball">🏀 سلة</option>
                      <option value="volleyball">🏐 طائرة</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1">المدينة/المحافظة:</label>
                    <select
                      value={newTeamCity}
                      onChange={(e) => setNewTeamCity(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                    >
                      <option value="عمان">عمان</option>
                      <option value="إربد">إربد</option>
                      <option value="الزرقاء">الزرقاء</option>
                      <option value="العقبة">العقبة</option>
                      <option value="السلط">السلط</option>
                      <option value="جرش">جرش</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">وصف الفريق ورؤيته:</label>
                  <textarea
                    rows={2}
                    value={newTeamDesc}
                    onChange={(e) => setNewTeamDesc(e.target.value)}
                    placeholder="اكتب نبذة عن فريقكم وطموحاتكم في البطولات والتكميلات..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:border-[#39FF14] focus:outline-none"
                  />
                </div>

                {/* Preset Logos */}
                <div>
                  <label className="text-slate-300 font-bold block mb-1">اختر الشعار الخارجي للفريق:</label>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {[
                      'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=150&auto=format&fit=crop&q=80',
                      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=150&auto=format&fit=crop&q=80',
                      'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=150&auto=format&fit=crop&q=80',
                      'https://images.unsplash.com/photo-1543351611-58f69d7c1781?w=150&auto=format&fit=crop&q=80',
                    ].map((imgUrl, idx) => (
                      <img
                        key={idx}
                        src={imgUrl}
                        alt="Logo"
                        onClick={() => setNewTeamLogo(imgUrl)}
                        className={`w-12 h-12 rounded-2xl object-cover cursor-pointer border-2 transition-all ${
                          newTeamLogo === imgUrl ? 'border-[#39FF14] scale-105' : 'border-slate-800 opacity-60'
                        }`}
                        referrerPolicy="no-referrer"
                      />
                    ))}
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-[#39FF14] text-slate-950 font-black shadow-lg hover:bg-[#32e012]"
                  >
                    اعتماد وإنشاء الكيان 🏆
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TEAM ROOM & INTERNAL CHAT MODAL */}
      <AnimatePresence>
        {activeTeam && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl bg-[#161F33] border-2 border-emerald-500/60 rounded-3xl p-5 shadow-2xl space-y-4 text-right max-h-[90vh] overflow-y-auto flex flex-col justify-between"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-3">
                  <img
                    src={activeTeam.logo}
                    alt={activeTeam.name}
                    className="w-12 h-12 rounded-2xl object-cover border-2 border-[#39FF14]"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                      <span>{activeTeam.name}</span>
                      <span className="text-xs text-amber-400 font-bold">({activeTeam.city})</span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      مقر التواصل الداخلي وطلبات الانضمام للفريق
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedTeamId(null)}
                  className="p-1.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Members & Join Requests Tab Panel */}
              <div className="space-y-4">
                {/* Team Members List */}
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
                  <h4 className="text-xs font-black text-white flex items-center justify-between">
                    <span className="flex items-center gap-1 text-[#39FF14]">
                      <Users className="w-4 h-4" />
                      أعضاء الفريق والتشكيلة ({activeTeam.members ? activeTeam.members.length : 0}):
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">تأسس بواسطة {activeTeam.founderName || 'الكابتن'}</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {(activeTeam.members || []).map((mem) => {
                      const isFounder = mem.userId === activeTeam.founderId;
                      const currentUserIsManager =
                        currentUser &&
                        (activeTeam.founderId === currentUser.id ||
                          activeTeam.members.find((m) => m.userId === currentUser.id)?.canApproveRequests ||
                          activeTeam.members.find((m) => m.userId === currentUser.id)?.canManageJoinRequests);

                      return (
                        <div
                          key={mem.id}
                          className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <img
                              src={
                                mem.avatar ||
                                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                              }
                              alt={mem.name}
                              className="w-8 h-8 rounded-xl object-cover shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div className="truncate">
                              <p className="font-extrabold text-white text-xs truncate">{mem.name}</p>
                              <span className="text-[10px] text-slate-400 block font-bold">
                                {mem.role === 'founder'
                                  ? '👑 كابتن ومؤسس'
                                  : mem.role === 'coach'
                                  ? '🧢 مدرب الفريق'
                                  : '⚽ لاعب بالفريق'}
                              </span>
                            </div>
                          </div>

                          {/* Permission Toggle for Managers */}
                          {currentUserIsManager && !isFounder && (
                            <button
                              onClick={() => {
                                onToggleMemberPermission(activeTeam.id, mem.userId || mem.id);
                                notify('تم تحديث صلاحيات العضو بنجاح 🔑');
                              }}
                              className={`px-2 py-1 rounded-lg text-[10px] font-black border transition-all ${
                                mem.canApproveRequests || mem.canManageJoinRequests
                                  ? 'bg-[#39FF14]/20 text-[#39FF14] border-[#39FF14]/50'
                                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                              }`}
                              title="منح أو سحب صلاحية قبول طلبات الانضمام للفريق"
                            >
                              {mem.canApproveRequests || mem.canManageJoinRequests ? 'صلاحية قبول ✅' : 'منح صلاحية 🔑'}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Pending Join Requests (Visible to Founder or Authorized Members) */}
                {currentUser &&
                  (activeTeam.founderId === currentUser.id ||
                    activeTeam.members?.find((m) => m.userId === currentUser.id)?.canApproveRequests ||
                    activeTeam.members?.find((m) => m.userId === currentUser.id)?.canManageJoinRequests) && (
                    <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                      <h4 className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                        <UserCheck className="w-4 h-4" />
                        طلبات الانضمام المعلقة ({getTeamRequests(activeTeam).filter((r) => r.status === 'pending').length}):
                      </h4>

                      {getTeamRequests(activeTeam).filter((r) => r.status === 'pending').length === 0 ? (
                        <p className="text-[11px] text-slate-400 italic">لا توجد طلبات انضمام معلقة حالياً.</p>
                      ) : (
                        <div className="space-y-2">
                          {getTeamRequests(activeTeam)
                            .filter((r) => r.status === 'pending')
                            .map((req) => (
                              <div
                                key={req.id}
                                className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2"
                              >
                                <div className="flex items-center gap-2">
                                  <img
                                    src={
                                      req.userAvatar ||
                                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                                    }
                                    alt={req.userName}
                                    className="w-8 h-8 rounded-xl object-cover shrink-0"
                                    referrerPolicy="no-referrer"
                                  />
                                  <div>
                                    <p className="font-extrabold text-white text-xs">{req.userName}</p>
                                    <p className="text-[10px] text-slate-400">{req.message || req.position || 'طلب انضمام'}</p>
                                  </div>
                                </div>

                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => {
                                      onHandleJoinRequest(activeTeam.id, req.id, 'approve');
                                      notify(`تمت القبول والموافقة على انضمام ${req.userName} 🎉`);
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-[#39FF14] text-slate-950 text-[11px] font-black hover:bg-[#32e012]"
                                  >
                                    قبول ✅
                                  </button>
                                  <button
                                    onClick={() => {
                                      onHandleJoinRequest(activeTeam.id, req.id, 'reject');
                                      notify(`تم رفض طلب انضمام ${req.userName}`);
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30 text-[11px] font-bold hover:bg-red-500/30"
                                  >
                                    رفض ❌
                                  </button>
                                </div>
                              </div>
                            ))}
                        </div>
                      )}
                    </div>
                  )}

                {/* Team Chat Room */}
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <h4 className="text-xs font-black text-[#39FF14] flex items-center gap-1.5">
                      <MessageSquare className="w-4 h-4" />
                      غرفة المحادثات والشات الداخلي للفريق
                    </h4>
                    {activeTeam.isChatLocked && (
                      <span className="text-[10px] text-red-400 font-extrabold flex items-center gap-1 bg-red-500/20 px-2 py-0.5 rounded-md border border-red-500/40">
                        <Lock className="w-3 h-3" />
                        المحادثة مقفلة بقرار إداري
                      </span>
                    )}
                  </div>

                  {/* Chat Messages Box */}
                  <div className="h-44 overflow-y-auto space-y-2 p-2 bg-slate-950/70 rounded-xl border border-slate-800 text-xs dir-rtl no-scrollbar">
                    {!activeTeam.chatMessages || activeTeam.chatMessages.length === 0 ? (
                      <div className="text-center py-10 text-slate-500 italic">
                        لا توجد رسائل حالياً. ابدأ المحادثة مع زملائك بالفريق! 💬
                      </div>
                    ) : (
                      activeTeam.chatMessages.map((msg) => (
                        <div key={msg.id} className="space-y-0.5">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="font-extrabold text-amber-300">{msg.senderName}</span>
                            <span className="text-slate-500 font-mono">{msg.timestamp}</span>
                          </div>
                          <p className="bg-slate-900/90 text-slate-200 p-2 rounded-xl border border-slate-800 leading-normal">
                            {msg.message}
                          </p>
                        </div>
                      ))
                    )}
                    <div ref={chatEndRef} />
                  </div>

                  {/* Chat Input */}
                  {!activeTeam.isChatLocked ? (
                    <form onSubmit={handleSendChat} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="اكتب رسالة لأعضاء الفريق..."
                        className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#39FF14]"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-[#39FF14] text-slate-950 font-black hover:bg-[#32e012] text-xs flex items-center gap-1 shadow-md"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>إرسال</span>
                      </button>
                    </form>
                  ) : (
                    <div className="p-2.5 text-center text-xs text-red-400 bg-red-500/10 border border-red-500/30 rounded-xl font-bold">
                      ⛔ تم قفل خاصية الشات لهذا الفريق مؤقتاً بواسطة إدارة المنصة.
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
