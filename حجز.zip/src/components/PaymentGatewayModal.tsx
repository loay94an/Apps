import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CreditCard, Wallet, CheckCircle2, Copy, X, QrCode, ArrowLeft, ShieldCheck, DollarSign, Download, Building, Smartphone, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  amountJOD: number;
  itemTitle: string;
  onPaymentSuccess?: (transactionId: string) => void;
  isDarkMode?: boolean;
}

export const PaymentGatewayModal: React.FC<Props> = ({
  isOpen,
  onClose,
  amountJOD,
  itemTitle,
  onPaymentSuccess,
  isDarkMode = true,
}) => {
  const [selectedMethod, setSelectedMethod] = useState<'efawateer' | 'cliq' | 'zain_cash' | 'orange_money' | 'card' | 'cash'>('efawateer');
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [receiptData, setReceiptData] = useState<{ txId: string; date: string } | null>(null);

  // Form states for methods
  const [cliqRef, setCliqRef] = useState('');
  const [walletPhone, setWalletPhone] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  if (!isOpen) return null;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      const generatedTx = 'JO-TX-' + Math.floor(100000 + Math.random() * 900000);
      const now = new Date().toLocaleString('ar-JO', { dateStyle: 'short', timeStyle: 'short' });
      
      setIsProcessing(false);
      setPaymentCompleted(true);
      setReceiptData({ txId: generatedTx, date: now });

      if (onPaymentSuccess) {
        onPaymentSuccess(generatedTx);
      }
    }, 1800);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] transition-colors ${
            isDarkMode
              ? 'bg-[#0F172A] border-slate-800 text-white'
              : 'bg-white border-slate-200 text-slate-900'
          }`}
        >
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-md border border-white/20 shadow-md">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-base font-black flex items-center gap-1.5">
                  <span>بوابة الدفع الإلكتروني بالأردن</span>
                  <span className="text-[10px] bg-emerald-400 text-slate-950 font-black px-2 py-0.5 rounded-full">
                    آمن ومضمون 🇯🇴
                  </span>
                </h3>
                <p className="text-xs text-white/80 font-medium">{itemTitle}</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Amount Summary Badge */}
          <div className={`p-3 border-b flex items-center justify-between px-5 ${
            isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}>
            <span className="text-xs text-slate-400 font-bold">المبلغ المطلوب سداده:</span>
            <div className="flex items-baseline gap-1 dir-ltr">
              <span className="text-xl font-mono font-black text-emerald-500">{amountJOD.toFixed(2)}</span>
              <span className="text-xs font-bold text-emerald-600">JOD</span>
            </div>
          </div>

          {/* Main Content */}
          <div className="p-4 flex-1 overflow-y-auto min-h-0">
            {paymentCompleted && receiptData ? (
              /* RECEIPT DISPLAY */
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-4 text-center py-2"
              >
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <div>
                  <h4 className="text-base font-black text-emerald-500">تمت عملية الدفع بنجاح!</h4>
                  <p className="text-xs text-slate-400 mt-1">إيصال ملكية وحجز رسمي مؤكد لدى إدارة الملعب</p>
                </div>

                {/* Printable Receipt Box */}
                <div className={`p-4 rounded-2xl border text-right space-y-2 text-xs font-medium ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div className="flex justify-between border-b pb-2 border-slate-700/40">
                    <span className="text-slate-400">رقم المرجعية (Tx ID):</span>
                    <span className="font-mono font-bold text-emerald-400 dir-ltr">{receiptData.txId}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2 border-slate-700/40">
                    <span className="text-slate-400">التاريخ والوقت:</span>
                    <span className="font-bold text-slate-300">{receiptData.date}</span>
                  </div>
                  <div className="flex justify-between border-b pb-2 border-slate-700/40">
                    <span className="text-slate-400">طريقة الدفع المستخدمة:</span>
                    <span className="font-bold text-emerald-400">
                      {selectedMethod === 'efawateer' && 'eFAWATEERcom (إي فواتيركم)'}
                      {selectedMethod === 'cliq' && 'CliQ (كليك أردني)'}
                      {selectedMethod === 'zain_cash' && 'Zain Cash (زين كاش)'}
                      {selectedMethod === 'orange_money' && 'Orange Money'}
                      {selectedMethod === 'card' && 'بطاقة ائتمان (Visa/Mastercard)'}
                      {selectedMethod === 'cash' && 'الدفع نقداً بالملعب'}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-slate-400">المبلغ المدفوع:</span>
                    <span className="font-mono font-black text-emerald-500 text-sm dir-ltr">{amountJOD.toFixed(2)} JOD</span>
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-all shadow-md"
                >
                  إغلاق ومتابعة التطبيق
                </button>
              </motion.div>
            ) : (
              /* PAYMENT SELECTOR & FORMS */
              <form onSubmit={handleProcessPayment} className="space-y-4">
                {/* Method Selector Pills */}
                <div>
                  <label className="block text-xs font-bold mb-2 text-right">اختر طريقة الدفع المناسبة لك:</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {/* 1. eFAWATEERcom */}
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('efawateer')}
                      className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                        selectedMethod === 'efawateer'
                          ? 'bg-amber-500/20 border-amber-500 text-amber-400 shadow-md scale-[1.02]'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Building className="w-5 h-5 text-amber-400" />
                      <span>إي فواتيركم</span>
                    </button>

                    {/* 2. CliQ */}
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('cliq')}
                      className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                        selectedMethod === 'cliq'
                          ? 'bg-blue-500/20 border-blue-500 text-blue-400 shadow-md scale-[1.02]'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <QrCode className="w-5 h-5 text-blue-400" />
                      <span>CliQ (كليك)</span>
                    </button>

                    {/* 3. Zain Cash */}
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('zain_cash')}
                      className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                        selectedMethod === 'zain_cash'
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 shadow-md scale-[1.02]'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Smartphone className="w-5 h-5 text-emerald-400" />
                      <span>زين كاش</span>
                    </button>

                    {/* 4. Orange Money */}
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('orange_money')}
                      className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                        selectedMethod === 'orange_money'
                          ? 'bg-orange-500/20 border-orange-500 text-orange-400 shadow-md scale-[1.02]'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Wallet className="w-5 h-5 text-orange-400" />
                      <span>أورانج ماني</span>
                    </button>

                    {/* 5. Credit Card */}
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('card')}
                      className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                        selectedMethod === 'card'
                          ? 'bg-purple-500/20 border-purple-500 text-purple-400 shadow-md scale-[1.02]'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <CreditCard className="w-5 h-5 text-purple-400" />
                      <span>بطاقة ائتمان</span>
                    </button>

                    {/* 6. Cash at Pitch */}
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('cash')}
                      className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all ${
                        selectedMethod === 'cash'
                          ? 'bg-teal-500/20 border-teal-500 text-teal-400 shadow-md scale-[1.02]'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <DollarSign className="w-5 h-5 text-teal-400" />
                      <span>نقداً بالملعب</span>
                    </button>
                  </div>
                </div>

                {/* DETAILS AREA BASED ON METHOD */}
                <div className={`p-4 rounded-2xl border text-right space-y-3 ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}>
                  {/* eFAWATEERcom */}
                  {selectedMethod === 'efawateer' && (
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-amber-400">كود سداد إي فواتيركم (eFAWATEERcom):</span>
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-mono font-bold">
                          خدمات رياضة وترفيه
                        </span>
                      </div>

                      <div className="p-3 bg-black/40 rounded-xl border border-amber-500/30 flex items-center justify-between">
                        <div className="text-right">
                          <span className="block text-[10px] text-slate-400">رمز الفاتورة:</span>
                          <span className="font-mono text-base font-black text-amber-300 dir-ltr">EBILL-882391</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy('EBILL-882391', 'كود الفاتورة')}
                          className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1 border border-amber-500/40"
                        >
                          {copiedText === 'كود الفاتورة' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedText === 'كود الفاتورة' ? 'تم النسخ!' : 'نسخ الكود'}</span>
                        </button>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        افتَح تطبيق بنكك بالأردن أو موقع eFAWATEERcom ➔ اختر "خدمات رياضية" ➔ ادخل الرمز أعلاه وسدّد {amountJOD.toFixed(2)} JOD.
                      </p>
                    </div>
                  )}

                  {/* CliQ */}
                  {selectedMethod === 'cliq' && (
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-blue-400">التحويل السريع عبر CliQ:</span>
                        <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded font-mono font-bold">
                          تأكيد فوري ⚡
                        </span>
                      </div>

                      <div className="p-3 bg-black/40 rounded-xl border border-blue-500/30 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="block text-[10px] text-slate-400">اسم المستعار (CliQ Alias):</span>
                            <span className="font-mono text-sm font-black text-blue-300 dir-ltr">MAL3ABAK_JO</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleCopy('MAL3ABAK_JO', 'Alias')}
                            className="px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 text-xs font-bold flex items-center gap-1"
                          >
                            <Copy className="w-3 h-3" />
                            <span>{copiedText === 'Alias' ? 'تم!' : 'نسخ'}</span>
                          </button>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-blue-500/20">
                          <div>
                            <span className="block text-[10px] text-slate-400">رقم الهاتف للتحويل:</span>
                            <span className="font-mono text-sm font-black text-blue-300 dir-ltr">+962 7 9123 4567</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleCopy('+962791234567', 'Phone')}
                            className="px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 text-xs font-bold flex items-center gap-1"
                          >
                            <Copy className="w-3 h-3" />
                            <span>{copiedText === 'Phone' ? 'تم!' : 'نسخ'}</span>
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-300 mb-1">رقم المرجعية بعد التحويل (اختياري):</label>
                        <input
                          type="text"
                          value={cliqRef}
                          onChange={(e) => setCliqRef(e.target.value)}
                          placeholder="مثال: CLQ-9921203"
                          className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-700 text-white dir-ltr font-mono"
                        />
                      </div>
                    </div>
                  )}

                  {/* Zain Cash */}
                  {selectedMethod === 'zain_cash' && (
                    <div className="space-y-2.5">
                      <span className="text-xs font-black text-emerald-400 block">الدفع المباشر محفظة زين كاش:</span>
                      <div>
                        <label className="block text-[10px] text-slate-300 font-bold mb-1">رقم محفظة زين كاش الخاص بك:</label>
                        <input
                          type="tel"
                          required
                          value={walletPhone}
                          onChange={(e) => setWalletPhone(e.target.value)}
                          placeholder="079xxxxxxx"
                          className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-950 border border-slate-700 text-white dir-ltr font-mono font-bold"
                        />
                      </div>
                      <p className="text-[10px] text-slate-400">سيصلك إشعار لتأكيد عملية الخصم بقيمة {amountJOD.toFixed(2)} JOD عبر تطبيق Zain Cash.</p>
                    </div>
                  )}

                  {/* Orange Money */}
                  {selectedMethod === 'orange_money' && (
                    <div className="space-y-2.5">
                      <span className="text-xs font-black text-orange-400 block">الدفع عبر محفظة أورانج ماني:</span>
                      <div>
                        <label className="block text-[10px] text-slate-300 font-bold mb-1">رقم خط Orange الخاص بك:</label>
                        <input
                          type="tel"
                          required
                          value={walletPhone}
                          onChange={(e) => setWalletPhone(e.target.value)}
                          placeholder="077xxxxxxx"
                          className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-950 border border-slate-700 text-white dir-ltr font-mono font-bold"
                        />
                      </div>
                    </div>
                  )}

                  {/* Credit Card */}
                  {selectedMethod === 'card' && (
                    <div className="space-y-2.5">
                      <div>
                        <label className="block text-[10px] text-slate-300 font-bold mb-1">رقم البطاقة الائتمانية:</label>
                        <input
                          type="text"
                          required
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="4000 0000 0000 0000"
                          className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-950 border border-slate-700 text-white dir-ltr font-mono font-bold"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-300 font-bold mb-1">تاريخ الانتهاء:</label>
                          <input
                            type="text"
                            required
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="MM/YY"
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-700 text-white dir-ltr font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-300 font-bold mb-1">رمز الأمان (CVV):</label>
                          <input
                            type="password"
                            maxLength={4}
                            required
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            placeholder="123"
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-950 border border-slate-700 text-white dir-ltr font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Cash at pitch */}
                  {selectedMethod === 'cash' && (
                    <div className="space-y-2">
                      <span className="text-xs font-black text-teal-400 block">الدفع النقدي مباشرة عند الوصول للملعب:</span>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        سيتم تأكيد حجزك واحتياطياً بخصم نقاط XP أو تأكيد هاتفياً من قبل إدارة الملعب قبل موعد المباراة بساعة.
                      </p>
                    </div>
                  )}
                </div>

                {/* Confirm Pay Button */}
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-all shadow-lg flex items-center justify-center gap-2"
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>جاري المعالجة والأمان...</span>
                    </div>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>تأكيد سداد المبلغ ({amountJOD.toFixed(2)} JOD)</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
