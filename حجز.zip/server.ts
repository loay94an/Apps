import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Server-side Gemini AI endpoint for smart Jordanian matchmaking tips & tactics
  app.post("/api/gemini/matchmaker", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY is missing on server" });
      }

      const { sport, city, missingPositions } = req.body;

      const ai = new GoogleGenAI({ apiKey });
      const prompt = `أنت مساعد ذكي لخبير تدريب رياضي في الأردن لتطبيق "ملعبك". قدم نصيحة تكتيكية قصيرة وسريعة (3 أسطر باللغة العربية) لفريق يلعب مباراة ${sport} في مدينة ${city} ينقصه مراكز: ${missingPositions?.join(', ') || 'لاعبين'}. ركز على حماس النشامى وروحي الرياضية.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      res.json({ advice: response.text });
    } catch (err: any) {
      console.error("Gemini API Error:", err);
      res.status(500).json({ error: "Failed to generate AI advice" });
    }
  });

  // Health check API
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "Malaebak Jordan Pitch Booking" });
  });

  // Vite middleware for development vs static production serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Malaebak Server running on http://localhost:${PORT}`);
  });
}

startServer();
