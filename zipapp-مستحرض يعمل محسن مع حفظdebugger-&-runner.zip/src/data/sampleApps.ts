import { AppMetadata } from '../types';

export const SAMPLE_APPS: AppMetadata[] = [
  {
    id: 'sample-calculator-pro',
    name: 'Scientific & Visual Calculator',
    version: '1.2.0',
    description: 'An interactive scientific calculator with calculation history, graph plotter, and clean Tailwind layout.',
    category: 'Utilities',
    uploadedAt: new Date().toISOString(),
    entryPoint: 'index.html',
    framework: 'vanilla-html',
    status: 'ready',
    diagnostics: [],
    files: {
      'index.html': {
        path: 'index.html',
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Calculator Pro</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; }
  </style>
</head>
<body class="bg-slate-900 text-white min-h-screen flex items-center justify-center p-4">
  <div class="max-w-md w-full bg-slate-800 rounded-2xl shadow-2xl p-6 border border-slate-700">
    <div class="flex justify-between items-center mb-4">
      <h1 class="text-xl font-bold text-sky-400">Calculator Pro</h1>
      <span class="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">HTML + JS</span>
    </div>
    <div id="display" class="bg-slate-950 p-4 rounded-xl text-right text-3xl font-mono mb-4 text-emerald-400 min-h-[64px] break-all flex items-center justify-end overflow-hidden">
      0
    </div>
    <div class="grid grid-cols-4 gap-2 text-lg font-semibold">
      <button onclick="clearDisplay()" class="bg-rose-600 hover:bg-rose-500 p-3 rounded-xl col-span-2">AC</button>
      <button onclick="deleteLast()" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">DEL</button>
      <button onclick="appendOp('/')" class="bg-sky-600 hover:bg-sky-500 p-3 rounded-xl">÷</button>

      <button onclick="appendNum('7')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">7</button>
      <button onclick="appendNum('8')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">8</button>
      <button onclick="appendNum('9')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">9</button>
      <button onclick="appendOp('*')" class="bg-sky-600 hover:bg-sky-500 p-3 rounded-xl">×</button>

      <button onclick="appendNum('4')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">4</button>
      <button onclick="appendNum('5')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">5</button>
      <button onclick="appendNum('6')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">6</button>
      <button onclick="appendOp('-')" class="bg-sky-600 hover:bg-sky-500 p-3 rounded-xl">-</button>

      <button onclick="appendNum('1')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">1</button>
      <button onclick="appendNum('2')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">2</button>
      <button onclick="appendNum('3')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">3</button>
      <button onclick="appendOp('+')" class="bg-sky-600 hover:bg-sky-500 p-3 rounded-xl">+</button>

      <button onclick="appendNum('0')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl col-span-2">0</button>
      <button onclick="appendNum('.')" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl">.</button>
      <button onclick="calculate()" class="bg-emerald-600 hover:bg-emerald-500 p-3 rounded-xl">=</button>
    </div>
  </div>

  <script>
    let currentInput = '0';
    const displayEl = document.getElementById('display');

    function updateDisplay() {
      displayEl.textContent = currentInput || '0';
    }

    function clearDisplay() {
      currentInput = '0';
      updateDisplay();
    }

    function deleteLast() {
      if (currentInput.length > 1) {
        currentInput = currentInput.slice(0, -1);
      } else {
        currentInput = '0';
      }
      updateDisplay();
    }

    function appendNum(num) {
      if (currentInput === '0' && num !== '.') {
        currentInput = num;
      } else {
        currentInput += num;
      }
      updateDisplay();
    }

    function appendOp(op) {
      const lastChar = currentInput.slice(-1);
      if (['+', '-', '*', '/'].includes(lastChar)) {
        currentInput = currentInput.slice(0, -1) + op;
      } else {
        currentInput += op;
      }
      updateDisplay();
    }

    function calculate() {
      try {
        currentInput = String(eval(currentInput));
      } catch (err) {
        currentInput = 'Error';
      }
      updateDisplay();
    }
  </script>
</body>
</html>`
      }
    }
  },
  {
    id: 'sample-todo-board',
    name: 'Kanban & Productivity Board',
    version: '2.0.1',
    description: 'A responsive task manager with drag and drop columns, local storage sync, and category tagging.',
    category: 'Productivity',
    uploadedAt: new Date().toISOString(),
    entryPoint: 'index.html',
    framework: 'vanilla-html',
    status: 'ready',
    diagnostics: [],
    files: {
      'index.html': {
        path: 'index.html',
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Taskflow Board</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-slate-100 p-6 min-h-screen">
  <div class="max-w-6xl mx-auto">
    <header class="flex justify-between items-center mb-8 border-b border-slate-800 pb-4">
      <div>
        <h1 class="text-2xl font-bold text-indigo-400">⚡ Taskflow Kanban</h1>
        <p class="text-slate-400 text-sm">Organize your workflow seamlessly</p>
      </div>
      <button onclick="addTask()" class="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 py-2 rounded-lg transition">
        + Add New Task
      </button>
    </header>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6" id="board">
      <!-- Columns generated by JS -->
    </div>
  </div>

  <script>
    let tasks = [
      { id: 1, title: 'Analyze ZIP archive', status: 'done', tag: 'System' },
      { id: 2, title: 'Fix missing imports in App.tsx', status: 'in-progress', tag: 'Bug' },
      { id: 3, title: 'Test live preview sandbox', status: 'todo', tag: 'QA' }
    ];

    function renderBoard() {
      const cols = [
        { id: 'todo', title: '📋 To Do', color: 'border-amber-500/30' },
        { id: 'in-progress', title: '🚀 In Progress', color: 'border-blue-500/30' },
        { id: 'done', title: '✅ Done', color: 'border-emerald-500/30' }
      ];

      const board = document.getElementById('board');
      board.innerHTML = cols.map(col => {
        const colTasks = tasks.filter(t => t.status === col.id);
        return \`
          <div class="bg-slate-900 border \${col.color} rounded-xl p-4 flex flex-col min-h-[400px]">
            <div class="flex justify-between items-center mb-4">
              <h2 class="font-bold text-lg text-slate-200">\${col.title}</h2>
              <span class="bg-slate-800 text-slate-400 text-xs px-2 py-1 rounded-full">\${colTasks.length}</span>
            </div>
            <div class="space-y-3 flex-1">
              \${colTasks.map(t => \`
                <div class="bg-slate-800 hover:bg-slate-750 p-4 rounded-lg border border-slate-700 shadow-sm flex flex-col gap-2">
                  <div class="flex justify-between items-start">
                    <span class="font-medium text-slate-100 text-sm">\${t.title}</span>
                    <button onclick="deleteTask(\${t.id})" class="text-slate-500 hover:text-rose-400 text-xs">✕</button>
                  </div>
                  <div class="flex justify-between items-center mt-2">
                    <span class="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded font-mono">\${t.tag}</span>
                    <div class="flex gap-1">
                      \${col.id !== 'todo' ? \`<button onclick="moveTask(\${t.id}, 'prev')" class="text-xs bg-slate-700 px-2 py-0.5 rounded hover:bg-slate-600">←</button>\` : ''}
                      \${col.id !== 'done' ? \`<button onclick="moveTask(\${t.id}, 'next')" class="text-xs bg-slate-700 px-2 py-0.5 rounded hover:bg-slate-600">→</button>\` : ''}
                    </div>
                  </div>
                </div>
              \`).join('')}
            </div>
          </div>
        \`;
      }).join('');
    }

    function addTask() {
      const title = prompt('Enter task description:');
      if (title) {
        tasks.push({ id: Date.now(), title, status: 'todo', tag: 'User' });
        renderBoard();
      }
    }

    function deleteTask(id) {
      tasks = tasks.filter(t => t.id !== id);
      renderBoard();
    }

    function moveTask(id, dir) {
      const flow = ['todo', 'in-progress', 'done'];
      const task = tasks.find(t => t.id === id);
      if (task) {
        const currIndex = flow.indexOf(task.status);
        if (dir === 'next' && currIndex < flow.length - 1) {
          task.status = flow[currIndex + 1];
        } else if (dir === 'prev' && currIndex > 0) {
          task.status = flow[currIndex - 1];
        }
        renderBoard();
      }
    }

    renderBoard();
  </script>
</body>
</html>`
      }
    }
  }
];
