import React, { useState, useEffect, useRef } from 'react';
import { Play, ArrowLeft, RefreshCw, Monitor, Tablet, Smartphone, Maximize2, Terminal, X, AlertCircle } from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { generateRunnableSrcDoc } from '../utils/appRunner';

interface AppRunnerModalProps {
  lang: Language;
  app: AppMetadata;
  onClose: () => void;
  onInspect: () => void;
}

export const AppRunnerModal: React.FC<AppRunnerModalProps> = ({
  lang,
  app,
  onClose,
  onInspect,
}) => {
  const isAr = lang === 'ar';
  const [deviceViewport, setDeviceViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [showConsole, setShowConsole] = useState(false);
  const [logs, setLogs] = useState<{ type: string; message: string; timestamp: string }[]>([]);
  const [iframeKey, setIframeKey] = useState(1);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const srcDoc = generateRunnableSrcDoc(app);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'APP_CONSOLE_LOG') {
        setLogs((prev) => [
          ...prev,
          {
            type: event.data.logType || 'log',
            message: event.data.message || '',
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleRefresh = () => {
    setLogs([]);
    setIframeKey((prev) => prev + 1);
  };

  const getViewportWidth = () => {
    switch (deviceViewport) {
      case 'mobile': return 'w-[375px] h-[667px]';
      case 'tablet': return 'w-[768px] h-[900px]';
      default: return 'w-full h-full';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col">
      {/* Top Sandbox Navigation Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2 overflow-x-auto">
        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={onClose}
            className="p-2 bg-slate-800 hover:bg-slate-700 active:bg-slate-700 text-slate-300 rounded-xl transition flex items-center gap-1.5 text-xs font-semibold min-h-[40px]"
          >
            <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
            <span className="hidden sm:inline">{isAr ? 'الرجوع للمعرض' : 'Back to Catalog'}</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
            <h2 className="font-bold text-xs sm:text-sm text-white truncate max-w-[120px] sm:max-w-xs">{app.name}</h2>
          </div>
        </div>

        {/* Viewport & Controls */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {/* Device switcher */}
          <div className="hidden sm:flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700">
            <button
              onClick={() => setDeviceViewport('desktop')}
              className={`p-1.5 rounded-lg transition min-h-[32px] min-w-[32px] flex items-center justify-center ${
                deviceViewport === 'desktop' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Desktop View"
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setDeviceViewport('tablet')}
              className={`p-1.5 rounded-lg transition min-h-[32px] min-w-[32px] flex items-center justify-center ${
                deviceViewport === 'tablet' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Tablet View"
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              onClick={() => setDeviceViewport('mobile')}
              className={`p-1.5 rounded-lg transition min-h-[32px] min-w-[32px] flex items-center justify-center ${
                deviceViewport === 'mobile' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Mobile View"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          {/* Reload button */}
          <button
            onClick={handleRefresh}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition min-h-[40px] min-w-[40px] flex items-center justify-center"
            title={isAr ? 'إعادة تحميل' : 'Reload Sandbox'}
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* Console toggle button */}
          <button
            onClick={() => setShowConsole(!showConsole)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition min-h-[40px] ${
              showConsole ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span className="hidden sm:inline">Console</span>
            {logs.length > 0 && (
              <span className="bg-slate-950 text-indigo-300 px-1.5 py-0.5 rounded-full text-[10px] font-mono">
                {logs.length}
              </span>
            )}
          </button>

          {/* Inspect code button */}
          <button
            onClick={onInspect}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-3 py-2 rounded-xl text-xs transition border border-slate-700 min-h-[40px]"
          >
            {isAr ? 'الكود' : 'Code'}
          </button>
        </div>
      </div>

      {/* Main Sandbox Stage */}
      <div className="flex-1 overflow-hidden flex items-center justify-center p-2 sm:p-4 bg-slate-950 relative">
        <div
          className={`${getViewportWidth()} max-w-full max-h-full bg-white rounded-xl sm:rounded-2xl shadow-2xl overflow-hidden border border-slate-700 transition-all duration-300 flex flex-col`}
        >
          <iframe
            key={iframeKey}
            ref={iframeRef}
            srcDoc={srcDoc}
            title={app.name}
            className="w-full h-full border-none"
            sandbox="allow-scripts allow-modals allow-same-origin allow-forms"
          />
        </div>
      </div>

      {/* Console Drawer */}
      {showConsole && (
        <div className="h-48 bg-slate-950 border-t border-slate-800 flex flex-col font-mono text-xs">
          <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
            <span className="text-slate-400 font-bold flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              {isAr ? 'سجل تشغيل المخرجات (Console Logs)' : 'Console Output Logs'}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLogs([])}
                className="text-[10px] bg-slate-800 text-slate-400 hover:text-white px-2 py-1 rounded"
              >
                {isAr ? 'مسح السجل' : 'Clear'}
              </button>
              <button onClick={() => setShowConsole(false)} className="text-slate-500 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 p-3 overflow-y-auto space-y-1">
            {logs.length === 0 ? (
              <p className="text-slate-600 italic">{isAr ? 'لا توجد مخرجات بعد...' : 'No console output recorded yet...'}</p>
            ) : (
              logs.map((log, idx) => (
                <div key={idx} className="flex items-start gap-2 text-slate-300">
                  <span className="text-slate-600 text-[10px]">{log.timestamp}</span>
                  <span
                    className={`font-semibold ${
                      log.type === 'error' ? 'text-rose-400' : log.type === 'warn' ? 'text-amber-400' : 'text-sky-400'
                    }`}
                  >
                    [{log.type.toUpperCase()}]
                  </span>
                  <span className="break-all">{log.message}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
