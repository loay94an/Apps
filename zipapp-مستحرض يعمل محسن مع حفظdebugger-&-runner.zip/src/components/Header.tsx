import React from 'react';
import { Sparkles, FolderArchive, Layers, Globe, CheckCircle2 } from 'lucide-react';
import { Language, ViewMode } from '../types';

interface HeaderProps {
  lang: Language;
  setLang: (lang: Language) => void;
  activeView: ViewMode;
  setActiveView: (view: ViewMode) => void;
  appsCount: number;
  fixedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  setLang,
  activeView,
  setActiveView,
  appsCount,
  fixedCount,
}) => {
  const isAr = lang === 'ar';

  return (
    <>
      {/* Top Header */}
      <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-lg backdrop-blur-md bg-opacity-95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Brand & Logo */}
          <div
            className="flex items-center space-x-2.5 rtl:space-x-reverse cursor-pointer select-none"
            onClick={() => setActiveView('catalog')}
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-md shadow-indigo-500/20 flex-shrink-0">
              <FolderArchive className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-bold text-base sm:text-lg tracking-tight bg-gradient-to-r from-white via-slate-200 to-sky-400 bg-clip-text text-transparent truncate max-w-[180px] sm:max-w-none">
                  {isAr ? 'مستعرض التطبيقات' : 'App Browser Pro'}
                </h1>
                <span className="text-[9px] sm:text-[10px] bg-indigo-500/20 text-indigo-300 font-mono border border-indigo-500/30 px-1.5 py-0.5 rounded-full flex-shrink-0">
                  ZIP
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden md:block">
                {isAr ? 'رفع، تحليل، تصحيح الأخطاء، إعادة تنظيم وتشغيل' : 'Upload, analyze, auto-fix & run ZIP apps'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden sm:flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
            <button
              onClick={() => setActiveView('catalog')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 min-h-[36px] ${
                activeView === 'catalog'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{isAr ? 'معرض التطبيقات' : 'App Catalog'}</span>
              <span className="ml-1 bg-slate-900/60 px-1.5 py-0.5 rounded text-[10px] text-slate-300 font-mono">
                {appsCount}
              </span>
            </button>

            <button
              onClick={() => setActiveView('uploader')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 min-h-[36px] ${
                activeView === 'uploader'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              <span>{isAr ? 'رفع ملف تطبيق' : 'Upload File'}</span>
            </button>
          </nav>

          {/* Right Tools: Language Toggle & Stats */}
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <div className="hidden lg:flex items-center gap-2 bg-slate-950/60 border border-slate-800 px-2.5 py-1 rounded-lg text-xs text-slate-400">
              <div className="flex items-center gap-1 text-emerald-400 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{fixedCount} {isAr ? 'جاهز' : 'Ready'}</span>
              </div>
            </div>

            <button
              onClick={() => setLang(isAr ? 'en' : 'ar')}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition active:scale-95 min-h-[36px]"
              title={isAr ? 'تغيير اللغة' : 'Change Language'}
            >
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span>{isAr ? 'EN' : 'العربية'}</span>
            </button>
          </div>

        </div>
      </header>

      {/* Fixed Bottom Navigation Bar for Mobile Phones */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 border-t border-slate-800 backdrop-blur-lg px-6 py-2 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => setActiveView('catalog')}
          className={`flex flex-col items-center justify-center gap-1 py-1 px-4 rounded-xl transition ${
            activeView === 'catalog' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px]">{isAr ? 'المعرض' : 'Catalog'}</span>
        </button>

        <button
          onClick={() => setActiveView('uploader')}
          className={`flex flex-col items-center justify-center gap-1 py-1 px-4 rounded-xl transition ${
            activeView === 'uploader' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <Sparkles className="w-5 h-5 text-sky-400" />
          <span className="text-[10px]">{isAr ? 'رفع ملف' : 'Upload'}</span>
        </button>
      </div>
    </>
  );
};

