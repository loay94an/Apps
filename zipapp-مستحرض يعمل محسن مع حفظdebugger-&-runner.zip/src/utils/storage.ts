import { AppMetadata } from '../types';

const DB_NAME = 'AppBrowserDB';
const STORE_NAME = 'apps';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function loadSavedApps(defaultApps: AppMetadata[]): Promise<AppMetadata[]> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();

    return new Promise((resolve) => {
      request.onsuccess = () => {
        const result = request.result as AppMetadata[];
        if (result && result.length > 0) {
          resolve(result);
        } else {
          // Check localStorage as fallback
          try {
            const savedLS = localStorage.getItem('app_browser_saved_apps_v1');
            if (savedLS) {
              const parsed = JSON.parse(savedLS);
              if (Array.isArray(parsed) && parsed.length > 0) {
                saveAllApps(parsed).catch(() => {});
                resolve(parsed);
                return;
              }
            }
          } catch (e) {}
          resolve(defaultApps);
        }
      };
      request.onerror = () => {
        resolve(defaultApps);
      };
    });
  } catch (e) {
    try {
      const savedLS = localStorage.getItem('app_browser_saved_apps_v1');
      if (savedLS) {
        const parsed = JSON.parse(savedLS);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (lsErr) {}
    return defaultApps;
  }
}

export async function saveAllApps(apps: AppMetadata[]): Promise<void> {
  // Primary persistence: IndexedDB (Supports large zip files and multiple apps)
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.clear();
    for (const app of apps) {
      store.put(app);
    }
  } catch (e) {
    console.warn('IndexedDB save error:', e);
  }

  // Backup persistence: localStorage (Safely handled with QuotaExceeded fallback)
  try {
    localStorage.setItem('app_browser_saved_apps_v1', JSON.stringify(apps));
  } catch (e) {
    // QuotaExceededError fallback - store trimmed version or omit from localStorage without throwing error
    try {
      const lightApps = apps.map((app) => ({
        ...app,
        files: Object.fromEntries(
          Object.entries(app.files).map(([path, file]) => [
            path,
            file.isBinary || file.content.length > 50000
              ? { ...file, content: file.content.slice(0, 100) + '...[truncated for storage]' }
              : file,
          ])
        ),
      }));
      localStorage.setItem('app_browser_saved_apps_v1', JSON.stringify(lightApps));
    } catch (fallbackErr) {
      // Gracefully silent: IndexedDB handles full data storage
    }
  }
}
