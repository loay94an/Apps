export interface AppFile {
  path: string;
  name: string;
  content: string;
  isBinary?: boolean;
  size?: number;
  language?: string;
}

export interface DiagnosticIssue {
  id: string;
  type: 'error' | 'warning' | 'info';
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  file?: string;
  line?: number;
  autoFixable: boolean;
  suggestedFix?: string;
}

export interface AppMetadata {
  id: string;
  name: string;
  version: string;
  description: string;
  category: string;
  icon?: string;
  uploadedAt: string;
  entryPoint: string; // e.g. 'index.html' or 'src/App.tsx'
  framework: 'vanilla-html' | 'react' | 'vue' | 'node-express' | 'unknown';
  files: Record<string, AppFile>;
  diagnostics: DiagnosticIssue[];
  status: 'raw' | 'analyzed' | 'errors_found' | 'reorganized' | 'ready';
  readmeContent?: string;
}

export type ViewMode = 'catalog' | 'inspector' | 'runner' | 'uploader';
export type Language = 'ar' | 'en';
