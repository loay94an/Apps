import React, { useState, useRef } from 'react';
import { Upload, FileArchive, CheckCircle2, AlertCircle, RefreshCw, Play, FolderTree, FileCode, ArrowLeft } from 'lucide-react';
import { AppMetadata, Language } from '../types';
import { parseZipFile, autoFixAndReorganizeApp } from '../utils/zipParser';

interface ZipUploaderProps {
  lang: Language;
  onAppUploaded: (app: AppMetadata) => void;
  onInspectApp: (app: AppMetadata) => void;
  onRunApp: (app: AppMetadata) => void;
}

export const ZipUploader: React.FC<ZipUploaderProps> = ({
  lang,
  onAppUploaded,
  onInspectApp,
  onRunApp,
}) => {
  const isAr = lang === 'ar';
  const [isDragging, setIsDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analyzedApp, setAnalyzedApp] = useState<AppMetadata | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.zip')) {
      setError(isAr ? 'يرجى اختيار ملف بصيغة ZIP مضغوط فقط.' : 'Please select a valid .ZIP file archive.');
      return;
    }

    setError(null);
    setLoading(true);
    setAnalyzedApp(null);

    try {
      const rawMeta = await parseZipFile(file);
      // Automatically apply auto-fix and file reorganization on upload
      const fixedMeta = autoFixAndReorganizeApp(rawMeta);
      setAnalyzedApp(fixedMeta);
      onAppUploaded(fixedMeta);
    } catch (err: any) {
      setError(
        isAr
          ? `فشل في تحليل ملف ZIP: ${err.message || 'الملف تالف أو غير مدعوم'}`
          : `Failed to analyze ZIP file: ${err.message || 'Invalid or corrupted zip archive'}`
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-4 sm:py-8 px-3 sm:px-4">
      <div className="text-center mb-6 sm:mb-8">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {isAr ? 'رفع وتحليل تطبيق من ملف ZIP' : 'Upload & Analyze App ZIP Archive'}
        </h2>
        <p className="text-slate-400 mt-2 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed">
          {isAr
            ? 'قم بسحب وإسقاط ملف ZIP للتطبيق. سيقوم النظام بتحليله فوراً وتكتشف الأخطاء وإعادة تنظيمه وتشغيله.'
            : 'Drag and drop your project ZIP file. The browser will instantly extract, analyze diagnostics, auto-fix structure, and launch the application.'}
        </p>
      </div>

      {/* Upload Box */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-10 text-center cursor-pointer transition-all duration-300 ${
          isDragging
            ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
            : 'border-slate-700 bg-slate-900/80 hover:border-slate-500 hover:bg-slate-800/50'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".zip"
          className="hidden"
          onChange={(e) => {
            if (e.target.files && e.target.files[0]) {
              const file = e.target.files[0];
              e.target.value = '';
              handleFile(file);
            }
          }}
        />

        <div className="w-14 h-14 sm:w-16 sm:h-16 mx-auto rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/10">
          {loading ? (
            <RefreshCw className="w-7 h-7 sm:w-8 sm:h-8 animate-spin text-indigo-400" />
          ) : (
            <Upload className="w-7 h-7 sm:w-8 sm:h-8 text-indigo-400" />
          )}
        </div>

        {loading ? (
          <div>
            <h3 className="text-base sm:text-lg font-semibold text-white">
              {isAr ? 'جاري استخراج الملفات وتحليل البرمجيات...' : 'Extracting & Analyzing Project Files...'}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              {isAr ? 'يتم فحص شجرة الملفات، التبعيات، وسجلات الأخطاء' : 'Checking directory structure, dependencies, and syntax diagnostics'}
            </p>
          </div>
        ) : (
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-100">
              {isAr ? 'اسقط ملف ZIP هنا أو انقر للاستعراض' : 'Drop your app ZIP file here or click to browse'}
            </h3>
            <p className="text-xs text-slate-400 mt-2">
              {isAr ? 'يدعم مشاريع HTML, React, JS, Tailwind, Node' : 'Supports HTML5, React, JS, Tailwind, Node projects'}
            </p>
          </div>
        )}
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-4 sm:mt-6 p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-3 text-rose-300 text-xs sm:text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Analysis Result Summary Card */}
      {analyzedApp && (
        <div className="mt-6 sm:mt-8 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-4 mb-4 sm:mb-6 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <FileArchive className="w-5 h-5 text-indigo-400 flex-shrink-0" />
                <h3 className="text-lg sm:text-xl font-bold text-white truncate">{analyzedApp.name}</h3>
                <span className="text-[10px] sm:text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full font-mono flex-shrink-0">
                  {analyzedApp.framework}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {Object.keys(analyzedApp.files).length} {isAr ? 'ملف مستخرج' : 'files extracted'} • {isAr ? 'النقطة الرئيسية:' : 'Entry Point:'} <code className="text-sky-300 font-mono">{analyzedApp.entryPoint}</code>
              </p>
            </div>

            <div className="flex items-center gap-2">
              {analyzedApp.diagnostics.length === 0 ? (
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs px-3 py-1 rounded-full flex items-center gap-1.5 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {isAr ? 'سليم وجاهز للتشغيل' : 'Healthy & Ready'}
                </span>
              ) : (
                <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs px-3 py-1 rounded-full flex items-center gap-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {analyzedApp.diagnostics.length} {isAr ? 'ملاحظة/أخطاء رصدت' : 'Issues Detected'}
                </span>
              )}
            </div>
          </div>

          {/* Diagnostics preview */}
          {analyzedApp.diagnostics.length > 0 && (
            <div className="mb-6 bg-slate-950/80 border border-amber-500/20 rounded-xl p-3 sm:p-4">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4" />
                {isAr ? 'تقرير الفحص السريع والأخطاء' : 'Diagnostic Findings'}
              </h4>
              <ul className="space-y-2 text-xs">
                {analyzedApp.diagnostics.map((diag) => (
                  <li key={diag.id} className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-200">{isAr ? diag.titleAr : diag.title}</p>
                      <p className="text-slate-400 mt-0.5">{isAr ? diag.descriptionAr : diag.description}</p>
                    </div>
                    {diag.autoFixable && (
                      <span className="bg-indigo-500/20 text-indigo-300 text-[10px] px-2 py-0.5 rounded border border-indigo-500/30 flex-shrink-0">
                        {isAr ? 'قابل للتصحيح التلقائي' : 'Auto-Fixable'}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => onRunApp(analyzedApp)}
              className="w-full sm:flex-1 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition shadow-lg shadow-emerald-600/20 min-h-[44px]"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{isAr ? 'تشغيل التطبيق الآن' : 'Run App Sandbox'}</span>
            </button>

            <button
              onClick={() => onInspectApp(analyzedApp)}
              className="w-full sm:flex-1 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition shadow-lg shadow-indigo-600/20 min-h-[44px]"
            >
              <FolderTree className="w-4 h-4" />
              <span>{isAr ? 'مستعرض ملفات التطبيق' : 'App File Browser'}</span>
            </button>
            <button
              onClick={() => {
                setAnalyzedApp(null);
                setError(null);
                fileInputRef.current?.click();
              }}
              className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition min-h-[44px]"
            >
              <Upload className="w-4 h-4 text-indigo-400" />
              <span>{isAr ? 'رفع ملف ZIP آخر' : 'Upload Another ZIP'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
